    jmp label1
    nop
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
label1:
    xchg bx, [0xe129]
    db 0x8B, 0xF0 ;$1 mov si, ax
    db 0x8B, 0xC3 ;$1 mov ax, bx
    div word [bx+0x29]
    add dx, 0x0ff6
    mov cl, 0x0d
    db 0x8B, 0xEA ;$1 mov bp, dx
    rcr bp, cl
    add bp, 0x0211
    les ax, [bx+0x2b]
    mov [bp+0x02], dx
    mov dx, 0xd7e0
    lea di, [si-0x0100]
    int 0x86
    add di, 0x0200
    add bx, 0x002f
    int 0x86
    lea di, [bx+0x00d3]
    mov [di+0x14], di
    mov [di+0x1b], di
    db 0x33, 0xFF ;$1 xor di, di
    push ss
    add si, 0x00de
    pop es
    rep movsw
    lea ax, [si+0x5108]
    mov al, 0xa2
    mov [si-0x55], bl
    xchg ax, [bp+0x00]
    mov [si-0x5b], bh
    push bp
    mov cl, 0x04
    lea bx, [si]
    db 0x33, 0xF6 ;$1 xor si, si
    mov [0x8701], bp
    db 0x8B, 0xEF ;$1 mov bp, di
    mov [0x8801], bx
label2:
    mov [0x4501], al
    mov [0x4701], al
    mov [0x4401], al
    mov [0x4101], al
    mov [0x4201], al
    mov [0x4301], al
    xchg sp, [di-0x7f1a]
    xchg dx, [di-0x7d1a]
    xchg si, [di-0x7b1a]
    xchg ax, [di-0x791a]
loop1:
    nop
    xlatb
    xchg ah, al
    xlatb
    db 0x32, 0xE0 ;$1 xor ah, al
    xchg di, ax
    mov word [di+0x6e], 0xffcc
    mov word [di+0x6c], 0xccb9
    add byte [bx-0x66], 0x02
    loop loop1
    mov byte [bx-0x66], 0x90
    inc bp
    mov cl, 0x04
    db 0x8B, 0xFD ;$1 mov di, bp
    mov sp, 0x07fe
    jp label2
    pop bx
    push ss
    mov cl, 0x08
    pop ds
    push cs
    db 0x33, 0xF6 ;$1 xor si, si
    pop ss
    mov ax, 0xcccc
    push cs
    mov dx, 0x29cc
    pop es
    int 0x87
    les di, [bx+si]
    db 0x8B, 0xC3 ;$1 mov ax, bx
    dec di
    lea sp, [bx+di]
    mov bp, 0x0002
    mov dx, 0x5200
    movsw
    movsw
    db 0x2B, 0xFD ;$1 sub di, bp
    call far [bx]
    db 0x66
    call far [bx]
    db 0x68
    movsb
    movsw
    rep movsw
    mov cl, 0x08
    add di, [si]
    lea sp, [bx+di]
    db 0x33, 0xF6 ;$1 xor si, si
    add [bx+si], dx
    movsw
    movsw
loop2:
    db 0x2B, 0xFD ;$1 sub di, bp
    call far [bx]
    jmp 0x882e:0x0051
    cmpsb
    sub ax, [di]
    mov [0x938d], ax
    mov bp, 0x351b
    mov ax, 0x3096
    push ds
loop3:
    dec si
    db 0x60
label3:
    db 0xC6, 0xE8, 0x65 ;$6 mov al, 0x65
    dec bx
    in ax, dx
    ret
    esc 0xdd
    db 0xF3, 0x55
    jnp label3+1
    esc 0xd8
    jle label5+2
    cli
    aam 0x72
    pop sp
    sar di, 1
    pop cx
    ja label8+1
    inc di
    loopz loop2+1
    inc dx
    db 0x6C
    retf 0xb4e4
    call 0xb19f:0x123c
    pop ss
    cmp [bx], sp
    or [bx+0x0c81], bp
    and al, [si+0x6aaa]
    inc sp
    loop loop3
    inc cx
    db 0x6F
    db 0xC9
    out 0xf9, ax
    xlatb
    jno label9+2
    sar ah, cl
    pop dx
    jz label6
    or ch, [si+0x0f82]
    and [bx-0x4857], ax
    cwd
    aas
    adc [si+0x14b2], bx
    cmp dl, [bx+si+0x18be]
    ss:
    mov bx, 0x3395
    sbb ax, 0x2d03
label4:
    mov sp, [di+0x0628]
label5:
    mov al, [0xde8e]
    lock
    push si
    js label4
label6:
    esc 0xdb
    jge label11
    dec bp
    db 0x63
    db 0xC5, 0xEB
    db 0x66
    dec ax
    out dx, al
    db 0xC0
label7:
    sub byte [bp+0x2608], 0xab
    test [bp+di], sp
    or ax, 0x3d13
    db 0x9B, 0xB5  ; wait
    cmp [0x9eb0], dl
    into
label8:
    loopnz loop4
    db 0x68
    in ax, 0xcb
    db 0x6D
    inc bx
    pop bp
    jnb label5+2
    sti
    jbe label12
    db 0xFE, 0xD0
    jp label12
    db 0xF2, 0xDC
    push cx
    jg label7
    imul cx
label9:
    db 0xC7, 0x61, 0x4F, 0xC2, 0xEC ;$4 mov word [bx+di+0x4f], 0xecc2
    dec dx
    db 0x64
    xor al, 0x1a
    mov sp, 0x1f92
    xor [bx-0x5847], dx
    mov [bx], bp
    add [si+0x04a2], cx
    db 0x2A, 0xEA ;$1 sub ch, dl
    les sp, [bp+si+0x4c]
    db 0xC1
    out dx, ax
    dec cx
    db 0x67
label10:
    jns 537
    db 0xF1
label11:
    esc 0xdf
    push dx
    jl label9
    hlt
    movsb
    mov ch, [si]
    add cl, [bx+0x07a1]
    sub [bx], si
loop4:
    sbb [bx+0x1c91], di
    xor dl, [si+0x10ba]
    ds:
    cbw
    mov dh, 0x3b
    adc ax, 0x9db3
    sub word [di+0x250b], 0xffa8
    xchg ah, [bx+si]
    push cs
    pop si
    jo label10+1
    clc
    jnz 585
label12:
    std
    ror bp, cl
    jcxz 568
    db 0x6B
    out 0xc8, al
    db 0x6E
    inc ax
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb