    mov [0xe129], ax
    jmp label2
    nop
    xlatb
    xchg ah, al
    xlatb
    nop
    xlatb
    xchg ah, al
    xlatb
    nop
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    db 0x0F
    add bh, dl
    xchg al, [bx+si]
    adc [bp+di-0x1dc2], cl
    clc
    int 0x86
    mov di, [0x8346]
    int 0x86
    mov ax, 0x86d7
    xchg cx, si
    std
    mov dx, 0xd7c4
    int 0x87
    cld
    lea ax, [si-0x2b]
    db 0x33, 0xD2 ;$1 xor dx, dx
    div word [si-0x06]
    add dx, 0x0ff6
    add si, 0x0191
label1:
    xchg ch, [si]
    cmp ch, 0x01
    jnz label1
    xchg ch, [si]
    inc si
    db 0x8B, 0xEA ;$1 mov bp, dx
    mov cl, 0x0d
    push ss
    clc
    rcr bp, cl
    pop es
    db 0x33, 0xFF ;$1 xor di, di
    rep movsw
    movsw
    lea bx, [bp+0x0211]
    add byte [si-0x0162], 0x04
    lea ax, [si-0x3bc0]
    push ss
    mov al, 0xa2
    pop ds
    mov [bx], ax
    push cs
    mov [bx+0x02], dx
    pop es
    push cs
    db 0x8B, 0xC3 ;$1 mov ax, bx
    pop ss
    mov dx, 0xc600
    mov cl, 0x09
    db 0x33, 0xF6 ;$1 xor si, si
    les di, [bx+si]
    mov bp, 0x8080
    dec di
    lea sp, [bx+di]
    mov word [bx+0x1a], 0xc810
    movsw
    movsw
    mov byte [bx+si], 0x02
    sub di, [bx+si]
    call far [bx]
label2:
    add ax, 0x018a
    mov bx, ss
    or bx, 0x0010
    add bx, 0x0014
    xchg si, ax
    push bx
    mov di, 0x0084
    push si
    lea dx, [si-0x41c0]
    mov es, bx
    mov cl, 0x1b
    mov dl, 0xfa
    rep movsw
    mov cl, 0x04
    db 0x8B, 0xEF ;$1 mov bp, di
    lea bx, [si-0x0191]
    mov [si-0x00b3], bh
    mov [si-0x00ad], bl
    db 0x33, 0xF6 ;$1 xor si, si
    add dx, [0x8701]
    push dx
    xchg bx, [0x8801]
label3:
    mov [0xc501], al
    mov [0xc701], al
    mov [0xc401], al
    mov [0xc101], al
    mov [0xc201], al
    mov [0xc301], al
    xchg sp, [di-0x7eba]
    xchg dx, [di-0x7cba]
    xchg si, [di-0x7aba]
    xchg ax, [di-0x78ba]
loop1:
    nop
    xlatb
    xchg ah, al
    xlatb
    db 0x32, 0xE0 ;$1 xor ah, al
    xchg di, ax
    mov word [di+0x6e], 0xffcc
    mov word [di+0x6c], 0xccb9
    add byte [0xcccc], 0x02
    loop loop1
    mov byte [0xcccc], 0x90
    inc bp
    mov cl, 0x04
    db 0x8B, 0xFD ;$1 mov di, bp
    mov sp, 0x07fa
    jp label3
    pop bx
    mov cl, 0x10
    pop si
    mov di, 0x0064
    push cs
    add si, 0xffe0
    rep movsw
    pop es
    mov di, [0x0000]
    pop ds
    int 0x86
    db 0x33, 0xFF ;$1 xor di, di
    int 0x86
    add bx, 0x0025
    mov si, 0x0088
    mov [si+0x32], ds
    push cs
    mov cl, 0x14
    mov ax, 0xcccc
    pop ss
    mov dx, 0x29cc
    lea sp, [bx+0x66]
    int 0x87
    mov ax, 0xa593
    lea dx, [bx-0x25]
    lea di, [bx-0x01]
    db 0x8B, 0xEF ;$1 mov bp, di
    movsw
    jmp bp
    cwd
    movsw
    movsw
    mov cx, 0x000d
    movsw
    rep movsw
    lea sp, [bx+0x61]
    mov cx, 0x0504
    db 0x8B, 0xDF ;$1 mov bx, di
label4:
    pop di
    pop bp
    shl bp, cl
    mov [bp+di-0x02], ax
    add sp, 0xfffd
    dec ch
    jnz label4
    mov di, bx
    rep movsw
    mov cl, 0x12
    rep movsw
    add di, 0x003b
    movsw
    sub di, 0x0066
    db 0x8B, 0xDF ;$1 mov bx, di
    movsw
    mov cx, [si+0x04]
    lds si, [si]
    add dh, 0xc0
label5:
    pop di
    pop bp
    add sp, [bx]
    shl bp, cl
    mov [bp+di-0x02], ax
    mov bp, [bx]
    cmp [bx+si], bp
    jz label5
    mov ds, cx
    db 0x8B, 0xFA ;$1 mov di, dx
    movsw
    jmp dx
    in ax, dx
    add ch, ch
    add [si+byte 0x00], ah
    add [bx+si], dl
    add [bp-0x01], sp
    pop ds
    db 0x68
    movsb
    movsw
    rep movsw
    mov cl, 0x09
    add di, [si]
    add sp, [bx+si]
    db 0x33, 0xF6 ;$1 xor si, si
    add [bx+si], dx
    movsw
    movsw
    sub di, [bx+si]
    dec bp
label6:
    js label6+1
    pop ds
    call -9821
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb
    xlatb
    xchg ah, al
    xlatb