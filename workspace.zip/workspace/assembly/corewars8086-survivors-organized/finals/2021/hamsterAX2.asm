    jmp label2
    add ax, 0x00ca
    mov si, ax
    push ss
    pop es
    mov cl, 0x36
    rep movsw
    push ss
    push cs
    pop es
    pop ds
    mov dx, ss
    push cs
    pop ss
    add ah, 0x08
    mov al, 0xa3
    mov bx, 0x0123
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov al, 0x0f
    mov si, 0x000e
    jmp label3
    rep movsw
    les di, [bx]
    lea sp, [di+0x0200]
    mov cl, 0x08
    movsw
    dec di
    call far [bx]
    call far [bx]
    rep movsw
    sub di, 0x1214
    mov bp, di
    mov cl, 0x0a
    rep movsw
    lds cx, [0x0068]
    call bp
    pop ss
    rep movsw
    mov si, 0x0036
    add di, 0x0802
    mov ds, dx
    mov cl, 0x18
    mov bp, di
    movsw
    jmp bp
    int3
    rep movsw
    lds cx, [si]
    lea si, [bp-0x0a00]
    lea di, [bp+0x0800]
    rep cmpsw
    scasb
    db 0x0F
    test [bp-0x5200], ah
    db 0x0F
    test [bx+di-0x7700], ah
    imul word [bp-0x7bf1]
    call 0x850f:0xae00
    pushf
label1:
    add ah, al
    jge label1
    sub di, 0x0002
    stosw
    mov ds, dx
    mov cl, 0x06
    sub word [bx], 0x3200
    xor si, si
    les di, [bx]
    movsw
    jmp word [bx]
    inc word [bx+si]
    add [bx+si], dl
label2:
    add ax, 0x00ca
    mov si, ax
    push ss
    pop es
    mov cl, 0x36
    rep movsw
    push ss
    push cs
    pop es
    pop ds
    mov dx, ss
    push cs
    pop ss
    add ah, 0x08
    mov al, 0xa3
    mov bx, 0x0123
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov al, 0x0f
    mov si, 0x000e
    jmp label3
    rep movsw
label3:
    les di, [bx]
    lea sp, [di+0x0200]
    mov cl, 0x08
    movsw
    dec di
    call far [bx]
    call far [bx]
    rep movsw
    sub di, 0x1214
    mov bp, di
    mov cl, 0x0a
    rep movsw
    lds cx, [0x0068]
    call bp
    pop si
    rep movsw
    mov si, 0x0036
    add di, 0x0802
    mov ds, dx
    mov cl, 0x18
    mov bp, di
    movsw
    jmp bp
    int3
    rep movsw
    lds cx, [si]
    lea si, [bp-0x0a00]
    lea di, [bp+0x0800]
    rep cmpsw
    scasb
    jz label4
    scasb
    jz label4
    mov di, si
    scasb
    jz label4
    scasb
    jnz label5
label4:
    les di, [di-0x04]
    sub di, 0x0002
    stosw
label5:
    mov ds, dx
    mov cl, 0x06
    sub word [bx], 0x3200
    xor si, si
    les di, [bx]
    movsw
    jmp word [bx]
    inc word [bx+si]
    add [bx+si], dl