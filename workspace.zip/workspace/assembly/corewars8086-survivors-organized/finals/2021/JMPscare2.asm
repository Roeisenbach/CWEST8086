    mov cx, 0x0704
    mov word [0xfdef], 0x1cff
    mov word [0xfded], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edf
    mov word [di], 0x1dfd
    mov word [di+0x02], 0x1dff
    call far [di]