    jmp label1
    nop
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
label1:
    mov dx, es
    push cs
    pop es
    mov cx, 0x0028
loop1:
    db 0x9B, 0x9B ;$1 nrg
    loop loop1
    push ax
    push dx
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov cx, 0x00cc
    db 0x8B, 0xD9 ;$1 mov bx, cx
    int 0x87
    pop dx
    pop ax
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0048
    db 0x8B, 0xF7 ;$1 mov si, di
    add si, 0x002a
    add ax, 0x004b
    push dx
    pop ds
    mov bx, 0x0058
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    add ax, 0x0202
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub ax, 0x01d7
    std
    nop
    mov ds, dx
    db 0x3B, 0xC4 ;$1 cmp ax, sp
    jg label2
    call far [bx]
label2:
    sub word [bx], 0x1500
    sub ax, 0x1500
    db 0x8B, 0xE0 ;$1 mov sp, ax
    add sp, 0x01d2
    mov cx, cs
    mov ds, cx
    sub di, 0x14d6
    mov cx, 0x0016
    rep movsw
    add di, 0x0002
    sub si, 0x14d4
    jmp di
    nop