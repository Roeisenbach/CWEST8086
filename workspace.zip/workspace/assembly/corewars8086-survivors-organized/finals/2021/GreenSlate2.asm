    jmp label1
    rep movsw
    sub di, 0x2713
    sub di, ax
    mov cl, 0x09
    dec bp
    jmp word [bx]
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x1915
    sub di, ax
    mov cl, 0x08
    inc bp
    nop
    sub sp, bp
    call far [bx+si]
    rep movsw
    sub di, 0x4013
    sub di, ax
    mov cl, 0x08
    rep movsw
    sub di, 0x4013
    sub di, ax
    mov cl, 0x0c
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x401b
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    mov bp, 0x0024
    sub sp, 0x2700
    xor si, si
    jmp word [bx+si]
    nop
    sub sp, bp
    call far [bx+si]
label1:
    push es
    push ss
    pop es
    mov cx, 0x0073
    mov si, ax
    add si, 0x00be
    rep movsw
    mov dx, cs
    add dx, 0xffff
    push dx
    pop ds
    push dx
    mov dx, ax
    add dx, 0x00a0
    push dx
    and ax, 0xc000
    add ax, 0x3500
    mov bh, ah
    mov word [bx-0x0e5d], 0x1fff
    mov word [bx-0x0e5f], 0xec29
    retf
    mov al, 0xa1
    sub ax, 0x0f00
    push ds
    push es
    pop ds
    mov bx, 0x0300
    mov [bx+0x02], cs
    mov [bx], ax
    pop es
    push cs
    pop ss
    mov sp, ax
    add sp, 0x4000
    mov di, ax
    inc di
    mov cx, 0x0008
    mov si, 0x002e
    mov ax, 0x0003
    mov bp, 0x00fc
    jmp word [bx]
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x2713
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x09
    dec bp
    jmp word [bx]
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x1915
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    inc bp
    xor si, si
    jmp word [bx+si]
    nop
    sub sp, bp
    call far [bx+si]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x0c
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x401b
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    mov bp, 0x0024
    sub sp, 0x2700
    xor si, si
    jmp word [bx+si]
    nop
    sub sp, bp
    call far [bx+si]
    rep movsw
    sub di, 0x2713
    sub di, ax
    mov cl, 0x09
    dec bp
    jmp word [bx]
    nop
    rep movsw
    sub di, 0x1915
    sub di, ax
    mov cl, 0x08
    inc bp
    xor si, si
    jmp word [bx+si]
    nop
    sub sp, bp
    call far [bx+si]
    rep movsw
    sub di, 0x4013
    mov [bx], di
    movsw
    movsw
    sub di, ax
    mov cl, 0x08
    jmp word [bx]
    nop
    nop
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x4013
    sub di, ax
    mov cl, 0x0c
    sub sp, bp
    call far [bx]
    rep movsw
    sub di, 0x401b
    sub di, ax
    mov cl, 0x08
    mov bp, 0x0024
    sub sp, 0x2700
    nop
    sub sp, bp
    call far [bx+si]