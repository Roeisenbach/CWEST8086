    jmp label1
    push ds
    pop es
    mov dx, 0xcccc
    mov di, ax
    add di, 0x06e5
    push ax
    mov ax, 0xcccc
    sub di, 0x0e00
    pop ax
    db 0x83, 0xC0, 0x74 ;$1 add ax, 0x0074
    push es
    pop ds
    mov bx, ax
    add bx, 0x0100
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x06fc
    sub sp, 0x0010
    call far [bx]
label1:
    mov si, ax
    add si, 0x0074
    mov cx, 0x001e
    rep movsw
    push ds
    pop es
    mov dx, 0xcccc
    mov di, ax
    add di, 0x06e5
    push ax
    mov ax, 0xcccc
    int 0x86
    sub di, 0x0e00
    int 0x86
    pop ax
    db 0x83, 0xC0, 0x74 ;$1 add ax, 0x0074
    push es
    pop ds
    mov bx, ax
    add bx, 0x0104
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0600
    push cs
    pop es
    mov di, ax
    mov dx, 0x2000
    sub sp, 0x0007
    call far [bx]
    mov ds, dx
    rep movsw
    nop
    xor si, si
    sub di, 0x0600
    mov cx, 0x0005
    rep movsw
    sub di, 0x000a
    mov sp, di
    add sp, 0x0600
    push cs
    pop ds
    mov bx, di
    add bx, 0x0104
    mov [bx+0x02], cs
    mov [bx], di
    mov si, 0x000a
    add di, 0x000a
    mov cx, 0x001a
    mov ax, di
    db 0x83, 0xE8, 0x0A ;$1 sub ax, 0x000a
    jmp ax
    nop
    push ds
    pop es
    mov dx, 0xcccc
    mov di, ax
    add di, 0x06e5
    push ax
    mov ax, 0xcccc
    int 0x86
    sub di, 0x0e00
    int 0x86
    pop ax
    db 0x83, 0xC0, 0x74 ;$1 add ax, 0x0074
    push es
    pop ds
    mov bx, ax
    add bx, 0x0100
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x06fc
    sub sp, 0x0010
    call far [bx]