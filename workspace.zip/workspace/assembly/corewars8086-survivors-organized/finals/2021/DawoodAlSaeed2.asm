    jmp label1
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov [bx+0x06], cs
    mov ax, ax
    mov di, [bx]
    call far [bx+0x04]
label1:
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov [bx+0x06], cs
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov di, [bx]
    call far [bx+0x04]
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov [bx+0x06], cs
    mov ax, ax
    mov di, [bx]
    call far [bx+0x04]