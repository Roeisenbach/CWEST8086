    push ax
    xchg si, ax
    les ax, [si+0x00ee]
    mov dx, 0xc681
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    pop ax
    xor bx, bx
    mov si, ax
    mov cx, 0x0029
    loop $
    mov [si+0x00d3], ax
    add ax, 0x00d2
    mov bx, si
    add bx, 0x00f2
    mov ax, 0xcccc
    cmp word [0x8100], 0xcccc
    jnz label1
    nop
label1:
    xchg ax, [0x8100]
    xlatb
    xchg al, ah
    xlatb
    xor ah, al
    mov di, ax
    mov word [di+0x6c], 0x15ff
    xchg ax, [0x8300]
    xlatb
    xchg al, ah
    xlatb
    xor ah, al
    mov di, ax
    mov word [di+0x70], 0x15ff
    xchg ax, [0x8500]
    xlatb
    xchg al, ah
    xlatb
    xor ah, al
    mov di, ax
    mov word [di+0x6c], 0x15ff
    xchg ax, [0x8700]
    xlatb
    xchg al, ah
    xlatb
    xor ah, al
    mov di, ax
    mov word [di+0x72], 0x15ff
    xor di, di
    xor dx, dx
label2:
    push ss
    pop es
    mov cl, 0x0c
    add si, 0x00ba
    rep movsw
    mov ax, [0x9090]
    push cs
    push ss
    pop ds
    pop ss
    sub ax, 0xa60f
    mov al, 0xa1
    mov bl, 0x40
    mov bp, 0x002b
    mov bx, 0x0040
    mov [bx], ax
    mov word [bx+0x02], 0x0fff
    les di, [bx]
    mov cl, 0x09
    mov word [bx+0x16], 0x1ffc
    mov si, 0x0014
    movsw
    movsw
    dec di
    lea sp, [di+0x23ef]
    xor si, si
    mov ax, 0x0400
    call far [bx]
    rep movsw
    sub [bx], ax
    les di, [bx]
    movsw
    add sp, [bx+si]
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label3:
    jnz label3+1
    sbb ah, cl
    sub sp, bp
    call far [bx+si]
    mov si, 0x0000
    mov ax, 0x0008
    dec byte [si+0x00d6]
    xor dx, dx
    mov cx, 0x4bce
    mul cx
    add ax, si
    mov dx, 0x01c2
    xor ch, ch
    xor bx, bx
loop1:
    jmp label2
    mov cl, 0x09
    add [bx+si], dl
    add [0xa688], ch
    sub ax, [di]
    mov [0x938d], ax
    mov bp, 0x351b
    mov ax, 0x3096
    push ds
loop2:
    dec si
    db 0x60
label4:
    db 0xC6, 0xE8, 0x65 ;$6 mov al, 0x65
    dec bx
    in ax, dx
    ret
    esc 0xdd
    db 0xF3, 0x55
    jnp label4+1
    esc 0xd8
    jle label6+2
    cli
    aam 0x72
    pop sp
    sar di, 1
    pop cx
    ja label9+1
    inc di
    loopz loop1+1
    inc dx
    db 0x6C
    retf 0xb4e4
    call 0xb19f:0x123c
    pop ss
    cmp [bx], sp
    or [bx+0x0c81], bp
    and al, [si+0x6aaa]
    inc sp
    loop loop2
    inc cx
    db 0x6F
    db 0xC9
    out 0xf9, ax
    xlatb
    jno label10+2
    sar ah, cl
    pop dx
    jz label7
    or ch, [si+0x0f82]
    and [bx-0x4857], ax
    cwd
    aas
    adc [si+0x14b2], bx
    cmp dl, [bx+si+0x18be]
    ss:
    mov bx, 0x3395
    sbb ax, 0x2d03
label5:
    mov sp, [di+0x0628]
label6:
    mov al, [0xde8e]
    lock
    push si
    js label5
label7:
    esc 0xdb
    jge label12
    dec bp
    db 0x63
    db 0xC5, 0xEB
    db 0x66
    dec ax
    out dx, al
    db 0xC0
label8:
    sub byte [bp+0x2608], 0xab
    test [bp+di], sp
    or ax, 0x3d13
    db 0x9B, 0xB5  ; wait
    cmp [0x9eb0], dl
    into
label9:
    loopnz loop3
    db 0x68
    in ax, 0xcb
    db 0x6D
    inc bx
    pop bp
    jnb label6+2
    sti
    jbe label13
    db 0xFE, 0xD0
    jp label13
    db 0xF2, 0xDC
    push cx
    jg label8
    imul cx
label10:
    db 0xC7, 0x61, 0x4F, 0xC2, 0xEC ;$4 mov word [bx+di+0x4f], 0xecc2
    dec dx
    db 0x64
    xor al, 0x1a
    mov sp, 0x1f92
    xor [bx-0x5847], dx
    mov [bx], bp
    add [si+0x04a2], cx
    db 0x2A, 0xEA ;$1 sub ch, dl
    les sp, [bp+si+0x4c]
    db 0xC1
    out dx, ax
    dec cx
    db 0x67
label11:
    jns 531
    db 0xF1
label12:
    esc 0xdf
    push dx
    jl label10
    hlt
    movsb
    mov ch, [si]
    add cl, [bx+0x07a1]
    sub [bx], si
loop3:
    sbb [bx+0x1c91], di
    xor dl, [si+0x10ba]
    ds:
    cbw
    mov dh, 0x3b
    adc ax, 0x9db3
    sub word [di+0x250b], 0xffa8
    xchg ah, [bx+si]
    push cs
    pop si
    jo label11+1
    clc
    jnz 579
label13:
    std
    ror bp, cl
    jcxz 562
    db 0x6B
    out 0xc8, al
    db 0x6E
    inc ax