    jmp label1
    add si, 0x0126
    mov cx, 0x0035
    rep movsw
    pop es
    mov ax, 0x40e0
    mov di, 0x0050
    jmp ax
    mov bl, 0xa3
    mov cx, 0x0002
    push cx
loop1:
    mov cx, 0x0100
    cmp bl, 0xa3
    or [si-0x02], si
    mov word [bx+di-0x5c05], 0xf6e3
    loop -84
    ret
    push es
    pop cx
    esc 0xd9
    loop loop2+1
    push es
    pop ds
    pop es
    mov bx, 0x0056
    mov ax, 0x03a3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
loop2:
    add sp, 0x0300
    add si, 0x0014
    db 0x02, 0xEB ;$1 add ch, bl
    rep movsw
    sub word [bx], 0x0300
    mov di, [bx]
    movsw
    sub sp, 0x0100
    mov cx, 0x000a
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]
    push es
    push di
    push ds
    mov di, 0x40e0
    mov cx, 0x0035
    rep movsw
    pop es
    mov ax, 0x40e0
    mov di, 0x0050
    jmp ax
    mov bl, 0xa3
    mov cx, 0x0002
    push cx
    mov cx, 0x0100
    cmp bl, 0xa3
    or [si-0x02], si
    mov word [bx+di-0x5c05], 0xf6e3
    loop loop1
    ret
    push es
    pop cx
    esc 0xd9
    loop loop3+1
    push es
    pop ds
    pop es
    mov bx, 0x0056
    mov ax, 0x03a3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
loop3:
    add sp, 0x0300
    add si, 0x0014
    db 0x02, 0xEB ;$1 add ch, bl
    rep movsw
    sub word [bx], 0x0300
    mov di, [bx]
    movsw
    sub sp, 0x0100
    mov cx, 0x000a
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    int 0x87
    pop ax
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    int 0x87
    pop ax
label1:
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    pop ax
    push es
    push di
    push ds
    cld
    pop es
    mov di, 0x1800
    int 0x86
    int 0x86
    pop di
    pop es
    push es
    push cs
    pop es
    push ax
    pop si
    mov di, 0xcde0
    add si, 0x0126
    mov cx, 0x0035
    rep movsw
    pop es
    mov ax, 0xcde0
    mov di, 0x0050
    jmp ax
    mov bl, 0xc1
    mov cx, 0x0002
loop4:
    push cx
    mov cx, 0x0100
    cmp bl, 0xa3
    jz loop6
loop5:
    inc bh
    mov byte [bx], 0xcc
    loop loop5
    jmp label3
loop6:
    inc bh
    cmp bx, 0xe3a3
    jnz label2
    loop loop6
label2:
    mov byte [bx], 0xcc
    loop loop6
label3:
    mov bl, 0xa3
    pop cx
    loop loop4
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0056
    mov ax, 0x03a3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
    add sp, 0x0300
    add si, 0x0014
    jmp label4
    rep movsw
label4:
    sub word [bx], 0x0300
loop7:
    mov di, [bx]
    movsw
    sub sp, 0x0100
    mov cx, 0x000a
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]
    pop cx
    esc 0xd9
    loop loop8+1
    push es
    pop ds
    pop es
    mov bx, 0x0056
    mov ax, 0x03a3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
loop8:
    add sp, 0x0300
    add si, 0x0014
    db 0x02, 0xEB ;$1 add ch, bl
    rep movsw
    sub word [bx], 0x0300
    mov di, [bx]
    movsw
    sub sp, 0x0100
    mov cx, 0x000a
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]
    push es
    mov di, 0x40e0
    add si, 0x0126
    mov cx, 0x0035
    rep movsw
    pop es
    mov ax, 0x40e0
    mov di, 0x0050
    jmp ax
    mov bl, 0xa3
    mov cx, 0x0002
    push cx
    mov cx, 0x0100
    cmp bl, 0xa3
    or [si-0x02], si
    mov word [bx+di-0x5c05], 0xf6e3
    loop loop7+1
    ret