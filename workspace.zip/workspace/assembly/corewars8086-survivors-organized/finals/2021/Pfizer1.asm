    brk
    mov [0xdddd], ax
    mov si, ax
    sub si, 0x0100
    and si, 0x0700
    mov bx, ax
    add bx, 0x00c5
    mov cx, 0x0003
loop1:
    nrg
    nrg
    nrg
    nrg
    nrg
    loop loop1
    mov cx, 0xf0f1
    mov [si+0x3d00], cx
    mov [si-0x2300], cx
    mov [si+0x5d00], cx
    mov [si-0x2700], cx
    mov [si+0x3900], cx
    mov [si+0x5900], cx
    mov [si-0x0700], cx
    mov [si+0x3100], cx
    mov [si-0x2f00], cx
    mov [si+0x5100], cx
    mov [si+0x2100], cx
    mov dx, ax
    mov word [0xf8e2], 0xcccc
    xor ax, ax
    jmp $
    add [di], bh
    xor ax, [si-0x2300]
    xor ax, [si+0x5d00]
    xor ax, [si-0x2700]
    xor ax, [si+0x3900]
    xor ax, [si+0x5900]
    jz label1
    xor ax, 0xf0f1
    jmp label3
label1:
    xor ax, [si-0x0700]
    xor ax, [si+0x3100]
    jz label2
    xor ax, 0xf0f1
    jmp label3
label2:
    xor ax, [si-0x2f00]
    xor ax, [si+0x5100]
    xor ax, [si+0x2100]
label3:
    xlatb
    xchg al, ah
    xlatb
    xor ah, al
    mov bx, ax
    mov word [bx+0x70], 0xa5ff
    push ds
    pop es
    mov di, 0x0000
    mov ax, 0x0300
    mov dx, 0xe3d1
    mov bx, 0x0300
    mov cx, 0xa5ff
loop2:
    int 0x87
    jmp word [0xcccd]
    add [0xa688], ch
    sub ax, [di]
    mov [0x938d], ax
    mov bp, 0x351b
    mov ax, 0x3096
    push ds
loop3:
    dec si
    db 0x60
label4:
    db 0xC6, 0xE8, 0x65 ;$6 mov al, 0x65
    dec bx
    in ax, dx
    ret
    esc 0xdd
    db 0xF3, 0x55
    jnp label4+1
    esc 0xd8
    jle label6+2
    cli
    aam 0x72
    pop sp
    sar di, 1
    pop cx
    ja label9+1
    inc di
    loopz loop2+1
    inc dx
    db 0x6C
    retf 0xb4e4
    call 0xb19f:0x123c
    pop ss
    cmp [bx], sp
    or [bx+0x0c81], bp
    and al, [si+0x6aaa]
    inc sp
    loop loop3
    inc cx
    db 0x6F
    db 0xC9
    out 0xf9, ax
    xlatb
    jno label10+2
    sar ah, cl
    pop dx
    jz label7
    or ch, [si+0x0f82]
    and [bx-0x4857], ax
    cwd
    aas
    adc [si+0x14b2], bx
    cmp dl, [bx+si+0x18be]
    ss:
    mov bx, 0x3395
    sbb ax, 0x2d03
label5:
    mov sp, [di+0x0628]
label6:
    mov al, [0xde8e]
    lock
    push si
    js label5
label7:
    esc 0xdb
    jge label12
    dec bp
    db 0x63
    db 0xC5, 0xEB
    db 0x66
    dec ax
    out dx, al
    db 0xC0
label8:
    sub byte [bp+0x2608], 0xab
    test [bp+di], sp
    or ax, 0x3d13
    db 0x9B, 0xB5  ; wait
    cmp [0x9eb0], dl
    into
label9:
    loopnz loop4
    db 0x68
    in ax, 0xcb
    db 0x6D
    inc bx
    pop bp
    jnb label6+2
    sti
    jbe label13
    db 0xFE, 0xD0
    jp label13
    db 0xF2, 0xDC
    push cx
    jg label8
    imul cx
label10:
    db 0xC7, 0x61, 0x4F, 0xC2, 0xEC ;$4 mov word [bx+di+0x4f], 0xecc2
    dec dx
    db 0x64
    xor al, 0x1a
    mov sp, 0x1f92
    xor [bx-0x5847], dx
    mov [bx], bp
    add [si+0x04a2], cx
    db 0x2A, 0xEA ;$1 sub ch, dl
    les sp, [bp+si+0x4c]
    db 0xC1
    out dx, ax
    dec cx
    db 0x67
label11:
    jns 486
    db 0xF1
label12:
    esc 0xdf
    push dx
    jl label10
    hlt
    movsb
    mov ch, [si]
    add cl, [bx+0x07a1]
    sub [bx], si
loop4:
    sbb [bx+0x1c91], di
    xor dl, [si+0x10ba]
    ds:
    cbw
    mov dh, 0x3b
    adc ax, 0x9db3
    sub word [di+0x250b], 0xffa8
    xchg ah, [bx+si]
    push cs
    pop si
    jo label11+1
    clc
    jnz 534
label13:
    std
    ror bp, cl
    jcxz 517
    db 0x6B
    out 0xc8, al
    db 0x6E
    inc ax