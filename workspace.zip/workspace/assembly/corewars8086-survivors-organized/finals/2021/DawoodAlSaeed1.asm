    push ax
    push es
    mov si, ax
    mov cx, ax
    push cs
    pop es
    mov di, ax
    sub di, 0x0262
    mov dx, 0xcccc
    mov ax, dx
    int 0x86
    int 0x86
    add cx, 0x0032
    pop ds
    pop [bx]
    mov [bx+0x04], cx
    push cs
    pop ss
    add si, 0x0030
    mov [bx], si
    mov [bx+0x02], cs
    mov sp, di
    sub sp, 0x0203
    call far [bx]
    mov bx, 0x00cc
    add di, 0x045e
    mov dx, 0xcccc
    mov ax, dx
    int 0x86
    int 0x86
    mov ax, 0x53b8
    stosw
    mov ax, 0xabab
    stosw
    mov ax, 0xab53
    stosw
    add bp, di
    sub bp, 0x09c4
    sub di, 0x0001
    mov cx, di
    sub cx, 0x0005
    jmp cx