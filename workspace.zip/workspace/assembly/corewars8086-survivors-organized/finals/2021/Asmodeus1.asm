    jmp label1
    rep movsw
    sub [bx], ax
    les di, [bx]
    or [bx+di+0x202b], dh
    dec di
    xor si, si
    dec dx
    push word [di+0x1f]
    rep movsw
    sub [bx], ax
    les di, [bx]
    or [bx+di+0x202b], dh
    dec di
    xor si, si
    dec dx
    push word [di+0x1f]
label1:
    mov si, ax
    mov bx, ax
    mov [bx+0x00cb], ax
    add si, 0x00b6
    xor di, di
    push es
    push ss
    pop es
    mov cl, 0x0b
    rep movsw
    push ax
    mov bx, ax
    add ax, 0x00ca
    mov [bx], ax
    pop ax
    mov bx, 0xc600
    mov dx, 0xcccc
    mov cx, 0x0050
loop1:
    xor bx, 0x8000
    cmp [bx], dx
    jnz label2
    loop loop1
label2:
    mov cx, [bx]
    xchg cl, ch
    mov bh, 0x00
    mov bl, cl
    add bx, ax
    add bx, 0x00e2
    mov cl, [bx]
    mov bh, 0x00
    mov bl, ch
    add bx, ax
    add bx, 0x00e2
    mov ch, [bx]
    xor ch, cl
    xchg cx, bx
    add bx, 0x0078
    mov word [bx], 0x26ff
    mov [bx+0x02], ax
    xor bp, bp
label3:
    push cs
    pop es
    mov ax, 0x1fff
    mov di, 0x3273
    add di, bp
    stosw
    dec di
    push ds
    push ss
    pop ds
    xor si, si
    mov bx, 0x0069
    mov word [bx], 0x32a3
    add [bx], bp
    mov word [bx+0x02], 0x0ffd
    mov word [bx+0x14], 0x2e00
    push cs
    push cs
    pop es
    pop ss
    mov sp, 0x35a3
    add sp, bp
    mov cx, 0x0008
    mov ax, 0x3100
    call far [bx]
    rep movsw
    sub [bx], ax
    les di, [bx]
    mov cl, 0x08
    movsw
    sub sp, [bx+si]
    dec di
    xor si, si
    dec dx
label4:
    jnz label4+1
    pop ds
    call far [bx]
    mov si, 0x4590
    mov dx, 0x0013
    add si, 0x00b6
    xor di, di
    push ss
    pop es
    mov cl, 0x0b
    rep movsw
loop2:
    mov bp, 0x5000
    jmp label3
    nop
    add [0xa688], ch
    sub ax, [di]
    mov [0x938d], ax
    mov bp, 0x351b
    mov ax, 0x3096
    push ds
loop3:
    dec si
    db 0x60
label5:
    db 0xC6, 0xE8, 0x65 ;$6 mov al, 0x65
    dec bx
    in ax, dx
    ret
    esc 0xdd
    db 0xF3, 0x55
    jnp label5+1
    esc 0xd8
    jle label7+2
    cli
    aam 0x72
    pop sp
    sar di, 1
    pop cx
    ja label10+1
    inc di
    loopz loop2+1
    inc dx
    db 0x6C
    retf 0xb4e4
    call 0xb19f:0x123c
    pop ss
    cmp [bx], sp
    or [bx+0x0c81], bp
    and al, [si+0x6aaa]
    inc sp
    loop loop3
    inc cx
    db 0x6F
    db 0xC9
    out 0xf9, ax
    xlatb
    jno label11+2
    sar ah, cl
    pop dx
    jz label8
    or ch, [si+0x0f82]
    and [bx-0x4857], ax
    cwd
    aas
    adc [si+0x14b2], bx
    cmp dl, [bx+si+0x18be]
    ss:
    mov bx, 0x3395
    sbb ax, 0x2d03
label6:
    mov sp, [di+0x0628]
label7:
    mov al, [0xde8e]
    lock
    push si
    js label6
label8:
    esc 0xdb
    jge label13
    dec bp
    db 0x63
    db 0xC5, 0xEB
    db 0x66
    dec ax
    out dx, al
    db 0xC0
label9:
    sub byte [bp+0x2608], 0xab
    test [bp+di], sp
    or ax, 0x3d13
    db 0x9B, 0xB5  ; wait
    cmp [0x9eb0], dl
    into
label10:
    loopnz loop4
    db 0x68
    in ax, 0xcb
    db 0x6D
    inc bx
    pop bp
    jnb label7+2
    sti
    jbe label14
    db 0xFE, 0xD0
    jp label14
    db 0xF2, 0xDC
    push cx
    jg label9
    imul cx
label11:
    db 0xC7, 0x61, 0x4F, 0xC2, 0xEC ;$4 mov word [bx+di+0x4f], 0xecc2
    dec dx
    db 0x64
    xor al, 0x1a
    mov sp, 0x1f92
    xor [bx-0x5847], dx
    mov [bx], bp
    add [si+0x04a2], cx
    db 0x2A, 0xEA ;$1 sub ch, dl
    les sp, [bp+si+0x4c]
    db 0xC1
    out dx, ax
    dec cx
    db 0x67
label12:
    jns 515
    db 0xF1
label13:
    esc 0xdf
    push dx
    jl label11
    hlt
    movsb
    mov ch, [si]
    add cl, [bx+0x07a1]
    sub [bx], si
loop4:
    sbb [bx+0x1c91], di
    xor dl, [si+0x10ba]
    ds:
    cbw
    mov dh, 0x3b
    adc ax, 0x9db3
    sub word [di+0x250b], 0xffa8
    xchg ah, [bx+si]
    push cs
    pop si
    jo label12+1
    clc
    jnz 563
label14:
    std
    ror bp, cl
    jcxz 546
    db 0x6B
    out 0xc8, al
    db 0x6E
    inc ax
    rep movsw
    sub [bx], ax
    les di, [bx]
    or [bx+di+0x202b], dh
    dec di
    xor si, si
    dec dx
    push word [di+0x1f]
    rep movsw
    sub [bx], ax
    les di, [bx]
    or [bx+di+0x202b], dh
    dec di
    xor si, si