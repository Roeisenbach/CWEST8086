    jmp label3
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    xlatb
    push ds
    push es
    pop ds
    pop es
    xchg ah, al
    xlatb
    xor ah, al
    mov cx, 0xcccc
    int 0x87
    mov cx, 0xcccc
    int 0x87
    push ds
    push es
    pop ds
    pop es
    mov [bx], ax
    mov word [bx+0x02], 0x0ffb
    movsw
    rep movsw
    movsw
    movsw
    dec di
    dec di
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, 0x0010
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    dec di
    dec di
    rep movsw
    mov sp, [bx]
    push ds
    push es
    pop ds
    pop es
    mov word [di], 0x1eff
    mov [di+0x02], cx
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    xlatb
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    mov bx, 0x0040
    mov al, 0xa0
    dec di
    dec di
    xor si, si
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    xlatb
    push ds
    push es
    pop ds
    pop es
    xchg ah, al
    xlatb
    xor ah, al
    mov cx, 0xcccc
    int 0x87
    mov cx, 0xcccc
    int 0x87
    push ds
    push es
    pop ds
    pop es
    mov [bx], ax
    mov word [bx+0x02], 0x0ffb
    movsw
    rep movsw
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, bp
label1:
    xchg cx, ax
    mov bx, cx
    add bx, 0x0006
    mov si, 0xc700
label2:
    mov ax, [si]
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    db 0x83, 0xC0, 0x73 ;$1 add ax, 0x0073
    xchg di, ax
    mov word [di], 0x1eff
    mov [di+0x02], cx
    sub si, 0x0100
    cmp si, 0xc400
    jnz label2
    jmp label4
label3:
    mov si, [0xa741]
    add ax, 0x00d8
    mov [si], ax
    mov [si+0x02], cs
    dec dx
    mov bh, 0x30
    mov dl, 0x70
    push ax
    push cs
    pop es
    mov ax, [0xa741]
    mov si, ax
    mov di, [si]
    push di
    push dx
    add di, bx
    mov dx, 0x1eff
    int 0x86
    neg di
    int 0x86
    mov si, [si]
    add si, 0x007a
    push ax
    mov ax, 0x1fff
    mov cx, 0xcccc
    int 0x87
    pop ax
    pop dx
    xor di, di
    push ss
    pop es
    mov cx, 0x0011
    pop si
    add si, 0x0059
    rep movsw
    dec dx
    js label1
label4:
    push ds
    push es
    pop ds
    pop es
    pop ax
    mov bx, 0x0040
    mov al, 0xa0
    add ah, 0x33
    mov [bx], ax
    mov word [bx+0x02], 0x0ffb
    mov cl, 0x0d
    push cs
    pop ss
    mov si, 0x001d
    mov bp, 0x000e
    jmp label5
    movsw
    rep movsw
label5:
    mov sp, [bx]
    sub word [bx], 0x3000
    les di, [bx]
    sub sp, 0x0010
    movsw
    movsw
    dec di
    dec di
    dec di
    xor si, si
    mov cx, 0x000d
    dec dx
label6:
    jnz label6+1
    sbb ah, cl
    sub sp, bp
    call far [bx+si]
    rep movsw
    push ds
    push es
    rep movsw
    push ds
    push es
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    xlatb
    push ds
    push es
    pop ds
    pop es
    xchg ah, al
    xlatb
    xor ah, al
    mov cx, 0xcccc
    int 0x87
    mov cx, 0xcccc
    int 0x87
    push ds
    push es
    pop ds
    pop es
    mov [bx], ax
    mov word [bx+0x02], 0x0ffb
    movsw
    rep movsw
    movsw
    movsw
    dec di
    dec di
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, 0x0010
    movsw
    movsw
    dec di
    dec di
    movsw
    movsw
    dec di
    dec di
    rep movsw
    mov sp, [bx]
    push ds
    push es
    pop ds
    pop es
    mov word [di], 0x1eff
    mov [di+0x02], cx
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    xlatb
    mov bx, 0x0040
    mov al, 0xa0
    dec di
    dec di
    xor si, si
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    xlatb
    push ds
    push es
    pop ds
    pop es
    xchg ah, al
    xlatb
    xor ah, al
    mov cx, 0xcccc
    int 0x87
    mov cx, 0xcccc
    int 0x87
    push ds
    push es
    pop ds
    pop es
    xor si, si
    xlatb
    xchg ah, al
    xlatb
    xor ah, al
    xlatb
    mov [bx], ax
    mov word [bx+0x02], 0x0ffb
    movsw
    rep movsw
    call far [bx+si]
    sub sp, bp
    call far [bx+si]
    sub sp, bp
    call far [bx+si]