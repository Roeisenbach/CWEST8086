    jmp label3
    nop
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0048
    nop
    mov di, 0x0000
    mov cx, 0x0015
    rep movsw
    mov cx, 0x0030
    nop
loop1:
    mov word [0x8346], 0xcccc
    loop loop1
    push es
    push cs
    pop es
    mov ax, 0x18ff
    mov dx, 0xcccc
    db 0x33, 0xFF ;$1 xor di, di
    int 0x87
    pop es
    mov bp, 0x0401
    mov dx, es
    add dx, 0x0100
    mov dl, 0xa0
    mov bx, 0x0250
    mov ax, 0x5001
    push es
    pop ds
    mov word [bx+0x02], 0x0ffc
    push cs
    pop ss
    jmp label1
    nop
    rep movsw
    push ds
    pop es
    db 0x2B, 0xD5 ;$1 sub dx, bp
label1:
    mov [bx], dx
    les di, [bx]
    mov si, 0x001c
    movsw
    movsw
    movsw
    sub di, 0x0005
    db 0x03, 0xD0 ;$1 add dx, ax
    db 0x8B, 0xE2 ;$1 mov sp, dx
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x0015
    sub sp, 0x001f
    call far [bx+si]
    inc cx
    nop
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0048
    nop
    mov di, 0x0000
    mov cx, 0x0015
    rep movsw
    mov cx, 0x0030
    nop
loop2:
    mov word [0x8346], 0xcccc
    loop loop2
    push es
    push cs
    pop es
    mov ax, 0x18ff
    mov dx, 0xcccc
    db 0x33, 0xFF ;$1 xor di, di
    int 0x87
    pop es
    mov bp, 0x0401
    mov dx, es
    add dx, 0x0100
    mov dl, 0xa0
    mov bx, 0x0250
    mov ax, 0x5001
    push es
    pop ds
    mov word [bx+0x02], 0x0ffc
    push cs
    pop ss
    jmp label2
    nop
    rep movsw
    push ds
    pop es
    db 0x2B, 0xD5 ;$1 sub dx, bp
label2:
    mov [bx], dx
    les di, [bx]
    mov si, 0x001c
    movsw
    movsw
    movsw
    sub di, 0x0005
    db 0x03, 0xD0 ;$1 add dx, ax
    db 0x8B, 0xE2 ;$1 mov sp, dx
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x0015
    sub sp, 0x001f
    call far [bx+si]
    inc cx
label3:
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0118
    mov di, 0x0000
    mov cx, 0x0015
    rep movsw
    mov cx, 0x0030
    nop
loop3:
    mov word [0x8346], 0xcccc
    loop loop3
    push es
    push cs
    pop es
    mov ax, 0x1fff
    mov dx, 0xcccc
    db 0x33, 0xFF ;$1 xor di, di
    int 0x87
    pop es
    mov bp, 0x0401
    mov dx, es
    add dx, 0x0100
    mov dl, 0xa0
    mov bx, 0x0250
    mov ax, 0x5001
    push es
    pop ds
    mov word [bx+0x02], 0x0ffc
    push cs
    pop ss
    jmp label4
    nop
    rep movsw
    push ds
    pop es
    db 0x2B, 0xD5 ;$1 sub dx, bp
label4:
    mov [bx], dx
    les di, [bx]
    mov si, 0x001c
    movsw
    movsw
    movsw
    sub di, 0x0005
    db 0x03, 0xD0 ;$1 add dx, ax
    db 0x8B, 0xE2 ;$1 mov sp, dx
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x0015
    sub sp, 0x001f
    call far [bx+si]
    inc cx
    nop
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0048
    nop
    mov di, 0x0000
    mov cx, 0x0015
    rep movsw
    mov cx, 0x0030
    nop
loop4:
    mov word [0x8346], 0xcccc
    loop loop4
    push es
    push cs
    pop es
    mov ax, 0x18ff
    mov dx, 0xcccc
    db 0x33, 0xFF ;$1 xor di, di
    int 0x87
    pop es
    mov bp, 0x0401
    mov dx, es
    add dx, 0x0100
    mov dl, 0xa0
    mov bx, 0x0250
    mov ax, 0x5001
    push es
    pop ds
    mov word [bx+0x02], 0x0ffc
    push cs
    pop ss
    jmp label5
    nop
    rep movsw
    push ds
    pop es
    db 0x2B, 0xD5 ;$1 sub dx, bp
label5:
    mov [bx], dx
    les di, [bx]
    mov si, 0x001c
    movsw
    movsw
    movsw
    sub di, 0x0005
    db 0x03, 0xD0 ;$1 add dx, ax
    db 0x8B, 0xE2 ;$1 mov sp, dx
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x0015
    sub sp, 0x001f
    call far [bx+si]
    inc cx
    nop
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0048
    nop
    mov di, 0x0000
    mov cx, 0x0015
    rep movsw
    mov cx, 0x0030
    nop
loop5:
    mov word [0x8346], 0xcccc
    loop loop5
    push es
    push cs
    pop es
    mov ax, 0x18ff
    mov dx, 0xcccc
    db 0x33, 0xFF ;$1 xor di, di
    int 0x87
    pop es
    mov bp, 0x0401
    mov dx, es
    add dx, 0x0100
    mov dl, 0xa0
    mov bx, 0x0250
    mov ax, 0x5001
    push es
    pop ds
    mov word [bx+0x02], 0x0ffc
    push cs
    pop ss
    jmp label6
    nop
    rep movsw
    push ds
    pop es
    db 0x2B, 0xD5 ;$1 sub dx, bp
label6:
    mov [bx], dx
    les di, [bx]
    mov si, 0x001c
    movsw
    movsw
    movsw
    sub di, 0x0005
    db 0x03, 0xD0 ;$1 add dx, ax
    db 0x8B, 0xE2 ;$1 mov sp, dx
    db 0x33  ; xor ax, [bx+si]