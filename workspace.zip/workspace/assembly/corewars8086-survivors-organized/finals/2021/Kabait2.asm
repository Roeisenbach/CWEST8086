    jmp label1
    push ax
    push es
    push cs
    pop es
    mov di, ax
    push di
    std
    mov ax, 0xec29
    mov dx, 0x1fff
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    sub di, 0x0004
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x86
    pop di
    add di, 0x00a8
    cld
    int 0x86
    pop es
    pop ax
    xor si, si
    mov bp, cs
    push es
    pop ds
    mov bx, ax
    sub bx, 0x0020
    add bx, 0x0059
    mov [si], bx
    mov word [si+0x02], 0x1002
    call far [si]
    movsw
    rep movsw
    sub [bx], dx
    mov di, [bx]
    movsw
    movsw
    xor si, si
    mov sp, di
    dec di
    add sp, bp
    mov cl, 0x08
    call far [bx]
    sub sp, ax
    call far [bx]
    mov si, ax
    add si, 0x0041
    mov ds, bp
    push ss
    pop es
    xor di, di
    mov cx, 0x000d
    rep movsw
    push ss
    push cs
    pop es
    pop ds
    mov ss, bp
    xor si, si
    mov cl, 0x08
    sub ax, 0x0200
    mov al, 0xc1
    mov sp, ax
    add sp, 0x0007
    mov bp, ax
    sub bp, 0x0700
    mov word [bp+0x00], 0xc429
    mov word [bp+0x02], 0x1fff
    sub bp, 0x0020
    mov bx, 0x005a
    mov [bx+0x02], cs
    mov [bx], bp
    mov ax, 0x0007
    mov di, bp
    add di, 0x0003
    mov dx, 0x0700
    mov bp, 0x070d
    call far [bx]
label1:
    push ax
    push es
    push cs
    pop es
    mov di, ax
    push di
    std
    mov ax, 0xec29
    mov dx, 0x1fff
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    sub di, 0x0004
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x86
    pop di
    add di, 0x01ff
    cld
    int 0x86
    pop es
    pop ax
    xor si, si
    mov bp, cs
    push es
    pop ds
    mov bx, ax
    sub bx, 0x0020
    add bx, 0x0107
    mov [si], bx
    mov word [si+0x02], 0x1002
    call far [si]
    movsw
    nop
    rep movsw
    sub [bx], ax
    mov di, [bx]
    nop
    movsw
    movsw
    mov sp, di
    dec di
    xor si, si
    mov cl, 0x09
    add sp, bp
    call far [bx]
    sub sp, dx
    call far [bx]
    mov si, ax
    add si, 0x00ed
    mov ds, bp
    push ss
    pop es
    xor di, di
    mov cx, 0x000d
    rep movsw
    push ss
    push cs
    pop es
    pop ds
    mov ss, bp
    xor si, si
    mov cl, 0x09
    sub ax, 0x0200
    mov al, 0xc1
    mov sp, ax
    add sp, 0x0007
    mov bp, ax
    sub bp, 0x0700
    mov word [bp+0x00], 0xd429
    mov word [bp+0x02], 0x1fff
    sub bp, 0x0020
    mov bx, 0x005a
    mov [bx+0x02], cs
    mov [bx], bp
    mov dx, 0x0007
    mov di, bp
    add di, 0x0003
    mov ax, 0x0700
    mov bp, 0x070d
    call far [bx]
    push ax
    push es
    push cs
    pop es
    mov di, ax
    push di
    std
    mov ax, 0xec29
    mov dx, 0x1fff
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    sub di, 0x0004
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x86
    pop di
    add di, 0x00a8
    cld
    int 0x86
    pop es
    pop ax
    xor si, si
    mov bp, cs
    push es
    pop ds
    mov bx, ax
    sub bx, 0x0020
    add bx, 0x0059
    mov [si], bx
    mov word [si+0x02], 0x1002
    call far [si]
    movsw
    rep movsw
    sub [bx], dx
    mov di, [bx]
    movsw
    movsw
    xor si, si
    mov sp, di
    dec di
    add sp, bp
    mov cl, 0x08
    call far [bx]
    sub sp, ax
    call far [bx]
    mov si, ax
    add si, 0x0041
    mov ds, bp
    push ss
    pop es
    xor di, di
    mov cx, 0x000d
    rep movsw
    push ss
    push cs
    pop es
    pop ds
    mov ss, bp
    xor si, si
    mov cl, 0x08
    sub ax, 0x0200
    mov al, 0xc1
    mov sp, ax
    add sp, 0x0007
    mov bp, ax
    sub bp, 0x0700
    mov word [bp+0x00], 0xc429
    mov word [bp+0x02], 0x1fff
    sub bp, 0x0020
    mov bx, 0x005a
    mov [bx+0x02], cs
    mov [bx], bp
    mov ax, 0x0007
    mov di, bp
    add di, 0x0003
    mov dx, 0x0700
    mov bp, 0x070d
    call far [bx]