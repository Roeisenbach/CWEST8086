    mov si, ax
    and si, 0xff00
    add si, 0x0100
    push word [si]
    add si, 0x0100
    push word [si]
    mov bx, [0xdddd]
    mov cx, bx
    add cx, 0x0300
    and cx, 0x0700
    push bx
    mov bx, cx
    mov dx, ax
    add dx, 0x014d
    mov byte [0xcccc], 0xb8
    mov [0xcccd], dx
    mov word [0xcccf], 0xe0ff
    mov word [0x26ff], 0xcccc
    mov cx, 0x0006
    loop $
    mov cx, 0xf0f1
    mov [bx+0x3d00], cx
    mov [bx-0x2300], cx
    mov [bx+0x5d00], cx
    mov [bx-0x2700], cx
    mov [bx+0x3900], cx
    mov [bx+0x5900], cx
    mov [bx+0x3100], cx
    mov [bx-0x2f00], cx
    mov [bx+0x5100], cx
    mov [bx+0x2100], cx
    xchg bx, cx
    pop bx
    push ax
    mov ax, 0xf0f1
    add bx, 0x00e0
    push bx
    mov word [0xf8e2], 0xcccc
    mov word [bx-0x79], 0x8433
    xchg bx, cx
    xor ax, [bx+0x3d00]
    xor ax, [bx-0x2300]
    xor ax, [bx+0x5d00]
    xor ax, [bx-0x2700]
    xor ax, [bx+0x3900]
    xor ax, [bx+0x5900]
    xor ax, [bx+0x3100]
    xor ax, [bx-0x2f00]
    xor ax, [bx+0x5100]
    xor ax, [bx+0x2100]
    xchg bx, cx
    xlatb
    xchg al, ah
    xlatb
    xor ah, al
    mov bx, ax
    mov word [bx+0x70], 0xa5ff
    pop ax
    pop cx
    mov [si], cx
    sub si, 0x0100
    pop cx
    mov [si], cx
    push ds
    pop es
    mov di, 0x0000
    mov ax, 0x0300
    mov dx, 0xe3d1
    mov bx, 0x0300
    mov cx, 0xa5ff
    int 0x87
    mov word [0xdeff], 0xc9a2
    mov cx, 0x0010
    mov si, ax
    lea si, [si+0x0127]
    push ss
    pop es
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0050
    mov ax, 0xdfa2
    mov [bx], ax
    sub word [bx], 0x0600
    push cs
    pop ss
    mov sp, ax
    xor dx, dx
    mov di, [bx]
    add di, 0xfff0
    sub sp, 0x0200
    mov si, 0x0010
    movsw
    dec di
label1:
    mov word [bx+0x02], 0x0fff
    mov word [bx+0x1b], 0x0200
    mov word [bx+0x10], 0x061e
    mov bp, 0x0600
    call far [bx]
    dec dx
    movsw
    movsw
    jz label2
    movsw
    movsw
    movsw
    movsw
    movsw
    sub di, [bx+si]
    movsw
    dec di
    call far [bx]
    call far [bx]
    movsw
    movsw
    movsw
    sub [bx], bp
    movsw
    sub sp, [bx+si]
    movsw
    movsw
    xor si, si
    movsw
    nop
    nop
label2:
    mov cx, 0xf1a2
    jmp label3
    push ds
    pop es
    mov di, 0x0000
    mov ax, 0x0300
    mov dx, 0xe3d1
    mov bx, 0x0300
    mov cx, 0xa5ff
    int 0x87
    mov cx, [0xdeff]
    sub word [0xdeff], 0x1400
label3:
    push ss
    pop ds
    push cs
    pop es
    push cs
    pop ss
    mov bx, 0x0050
    mov word [bx], 0xdfa2
    mov word [0x0000], 0xcccc
    mov word [0x0002], 0xffcc
    mov word [0x0004], 0xcc1f
    mov word [0x0006], 0xcccc
    mov dx, 0x0122
    mov sp, cx
    mov di, sp
    mov si, 0x0012
    sub word [bx], 0x0600
    jmp label1