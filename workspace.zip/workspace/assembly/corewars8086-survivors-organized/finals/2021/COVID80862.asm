    jmp label1
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    int 0x87
    pop ax
    cld
    push es
    push di
    stc
    push ds
    pop es
    mov di, 0x1a00
    int 0x86
    clc
    int 0x86
    pop di
    pop es
    or al, 0xb9
    add [bx+di-0x7e3a], cl
    db 0xC6, 0x21, 0x01 ;$4 mov byte [bx+di], 0x01
    rep movsw
    push ds
    push es
    pop ds
    pop es
    or bh, [bx+di-0x4500]
    push ax
    add [bx+si+0x07a3], bh
    mov [bx], ax
    mov [bx+0x02], cs
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
    add sp, 0x0300
    add si, 0x0014
    db 0x02, 0xEB ;$1 add ch, bl
    rep movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    mov cx, 0x000a
    movsw
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    int 0x87
    pop ax
    cld
    push es
    push di
    push ds
    pop es
    mov di, 0x1a00
    int 0x86
    int 0x86
    pop di
    pop es
    or al, 0xb9
    add [bx+di-0x7e3a], cl
    db 0xC6, 0x21, 0x01 ;$4 mov byte [bx+di], 0x01
    rep movsw
    push ds
    push es
    pop ds
    pop es
    or bh, [bx+di-0x4500]
    push ax
    add [bx+si+0x07a3], bh
    mov [bx], ax
    mov [bx+0x02], cs
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
    add sp, 0x0300
    add si, 0x0014
    db 0x02, 0xEB ;$1 add ch, bl
    rep movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    mov cx, 0x000a
    movsw
    xor si, si
    dec di
    call far [bx]
label1:
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    pop ax
    cld
    push es
    push di
    push ds
    pop es
    mov di, 0x1a00
    int 0x86
    int 0x86
    pop di
    pop es
    mov cx, 0x000c
    mov si, ax
    add si, 0x0121
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0050
    mov ax, 0x07a3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
    add sp, 0x0300
    add si, 0x0014
    jmp label2
    rep movsw
label2:
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    mov cx, 0x000a
    movsw
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    pop ax
    cld
    push es
    push di
    push ds
    pop es
    mov di, 0x1a00
    int 0x86
    int 0x86
    pop di
    pop es
    or al, 0xb9
    add [bx+di-0x7e3a], cl
    db 0xC6, 0x21, 0x01 ;$4 mov byte [bx+di], 0x01
    rep movsw
label3:
    push ds
    push es
    pop ds
    pop es
    or bh, [bx+di-0x7d00]
    db 0xC6, 0x14, 0x02 ;$2 mov byte [si], 0x02
    jmp label3
    movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    mov cx, 0x000a
    movsw
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]
    push ax
    std
    mov ax, 0xa5f3
    mov dx, 0x2f81
    int 0x87
    pop ax
    cld
    push es
    push di
    push ds
    pop es
    mov di, 0x1a00
    int 0x86
    int 0x86
    pop di
    pop es
    or al, 0xb9
    add [bx+di-0x7e3a], cl
    db 0xC6, 0x21, 0x01 ;$4 mov byte [bx+di], 0x01
    rep movsw
    push ds
    push es
    pop ds
    pop es
    or bh, [bx+di-0x4500]
    push ax
    add [bx+si+0x07a3], bh
    mov [bx], ax
    mov [bx+0x02], cs
    mov dx, 0x1000
    mov ss, dx
    mov ss, dx
    mov sp, ax
    add sp, 0x0300
    add si, 0x0014
    db 0x02, 0xEB ;$1 add ch, bl
    rep movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    movsw
    sub word [bx], 0x0900
    mov di, [bx]
    sub sp, 0x0500
    mov cx, 0x000a
    movsw
    xor si, si
    dec di
    call far [bx]
    int3
    call far [bx]