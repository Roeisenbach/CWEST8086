    call prcd1
    mov dx, [0x8100]
    mov ax, dx
    and ax, 0x7f7f
    xlatb
    xor al, dl
    xchg al, ah
    xlatb
    xor al, dh
    xor ah, al
    mov dx, [0x8100]
    mov ax, dx
    and ax, 0x7f7f
    xlatb
    xor al, dl
    xchg al, ah
    xlatb
    xor al, dh
    xor ah, al
prcd1:
    pop si
    add si, 0x0133
    add [si], ax
    add si, 0xff54
    push ss
    pop es
    mov cl, 0x32
    rep movsw
    push ax
    mov bx, ax
    add bx, 0x0156
    mov dx, [0x8100]
    mov ax, dx
    and ax, 0x7f7f
    xlatb
    xor al, dl
    xchg al, ah
    xlatb
    xor al, dh
    xor ah, al
    lea bx, [bx-0x12]
    mov [0xe278], bx
    mov bx, ax
    mov word [bx+0x70], 0x78bf
    mov word [bx+0x73], 0x25ff
    mov cl, 0x2b
    rep movsw
    pop ax
    push ss
    push cs
    pop es
    pop ds
    push cs
    mov dx, ss
    pop ss
    add ah, 0x08
    mov al, 0xa3
    mov bx, 0x0123
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov al, 0x0f
    mov si, 0x000e
    jmp label1
    rep movsw
label1:
    les di, [bx]
    lea sp, [di+0x0200]
    mov cl, 0x08
    movsw
    dec di
    call far [bx]
    call far [bx]
    rep movsw
    sub di, 0x1214
    mov bp, di
    mov cl, 0x0a
    rep movsw
    lds cx, [0x00a6]
    call bp
    pop si
    rep movsw
    mov si, 0x0036
    add di, 0x0802
    mov ds, dx
    mov cl, 0x37
    mov bp, di
    movsw
    jmp bp
    int3
    rep movsw
    lds cx, [si]
    lea di, [bp+0x58]
    mov [0x3333], di
    lea di, [bp+0x3269]
    mov word [di], 0x2f81
    lea si, [bp-0x0a00]
    lea di, [bp+0x0800]
    rep cmpsw
    scasb
    jz label2
    scasb
    jz label2
    mov di, si
    scasb
    jz label2
    scasb
    jnz label3
label2:
    les di, [di-0x04]
    add di, 0x000c
    mov ds, dx
    mov si, 0x00ac
    mov [si], bp
    add word [si], 0x0058
    add word [si+0x0a], 0x0002
    mov si, 0x00b8
    mov cl, 0x08
    std
    rep movsw
    cld
label3:
    mov ds, dx
    mov cl, 0x06
    sub word [bx], 0x3200
    xor si, si
    les di, [bx]
    movsw
    jmp word [bx]
    int3
    mov sp, [bx]
    sub sp, 0x0c00
    sub sp, bp
    add word [bx], 0x000e
    dec dx
    jz label4
    sub sp, 0x0010
    call far [bx]
    push cs
    db 0x32, 0xFF ;$1 xor bh, bh
    pop ds
    int3
label4:
    inc word [bx+si]
    add [bx+si], dl
    mov word [bx], 0x0118
label5:
    mov [bx+0x02], ss
    mov dx, 0x0100
    mov bp, 0x0000
    call far [bx]
    int3
    mov cx, 0x0226
    loop $
    mov ax, [0x3333]
    push ds
    push ss
    pop ds
    pop ss
    xor bx, bx
    mov [bx], ax
    jmp label5
    add [bx], ch
    mov ah, [di+word 0x002f]
    movsw
    mov bl, [bp+di+0x11b4]
    ds:
    mov ah, 0x9b
    ds:
    adc [bp+0x71], bx
    aam 0xfb
    jno label8+3
    sti
    aam 0xc5
label6:
    jmp 0xc5ea:0x604f
    db 0x60
loop1:
    dec di
    esc 0xda
    cmc
    push ax
    jg label6+1
    esc 0xda
    jg label9
label7:
    inc cx
    db 0x6E
    retf
    in al, 0x6e
    inc cx
    in al, 0xcb
    test [bp+di+0x210e], ch
    stosw
    test [bx+di], ah
    push cs
    pop ds
loop2:
    xor [di+0x30ba], dl
    pop ds
    mov dx, 0x2a95
    add ax, 0x8fa0
    add ax, 0x8f2a
    mov al, [0x9eb1]
    cmp dx, [si]
    sahf
    mov cl, 0x14
    cmp si, [si+0x5b]
    db 0xFE, 0xD1
    pop bx
    jz label7
    db 0xFE, 0xEF
    db 0xC0
    db 0x65
    dec dx
    db 0xC0
    out dx, ax
    dec dx
    db 0x65
    lock
    esc 0xdf
    jp 527
    esc 0xdf
    lock
    push bp
    jp 554
    inc sp
    loopz loop2+1
    inc sp
    db 0x6B
    into
    loopz loop1
label8:
    and word [si], 0x810b
    scasb
    or sp, [si]
label9:
    xor ax, 0xbf1a
    nop
    sbb dh, [di]
    nop
    db 0xBF  ; mov di, 0x0000