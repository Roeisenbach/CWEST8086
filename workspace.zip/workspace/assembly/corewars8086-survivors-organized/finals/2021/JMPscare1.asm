    mov cx, 0x0704
    mov word [0xecef], 0x1cff
    mov word [0xeced], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x0ddf
    mov word [si], 0x1cfd
    mov word [si+0x02], 0x1cff
    call far [si]