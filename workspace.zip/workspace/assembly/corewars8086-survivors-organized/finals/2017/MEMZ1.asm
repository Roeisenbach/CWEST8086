    add ax, 0x00ba
    add si, 0x000e
    push dx
    jmp ax
    int3
    int3
    int3
    mov dl, 0x11
    push dx
    db 0x83, 0xC0, 0x0D ;$1 add ax, 0x000d
    mov [bx], ax
    mov dx, 0x02c0
    push ax
    pop bx
    push ss
    pop es
    add si, [bx-0x20]
    mov cl, 0x07
    rep movsw
    mov di, 0xa20f
    cmp dl, 0xc0
    mov cl, 0x04
label1:
    db 0x9B, 0x9B ;$1 nrg
    jmp label1
    pop di
    jmp loop1
    add word [bx-0x20], 0x001c
    mov cl, 0x78
    loop $
loop1:
    mov ax, [si]
    mul ax
    div di
    xchg dx, ax
    mul word [si]
    div di
    mov bx, dx
    mov [0xcccc], bp
    mov word [bx-0x7f67], 0x16ff
    mov word [bx+0x0099], 0x16ff
    sub si, 0x0080
    loop loop1
    pop bx
    pop ax
    brk
    int3
    int3
    int3
    mov dl, 0x11
    push dx
    db 0x83, 0xC0, 0x0D ;$1 add ax, 0x000d
    mov [bx], ax
    mov dx, 0x02c0
    push ax
    pop bx
    push ss
    pop es
    add si, [bx-0x20]
    mov cl, 0x07
    rep movsw
    mov di, 0xa20f
    cmp dl, 0xc0
    mov cl, 0x04
label2:
    db 0x9B, 0x9B ;$1 nrg
    jmp label2
    pop di
    jmp loop2
    add word [bx-0x20], 0x001c
    mov cl, 0x78
    loop $
loop2:
    mov ax, [si]
    mul ax
    div di
    xchg dx, ax
    mul word [si]
    div di
    mov bx, dx
    mov [0xcccc], bp
    mov word [bx-0x7f67], 0x16ff
    mov word [bx+0x0099], 0x16ff
    sub si, 0x0080
    loop loop2
    pop bx
    pop ax
    brk
    int3
    int3
    int3
    mov dl, 0x11
    push dx
    db 0x83, 0xC0, 0x0D ;$1 add ax, 0x000d
    mov [bx], ax
    mov dx, 0x02c0
    push ax
    pop bx
    mov ax, bx
    dec bh
    mov bl, 0xa3
    mov word [bx+0x1f], 0xff99
    mov word [bx+0x21], 0xbb27
    xchg bx, ax
    mov [bx], ax
    push ss
    pop es
    add si, [bx-0x20]
    mov cl, 0x07
    rep movsw
    push ax
    push bx
    mov si, dx
    lea bp, [bx+0x70]
    push cs
    pop es
    mov di, 0xa20f
    cmp dl, 0xc0
    jnz label4
    push di
    mov di, 0x0101
    mov cl, 0x04
label3:
    db 0x9B, 0x9B ;$1 nrg
    jmp label3
    pop di
    jmp loop3
label4:
    add word [bx-0x20], 0x001c
    mov cl, 0x78
    loop $
    mov cl, 0x04
    mov word [bx+0x35], 0x86cd
loop3:
    mov ax, [si]
    mul ax
    div di
    xchg dx, ax
    mul word [si]
    div di
    mov bx, dx
    mov [0xcccc], bp
    mov word [bx-0x7f67], 0x16ff
    mov word [bx+0x0099], 0x16ff
    sub si, 0x0080
    loop loop3
    pop bx
    pop ax
    jmp label5
    call prcd1
prcd1:
    pop bx
    lea bx, [bx-0x73]
    mov cx, 0x0370
    pop ax
    mov al, 0x01
    push ax
    push ax
    mov ax, [bx]
label5:
    jmp word [bx-0x20]
    int3
    int3
    int3
    mov dl, 0x11
    push dx
    db 0x83, 0xC0, 0x0D ;$1 add ax, 0x000d
    mov [bx], ax
    mov dx, 0x02c0
    push ax
    pop bx
    push ss
    pop es
    add si, [bx-0x20]
    mov cl, 0x07
    rep movsw
    mov di, 0xa20f
    cmp dl, 0xc0
    mov cl, 0x04
label6:
    db 0x9B, 0x9B ;$1 nrg
    jmp label6
    pop di
    jmp loop4
    add word [bx-0x20], 0x001c
    mov cl, 0x78
    loop $
loop4:
    mov ax, [si]
    mul ax
    div di
    xchg dx, ax
    mul word [si]
    div di
    mov bx, dx
    mov [0xcccc], bp
    mov word [bx-0x7f67], 0x16ff
    mov word [bx+0x0099], 0x16ff
    sub si, 0x0080
    loop loop4
    pop bx
    pop ax
    brk
    int3
    int3
    int3
    mov dl, 0x11
    push dx
    db 0x83, 0xC0, 0x0D ;$1 add ax, 0x000d
    mov [bx], ax
    mov dx, 0x02c0
    push ax
    pop bx
    push ss
    pop es
    add si, [bx-0x20]
    mov cl, 0x07
    rep movsw
    mov di, 0xa20f
    cmp dl, 0xc0
    mov cl, 0x04
label7:
    db 0x9B, 0x9B ;$1 nrg
    jmp label7
    pop di
    jmp loop5
    add word [bx-0x20], 0x001c
    mov cl, 0x78
    loop $
loop5:
    mov ax, [si]
    mul ax
    div di
    xchg dx, ax
    mul word [si]
    div di
    mov bx, dx
    mov [0xcccc], bp
    mov word [bx-0x7f67], 0x16ff
    mov word [bx+0x0099], 0x16ff
    sub si, 0x0080
    loop loop5
    pop bx
    pop ax
    brk