    push ax
    add ax, 0x0105
    stosw
    pop ax
    push ax
    add ax, 0x00cf
    jmp ax
    push ax
    add ax, 0x0105
    stosw
    pop ax
    push ax
    add ax, 0x00cf
    jmp ax
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    pop ax
    push es
    pop ds
    mov [0x0044], ax
    add ax, 0x0103
    push ax
    mov bx, 0x0050
    sub ax, 0x0010
    mov [bx], ax
    mov dx, cs
    inc dx
    mov [bx+0x02], dx
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x027a
    call prcd1
    push cs
    pop ss
    mov sp, [0x0044]
    jmp label2
    mov sp, [0x0044]
    mov ax, [0x0060]
    mov [0x0050], ax
    call far [bx]
    mov di, [0x0000]
    add di, 0x0064
    nop
    call prcd1
    add di, 0x0214
    mov ax, 0xcccc
    mov si, [0x0000]
    sub si, 0x000c
    nop
    sub si, 0x0010
    push cs
    pop es
label1:
    mov cx, 0x3f7a
    rep stosw
    mov dx, [0x0050]
    mov [0x0060], dx
    mov [0x0050], si
    add di, 0x8000
    jmp label1
    mov ax, 0xcccc
    mov dx, 0xcccc
    push es
    push cs
    pop es
    cld
    int 0x86
    add di, 0x0014
    int 0x86
    pop es
    ret
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    pop ax
    push es
    pop ds
    mov [0x0044], ax
    add ax, 0x0103
    push ax
    mov bx, 0x0050
    sub ax, 0x0010
    mov [bx], ax
    mov dx, cs
    inc dx
    mov [bx+0x02], dx
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0284
    call prcd1
    push cs
    pop ss
    mov sp, [0x0044]
    jmp label2
    nop
    mov sp, [0x0044]
    mov ax, [0x0060]
    mov [0x0050], ax
label2:
    call far [bx]
    mov di, [0x0000]
    add di, 0x0064
    nop
    call prcd1
    add di, 0x0200
    mov ax, 0xcccc
    mov si, [0x0000]
    sub si, 0x000c
    sub si, 0x0010
    push cs
    pop es
label3:
    mov cx, 0x3f7a
    rep stosw
    mov dx, [0x0050]
    mov [0x0060], dx
    mov [0x0050], si
    add di, 0x8000
    jmp label3
prcd1:
    mov ax, 0xcccc
    mov dx, 0xcccc
    push es
    push cs
    pop es
    cld
    int 0x86
    add di, 0x001e
    int 0x86
    pop es
    ret
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]