    std
    push ax
    push es
    push cs
    pop es
    mov ax, 0x4fab
    mov dx, 0x1fff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop es
    pop ax
    cld
    mov bx, ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    push es
    pop ss
    mov ax, 0xa5ab
    mov dx, 0xd401
    mov di, 0x0150
    int 0x86
    mov di, 0x0194
    mov cx, 0x0038
    shr cx, 1
    add si, 0x0058
    nop
    rep movsw
    mov ss, bx
    mov bp, 0xefe8
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov dx, 0x3c88
    mov cx, 0x0150
    lea sp, [bp-0x171c]
    db 0x8B, 0xFD ;$1 mov di, bp
    inc di
    db 0x8B, 0xF1 ;$1 mov si, cx
    mov byte [bp+0x00], 0xab
    mov ax, 0xa552
    jmp bp
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov bx, [bp+0x0996]
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    cmp bx, [bp-0x0452]
    jz label1
    add bp, 0xf000
    lea sp, [bp-0x171c]
label1:
    movsw
    movsw
    movsw
    mov byte [bp+0x00], 0xab
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    db 0x8B, 0xF1 ;$1 mov si, cx
    db 0x8B, 0xFD ;$1 mov di, bp
    inc di
    jmp bp