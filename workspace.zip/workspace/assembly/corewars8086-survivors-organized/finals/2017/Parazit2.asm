    add ax, 0x00c9
    jmp ax
    push ax
    add ax, 0x0130
    stosw
    pop ax
    push ax
    add ax, 0x0130
    jmp ax
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    pop ax
    push es
    pop ds
    mov [0x0044], ax
    add ax, 0x0130
    push ax
    mov bx, 0x0050
    sub ax, 0x0010
    mov [bx], ax
    mov dx, cs
    inc dx
    mov [bx+0x02], dx
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0214
    call prcd1
    push cs
    pop ss
    mov sp, [0x0044]
    jmp label1
    mov sp, [0x0044]
    mov ax, [0x0060]
    mov [0x0050], ax
    call far [bx]
    mov di, [0x0000]
    add di, 0x0000
    nop
    call prcd1
    add di, 0x0214
    mov ax, 0xcccc
    mov si, [0x0000]
    sub si, 0x0000
    nop
    sub si, 0x0010
    push cs
    pop es
    mov cx, 0x3f7a
    rep stosw
    mov dx, [0x0050]
    mov [0x0060], dx
    mov [0x0050], si
    add di, 0x8000
    jmp label1
    mov ax, 0xcccc
    mov dx, 0xcccc
    push es
    push cs
    pop es
    cld
    int 0x86
    add di, 0x0014
    int 0x86
    pop es
    ret
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    mov cx, 0x3f7a
    push es
    pop ds
    call word [0x0000]
    push ax
    add ax, 0x0130
    stosw
    pop ax
    push ax
    add ax, 0x0130
    jmp ax
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    pop ax
    push es
    pop ds
    mov [0x0044], ax
    add ax, 0x0130
    push ax
    mov bx, 0x0050
    sub ax, 0x0010
    mov [bx], ax
    mov dx, cs
    inc dx
    mov [bx+0x02], dx
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0214
    call prcd1
    push cs
    pop ss
    mov sp, [0x0044]
    jmp label1
    nop
    mov sp, [0x0044]
    mov ax, [0x0060]
    mov [0x0050], ax
    call far [bx]
label1:
    mov di, [0x0000]
    add di, 0x0000
    call prcd1
    add di, 0x0214
    mov ax, 0xcccc
    mov si, [0x0000]
    sub si, 0x0000
    sub si, 0x0010
    push cs
    pop es
    mov cx, 0x3f7a
    rep stosw
    mov dx, [0x0050]
    mov [0x0060], dx
    mov [0x0050], si
    add di, 0x8000
    jmp label1
prcd1:
    mov ax, 0xcccc
    mov dx, 0xcccc
    push es
    push cs
    pop es
    cld
    int 0x86
    add di, 0x0014
    int 0x86
    pop es
    ret
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]
    nop
    nop
    call far [bx]