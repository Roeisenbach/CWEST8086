    add ax, 0x00d1
    mov dl, 0x0c
    push dx
    jmp ax
    int3
    int3
    int3
    mov dx, 0x0314
    push dx
    mov dx, 0x0280
    mov bx, [bx]
    db 0x83, 0xC0, 0x11 ;$1 add ax, 0x0011
    mov [bx-0x20], ax
    jmp bx
    les ax, [bx+di]
    xlatb
    movsw
    dec di
    xor si, si
    dec cx
    jz label1
    call far [bx]
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    movsw
    sub [bx], bp
    mov sp, [bx]
    mov di, [bx]
    add di, di
    pop ds
label1:
    push ss
    pop ds
    mov bx, 0x0200
    mov [bx], ax
    mov word [bx+0x02], 0x1002
    pop ax
    pop dx
    push cs
    pop ss
    xor si, si
    mov sp, ax
    mov di, ax
    cmp cx, si
    jnz label2
    add sp, [bx]
    les di, [bx]
    add di, dx
    inc di
    cmp dl, 0x0c
    jnz label2
    mov bp, [bx]
    mov word [bp+0x20], 0x1fff
label2:
    mov bp, 0x3200
    call far [bx]
    nop
    int3
    int3
    int3
    mov dx, 0x0314
    push dx
    mov dx, 0x0280
    mov bx, [bx]
    db 0x83, 0xC0, 0x11 ;$1 add ax, 0x0011
    mov [bx-0x20], ax
    jmp bx
    les ax, [bx+di]
    xlatb
    movsw
    dec di
    xor si, si
    dec cx
    jz label3
    call far [bx]
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    movsw
    sub [bx], bp
    mov sp, [bx]
    mov di, [bx]
    add di, di
    pop ds
label3:
    push ss
    pop ds
    mov bx, 0x0200
    mov [bx], ax
    mov word [bx+0x02], 0x1002
    pop ax
    pop dx
    push cs
    pop ss
    xor si, si
    mov sp, ax
    mov di, ax
    cmp cx, si
    jnz label4
    add sp, [bx]
    les di, [bx]
    add di, dx
    inc di
    cmp dl, 0x0c
    jnz label4
    mov bp, [bx]
    mov word [bp+0x20], 0x1fff
label4:
    mov bp, 0x3200
    call far [bx]
    nop
    int3
    int3
    int3
    mov dx, 0x0314
    push dx
    mov dx, 0x0280
    mov bx, [bx]
    db 0x83, 0xC0, 0x11 ;$1 add ax, 0x0011
    mov [bx-0x20], ax
    jmp bx
    les ax, [bx+di]
    xlatb
    movsw
    dec di
    xor si, si
    dec cx
    jz label5
    call far [bx]
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    movsw
    sub [bx], bp
    mov sp, [bx]
    mov di, [bx]
    add di, di
    pop ds
label5:
    push ss
    pop ds
    mov bx, 0x0200
    mov [bx], ax
    mov word [bx+0x02], 0x1002
    pop ax
    pop dx
    push cs
    pop ss
    xor si, si
    mov sp, ax
    mov di, ax
    cmp cx, si
    jnz label6
    add sp, [bx]
    les di, [bx]
    add di, dx
    inc di
    cmp dl, 0x0c
    jnz label6
    mov bp, [bx]
    mov word [bp+0x20], 0x1fff
label6:
    mov bp, 0x3200
    call far [bx]
    nop
    int3
    int3
    int3
    mov dx, 0x0314
    push dx
    mov dx, 0x0280
    mov bx, [bx]
    db 0x83, 0xC0, 0x11 ;$1 add ax, 0x0011
    mov [bx-0x20], ax
    jmp bx
    les ax, [bx+di]
    xlatb
    movsw
    dec di
    xor si, si
    dec cx
    jz label7
    call far [bx]
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    movsw
    sub [bx], bp
    mov sp, [bx]
    mov di, [bx]
    add di, di
    pop ds
label7:
    push ss
    pop ds
    mov bx, 0x0200
    mov [bx], ax
    mov word [bx+0x02], 0x1002
    pop ax
    pop dx
    push cs
    pop ss
    xor si, si
    mov sp, ax
    mov di, ax
    cmp cx, si
    jnz label8
    add sp, [bx]
    les di, [bx]
    add di, dx
    inc di
    cmp dl, 0x0c
    jnz label8
    mov bp, [bx]
    mov word [bp+0x20], 0x1fff
label8:
    mov bp, 0x3200
    call far [bx]
    nop
    int3
    int3
    int3
    mov dx, 0x0314
    push dx
    mov dx, 0x0280
    mov bx, [bx]
    db 0x83, 0xC0, 0x11 ;$1 add ax, 0x0011
    mov [bx-0x20], ax
    jmp bx
    les ax, [bx+di]
    xlatb
    movsw
    dec di
    xor si, si
    dec cx
    jz label9
    call far [bx]
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    movsw
    sub [bx], bp
    mov sp, [bx]
    mov di, [bx]
    add di, di
    pop ds
label9:
    push ss
    pop ds
    mov bx, 0x0200
    mov [bx], ax
    mov word [bx+0x02], 0x1002
    pop ax
    pop dx
    push cs
    pop ss
    xor si, si
    mov sp, ax
    mov di, ax
    cmp cx, si
    jnz label10
    add sp, [bx]
    les di, [bx]
    add di, dx
    inc di
    cmp dl, 0x0c
    jnz label10
    mov bp, [bx]
    mov word [bp+0x20], 0x1fff
label10:
    mov bp, 0x3200
    call far [bx]
    nop