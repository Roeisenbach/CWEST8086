    mov si, ax
    push cs
    pop es
    mov dx, 0x88b9
    mov ax, 0x0000
    mov cx, 0xcccc
    mov bx, cx
    int 0x87
    mov bx, si
    push ds
    pop es
    push ds
    pop ss
    mov ax, 0xab50
    mov sp, bx
    add bx, word 0x0013
    mov di, bx
    stosw
    db 0xE9, 0xED, 0xFF ;$1 jmp 19