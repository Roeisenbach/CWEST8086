    jmp label1
    nop
    mov cx, es
    mov word [0x1dfb], 0x1dff
    mov word [0x1dfd], 0x1dff
    mov word [0x1dff], 0x1dff
    mov ds, cx
    mov di, 0x0002
    push cs
    pop ss
    mov sp, 0x0005
    mov word [di], 0x1dfd
    mov [di+0x02], cs
    call far [di]
    mov cx, es
label1:
    std
    push ax
    push es
    push cs
    pop es
    mov ax, 0x4fab
    mov dx, 0x1fff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop es
    pop ax
    cld
    mov cx, es
    mov word [0x1dfb], 0x1dff
    mov word [0x1dfd], 0x1dff
    mov word [0x1dff], 0x1dff
    mov ds, cx
    mov di, 0x0002
    push cs
    pop ss
    mov sp, 0x0005
    mov word [di], 0x1dfd
    mov [di+0x02], cs
    call far [di]
    call far [di]
    mov cx, es
    mov word [0x1dfb], 0x1dff
    mov word [0x1dfd], 0x1dff
    mov word [0x1dff], 0x1dff
    mov ds, cx
    mov di, 0x0002
    push cs
    pop ss
    mov sp, 0x0005
    mov word [di], 0x1dfd
    mov [di+0x02], cs
    call far [di]