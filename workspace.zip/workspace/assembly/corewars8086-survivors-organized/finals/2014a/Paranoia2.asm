    mov si, 0x95d0
    jmp label2
    xor di, di
    mov ax, 0x5350
    mov dx, 0xd4ff
    mov bx, 0x6060
    mov cx, 0x6060
    pop es
    call prcd2
    pop bx
    call prcd3
    add word [bx-0x008e], 0x0060
    add word [bx-0x22], 0x0010
    add word [bx+0x02], 0x0074
    mov cx, 0x0007
    lea si, [bx+0x6a]
    rep movsw
    lea ax, [si+0x5d]
    mov dx, 0x1000
    mov di, 0x0280
    int 0x86
    push es
    pop ds
    movsw
    movsw
    movsw
    movsw
    mov di, [bx+si+0x01]
    sub di, cx
    movsb
    call far [bx+si]
    jmp label6
    int3
label1:
    jmp $
    nop
    nop
    jmp label1
    int3
    int3
    int3
    mov si, 0x95d0
    mov cx, 0x000c
    mov [si+0x02], dx
    mov word [si], 0xffff
loop1:
    test [si+0x02], si
    loopz loop1
    mov cx, 0x000c
    mov word [si], 0xffff
    mov [si+0x02], dx
loop2:
    test [si+0x02], si
    loopz loop2
label2:
    mov di, 0x8000
    mov [si], di
    mov bp, di
    mov ax, 0x4000
    add di, ax
    mov [si+0x02], dx
    mov cl, 0x07
    cmp [si+0x02], bp
    jb label3
    sub di, bp
    mov [si], di
    dec cx
loop3:
    shr ax, 1
    add di, ax
    mov [si+0x02], dx
    sar bp, 1
    cmp [si+0x02], bp
    jb label3
    add di, bp
label3:
    mov [si], di
    loop loop3
    mov [si+0x02], dx
    call prcd1
prcd1:
    pop bx
    add di, 0x0016
    nop
    nop
    cmp [si+0x02], ax
    jb label4
    sub di, 0x0100
label4:
    sub word [bx-0x55], 0x0020
    lea ax, [bx-0x56]
    mov [0x4848], ax
    mov ax, 0x4848
    mov dx, 0x16ff
    push es
    push ds
    pop es
    cld
    int 0x86
    xor di, di
    mov ax, 0x5350
    mov dx, 0xd4ff
    mov bx, 0x6060
    mov cx, 0x6060
    int 0x87
    pop es
    call prcd2
prcd2:
    pop bx
    call prcd3
prcd3:
    add word [bx-0x008e], 0x0060
    add word [bx-0x22], 0x0010
    add word [bx+0x02], 0x0074
    mov cx, 0x0007
    lea si, [bx+0x6a]
    rep movsw
    lea ax, [si+0x5d]
    mov dx, 0x1000
    mov di, 0x0280
    int 0x86
    push es
    pop ds
    push cs
    pop es
    push cs
    pop ss
    lea sp, [si+0x5d]
    mov di, 0x00f8
    mov bx, 0x0010
label5:
    mov word [bx+di], 0xec29
    sub di, 0x0008
    jnb label5
    mov bx, 0x0271
    mov bp, 0xa774
    mov si, 0x000e
    mov cx, 0x0000
    mov dx, 0x0278
    mov di, sp
    mov word [0x0276], 0x0077
    mov byte [0x0278], 0x10
    mov cl, 0x80
    loop $
    sub di, 0x0004
    mov ax, 0x9090
    stosw
    stosw
    movsb
    mov ax, 0x0008
    call far [bx+si]
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov di, [bx+si+0x01]
    sub di, cx
    movsb
    call far [bx+si]
    mov cx, 0x2104
    add word [bx+0x79], 0x4208
    sub word [bx+0x0087], 0x0120
    mov si, 0x0398
    push cs
    pop ss
    push es
    brk
label6:
    add word [bx+0x008d], 0x0020
    add word [0x4848], 0x0075
    mov word [bx-0x11], 0xa552
    mov word [bx-0x0e], 0xcccc
    mov dx, 0x1000
    lea ax, [bx+0x010e]
    mov di, 0x0280
    int 0x86
    pop ds
    push cs
    pop es
    mov dx, si
    mov byte [si], 0x10
    mov word [si-0x02], 0x0072
    mov sp, [0x0280]
    mov bp, 0xa774
    mov ax, 0x0008
    mov bx, 0x0271
    sub sp, cx
    mov si, 0x000f
    mov di, sp
    call far [bx+si]
label7:
    jmp $
    nop
    nop
    jmp label7
    int3
    int3
    int3