    nrg
    nrg
    nrg
    nrg
    push es
    pop ds
    lodsw
    jmp ax