    push cs
    pop es
    push cs
    pop ss
    mov [0xfffc], ax
    mov si, 0x0030
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    mov bp, ax
    std
    mov ax, 0xf4e2
    mov dx, 0xa0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, bp
    jmp label7
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x006a
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xb0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    cld
    mov ax, [0xfffc]
    push cs
    pop ss
    mov sp, ax
    inc sp
    mov bx, 0xa505
label1:
    push bx
    sub sp, 0x00fe
    jmp label1
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x00a5
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xc0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0002
    mov bx, 0xcccc
label2:
    push bx
    sub sp, 0x00fe
    jmp label2
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x00de
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xd0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    push cs
    pop ss
    mov sp, ax
    inc sp
    mov bx, 0xa505
label3:
    push bx
    sub sp, 0x00fe
    jmp label3
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x0117
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xe0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    push cs
    pop ss
    mov sp, ax
    inc sp
    mov bx, 0xa505
label4:
    push bx
    sub sp, 0x00fe
    jmp label4
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x0153
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xf0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x7000
    mov bx, 0xa505
label5:
    push bx
    sub sp, 0x00fe
    jmp label5
    mov ax, [0xfffc]
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x8200
    mov bx, 0xa505
label6:
    push bx
    sub sp, 0x00fe
    jmp label6
label7:
    cld
    push cs
    pop es
    push cs
    pop ss
    mov sp, ax
    add sp, 0x018b
    sub sp, 0x0404
    mov si, ax
    add si, 0x018b
    mov dx, 0xffff
    mov [si+0x0200], dl
    mov [si-0x0200], dl
    mov bx, 0xcccc
label8:
    push bx
    cmp [si+0x0200], dl
    jnz label9
    cmp [si-0x0200], dl
    jnz label9
    jmp label8
label9:
    mov di, si
    add di, 0x0400
    mov cx, 0x0028
loop1:
    movsw
    loop loop1
    add si, 0x03b0
    mov [si+0x0200], dl
    mov [si-0x0200], dl
    jmp si