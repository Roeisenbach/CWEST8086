    push cs
    pop es
    push cs
    pop ss
    mov [0xfffc], ax
    mov si, 0x002e
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    mov bp, ax
    std
    mov ax, 0xf4e2
    mov dx, 0xa0be
    mov cx, 0xffff
    mov bx, 0x16ff
    mov ax, bp
    jmp label1
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x006c
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xb0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    db 0x83, 0xC0, 0x6A ;$1 add ax, 0x006a
    push es
    pop ds
    mov bx, 0x04b0
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, 0x044c
    call far [bx]
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x00af
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xc0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    add ax, 0x00ad
    push es
    pop ds
    mov bx, 0x04ab
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, 0x044c
    mov cx, 0x03e8
    loop $
    call far [bx]
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x00f2
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xd0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    add ax, 0x00f0
    push es
    pop ds
    mov bx, 0x04a6
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, 0x044c
    mov cx, 0x07d0
    loop $
    call far [bx]
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x0135
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xe0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    add ax, 0x0133
    push es
    pop ds
    mov bx, 0x049c
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, 0x044c
    mov cx, 0x0bb8
    loop $
    call far [bx]
    push cs
    pop es
    mov ax, [0xfffc]
    mov si, 0x017b
    add si, ax
    mov bl, 0xea
    mov [0xcccc], bl
    mov [0xcccd], si
    mov [0xcccf], cs
    std
    mov ax, 0xf4e2
    mov dx, 0xf0be
    mov cx, 0xffff
    mov bx, 0x16ff
    int 0x87
    mov ax, [0xfffc]
    mov cx, 0x0258
    add ax, 0x0179
    push es
    pop ds
    mov bx, 0x0492
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, 0x044c
    mov cx, 0x0fa0
    loop $
    call far [bx]
    mov ax, [0xfffc]
    add ax, 0x0195
    push es
    pop ds
    mov bx, 0x047e
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, 0x044c
    mov cx, 0x1388
    loop $
    call far [bx]
label1:
    cld
    push cs
    pop es
    push cs
    pop ss
    mov sp, ax
    add sp, 0x01ba
    sub sp, 0x0404
    mov si, ax
    add si, 0x01ba
    mov dx, 0xffff
    mov [si+0x0200], dl
    mov [si-0x0200], dl
    mov bx, 0xcccc
label2:
    push bx
    cmp [si+0x0200], dl
    jnz label3
    cmp [si-0x0200], dl
    jnz label3
    jmp label2
label3:
    mov di, si
    add di, 0x0400
    mov cx, 0x0028
loop1:
    movsw
    loop loop1
    add si, 0x03b0
    mov di, si
    mov [si+0x0200], dl
    mov [si-0x0200], dl
    jmp si