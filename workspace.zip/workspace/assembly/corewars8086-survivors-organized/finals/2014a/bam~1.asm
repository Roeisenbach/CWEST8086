    jmp label1
    push cs
    pop ss
    mov sp, ax
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    call ax
label1:
    db 0x83, 0xC0, 0x02 ;$1 add ax, 0x0002
    stosw
    mov si, ax
    add si, 0x001f
    mov di, si
    add di, 0x0100
    push cs
    pop es
    push cs
    pop ss
    mov bx, 0x0100
    mov cx, di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov si, cx
    add di, bx
    jmp si