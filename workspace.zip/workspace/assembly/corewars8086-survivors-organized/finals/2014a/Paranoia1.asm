    mov si, 0x95c0
    jmp label4
    sub di, 0x0100
    sub word [bx-0x55], 0x0020
    lea ax, [bx-0x56]
    mov [0x4e4e], ax
    mov ax, 0x4e4e
    mov dx, 0x16ff
    push es
    push ds
    pop es
    cld
    int 0x86
    xor di, di
    mov ax, 0x18ff
    mov dx, 0xcccc
    mov bx, 0x6060
    mov cx, 0x6060
    int 0x87
    pop es
    call prcd1
prcd1:
    pop bx
    call prcd2
prcd2:
    movsw
    dec ax
    movsw
    movsw
    movsw
    jz label1
    xor si, si
label1:
    movsw
    movsw
    movsw
    jnz label2
    int3
label2:
    movsw
    movsw
    mov al, 0x08
    movsw
    movsw
    movsw
    movsw
    mov si, 0x0100
label3:
    sub word [bx+si], 0x1a00
    sub si, [bx]
    jnz label3
    xchg bx, dx
    movsw
    jmp label11
    int3
    int3
    int3
    mov si, 0x95c0
    mov cx, 0x000c
    mov [si+0x02], dx
    mov word [si], 0xffff
loop1:
    test [si+0x02], si
    loopz loop1
    mov cx, 0x000c
    mov word [si], 0xffff
    mov [si+0x02], dx
loop2:
    test [si+0x02], si
    loopz loop2
label4:
    mov di, 0x8000
    mov [si], di
    mov bp, di
    mov ax, 0x4000
    add di, ax
    mov [si+0x02], dx
    mov cl, 0x07
    cmp [si+0x02], bp
    jb label5
    sub di, bp
    mov [si], di
    dec cx
loop3:
    shr ax, 1
    add di, ax
    mov [si+0x02], dx
    sar bp, 1
    cmp [si+0x02], bp
    jb label5
    add di, bp
label5:
    mov [si], di
    loop loop3
    mov [si+0x02], dx
    call prcd3
prcd3:
    pop bx
    add di, 0x0016
    nop
    nop
    cmp [si+0x02], ax
    jb label6
    sub di, 0x0100
label6:
    sub word [bx-0x55], 0x0020
    lea ax, [bx-0x56]
    mov [0x4e4e], ax
    mov ax, 0x4e4e
    mov dx, 0x16ff
    push es
    push ds
    pop es
    cld
    int 0x86
    xor di, di
    mov ax, 0x18ff
    mov dx, 0xcccc
    mov bx, 0x6060
    mov cx, 0x6060
    int 0x87
    pop es
    call prcd4
prcd4:
    pop bx
    call prcd5
prcd5:
    add word [bx-0x008e], 0x0060
    add word [bx-0x22], 0x0010
    add word [bx+0x02], 0x0098
    mov di, 0x000e
    mov dx, 0x18ff
    mov ax, 0xa5a5
    int 0x86
    add di, 0xfffc
    mov cx, 0x001d
    lea si, [bx+0x63]
    rep movsw
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov di, 0x00f8
    mov bx, 0x0280
label7:
    add [bx+di], di
    sub di, 0x0008
    jnz label7
    mov ax, 0x0008
    mov bp, 0xa774
    mov cx, 0xe71c
    mov sp, [0x0280]
    mov bx, 0x0271
    sub sp, cx
    mov di, sp
    mov si, 0x000e
    mov byte [0x0270], 0x10
    mov dx, 0x0270
    movsb
    mov word [0x026e], 0x0077
    call far [bx+si]
    movsw
    dec ax
    movsw
    movsw
    movsw
    movsw
    jz label8
    xor si, si
label8:
    movsw
    movsw
    xchg bx, dx
    movsw
    movsw
    movsw
    dec word [bx-0x02]
    movsw
    movsw
    movsw
    jnz label9
    int3
label9:
    movsw
    movsw
    mov al, 0x08
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov si, 0x0100
label10:
    sub word [bx+si], 0x1a00
    sub si, [bx]
    jnz label10
    xchg bx, dx
    movsw
    mov cx, 0x4208
    add word [bx+0x009d], 0x4208
    sub word [bx+0x00ac], 0x0120
    mov dx, 0x0390
    push cs
    pop ss
    push es
    brk
label11:
    mov word [bx-0x11], 0xcca5
    add word [0x4e4e], 0x0075
    add word [bx+0x00b2], 0x001e
    mov si, 0x00f8
    mov bx, 0x0280
    pop ds
label12:
    add [bx+si], si
    sub si, 0x0008
    jnz label12
    push ds
    pop ds
    mov bx, dx
    mov byte [bx], 0x10
    mov word [bx-0x02], 0x0072
    push cs
    pop ss
    mov bp, 0xa774
    mov ax, 0x0008
    mov sp, [0x0280]
    sub sp, cx
    mov bx, 0x0271
    mov si, 0x000f
    mov di, sp
    call far [bx+si]