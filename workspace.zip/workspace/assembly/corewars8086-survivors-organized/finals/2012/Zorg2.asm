    jmp label1
    mov si, ax
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0x0789
    mov dx, 0xfeeb
    int 0x87
    pop es
    mov dx, si
    mov bp, 0x17a8
    mov cx, 0x03f3
    mov ax, 0xab53
    mov bx, 0xcca5
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    mov si, ax
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0x0789
    mov dx, 0xfeeb
    int 0x87
    pop es
    mov dx, si
    mov bp, 0x17a8
    mov cx, 0x03f3
    mov ax, 0xab53
    mov bx, 0xcca5
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
label1:
    mov si, ax
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0x0789
    mov dx, 0xfeeb
    int 0x87
    pop es
    mov dx, si
    mov bp, 0x17a8
    mov cx, 0x03f3
    mov ax, 0xab53
    mov bx, 0xcca5
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    mov si, ax
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0x0789
    mov dx, 0xfeeb
    int 0x87
    pop es
    mov dx, si
    mov bp, 0x17a8
    mov cx, 0x03f3
    mov ax, 0xab53
    mov bx, 0xcca5
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    mov si, ax
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0x0789
    mov dx, 0xfeeb
    int 0x87
    pop es
    mov dx, si
    mov bp, 0x17a8
    mov cx, 0x03f3
    mov ax, 0xab53
    mov bx, 0xcca5
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx