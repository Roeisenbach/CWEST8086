    jmp label2
label1:
    mov cx, 0x0018
loop1:
    movsw
    loop loop1
    mov si, 0xd8ce
    call si
label2:
    push cs
    pop es
    push cs
    pop ss
    mov sp, 0xa57f
    mov bx, ax
    db 0x83, 0xC0, 0x31 ;$1 add ax, 0x0031
    mov si, ax
    mov di, 0xd8ce
    mov ax, 0xd8ce
    db 0x83, 0xC0, 0x03 ;$1 add ax, 0x0003
    add bx, 0x005d
    mov [bx], ax
    mov [bx+0x02], cs
    mov dx, 0x0000
    jmp label1
    mov cx, 0x0400
    dec cx
    cmp cx, dx
    jz label4
label3:
    call far [bx]
label4:
    mov si, ax
    mov di, sp
    add di, 0x0fc3
    mov bp, di
    mov cx, 0x0018
    rep movsw
    sub sp, 0x1000
    mov cx, 0x0400
    mov bx, bp
    add bx, 0x002c
    mov [bx], bp
    mov [bx+0x02], cs
    jmp label3
    mov ax, ax
    mov ax, ax