    jmp label3
label1:
    push di
    mov ax, 0xcccc
    mov cx, 0x154c
loop1:
    stosw
    add di, 0x0004
    loop loop1
    pop di
    add di, 0x0002
    jmp label1
    pop ds
    sub bx, 0x0002
    mov di, bx
    std
label2:
    push di
    mov ax, 0xcccc
    mov cx, 0x154c
loop2:
    stosw
    sub di, 0x0004
    loop loop2
    pop di
    sub di, 0x0002
    jmp label2
label3:
    push ds
    push es
    push cs
    pop es
    push ax
    xor di, di
    mov ax, 0x0f88
    mov dx, 0xc383
    mov cx, 0xcccc
    mov bx, cx
    int 0x87
    pop di
    add di, 0x0600
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    xor di, di
    pop ds
    lodsw
    mov bx, ax
    jmp ax