    db 0x83, 0xC0, 0x21 ;$1 add ax, 0x0021
    mov dx, ax
    add dx, 0x000e
    add dx, 0x000a
    mov cx, ax
    sub cx, 0x0004
    push cs
    pop ss
    mov bx, ax
    add bx, 0x0029
    add bx, 0x0002
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    cmp sp, dx
    jnz label1
    sub sp, 0x0100
label1:
    call far [bx]
    mov ax, ax
    mov ax, ax