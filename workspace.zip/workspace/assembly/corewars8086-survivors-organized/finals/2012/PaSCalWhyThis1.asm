    nrg
    nrg
    nrg
    db 0x83, 0xC0, 0x30 ;$1 add ax, 0x0030
    push cs
    pop es
    mov di, ax
    mov ax, 0xcccc
    cld
    mov cx, 0x7d00
    rep stosw
    nrg
    db 0x83, 0xE8, 0x31 ;$1 sub ax, 0x0031
    push cs
    pop es
    mov di, ax
    mov ax, 0xcccc
    std
    mov cx, 0x7d00
    rep stosw