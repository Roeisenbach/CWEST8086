    mov bp, ax
    lea si, [bp+0x0082]
    mov [0x0000], si
    mov ax, 0x0789
    mov dx, 0xfeeb
    mov bx, 0x26ff
    push es
    push ds
    pop es
    std
    int 0x87
    cld
    pop es
    lea si, [bp+0x54]
    mov cx, 0x0017
    rep movsw
    lea di, [bp+0x0682]
    mov cx, 0x0005
    push es
    push cs
    mov word [0x1dfd], 0xcccc
    pop es
    pop ds
    mov [0x0200], di
    mov [0x0202], cs
    push cs
    pop ss
    lea sp, [bp-0x03ee]
    mov si, 0x0000
    sub di, 0x0004
    lea bp, [bp+0x067e]
    rep movsw
    mov cx, 0x0100
    jmp bp
loop1:
    mov bp, 0x1eff
    add [bp+si], al
    loop loop1+1
    movsw
    movsw
    movsw
    mov cx, 0x0010
    rep movsw
    lea di, [bp+0x062e]
    mov [0x0200], di
    add di, 0xfffc
    mov cx, 0x0004
    mov si, 0x0000
    lea bp, [bp+0x062a]
    lea sp, [bp-0x03ee]
    rep movsw
    mov cx, 0x0100
    jmp bp
    call prcd1
prcd1:
    pop bp
    lea si, [bp-0x31]
    mov cx, 0x0017
    rep movsw
    lea di, [bp+0x0e82]
    mov cx, 0x0005
    push es
    push cs
    pop es
    pop ds
    mov [0x0200], di
    mov [0x0202], cs
    push cs
    pop ss
    lea sp, [bp-0x0bee]
    mov si, 0x0000
    sub di, 0x0004
    lea bp, [bp+0x0e7e]
    rep movsw
    mov cx, 0x0100
    jmp bp