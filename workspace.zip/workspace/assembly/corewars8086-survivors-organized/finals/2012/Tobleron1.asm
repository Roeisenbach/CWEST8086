    mov bx, ax
    add bx, 0x0045
    mov dx, [bx]
    mov ax, 0xe24f
    stosw
    push cs
    pop ss
    push cs
    pop es
    push ds
    pop es
    mov di, 0x1cf2
    int 0x86
    mov di, 0x2d23
    int 0x86
    mov sp, 0xe249
    mov bx, 0x1fff
    mov cx, 0xcccc
    mov [bx], cx
    mov bx, 0x1dff
    mov [bx], cx
    mov di, 0xe24b
    mov ax, 0xe24f
    mov cx, 0x1dff
    mov [di], ax
    mov [di+0x02], cs
    mov [di+0x04], dx
    mov [di+0x06], cx
    mov [di+0x08], cx
    mov bp, 0x0010
    sub sp, bp
    call far [di]