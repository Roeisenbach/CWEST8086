    push es
    pop ds
    push cs
    pop es
    push cs
    pop ss
    jmp label1
    lodsw
    movsb
label1:
    mov bp, ax
    lodsw
    db 0x83, 0xC0, 0x04 ;$1 add ax, 0x0004
    mov bx, ax
    push cs
    pop ds
    mov cx, 0x000a
loop1:
    nrg
    loop loop1
    mov si, bx
    mov di, si
    inc di
    cld
    add bp, 0x002d
    mov ax, [bp+0x00]
    mov [bx], ax
    jmp bx
    movsb