    jmp label2
    add si, 0x00b4
    mov cx, 0x0006
    movsb
    rep movsw
    add si, 0x0060
    mov cx, 0x000b
    rep movsw
    mov bp, 0x00ff
    jmp label4
    movsw
    movsw
    movsw
    add dx, 0x17a8
    movsw
    dec bp
    movsw
    movsw
    jz label1
    mov si, ax
    nop
    add ax, 0x0095
    mov byte [0x0000], 0xbe
    mov [0x0001], si
label1:
    mov word [0x0003], 0xc289
    mov byte [0x0005], 0xe9
    mov [0x0006], ax
    nop
    nop
    nop
    nop
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0xcccc
    mov dx, 0xffcc
    int 0x87
    pop es
    mov dx, si
    add si, 0x011e
    mov cx, 0x000d
    rep movsw
    mov bp, 0x17a8
    mov cx, 0x03f3
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0xab53
    mov bx, 0xcca5
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    movsw
    add dx, bp
    movsw
    movsw
    mov sp, dx
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, dx
    stosw
    jmp dx
    add si, 0x00b4
    mov cx, 0x0006
    movsb
    rep movsw
    add si, 0x0060
    mov cx, 0x000b
    rep movsw
    mov bp, 0x00ff
    jmp label4
    movsw
    movsw
    movsw
    add dx, 0x17a8
    movsw
    dec bp
    movsw
    movsw
    jz label3
label2:
    mov si, ax
    nop
    add ax, 0x0095
    mov byte [0x0000], 0xbe
    mov [0x0001], si
label3:
    mov word [0x0003], 0xc289
    mov byte [0x0005], 0xe9
    mov [0x0006], ax
    nop
    nop
    nop
    nop
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0xcccc
    mov dx, 0xffcc
    int 0x87
    pop es
    mov dx, si
    add si, 0x011e
    mov cx, 0x000d
    rep movsw
    mov bp, 0x17a8
label4:
    mov cx, 0x03f3
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0xab53
    mov bx, 0xcca5
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    movsw
    add dx, bp
    movsw
    movsw
    mov sp, dx
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, dx
    stosw
    jmp dx
    add si, 0x00b4
    mov cx, 0x0006
    movsb
    rep movsw
    add si, 0x0060
    mov cx, 0x000b
    rep movsw
    mov bp, 0x00ff
    jmp label4
    movsw
    movsw
    movsw
    add dx, 0x17a8
    movsw
    dec bp
    movsw
    movsw
    jz label5
    mov si, ax
    nop
    add ax, 0x0095
    mov byte [0x0000], 0xbe
    mov [0x0001], si
label5:
    mov word [0x0003], 0xc289
    mov byte [0x0005], 0xe9
    mov [0x0006], ax
    nop
    nop
    nop
    nop
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0xcccc
    mov dx, 0xffcc
    int 0x87
    pop es
    mov dx, si
    add si, 0x011e
    mov cx, 0x000d
    rep movsw
    mov bp, 0x17a8
    mov cx, 0x03f3
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0xab53
    mov bx, 0xcca5
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    movsw
    add dx, bp
    movsw
    movsw
    mov sp, dx
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, dx
    stosw
    jmp dx