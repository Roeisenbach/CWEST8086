    jmp label2
label1:
    mov cx, 0x0018
    rep movsw
    mov si, 0xde54
    call si
label2:
    push cs
    pop es
    push cs
    pop ss
    mov sp, 0x557f
    mov bx, ax
    db 0x83, 0xC0, 0x30 ;$1 add ax, 0x0030
    mov si, ax
    mov di, 0xde54
    mov ax, 0xde54
    db 0x83, 0xC0, 0x03 ;$1 add ax, 0x0003
    add bx, 0x005c
    mov [bx], ax
    mov [bx+0x02], cs
    mov dx, 0x0000
    jmp label1
    mov cx, 0x0400
    dec cx
    cmp cx, dx
    jz label4
label3:
    call far [bx]
label4:
    mov si, ax
    mov di, sp
    add di, 0x0fc3
    mov bp, di
    mov cx, 0x0019
    rep movsw
    sub sp, 0x1000
    mov cx, 0x0390
    mov bx, bp
    add bx, 0x002c
    mov [bx], bp
    mov [bx+0x02], cs
    jmp label3
    mov ax, ax
    mov ax, ax