    db 0x83, 0xC0, 0x10 ;$1 add ax, 0x0010
    push cs
    pop es
    mov di, ax
    mov ax, 0xcccc
    cld
    mov cx, 0x7d00
    rep stosw
    nrg
    db 0x83, 0xE8, 0x11 ;$1 sub ax, 0x0011
    push cs
    pop es
    mov di, ax
    mov ax, 0xcccc
    std
    mov cx, 0x7d00
    rep stosw