    add ax, 0x0012
    db 0x8B, 0xE8 ;$1 mov bp, ax
    mov cx, 0x0044
    db 0x8B, 0xF5 ;$1 mov si, bp
    db 0x33, 0xFF ;$1 xor di, di
    rep movsw
    push es
    call prcd1
    mov cx, 0x001e
    mov si, 0x004d
    lea di, [bp-0x01e5]
    rep movsw
    mov cx, 0x001e
    mov si, 0x004d
    lea di, [bp+0x021b]
    rep movsw
    call prcd1
label1:
    mov cx, 0x001e
    lea si, [bp-0x01e5]
    mov di, 0x004d
    rep cmpsw
    jnz label2
    mov cx, 0x001e
    lea si, [bp+0x021b]
    mov di, 0x004d
    rep cmpsw
    jnz label3
    jmp label1
label2:
    add bp, 0x021b
    jmp bp
label3:
    sub bp, 0x01e5
    add bp, 0x001e
    jmp bp
prcd1:
    push es
    push ds
    pop es
    pop ds
    ret
    push cs
    pop es
    pop ds
    push ds
    std
    mov cx, 0x0100
    lea di, [bp-0x0200]
    rep stosw
    cld
    mov cx, 0x0027
    db 0x33, 0xF6 ;$1 xor si, si
    add bp, 0xfbe5
    db 0x8B, 0xFD ;$1 mov di, bp
    rep movsw
    jmp bp
    push cs
    pop es
    pop ds
    push ds
    mov cx, 0x0100
    lea di, [bp+0x0200]
    rep stosw
    mov cx, 0x0027
    db 0x33, 0xF6 ;$1 xor si, si
    add bp, 0x03c7
    db 0x8B, 0xFD ;$1 mov di, bp
    rep movsw
    jmp bp