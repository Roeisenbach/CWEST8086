    jmp label2
    add ax, 0x00fe
    mov si, ax
    push es
    push ds
    pop es
    db 0x83, 0xC0, 0x46 ;$1 add ax, 0x0046
    mov [0xdead], ax
    mov ax, 0x86cd
    mov dx, 0x86cd
    mov bx, 0x26ff
    mov cx, 0xdead
    std
    int 0x87
    cld
    pop es
    mov bx, ss
    mov [si+0x21], bx
    mov bx, si
    mov ax, 0xa550
    push ss
    pop es
    add di, 0x0700
    mov cx, 0x0046
    rep movsw
    xor di, di
    mov dx, ax
    int 0x86
    mov cx, 0x0280
    int 0x86
    rep stosw
    push ss
    push cs
    pop es
    pop ds
    push cs
    pop ss
    xor si, si
    mov sp, bx
    mov di, bx
    and di, 0xfffe
    movsw
    nop
    movsw
    movsw
    mov cx, 0x1000
    movsw
    movsw
    mov ss, cx
    movsw
    movsw
    movsw
    and sp, 0xfffe
    movsw
    movsw
    movsw
    movsw
    sub sp, 0x8120
    movsw
    movsw
    movsw
    mov ax, 0xa550
    movsw
    movsw
    movsw
    mov cx, 0xdead
    movsw
    movsw
    movsw
    and dx, 0x003f
    movsw
    dec dx
    movsw
    movsw
    movsw
    movsw
    jnz label1
    mov ds, cx
label1:
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, 0xeb00
    movsw
    jmp -5225
    movsw
    xor si, si
    movsw
    call prcd1
prcd1:
    pop bx
    add bx, 0x0009
    and bx, 0xfffe
    jmp bx
    jmp bx
    int3
    int3
    int3
label2:
    add ax, 0x00fe
    mov si, ax
    push es
    push ds
    pop es
    db 0x83, 0xC0, 0x46 ;$1 add ax, 0x0046
    mov [0xdead], ax
    mov ax, 0x86cd
    mov dx, 0x86cd
    mov bx, 0x26ff
    mov cx, 0xdead
    std
    int 0x87
    cld
    pop es
    mov bx, ss
    mov [si+0x21], bx
    mov bx, si
    mov ax, 0xa550
    push ss
    pop es
    add di, 0x0700
    mov cx, 0x0046
    rep movsw
    xor di, di
    mov dx, ax
    int 0x86
    mov cx, 0x0280
    int 0x86
    rep stosw
    push ss
    push cs
    pop es
    pop ds
    push cs
    pop ss
    xor si, si
    mov sp, bx
    mov di, bx
    and di, 0xfffe
    movsw
    nop
    movsw
    movsw
    mov cx, 0x1000
    movsw
    movsw
    mov ss, cx
    movsw
    movsw
    movsw
    and sp, 0xfffe
    movsw
    movsw
    movsw
    movsw
    sub sp, 0x8120
    movsw
    movsw
    movsw
    mov ax, 0xa550
    movsw
    movsw
    movsw
    mov cx, 0xdead
    movsw
    movsw
    movsw
    and dx, 0x003f
    movsw
    dec dx
    movsw
    movsw
    movsw
    movsw
    jnz label3
    mov ds, cx
label3:
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, 0xeb00
    movsw
    jmp -5056
    movsw
    xor si, si
    movsw
    call prcd2
prcd2:
    pop bx
    add bx, 0x0009
    and bx, 0xfffe
    jmp bx
    jmp bx
    int3
    int3
    int3
    add ax, 0x00fe
    mov si, ax
    push es
    push ds
    pop es
    db 0x83, 0xC0, 0x46 ;$1 add ax, 0x0046
    mov [0xdead], ax
    mov ax, 0x86cd
    mov dx, 0x86cd
    mov bx, 0x26ff
    mov cx, 0xdead
    std
    int 0x87
    cld
    pop es
    mov bx, ss
    mov [si+0x21], bx
    mov bx, si
    mov ax, 0xa550
    push ss
    pop es
    add di, 0x0700
    mov cx, 0x0046
    rep movsw
    xor di, di
    mov dx, ax
    int 0x86
    mov cx, 0x0280
    int 0x86
    rep stosw
    push ss
    push cs
    pop es
    pop ds
    push cs
    pop ss
    xor si, si
    mov sp, bx
    mov di, bx
    and di, 0xfffe
    movsw
    nop
    movsw
    movsw
    mov cx, 0x1000
    movsw
    movsw
    mov ss, cx
    movsw
    movsw
    movsw
    and sp, 0xfffe
    movsw
    movsw
    movsw
    movsw
    sub sp, 0x8120
    movsw
    movsw
    movsw
    mov ax, 0xa550
    movsw
    movsw
    movsw
    mov cx, 0xdead
    movsw
    movsw
    movsw
    and dx, 0x003f
    movsw
    dec dx
    movsw
    movsw
    movsw
    movsw
    jnz label4
    mov ds, cx
label4:
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, 0xeb00
    movsw
    jmp -4887
    movsw
    xor si, si
    movsw
    call prcd3
prcd3:
    pop bx
    add bx, 0x0009
    and bx, 0xfffe
    jmp bx
    jmp bx