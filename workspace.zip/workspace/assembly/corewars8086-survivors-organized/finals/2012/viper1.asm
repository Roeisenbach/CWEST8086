    mov bx, ax
    add bx, 0x001e
    mov ax, 0xcccc
label1:
    mov cx, 0x0320
loop1:
    mov [bx], ax
    add bx, 0x0050
    loop loop1
    add bx, 0x0706
    jmp label1