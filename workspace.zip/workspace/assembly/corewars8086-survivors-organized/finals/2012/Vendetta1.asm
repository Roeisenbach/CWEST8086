    jmp label3
    pop di
    add di, 0x00d9
label1:
    push di
    mov ax, 0xcccc
    mov cx, 0x1f50
loop1:
    stosw
    add di, 0x0006
    loop loop1
    pop di
    add di, 0x0002
    jmp label1
    pop ds
    sub bx, 0x0006
    mov di, bx
    std
label2:
    push di
    mov ax, 0xcccc
    mov cx, 0x1f50
loop2:
    stosw
    sub di, 0x0006
    loop loop2
    pop di
    sub di, 0x0002
    jmp label2
label3:
    push ax
    mov word [0x1dfd], 0xcccc
    add ax, 0x00bb
    stosw
    push cs
    pop es
    xor di, di
    mov ax, 0x1789
    mov dx, 0xc383
    mov cx, 0xcccc
    mov bx, cx
    int 0x87
    pop bx
    mov di, bx
    push bx
    add di, 0x0600
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    mov word [0x1dfd], 0xcccc
    pop di
    add di, 0x00d9
label4:
    push di
    mov ax, 0xcccc
    mov cx, 0x1f50
loop3:
    stosw
    add di, 0x0006
    loop loop3
    pop di
    add di, 0x0002
    jmp label4
    add bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    add bx, 0x0001
    sub bx, 0x0001
    pop ds
    sub bx, 0x00bb
    sub bx, 0x000a
    mov di, bx
    std
label5:
    push di
    mov ax, 0xcccc
    mov cx, 0x1f50
loop4:
    stosw
    sub di, 0x0006
    loop loop4
    pop di
    sub di, 0x0002
    jmp label5