    push cs
    pop ss
    mov dx, ax
    add dx, 0x0002
    db 0x83, 0xC0, 0x17 ;$1 add ax, 0x0017
    mov sp, dx
    mov bx, 0x7fff
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x0100
    sub sp, 0x00fc
    loop loop1
    sub sp, 0x0032
    mov cx, 0x0100
loop1:
    call far [bx]