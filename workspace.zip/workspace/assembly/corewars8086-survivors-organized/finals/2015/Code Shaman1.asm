    push cs
    pop es
    push ax
    mov ax, 0xc381
    mov dx, 0x0300
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    jmp label1
    push cs
    pop es
    push ds
    pop ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x005c
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x005e
    mov dx, 0x52a5
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x040b
    push dx
    movsw
    jmp si
    movsw
    movsw
    push dx
    movsw
    push dx
    movsw
    movsw
    shl al, 1
    shl al, 1
    cmp al, 0x40
    jnz 187
    test bl, bl
    mov [bx], bl
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    movsw
    movsw
    movsw
label1:
    pop ax
    push ds
    pop ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x005c
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x005e
    mov dx, 0x52a5
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x040b
    push dx
    movsw
    jmp ax
    mov ax, 0xcccc
    stosw
    push cs
    pop es
    push ds
    pop ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x005c
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x005e
    mov dx, 0x52a5
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x040b
    push dx
    movsw
    jmp sp