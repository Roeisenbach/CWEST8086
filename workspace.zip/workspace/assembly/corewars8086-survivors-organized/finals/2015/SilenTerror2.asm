    add ax, 0x01d1
    mov [0x1000], ax
    mov bx, 0x0bd4
    jmp label1
    int3
    int3
    int3
    mov cl, 0x10
    mov bp, es
loop1:
    mov di, 0x0002
    mov [0x2015], bx
    mov word [bx], 0x5f0e
    mov word [bx+di], 0x15ff
    rol bx, 1
    dec bx
    push cs
    push es
    nop
    loop loop1
    xchg bp, ax
    mov bx, 0x6464
    pop ds
    pop es
    xor [si], bx
    xor [si+0x04], bx
    mov si, 0x0050
    mov cl, 0x26
loop2:
    xor [si], bx
    add si, 0x0004
    loop loop2
    mov ax, 0xcca5
    mov dx, 0xcccc
    int 0x87
    push cs
    pop ss
    sub bp, 0x0fef
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    movsb
    jmp bp
    int3
    int3
    int3
    mov cl, 0x10
    mov bp, es
loop3:
    mov di, 0x0002
    mov [0x2015], bx
    mov word [bx], 0x5f0e
    mov word [bx+di], 0x15ff
    rol bx, 1
    dec bx
    push cs
    push es
    nop
    loop loop3
    xchg bp, ax
    mov bx, 0x6464
    pop ds
    pop es
    xor [si], bx
    xor [si+0x04], bx
    mov si, 0x0050
    mov cl, 0x26
loop4:
    xor [si], bx
    add si, 0x0004
    loop loop4
    mov ax, 0xcca5
    mov dx, 0xcccc
    int 0x87
    push cs
    pop ss
    sub bp, 0x0fef
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    movsb
    jmp bp
    int3
    int3
    int3
label1:
    mov cl, 0x10
    mov bp, es
loop5:
    mov di, 0x0002
    mov [0x2015], bx
    mov word [bx], 0x5f0e
    mov word [bx+di], 0x15ff
    rol bx, 1
    dec bx
    push cs
    push es
    nop
    loop loop5
    xchg bp, ax
    mov bx, 0x6464
    pop ds
    pop es
    xor [si], bx
    xor [si+0x04], bx
    mov si, 0x0050
    mov cl, 0x26
loop6:
    xor [si], bx
    add si, 0x0004
    loop loop6
    mov ax, 0xcca5
    mov dx, 0xcccc
    int 0x87
    push cs
    pop ss
    sub bp, 0x0fef
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    movsb
    jmp bp
    int3
    int3
    int3
    mov cl, 0x10
    mov bp, es
loop7:
    mov di, 0x0002
    mov [0x2015], bx
    mov word [bx], 0x5f0e
    mov word [bx+di], 0x15ff
    rol bx, 1
    dec bx
    push cs
    push es
    nop
    loop loop7
    xchg bp, ax
    mov bx, 0x6464
    pop ds
    pop es
    xor [si], bx
    xor [si+0x04], bx
    mov si, 0x0050
    mov cl, 0x26
loop8:
    xor [si], bx
    add si, 0x0004
    loop loop8
    mov ax, 0xcca5
    mov dx, 0xcccc
    int 0x87
    push cs
    pop ss
    sub bp, 0x0fef
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    movsb
    jmp bp
    int3
    int3
    int3
    mov cl, 0x10
    mov bp, es
loop9:
    mov di, 0x0002
    mov [0x2015], bx
    mov word [bx], 0x5f0e
    mov word [bx+di], 0x15ff
    rol bx, 1
    dec bx
    push cs
    push es
    nop
    loop loop9
    xchg bp, ax
    mov bx, 0x6464
    pop ds
    pop es
    xor [si], bx
    xor [si+0x04], bx
    mov si, 0x0050
    mov cl, 0x26
loop10:
    xor [si], bx
    add si, 0x0004
    loop loop10
    mov ax, 0xcca5
    mov dx, 0xcccc
    int 0x87
    push cs
    pop ss
    sub bp, 0x0fef
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    movsb
    jmp bp
    int3
    int3
    int3
    push cs
    pop ss
    and cx, 0xe000
    add ch, 0x0f
    add cx, [di]
    mov sp, cx
    mov di, cx
    mov ax, 0xab50
    stosw
    jmp $