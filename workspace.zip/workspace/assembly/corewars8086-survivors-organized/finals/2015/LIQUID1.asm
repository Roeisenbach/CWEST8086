    push es
    push cs
    pop es
    sub ax, 0xff4b
    mov bp, ax
    mov ax, 0x86d7
    mov bx, 0x2015
    mov [bx], bp
    mov dx, 0xd7c4
    mov bx, 0xc3c3
    mov cx, 0xc3c3
    int 0x87
    db 0x8B, 0xFD ;$1 mov di, bp
    mov dx, 0x0f0f
    db 0x8B, 0xC2 ;$1 mov ax, dx
    add di, 0x8f10
    int 0x86
    sub di, 0xff80
    int 0x86
    mov bx, 0xe566
    mov ax, bp
    xchg bp, bx
    pop es
    push es
    lea si, [bx-word 0x0069]
    mov di, 0x0200
    lea dx, [si+0x02]
    mov cx, 0x0035
    rep movsw
    pop ds
    push cs
    push cs
    db 0x8B, 0xF8 ;$1 mov di, ax
    pop es
    pop ss
    mov si, 0x0269
    db 0x03, 0xC5 ;$1 add ax, bp
    db 0x8B, 0xF8 ;$1 mov di, ax
    std
    mov cl, 0x2d
    rep movsw
    sub di, 0xfffe
    call di
    mov si, 0x0300
    lea dx, [di+word 0x002f]
    mov [si+0x02], cs
    mov [si], dx
    sub dx, word 0xfffd
    mov [si+0x06], cs
    mov [si+0x04], dx
    sub dx, 0xfffd
    mov [si+0x0a], cs
    mov [si+0x08], dx
    sub dx, 0xfffd
    mov [si+0x0e], cs
    mov [si+0x0c], dx
    lea sp, [di-word 0x0069]
    mov cx, 0x0060
    call far [si+0x04]
    call far [si+0x08]
    call far [si+0x0c]
    loop loop1
    sub word [si], word 0xffe4
loop1:
    nrg
    nrg
    add sp, 0xffef
    call far [si]
    add ax, 0x0000
    mov si, 0x0200
    db 0x8B, 0xF8 ;$1 mov di, ax
    cld
    mov cl, 0x09
    rep movsw
    call prcd1
prcd1:
    pop bx
    db 0x33, 0xFF ;$1 xor di, di
    push cs
    push cs
    push ss
    pop ds
    pop es
    pop ss
    nop
    db 0x8B, 0xE3 ;$1 mov sp, bx
    sub bx, word 0xffc9
    mov [di+0x02], cs
    mov [di], bx
    sub bx, 0xfffd
    mov [di+0x06], cs
    mov [di+0x04], bx
    sub bx, 0xfffd
    mov [di+0x0a], cs
    mov [di+0x08], bx
    sub bx, 0xfffd
    mov [di+0x0e], cs
    mov [di+0x0c], bx
label1:
    mov cx, 0x0070
    add sp, 0xe5a6
    call far [di+0x04]
    call far [di+0x08]
    call far [di+0x0c]
    loop loop2
    sub word [di], word 0xffe4
loop2:
    nrg
    nrg
    sub sp, 0xffc6
    call far [di]
    add word [di], 0xffe4
    add sp, 0xeda0
    jmp label1