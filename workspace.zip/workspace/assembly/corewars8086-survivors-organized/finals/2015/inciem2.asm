    push cs
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov di, 0x0000
    mov dx, 0x8788
    mov ax, 0x2041
    mov cx, 0xcccc
    db 0x8B, 0xD9 ;$1 mov bx, cx
    int 0x87
    db 0x8B, 0xDE ;$1 mov bx, si
    add bx, 0x0121
label1:
    mov [bx], cx
    add bx, 0x000a
    jmp label1