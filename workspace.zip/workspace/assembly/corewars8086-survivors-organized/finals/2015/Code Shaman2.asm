    push ax
    mov di, ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    mov cx, 0xcccc
    mov bx, 0xcccc
    push es
    push ds
    pop es
    pop ds
    int 0x87
    pop ax
    mov dx, 0xa55d
    mov cx, 0x0023
    mov bp, 0x1800
    push cs
    pop ss
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov ax, ax
    mov di, [0x025e]
    mov bx, di
    add di, 0x7800
    mov sp, di
    sub sp, 0x0201
    add ax, 0x005a
    mov si, ax
    push es
    pop ds
    rep movsw
    mov si, bx
    add si, 0x7800
    mov [si+0x0200], dl
    mov [si-0x0200], dl
    mov [bx+0x0200], dl
    mov [bx-0x0200], dl
    call si
    cmp [si+0x0200], dl
    jnz label1
    cmp [si-0x0200], dl
    jnz label1
    cmp [bx+0x0200], dl
    jnz label1
    cmp [bx-0x0200], dl
    jnz label1
    call si
label1:
    mov [bx], dh
    sub bx, bp
    sub di, bp
    mov cx, 0x0023
    rep movsw
    sub sp, bp
    add si, 0x0046
    sub si, bp
    sub si, 0x0046
    mov [si+0x0200], dl
    mov [si-0x0200], dl
    mov [bx+0x0200], dl
    mov [bx-0x0200], dl
    call si