    mov si, 0x0000
    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0121
    add di, 0x0002
    mov dx, 0xcccc
    db 0x8B, 0xC2 ;$1 mov ax, dx
    int 0x86
    int 0x86
label1:
    mov word [si], 0x000c
    add si, 0x0104
    jmp label1