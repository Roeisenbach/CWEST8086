    add ax, 0x0072
    xchg si, ax
    mov cl, 0x11
    rep movsw
    mov ax, 0x18ff
    mov bx, 0xa5a5
    mov cl, 0x14
loop1:
    stosw
    xchg bx, ax
    stosw
    xchg bx, ax
    loop loop1
    mov cl, 0x13
    rep movsw
    movsb
    push es
    push cs
    pop es
    pop ds
    xor si, si
    call prcd1
prcd1:
    pop bp
    push cs
    pop ss
    mov sp, bp
    sub sp, 0x00c8
    add bp, 0x004d
    mov bx, 0x00fa
    add si, 0x0021
    mov cl, 0x15
loop2:
    mov [bx+si], bp
    mov word [bx+si+0x02], 0x1000
    add bp, 0x0004
    add si, 0x0004
    loop loop2
    mov dx, 0x86cd
    mov ax, 0x86cd
    xor di, di
    int 0x87
    mov ax, 0x0053
    sub bp, ax
    sub si, ax
    dec si
    mov dx, sp
    mov [bp+0x00fa], dl
    mov [bp-0x64], dl
    mov di, sp
    add di, 0x0116
    int 0x86
    nop
    int 0x86
    sub di, 0x0200
    movsw
    rep movsw
    movsw
    mov cl, 0x15
    add bp, 0x0021
    sub si, 0x0001
loop3:
    mov [bx+si], bp
    add bp, 0x0004
    add si, 0x0004
    loop loop3
    sub bp, ax
    sub si, ax
    dec si
    mov [bp+0x00fa], dl
    mov [bp-0x64], dl
    movsw
    movsw
    mov cl, 0x12
    rep movsw
    xor si, si
    cmp [bp+0x00fa], dl
    jnz label1
    cmp [bp-0x64], dl
    jz label2
    sub bp, 0x02bc
label1:
    add bp, 0x0190
    mov cl, 0x0f
    mov si, 0xffdf
label2:
    add si, 0x0021
    mov di, bp
    movsw
    jmp bp