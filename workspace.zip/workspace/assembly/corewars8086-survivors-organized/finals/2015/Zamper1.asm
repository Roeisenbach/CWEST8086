    add ax, 0x0062
    mov word [0x2015], 0x0000
    mov byte [0x0000], 0xbe
    mov [0x0001], ax
    mov word [0x0003], 0xe6ff
    mov cx, 0x0002
    loop $
    mov word [0x2015], 0xffff
    mov byte [0xffff], 0xbe
    mov [0x0000], ax
    mov word [0x0002], 0xe6ff
    mov cx, 0x0005
    loop $
    mov word [0x2015], 0x00ff
    mov byte [0x00ff], 0xbe
    mov [0x0100], ax
    mov word [0x0102], 0xe6ff
    mov cx, 0x0005
    loop $
    mov word [0x2015], 0xff00
    mov byte [0xff00], 0xbe
    mov [0xff01], ax
    mov word [0xff03], 0xe6ff
    mov cx, es
    push cs
    pop ss
    push cs
    pop es
    mov di, 0x2345
    int 0x86
    mov di, 0x930d
    int 0x86
    mov es, cx
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x009b
    db 0x8B, 0xC6 ;$1 mov ax, si
    mov di, 0x0000
    stosw
    mov si, 0x1cfd
    mov word [si], 0x1cff
    mov ds, cx
    mov si, 0x0002
    db 0x8B, 0xE0 ;$1 mov sp, ax
    and sp, 0xfffc
    inc sp
    mov word [si], 0x1cfd
    mov [si+0x02], cs
    call far [si]