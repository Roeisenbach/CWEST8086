    push es
    pop ds
    mov bx, 0x0032
    mov si, ax
    add si, word 0x001e
    mov [bx+0x02], cs
    mov [bx], si
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x0400
    mov di, ax
    add di, 0x0400
    call far [bx]