    mov es, [si]
    mov ax, 0xcc3d
    mov dx, 0x75cc
    mov bx, 0xfeeb
    int 0x87
    xchg ax, [si]
    mov bx, ax
    and bx, 0x0fff
    call prcd1
    mov si, 0x0000
    mov ax, 0x1000
    mov cx, 0x0011
    loop $
    db 0xE9, 0x17, 0x00 ;$1 jmp 61
prcd1:
    pop si
    mov byte [bx], 0xea
    mov [bx+0x01], si
    mov word [bx+0x03], 0x1000
    add [si+0x01], si
    add [si+0x04], ax
    mov word [bx+0x01], 0xcccc
    mov dx, ss
    mov es, dx
    add si, 0x0089
    xor di, di
    mov cx, 0x0010
    rep movsw
    mov ds, dx
    mov cx, cs
    mov ss, cx
    sub ax, 0x0500
    and al, 0x07
    sub al, 0x08
    mov ch, 0x0f
    mov cl, al
    shl al, 1
    shl al, 1
    shl al, 1
    shl al, 1
    mov sp, ax
    mov al, 0xa1
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cx
    mov di, ax
    sub sp, 0x055f
    mov es, cx
    xor si, si
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x86
    int 0x86
    sub di, 0x0200
    mov ax, 0xd401
    stosw
    mov ax, 0x1fff
    stosw
    sub di, 0x0003
    mov ax, 0x0d00
    mov dx, 0x27d0
    mov bp, 0x0800
    xor cx, cx
    call far [bx]
    movsw
    movsw
    mov cl, 0x0b
    rep movsw
    sub [bx], bp
    add ax, 0x5920
    sub sp, ax
    add dx, 0x0160
    mov di, [bx]
    movsw
    movsw
    sub di, 0x0003
    xor si, si
    call far [bx]
    add sp, dx
    call far [bx]