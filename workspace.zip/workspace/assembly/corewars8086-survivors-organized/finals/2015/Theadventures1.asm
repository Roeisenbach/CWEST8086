    push cs
    pop es
    mov cx, 0x00cc
    mov [0x07df], cx
    mov [bx+0x02], cs
    mov dx, ax
    add dx, word 0x0030
    mov [bx], dx
    push cs
    pop ss
    mov sp, ax
    mov di, ax
    pushf
    pop ax
    push ax
    xor ax, 0x0400
    push ax
    popf
    popf
    add di, word 0x0030
    mov ax, 0x50ab
    mov [0x07df], dx
    stosw
    push ax