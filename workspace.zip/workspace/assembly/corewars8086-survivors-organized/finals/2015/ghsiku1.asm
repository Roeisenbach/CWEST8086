    push ds
    pop es
    mov di, ax
    add di, 0x061e
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x05f4
    db 0x83, 0xC0, 0x20 ;$1 add ax, 0x0020
    mov bx, ax
    add bx, 0x0026
    mov [bx], ax
    mov [bx+0x02], cs
    mov ax, 0xcccc
    stosw
    add di, 0x0006
    call far [bx]
    add [bx+si], al
    add [bx+si], al