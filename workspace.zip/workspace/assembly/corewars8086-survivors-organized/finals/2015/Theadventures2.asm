    push cs
    pop es
    mov [bx+0x02], cs
    mov dx, ax
    add dx, word 0x0023
    mov [bx], dx
    push cs
    pop ss
    mov sp, ax
    mov di, ax
    add di, word 0x0023
    mov ax, 0x50ab
    mov cx, 0x00cc
    mov [0x07df], cx
    stosw
    push ax