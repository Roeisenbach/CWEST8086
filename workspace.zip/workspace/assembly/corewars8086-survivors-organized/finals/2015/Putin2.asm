    jmp label3
    push cs
    pop ss
    mov si, ax
    add si, 0x0022
    mov bx, [0x000a]
    mov bl, 0xb8
    add bx, 0x4000
    mov bp, bx
    mov dx, ax
    mov di, 0x00aa
    mov cx, 0x0008
    rep movsw
    jmp label1
    movsw
    movsw
    movsw
    mov bx, 0xf67f
    movsw
    movsw
    movsw
    mov ax, 0x0010
    movsw
    movsw
    xor si, si
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
label1:
    mov ax, 0x06c6
    stosw
    mov al, bl
    stosb
    mov al, bh
    stosb
    mov al, 0xa5
    stosb
    mov si, dx
    add si, 0x0051
    mov cx, 0x0005
    rep movsw
    jmp label2
    movsw
    movsw
    movsw
    movsw
    xor si, si
    call bp
    movsw
label2:
    mov di, bp
    add di, 0x0002
    mov dl, 0xa3
    mov sp, dx
    sub sp, 0x0078
    mov bl, 0xa1
    mov word [bp+0x00], 0xd429
    add bp, 0x0002
    mov word [bp+0x00], 0x1fff
    sub bp, 0x0002
    mov di, 0x00da
    mov dx, bp
    mov al, dl
    stosb
    mov al, dh
    stosb
    xor al, al
    stosb
    mov al, 0x10
    stosb
    mov bx, 0x00da
    mov di, bp
    add di, 0x0002
    mov si, 0x00aa
    push ds
    push es
    pop ds
    pop es
    mov cx, 0x0014
    mov dx, 0x006c
    call bp
label3:
    mov si, ax
    add si, 0x00d9
    push ds
    push es
    pop ds
    mov bx, 0x00df
    mov bx, [bx]
    pop ds
    mov cx, 0x0096
    push cs
    pop ss
loop1:
    mov bp, [0x2015]
    mov word [bp+0x00], 0x16ff
    add bp, 0x0002
    mov [bp+0x00], bx
    loop loop1
    mov bl, 0xb8
    add bx, 0x4000
    mov bp, bx
    mov dx, ax
    mov di, 0x00aa
    mov cx, 0x000b
    rep movsw
    jmp label4
    movsw
    movsw
    movsw
    mov bx, 0xf67f
    movsw
    movsw
    movsw
    movsw
    movsw
    mov ax, 0x0010
    xor si, si
    mov dx, 0x0003
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
label4:
    mov ax, 0x06c6
    stosw
    mov al, bl
    stosb
    mov al, bh
    stosb
    mov al, 0xa5
    stosb
    mov si, dx
    add si, 0x010c
    mov cx, 0x0005
    rep movsw
    jmp label5
    movsw
    movsw
    movsw
    movsw
    xor si, si
    call bp
    movsw
label5:
    mov di, bp
    add di, 0x0002
    mov dl, 0xa3
    mov sp, dx
    sub sp, 0x0100
    mov bl, 0xa1
    mov word [bp+0x00], 0xd429
    add bp, 0x0002
    mov word [bp+0x00], 0x1fff
    sub bp, 0x0002
    mov di, 0x00da
    mov dx, bp
    mov al, dl
    stosb
    mov al, dh
    stosb
    xor al, al
    stosb
    mov al, 0x10
    stosb
    mov bx, 0x00da
    mov di, bp
    add di, 0x0002
    mov si, 0x00aa
    push ds
    push es
    pop ds
    pop es
    mov cx, 0x0014
    mov dx, 0x006c
    call bp
    push cs
    pop ss
    mov si, ax
    add si, 0x017c
    mov bx, [0x000a]
    mov bl, 0xb8
    add bx, 0x4000
    mov bp, bx
    mov dx, ax
    mov di, 0x00aa
    mov cx, 0x0008
    rep movsw
    jmp label6
    movsw
    movsw
    movsw
    mov bx, 0xf67f
    movsw
    movsw
    movsw
    mov ax, 0x0010
    movsw
    movsw
    xor si, si
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
label6:
    mov ax, 0x06c6
    stosw
    mov al, bl
    stosb
    mov al, bh
    stosb
    mov al, 0xa5
    stosb
    mov si, dx
    add si, 0x01ac
    mov cx, 0x0005
    rep movsw
    jmp label7
    movsw
    movsw
    movsw
    movsw
    xor si, si
    call bp
    movsw
label7:
    mov di, bp
    add di, 0x0002
    mov dl, 0xa3
    mov sp, dx
    sub sp, 0x0100
    mov bl, 0xa1
    mov word [bp+0x00], 0xd429
    add bp, 0x0002
    mov word [bp+0x00], 0x1fff
    sub bp, 0x0002
    mov di, 0x00da
    mov dx, bp
    mov al, dl
    stosb
    mov al, dh
    stosb
    xor al, al
    stosb
    mov al, 0x10
    stosb
    mov bx, 0x00da
    mov di, bp
    add di, 0x0002
    mov si, 0x00aa
    push ds
    push es
    pop ds
    pop es
    mov cx, 0x0014
    mov dx, 0x014c
    call bp