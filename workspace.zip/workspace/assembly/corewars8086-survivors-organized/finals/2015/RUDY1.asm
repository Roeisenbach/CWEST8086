    nop
    nop
    nop
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x001c
    mov bx, es
    mov ax, [bx]
    push cs
    pop es
    push cs
    pop ds
    db 0x8B, 0xF8 ;$1 mov di, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add dx, 0x001c
    mov ax, 0xcccc
    jmp label1
    db 0x8B, 0xF2 ;$1 mov si, dx
label1:
    add di, 0x011e
    mov cx, 0x0040
loop1:
    stosw
    add di, 0x0024
    loop loop1
    mov cx, 0x000f
    sub di, 0x0150
    db 0x8B, 0xD7 ;$1 mov dx, di
    rep movsw
    db 0x8B, 0xFA ;$1 mov di, dx
    jmp di