    mov word [si], 0x1000
    mov cx, cs
    mov es, cx
    mov bl, 0xea
    mov ch, 0x00
    mov [si], ax
    and ax, 0x0fff
    mov bh, al
    mov cl, ah
    add cl, 0xe0
    mov ax, 0xfeeb
    int 0x87
    call prcd1
prcd1:
    pop ax
    mov dx, ss
    mov es, dx
    mov si, ax
    add si, word 0x005d
    mov cx, 0x0009
    rep movsw
    mov ds, dx
    mov cx, cs
    mov ss, cx
    sub ax, 0x1720
    and al, 0x07
    sub al, 0x08
    mov ch, 0x0f
    mov cl, al
    shl al, 1
    shl al, 1
    shl al, 1
    shl al, 1
    mov sp, ax
    mov al, 0xa3
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cx
    mov di, ax
    sub sp, word 0x005d
    mov es, cx
    xor si, si
    mov ax, 0xcccc
    mov dx, 0xcccc
    std
    int 0x86
    int 0x86
    cld
    add di, 0x0200
    mov ax, 0x1fff
    stosw
    dec di
    mov bp, 0x0800
    add sp, bp
    xor cx, cx
    call far [bx]
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    dec di
    xor si, si
    call far [bx]
    call far [bx]