    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    db 0x8B, 0xF8 ;$1 mov di, ax
    add si, 0x000c
    add di, 0x000d
    movsb