    jmp label1
    mov dx, 0x81fe
    jmp 0xc0dd:0x848a
    add cx, 0x003a
    mov di, 0xc0fe
    db 0x02, 0xD0 ;$1 add dl, al
label1:
    push ax
    std
    push es
    push cs
    pop es
    sub ax, 0x0b06
    mov [0x4590], ax
    mov bx, ax
    mov word [bx], 0xfeeb
    mov ax, 0xe000
    mov dx, 0x063c
    mov bx, 0x26ff
    mov cx, 0x4590
    int 0x87
    xor bx, bx
    pop es
    cld
    pop ax
    add ax, 0x00ca
    stosw
    xchg bp, ax
    mov dx, 0x2c2d
    mov ax, dx
    mov di, 0x01fe
    int 0x86
    int 0x86
    std
    lea si, [bp+0x16]
    mov cx, 0x0018
    rep movsw
    cld
    mov di, cs
    push es
    pop ds
    mov es, di
    mov ss, di
    mov si, bp
    lea di, [si-0x0be4]
    lea sp, [si-0x07fc]
    mov si, 0xa5f3
    push sp
    push si
    push sp
    pop sp
    mov bx, 0xf400
    mov dx, 0xf802
    mov bp, 0xfc04
    mov ax, 0x815e
    mov si, 0x0004
    mov cx, 0x01fe
    jmp sp
    nop
label2:
    nop
    nop
    nop
    nop
    cld
    mov bp, cs
    mov cl, 0x04
    shl bp, cl
    mov cl, 0x0b
    shl ax, cl
    xchg di, ax
    mov sp, di
    mov cx, 0x001d
    loop $
    mov bx, 0x1000
    mov ss, bx
    mov es, bx
    mov ds, bx
    call prcd1
prcd1:
    pop si
    lea si, [bp+si+0x07]
    push bx
    push si
    retf
    lea sp, [si+0x39]
    mov bx, di
    mov cx, 0x01fe
    pop ax
    and ah, 0x03
    dec ax
    pop sp
    pop bp
    mov dx, bp
    sub bp, 0x03fe
    mov si, sp
    add si, 0xfc1c
    xor di, si
    jmp sp
    lodsw
    esc 0xde
    rep movsw
    stosw
    add sp, dx
    push word [si-0x18]
    push dx
    xchg sp, ax
    stosw
    xchg sp, ax
    pop dx
    add di, bx
    add si, bp
    mov cx, 0x01fe
    dec ax
label3:
    jnz label3+1
    in al, 0xb9
    inc word [bx+si]
    loop $
    call prcd2
prcd2:
    pop ax
    jmp label2
    xchg bx, ax
label4:
    pop dx
    mov ax, [0x2015]
    push ax
    xor ax, cx
    xlatb
    xchg al, ah
    xlatb
    add al, ah
    cmp al, 0x06
    jge label4
    ret
label5:
    pop dx
    mov ax, [0x2015]
    push ax
    xor ax, cx
    xlatb
    xchg al, ah
    xlatb
    add al, ah
    cmp al, 0x06
    jge label5
    ret