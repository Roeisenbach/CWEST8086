    push cs
    pop es
    mov si, ax
    add si, word 0x0018
    mov dx, [0x1b39]
    mov ax, 0xcccc
    mov di, dx
    mov cx, 0x0040
    rep movsw
    jmp dx
    mov bp, 0xffff
    mov [0x2015], bp
    std
    mov si, 0x0002
    mov cx, dx
    sub dx, 0x0100
    add cx, 0x0200
    mov bx, ax
label1:
    cmp [bx], ax
    jnz label3
label2:
    sub bx, 0x0104
    jmp label1
label3:
    mov [0x2015], bp
    cmp bx, dx
    jl label4
    cmp bx, cx
    jl label2
label4:
    cmp si, 0x0000
    jnz label6
    mov ax, 0xcccc
    push cx
    mov di, bx
    add di, 0x0040
label5:
    mov cx, 0x0040
    rep stosw
    cmp [di], ax
    jnz label5
    mov bx, di
    pop cx
    jmp label2
label6:
    dec si
    push dx
    mov dx, 0xcccc
    mov di, bx
    add di, 0x0080
    int 0x86
    pop dx
    mov bx, di
    jmp label1