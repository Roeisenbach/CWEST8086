    mov cx, es
    push cs
    pop ss
    push cs
    pop es
    mov di, 0x2345
    int 0x86
    mov di, 0x930d
    int 0x86
    mov es, cx
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0039
    nop
    db 0x8B, 0xC6 ;$1 mov ax, si
    mov di, 0x0000
    stosw
    mov si, 0x1cfd
    mov word [si], 0x1cff
    mov ds, cx
    mov si, 0x0002
    db 0x8B, 0xE0 ;$1 mov sp, ax
    and sp, 0xfffc
    inc sp
    mov word [si], 0x1cfd
    mov [si+0x02], cs
    call far [si]