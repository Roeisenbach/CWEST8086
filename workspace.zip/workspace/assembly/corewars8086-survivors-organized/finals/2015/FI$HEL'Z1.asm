    jmp label2
    nop
    mov bx, 0x001d
    db 0x03, 0xD8 ;$1 add bx, ax
    push ax
    xchg cx, ax
    pop dx
label1:
    mov ax, [0x2015]
    push ax
    db 0x33, 0xC1 ;$1 xor ax, cx
    xlatb
    xchg al, ah
    xlatb
    db 0x02, 0xC4 ;$1 add al, ah
    cmp al, 0x06
    jge label1
    ret
label2:
    mov word [0x0010], 0xfffd
    mov word [0x2015], 0x4a78
    mov [0x1111], dl
    mov [0x2222], dl
    add ax, 0x0129
    mov [0x4e4e], ax
    sub ax, 0x0129
    push ax
    push cs
    pop es
    mov ax, 0x86d7
    mov dx, 0xd7c4
    mov bx, 0x26ff
    mov cx, 0x4e4e
    int 0x87
    pop ax
    mov bx, 0x4a78
    mov [0x2015], bx
    mov [0x2015], bx
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    neg bx
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    neg bl
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    neg bx
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0125
    mov di, 0xff22
    mov cx, 0x0002
    cld
    rep movsw
    mov cx, 0x0019
    mov bp, [0x4e4e]
loop1:
    mov [0x4e4e], bp
    loop loop1
    push ax
    mov cl, [0x2222]
    db 0x32, 0xED ;$1 xor ch, ch
    add cx, 0x0002
    mov ax, 0xffdf
    db 0x33, 0xD2 ;$1 xor dx, dx
    div cx
    mov [0x1111], ax
    pop si
    add si, 0x0152
    mov word [si+0x01], 0x00e3
    mov bx, 0xff12
    mov [0xfefd], bx
    mov [0xfeff], cs
    push cs
    pop ss
    dec cl
    db 0x33, 0xD2 ;$1 xor dx, dx
    mul cx
    db 0x8B, 0xE0 ;$1 mov sp, ax
    jmp bx
    call far [0xfffc]
    mov di, [0x4e4e]
    add di, 0x0020
    mov cl, [0x2222]
    inc cl
    mov [0x2222], cl
    mov bx, 0xff22
    push es
    pop ds
    mov [0xfffc], bx
    mov [0xfffe], cs
    push cs
    pop ss
    mov ax, [0x1111]
    db 0x32, 0xED ;$1 xor ch, ch
    mul cx
    db 0x8B, 0xE0 ;$1 mov sp, ax
    jmp di