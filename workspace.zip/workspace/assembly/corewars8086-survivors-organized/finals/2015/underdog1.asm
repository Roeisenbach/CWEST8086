    call prcd1
label1:
    add ax, 0x0014
    push es
    pop ds
    mov bx, 0x0032
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x0055
    call far [bx]
    jmp label1
prcd1:
    mov cx, 0x0005
    db 0x8B, 0xF0 ;$1 mov si, ax
    push si
    db 0x2B, 0xF1 ;$1 sub si, cx
    mov byte [si], 0xcc
    pop si
    ret