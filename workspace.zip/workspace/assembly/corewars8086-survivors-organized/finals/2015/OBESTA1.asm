    jmp label1
    nop
    mov [0x2015], ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    push cs
    pop es
    push cs
    pop ss
    mov dx, 0xef7d
    mov ax, 0x063c
    mov di, 0x0000
    mov bx, 0x0000
    mov cx, 0x0000
    int 0x87
    int 0x87
    add si, 0x0027
    db 0x8B, 0xFE ;$1 mov di, si
    add di, 0x0002
    mov ax, 0xa550
    movsw
    push ax
    mov [0x2015], ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    push cs
    pop es
    push cs
    pop ss
    mov dx, 0xef7d
    mov ax, 0x063c
    mov di, 0x0000
    mov bx, 0x0000
    mov cx, 0x0000
    int 0x87
    int 0x87
    add si, 0x0027
    db 0x8B, 0xFE ;$1 mov di, si
    add di, 0x0002
    mov ax, 0xa550
    movsw
    push ax
label1:
    mov [0x2015], ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    push cs
    pop es
    push cs
    pop ss
    mov dx, 0xef7d
    mov ax, 0x063c
    mov di, 0x0000
    mov bx, 0x0000
    mov cx, 0x0000
    int 0x87
    int 0x87
    add si, 0x007c
    db 0x8B, 0xFE ;$1 mov di, si
    add di, 0x0002
    mov ax, 0xa550
    movsw
    push ax