    db 0x8B, 0xD8 ;$1 mov bx, ax
    add ax, 0x007e
    stosw
    db 0x8B, 0xC3 ;$1 mov ax, bx
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add dx, 0x00cb
    mov cx, 0x009d
    mov [0x2015], dx
    mov [0x2015], dx
    add bx, 0x0200
loop1:
    mov word [bx], 0xcccc
    add bx, 0x0064
    mov word [bx], 0xcccc
    add bx, 0x0063
    mov word [bx], 0xcccc
    add bx, 0x0065
    add bx, 0x0064
    mov [0x2015], dx
    mov [0x2015], dx
    loop loop1
    std
    push cs
    pop es
label1:
    db 0x8B, 0xF8 ;$1 mov di, ax
    xor al, 0x01
    shr al, 1
    jb label2
    sub di, 0x0101
    shl al, 1
    jmp label3
    nop
label2:
    sub di, 0x0a00
    shl al, 1
    add al, 0x01
label3:
    mov dx, 0x000e
label4:
    mov bx, 0x0009
label5:
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0200
    mov cx, 0x0080
    rep movsw
    dec bx
    cmp bx, 0x0000
    jg label5
    sub di, 0x0900
    dec dx
    cmp dx, 0x0000
    jle label1
    jmp label4
    db 0x8B, 0xF3 ;$1 mov si, bx
    sub bx, 0x0084
    mov cx, 0x009d
loop2:
    mov word [bx], 0xcccc
    sub bx, 0x0064
    mov word [bx], 0xcccc
    sub bx, 0x0065
    mov word [bx], 0xcccc
    sub bx, 0x0064
    mov word [bx], 0xcccc
    sub bx, 0x0063
    loop loop2
    db 0x8B, 0xC6 ;$1 mov ax, si
    sub ax, 0x007e
    cld
    push cs
    pop es
label6:
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0200
    mov dx, 0x00fe
label7:
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x010f
    mov cx, 0x0080
    rep movsw
    dec dx
    cmp dx, 0x0000
    jle label6
    jmp label7
    db 0x33, 0xC0 ;$1 xor ax, ax
    db 0x33, 0xC0 ;$1 xor ax, ax
    db 0x33, 0xC0 ;$1 xor ax, ax
    db 0x8B, 0xEC ;$1 mov bp, sp
    mov bx, [bp-0x02]
    sub bx, 0x00e9
    and cx, 0x001f
    db 0x33, 0xD9 ;$1 xor bx, cx
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov dx, 0x0037
label8:
    mov cx, 0x00d1
    db 0x8B, 0xD8 ;$1 mov bx, ax
loop3:
    mov word [bx], 0xcccc
    sub bx, 0x0049
    mov word [bx], 0xcccc
    sub bx, 0x004b
    mov word [bx], 0xcccc
    sub bx, 0x004d
    mov word [bx], 0xcccc
    sub bx, 0x004b
    loop loop3
    dec dx
    sub ax, 0x0008
    cmp dx, 0x0000
    jg label8
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3