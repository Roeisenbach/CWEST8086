    jmp label1
    nop
    push es
    push ax
    push cs
    pop es
    mov al, 0xbf
    mov ah, 0x96
    mov dl, 0x70
    mov dh, 0xf3
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop ax
    pop es
    add ax, 0x006f
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov ax, 0xab50
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    int 0x86
    stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    db 0x8B, 0xE6 ;$1 mov sp, si
    db 0x8B, 0xFE ;$1 mov di, si
    db 0x33, 0xF6 ;$1 xor si, si
    and di, 0xfffe
    movsw
    nop
label1:
    push es
    push ax
    push cs
    pop es
    mov al, 0xbf
    mov ah, 0x96
    mov dl, 0x70
    mov dh, 0xf3
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop ax
    pop es
    add ax, 0x006f
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov ax, 0xab50
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    int 0x86
    stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    db 0x8B, 0xE6 ;$1 mov sp, si
    db 0x8B, 0xFE ;$1 mov di, si
    db 0x33, 0xF6 ;$1 xor si, si
    and di, 0xfffe
    movsw
    nop
    push es
    push ax
    push cs
    pop es
    mov al, 0xbf
    mov ah, 0x96
    mov dl, 0x70
    mov dh, 0xf3
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop ax
    pop es
    add ax, 0x006f
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov ax, 0xab50
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    int 0x86
    stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    db 0x8B, 0xE6 ;$1 mov sp, si
    db 0x8B, 0xFE ;$1 mov di, si
    db 0x33, 0xF6 ;$1 xor si, si
    and di, 0xfffe
    movsw
    nop
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    db 0x00  ; add [bx+si], al