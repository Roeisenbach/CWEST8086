    mov si, ax
    add si, word 0x0012
    mov di, ax
    dec di
    push cs
    pop es
    pushf
    pop ax
    xor ax, 0x0400
    push ax
    popf
    movsw
    db 0xE9, 0xFC, 0xFF ;$1 jmp 18