    mov si, 0xa5ab
    mov dx, 0xd429
    mov bp, [0x1000]
    jmp label1
    int3
    int3
    int3
    add ax, 0x014b
    xchg si, ax
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    rep movsw
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    int3
    int3
    int3
    add ax, 0x014b
    xchg si, ax
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    rep movsw
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    int3
    int3
    int3
label1:
    add ax, 0x014b
    xchg si, ax
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    rep movsw
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    int3
    int3
    int3
    add ax, 0x014b
    xchg si, ax
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    rep movsw
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    int3
    int3
    int3
    add ax, 0x014b
    xchg si, ax
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    rep movsw
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    lea sp, [bp-0x0094]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6c6c
    push dx
    mov [bp+0x02ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    int3
    int3
    int3
    db 0xC1
    db 0xC1
    movsw
    mov [bp+di-word 0x0040], cx
    in ax, 0xc1
    db 0xC1
    mov cl, 0x06
    db 0xC1
    db 0xC1
    rep movsw
    out dx, ax
    cli
    retf 0x5d02
    cli
    db 0x6A
    call word [bx+di]
    db 0x66
    xor si, si
    db 0xC1
    db 0xC1
    mov cl, 0x0d
    db 0xC1
    xchg di, ax
    movsw
    cmp [bx-0x6117], si
    db 0xC7, 0x66, 0x11, 0x08, 0x81 ;$4 mov word [bp+0x11], 0x8108
    mov [si+0x0a], sp
    or word [bx+0x0304], 0xa181
    db 0x64
    add ax, 0x8b89
    db 0xC1
    jmp bp
    add cl, al
    mov cl, 0x0c
    db 0xC1
    xchg di, ax
    movsw
    mov cx, 0x6160
loop1:
    xchg bx, sp
    in ax, dx
    mov ss, [bp+0x395e]
    mov bh, 0xe5
    mov [0x8399], di
    in al, dx
    db 0x67
    call 0xf296:0x75cd
    movsw
    movsw
    aad 0x62
    movsw
    db 0xF3, 0xC1
    jcxz loop1
    and word [bx+0x00ba], 0x08b8
    or [bx+di-0x3e2b], cl
    db 0xC1
    mov cl, 0x05
    db 0xC1
    db 0xC1
    rep movsw
    aad 0x5e
    xchg bx, di
    cwd
    xchg di, ax
    stosw
    mov [bp+di-0x5a68], di
    movsw
    aad 0x63
    movsw
    movsw
    xchg di, ax
    db 0xC1
    mov [bp-0x64f2], ax
    mov [bp+0x66ae], ax
    xchg dx, ax
    mov ax, 0xc136
    xor si, si
    db 0xC1