    push ds
    pop es
    push ds
    pop ss
    mov bx, ax
    lea sp, [bx-0x02]
    lea si, [bx+word 0x0014]
    lea di, [bx+word 0x0016]
    mov cx, 0xcccc
    movsw
    push cx