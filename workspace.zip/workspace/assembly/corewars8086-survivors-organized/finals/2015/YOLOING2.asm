    push cs
    pop es
    mov bx, ax
    mov di, ax
    mov ax, 0xcccc
    mov dx, ax
    sub di, 0x0700
    int 0x86
    int 0x86
    push ds
    pop es
    mov di, 0x0002
    mov si, 0x0000
    mov cx, 0xcccc
    push ds
    pop ss
    mov dx, 0xa551
    mov [0x0000], dx
    mov dx, 0x0000
    jmp dx
    movsw
    push cx