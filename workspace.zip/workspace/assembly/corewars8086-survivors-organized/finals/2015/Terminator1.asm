    push ds
    pop es
    mov di, ax
    add di, 0x0400
    add di, word 0x0042
    int 0x86
    int 0x86
    mov cx, ss
    mov bx, ds
    mov ss, bx
    mov sp, ax
    sub sp, 0x0400
    mov ds, cx
    xor bx, bx
    mov dx, ax
    add dx, word 0x002b
    mov [bx], dx
    mov [bx+0x02], ss
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    mov bx, ds
    mov ss, bx
    mov sp, ax
    mov dx, 0xcccc
    mov cx, 0x0080
loop1:
    push dx
    loop loop1