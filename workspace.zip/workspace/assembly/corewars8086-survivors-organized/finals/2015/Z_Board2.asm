    push es
    pop ds
    mov [0x0100], ax
    mov si, ax
    add si, 0x0097
    mov [0x0102], si
    push cs
    pop ds
    mov [0x2015], si
    mov bx, ax
    mov di, si
    mov [bx+0x0098], ax
    add [bx+0x00ad], ax
    add [bx+0x00b0], ax
    mov cx, 0x0023
loop1:
    add di, 0x1c58
    mov dx, di
    add dx, 0x0003
    mov [0x2015], di
    sub dx, si
    neg dx
    mov byte [di], 0xe9
    mov [di+0x01], dx
    add word [bx+0x00ad], 0x000a
    loop loop1
    mov cx, 0x0006
    loop $
    mov word [bx+0x00d8], 0xab52
    mov word [bx+0x00b9], 0x03cc
    mov [bx+0x00ad], bx
    mov [bx+0x00b0], bx
    add word [bx+0x00ad], 0xe4df
    add word [bx+0x00b0], 0x1d04
    jmp label1
    xor dx, dx
    mov ax, [bx+0x00ad]
    mov cx, 0x1c71
    div cx
    mov di, dx
    mov word [bx+0x00d8], 0xab52
    mov word [bx+0x00b9], 0x03cc
    jmp label2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    mov word [bx+0x009a], 0x87c7
    nop
label1:
    mov bx, 0x0000
    mov word [bx+0x009a], 0xf4eb
    add word [bx+0x00ad], 0x1c71
    sub word [bx+0x00b0], 0x1c71
label2:
    mov di, 0x0150
    mov sp, 0x0090
    mov ax, cs
    mov es, ax
    mov ss, ax
    and sp, 0xfff0
    and di, 0xfff0
    mov bp, bx
    add bp, 0x00e5
    mov si, 0x0000
    add word [bx+0x00c5], 0x0002
    mov [bx+si+0x0136], di
    dec word [bx+si+0x0136]
    mov dx, 0xcccc
    mov ax, 0xab50
    mov cx, di
    stosw
    mov word [bx+0x009a], 0x87c7
    jmp cx
    sub sp, 0x0022
    add di, 0x0022
    add word [bx+si+0x0136], 0x0023
    mov cx, di
    stosw
    inc cx
    jmp cx
    mov ax, 0xd5ff
    mov bp, bx
    add bp, 0x00e5
    nop
label3:
    cmp word [bx+0x0136], 0x0000
    jz label3
    mov cx, 0x0019
    loop $
    mov si, 0xfffe
label4:
    add si, 0x0002
    cmp si, 0x0006
    jle label6
label5:
    xor si, si
    add cx, 0x000c
label6:
    cmp word [bx+si+0x0136], 0x0000
    jnz label7
    add cx, 0x0064
    jmp label5
label7:
    add word [bx+si+0x0136], 0x0022
    mov di, [bx+si+0x0136]
    add di, cx
    stosw
    jmp label4
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    nop
    nop
    nop
    nop
    push dx
    stosw
    push dx
    stosw
    push dx
    stosw
    push dx
    stosw
    push dx
    stosw
    push dx
    stosw
    push dx
    stosw
    push dx
    call bp
    push dx
    stosw
    push dx
    stosw
    push dx
    stosw
    brk
    call prcd1
prcd1:
    pop si
    jmp label8
    mov word [si+0x08], 0x84c7
label8:
    mov word [si+0x08], 0xf8eb
    add word [si+0x13], 0x2000
    mov di, 0x2000
    sub si, 0x0003
    mov [0x2015], di
    mov ax, cs
    mov es, ax
    mov ds, ax
    mov cx, 0x0022
    mov [0x2015], di
    rep movsw
    sub si, 0x0045
    mov sp, si
    mov ss, ax
    mov dx, 0x6060
    mov ax, 0xab52
    add si, 0x0400
    mov di, si
    stosw
    jmp si
    nop
    push cs
    pop es
    int 0x87
    mov bx, 0x01cb
    add bx, ax
    push ax
    xchg cx, ax
label9:
    pop dx
    mov ax, [0x2015]
    push ax
    xor ax, cx
    xlatb
    xchg ah, al
    xlatb
    add al, ah
    cmp al, 0x06
    jge label9
    ret