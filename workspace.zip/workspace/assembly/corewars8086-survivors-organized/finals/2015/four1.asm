    mov di, ax
    add di, 0x0129
    db 0x83, 0xC0, 0x21 ;$1 add ax, 0x0021
    push es
    pop ds
    mov si, 0x0050
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    mov bp, 0xab55
    mov ax, bx
    push cs
    pop es
    push cs
    pop ss
    push bp
label1:
    stosw
    add di, 0x0005
    call far [bx]
    jmp label1