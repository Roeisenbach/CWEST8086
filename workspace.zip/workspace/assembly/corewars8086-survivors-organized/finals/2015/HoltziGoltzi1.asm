    mov cx, 0xcccc
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0011
    nop
label1:
    mov [bx], cx
    add bx, 0x012c
    jmp label1