    push cs
    pop ss
    db 0x8B, 0xE0 ;$1 mov sp, ax
    push cs
    pop es
    mov di, 0x0000
    mov ax, 0x86cd
    mov cx, 0xcccc
    mov dx, 0x86cd
    db 0x8B, 0xD9 ;$1 mov bx, cx
    int 0x87
    db 0x8B, 0xFC ;$1 mov di, sp
    db 0x8B, 0xD1 ;$1 mov dx, cx
    push cs
    db 0x8B, 0xC2 ;$1 mov ax, dx
    add di, 0x0600
    pop es
    sub sp, 0x0400
    int 0x86
    cli
    int 0x86
    mov ax, 0xab50
    mov [di], ax
    db 0x8B, 0xF7 ;$1 mov si, di
    add di, 0x0002
    jmp si
    inc dx
    inc di
    db 0x6F
    db 0x6E
    db 0x65
    db 0x6E
    and [bx+di+0x73], cl
    and [bx+0x75], cl
    jb label1
    inc di
    db 0x6F
    db 0x64
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
label1:
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    push cs
    pop ss
    db 0x8B, 0xE0 ;$1 mov sp, ax
    db 0x8B, 0xFC ;$1 mov di, sp
    mov word [0x0003], 0xe0ff
    mov byte [0x0000], 0xb8
    mov [0x0002], ah
    mov [0x0001], al
    mov word [0x2015], 0x0000
    mov dx, 0xcccc
    push cs
    db 0x8B, 0xC2 ;$1 mov ax, dx
    add di, 0x0600
    pop es
    sub sp, 0x0400
    int 0x86
    nop
    int 0x86
    mov ax, 0xab50
    mov [di], ax
    db 0x8B, 0xF7 ;$1 mov si, di
    add di, 0x0002
    jmp si