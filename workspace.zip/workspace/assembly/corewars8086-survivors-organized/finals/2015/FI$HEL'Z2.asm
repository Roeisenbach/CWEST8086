    jmp label2
    nop
    mov bx, 0x001d
    db 0x03, 0xD8 ;$1 add bx, ax
    push ax
    xchg cx, ax
    pop dx
label1:
    mov ax, [0x2015]
    push ax
    db 0x33, 0xC1 ;$1 xor ax, cx
    xlatb
    xchg al, ah
    xlatb
    db 0x02, 0xC4 ;$1 add al, ah
    cmp al, 0x06
    jge label1
    ret
label2:
    mov word [0xcccc], 0x26ff
    mov word [0xccce], 0x4e4e
    mov [0x2222], cl
    nop
    nop
    nop
    mov word [0x0010], 0xfffd
    mov [0x1111], dl
    mov [0x2222], dl
    push ax
    push cs
    pop es
    mov ax, 0x86d7
    mov dx, 0xd7c4
    mov bx, 0x26ff
    mov cx, 0x4e4e
    int 0x87
    pop ax
    mov bx, 0x5678
    mov di, 0xff00
    push ax
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    mov di, 0xfe00
    int 0x86
    pop ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0117
    mov di, 0xff12
    mov cx, 0x0002
    cld
    rep movsw
    mov cx, 0x0007
    mov bp, [0x4e4e]
loop1:
    mov [0x4e4e], bp
    loop loop1
    mov [0x2015], bx
    mov [0x2015], bx
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    neg bx
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    neg bl
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    neg bx
    mov word [bx], 0x26ff
    mov word [bx+0x02], 0x4e4e
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov [0x2015], bx
    mov bx, 0xff12
    mov [0xfefd], bx
    mov [0xfeff], cs
    push cs
    pop ss
    mov sp, 0xfdff
    jmp bx
    call far [0xfefd]