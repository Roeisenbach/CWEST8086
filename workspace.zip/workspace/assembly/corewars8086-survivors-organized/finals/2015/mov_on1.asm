    jmp label2
    adc ax, 0x83ab
    mov word [di], 0x1cff
    adc al, 0xa6
    jns -59
    int3
    int3
    mov dx, ax
    mov bx, 0x7096
    mov si, cx
label1:
    mov di, [0x2015]
    mov word [0x1234], 0x7096
    cmp di, bx
    jz label1
    sub di, 0x0010
    int 0x86
    mov [0x2015], bx
    mov cx, 0x0040
loop1:
    mov word [0x1234], 0x7096
    add si, 0x0400
    mov word [si], 0x26ff
    mov word [si+0x02], 0x1234
    mov [0x2015], si
    loop loop1
    mov di, [0x1237]
    add di, 0x0400
    lea bx, [0x70df]
    mov word [di], 0xcccc
    add di, 0x0002
    jmp bx
    ret
    rep movsw
    xchg di, [bx+si-0x0121]
label2:
    stosw
    mov bx, ax
    push ds
    push es
    push ds
    pop es
    jmp label3+1
    aaa
    movsw
    lds dx, [bp+si]
    lds bx, [bx+di]
    ret
label3:
    db 0x8E, 0xA3, 0x37, 0x12 ;$1 mov es, [bp+di+0x1237]
    lea cx, [0x002c]
    lea si, [bx+word 0x000c]
    mov di, 0x7096
    rep movsw
    push ax
    jmp label4+2
    cmp bl, [bp+si-0x70]
    ret
label4:
    adc dl, [bx+di+0x06c7]
    xor al, 0x12
    xchg si, ax
    jo label6
    mov ax, 0xa15a
    mov dx, 0x2015
    mov bx, 0x26ff
    mov cx, 0x1234
    int 0x87
    pop bx
    lea di, [bx+0x0400]
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    pop ax
    pop ds
    add ax, 0x00d3
    mov si, 0x0032
    mov [si+0x02], cs
    mov [si], ax
    pop ss
    lea sp, [bx-0x0400]
    jmp label5+1
    jnb label6+2
    xchg cx, ax
    out 0xde, ax
label5:
    mov [0xccb8], ax
    int3
    add di, 0x00c8
    stosw
    add di, 0x0005
    call far [si]
    nop
    adc word [bx+di], 0x0079
    db 0x6F
    db 0x64
    db 0x61
    and [bx+di+0x73], ch
    and [si+0x6f], ch
    jbe 333
    cs:
label6:
    and [bx+di+0x6f], bh
    db 0x64
    db 0x61
    and [bx+di+0x73], ch
    and [si+0x69], ch
    db 0x66
    db 0x65
    cs:
    stosw
    add di, 0x0005
    call far [si]