    push cs
    pop es
    mov dx, 0x86cd
    db 0x8B, 0xC2 ;$1 mov ax, dx
    mov cx, 0xcccc
    db 0x8B, 0xD9 ;$1 mov bx, cx
    int 0x87
label1:
    mov bx, [0x2015]
    add bx, 0x0030
    mov word [bx], 0xcccc
    jmp label1