    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x000f
    nop
    mov al, 0xcc
label1:
    mov [bx], al
    add bx, 0x0008
    jmp label1