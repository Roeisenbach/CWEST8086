start:
    mov word [bx], 0xcccc
    add bx, 0x0002
    push ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x000d
    add di, 0x000d
    movsb
    jmp start