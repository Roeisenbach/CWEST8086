    db 0xE9, 0x02, 0x00 ;$1 jmp 5
    call far [bx]
    push ds
    push es
    pop ds
    mov bx, [0x0000]
    pop ds
    jmp bx