    mov si, ax
    add si, 0xff80
label1:
    mov di, 0x00cc
    mov [si], di
    add si, 0xffef
    jmp label1