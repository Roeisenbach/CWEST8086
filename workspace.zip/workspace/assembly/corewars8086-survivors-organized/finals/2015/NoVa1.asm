    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x012d
    add di, 0x0050
    mov dx, 0xcccc
    sub di, 0x1300
    int 0x86
    add di, 0x1300
    mov cx, 0x0100
    mov ax, 0x0002
loop1:
    add di, 0x0023
    mov [di], dx
    mov [di+0x11], dx
    loop loop1
    mov cx, 0xffff
    jmp loop1