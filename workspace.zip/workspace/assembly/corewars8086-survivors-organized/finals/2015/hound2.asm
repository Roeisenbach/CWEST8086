    mov si, ax
    push cs
    pop es
    mov dx, 0xf9eb
    mov ax, 0x03c3
    mov cx, 0xcccc
    mov bx, cx
    int 0x87
    mov bx, si
    add bx, 0x011e
label1:
    mov [bx], cx
    add bx, 0x0014
    jmp label1