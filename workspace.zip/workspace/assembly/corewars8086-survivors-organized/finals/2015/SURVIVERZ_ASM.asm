    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0118
    mov dx, 0xcccc
    db 0x8B, 0xC2 ;$1 mov ax, dx
    int 0x86
    int 0x86
label1:
    mov [di], dx
    add di, 0x0008
    jmp label1