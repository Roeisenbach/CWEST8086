start:
    add ax, 0x0011
    push es
    pop ds
    mov bx, 0x001e
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x0270
    call far [bx]
    jmp start