    push ds
    pop es
    mov di, ax
    add di, 0x0628
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x05f4
    db 0x83, 0xC0, 0x2A ;$1 add ax, 0x002a
    mov bx, ax
    add bx, 0x0030
    mov [bx], ax
    mov [bx+0x02], cs
    mov ax, 0xcccc
    mov dx, ax
    add dx, 0x9810
    int 0x86
    int 0x86
    stosw
    add di, 0x0006
    call far [bx]
    add [bx+si], al
    add [bx+si], al