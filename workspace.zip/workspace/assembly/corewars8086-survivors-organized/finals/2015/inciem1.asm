    push cs
    pop es
    mov bx, 0x0000
    mov [bx], ax
    jmp $