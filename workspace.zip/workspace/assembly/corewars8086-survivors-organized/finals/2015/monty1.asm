    push es
    pop ds
    mov bx, 0x0064
    mov si, ax
    add si, word 0x0022
    mov [bx+0x02], cs
    mov [bx], si
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x0400
    mov di, ax
    add di, 0x0400
    push ax
    mov cx, 0x0200
label1:
    call far [bx]
    cmp cx, 0x0000
    jnz label1
    xor si, si
    mov si, 0xcccc
label2:
    movsw
    jmp label2