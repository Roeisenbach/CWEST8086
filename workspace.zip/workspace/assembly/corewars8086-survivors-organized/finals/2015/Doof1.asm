    mov bp, 0x1800
    mov dx, ax
    db 0x83, 0xE0, 0xF0 ;$1 and ax, 0xfff0
    mov si, ax
    add si, 0x0003
    mov cx, 0x18ff
    mov [si], cx
    shr ax, 1
    shr ax, 1
    shr ax, 1
    shr ax, 1
    and ax, 0x0fff
    add ax, 0x0ff6
    push ds
    push es
    pop ds
    pop es
    mov [0x025e], si
    and di, 0xfff0
    mov bx, 0x0500
    mov di, 0x00a3
    mov [bx], di
    mov [bx+0x02], ax
    push ax
    push bx
    push dx
    mov di, ax
    mov ax, 0x1e06
    mov dx, 0x1f07
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop dx
    pop bx
    pop ax
    jmp label1
    movsw
    movsw
    mov cl, 0x18
    rep movsw
    sub ax, 0x0180
    or ax, 0x1000
    mov [bx+0x02], ax
    les di, [bx]
    mov si, 0x001c
    movsw
    dec di
    sub sp, 0x0c00
    xor si, si
    call far [bx+si]
label1:
    push ds
    push es
    pop ds
    pop es
    mov si, dx
    add si, word 0x004e
    mov di, 0x0000
    mov cx, 0x0020
    rep movsw
    push ds
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, [0x025e]
    and sp, 0xfff0
    mov dx, sp
    add dx, 0x0003
    mov di, dx
    inc di
    mov si, 0x0000
    add sp, 0x0c03
    call far [bx+si]
    movsw