    push es
    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0132
    add di, 0x1000
    mov dx, 0xcccc
    push ax
    db 0x8B, 0xC2 ;$1 mov ax, dx
    int 0x86
    add di, 0x0800
    int 0x86
    pop ax
    pop es
    push cs
    pop ss
    push cs
    pop es
    db 0x8B, 0xE0 ;$1 mov sp, ax
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0032
    add ax, 0x002b
prcd1:
    movsw
    db 0x2B, 0xE6 ;$1 sub sp, si
    push cs
    call prcd1