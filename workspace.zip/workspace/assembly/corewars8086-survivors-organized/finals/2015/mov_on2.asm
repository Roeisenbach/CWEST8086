    push es
    pop ss
    mov bp, [bp+0x00]
    mov bx, ax
    mov sp, 0x0064
    push ds
    pop ss
    push bx
    push es
    push ds
    pop es
    mov dx, 0xe243
    mov ax, 0xc3d1
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop es
    pop bx
    push ds
    pop ss
    lea sp, [bp-0x1388]
    lea si, [bx+0x0094]
    lea di, [bp+0x0600]
    push ds
    pop es
    movsw
    mov cx, 0xcccc
    xchg bx, di
    mov dx, cx
    mov ax, dx
    lea di, [bp-0x1388]
    int 0x86
    int 0x86
    xchg bx, di
    lea si, [di-0x02]
    jmp si
    movsw
    push cx
    push es
    pop ss
    mov bp, [bp+0x00]
    mov bx, ax
    mov sp, 0x0064
    push ds
    pop ss
    push bx
    push es
    push ds
    pop es
    mov dx, 0xe243
    mov ax, 0xc3d1
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop es
    pop bx
    push ds
    pop ss
    lea sp, [bp-0x1388]
    lea si, [bx+0x0094]
    lea di, [bp+0x0600]
    push ds
    pop es
    movsw
    mov dx, 0xcccc
    xchg bx, di
    mov dx, cx
    mov ax, dx
    lea di, [bp-0x1388]
    int 0x86
    int 0x86
    xchg bx, di
    lea si, [di-0x02]
    jmp si
    movsw
    push dx
    push es
    pop ss
    mov bp, [bp+0x00]
    mov bx, ax
    mov sp, 0x0064
    push ds
    pop ss
    push bx
    push es
    push ds
    pop es
    mov dx, 0x071f
    mov ax, 0x061e
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop es
    pop bx
    push ds
    pop ss
    lea sp, [bp-0x1388]
    lea si, [bx+0x0094]
    lea di, [bp+0x0600]
    push ds
    pop es
    movsw
    mov cx, 0xcccc
    xchg bx, di
    mov dx, cx
    mov ax, dx
    lea di, [bp-0x1388]
    int 0x86
    int 0x86
    xchg bx, di
    lea si, [di-0x02]
    jmp si
    movsw
    push cx