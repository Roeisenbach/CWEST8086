    mov si, ax
    add si, 0x0080
label1:
    mov di, 0x00cc
    mov [si], di
    add si, 0x0016
    jmp label1