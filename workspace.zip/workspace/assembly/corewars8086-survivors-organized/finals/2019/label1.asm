    add ax, 0x0032
    db 0x8B, 0xD8 ;$1 mov bx, ax
    sub ax, 0x0032
label1:
    cmp [bx], ax
    jb label2
    add al, 0x2c
    cmp [bx], ax
    ja label2
    jmp label3
    nop
label2:
    sub al, 0x2c
    mov word [bx], 0xcccc
    add bh, 0x02
    cmp bh, 0xfe
    jb label3
    db 0x32, 0xFF ;$1 xor bh, bh
    add bl, 0x1e
label3:
    sub al, 0x2c
    jmp label1