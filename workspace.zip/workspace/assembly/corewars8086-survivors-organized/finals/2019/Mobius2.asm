    mov bx, 0x154a
    mov cx, 0x4f00
    mov [bx+0x3b], cx
    mov [bx+0x5b], cx
    mov [bx+0x009b], cx
    mov [bx+0x00ab], cx
    mov [bx+0x6b], cx
    mov [bx+0x008b], cx
    mov [bx+0x7b], cx
    mov [bx+0x4b], cx
    mov di, [bx+0x1d]
    mov [di+0x25], cx
    mov di, [bx+0x3d]
    mov [di+0x25], cx
    mov di, [bx+0x7d]
    mov [di+0x25], cx
    mov di, [bx+0x008d]
    mov [di+0x25], cx
    mov di, [bx+0x4d]
    mov [di+0x25], cx
    mov di, [bx+0x6d]
    mov [di+0x25], cx
    mov di, [bx+0x5d]
    mov [di+0x25], cx
    mov di, [bx+0x2d]
    mov [di+0x25], cx
    mov dx, [si]
    push es
    push ds
    pop es
    xchg cx, ax
    mov di, dx
    sub di, 0x0080
    int 0x86
    mov di, 0x1500
    int 0x86
    xchg cx, ax
    pop es
    add ax, 0x002f
    jmp label1
    db 0xC6, 0xC2, 0x00 ;$1 mov dl, 0x00
    mov cx, 0x006e
    mov di, 0x0200
    rep movsw
    mov di, 0x0051
    mov cl, 0x04
    rep movsw
    push es
    push ds
    pop es
    db 0xC6, 0xC2, 0x00 ;$1 mov dl, 0x00
    mov cx, 0x006e
    mov di, 0x0200
    rep movsw
    mov di, 0x0051
    mov cl, 0x04
    rep movsw
    push es
    push ds
    pop es
label1:
    push es
    pop ss
    mov si, [bp+0x00cc]
    mov bx, 0x03fc
    lea sp, [bx+0x04]
    add si, 0x0117
    mov [si+0x0209], si
    mov [si-0x0495], si
    mov bp, si
    xchg si, ax
    add si, 0x00c2
    mov cx, 0x006e
    mov di, 0x0200
    rep movsw
label2:
    mov di, 0x0051
label3:
    mov cl, 0x04
    rep movsw
    push es
    push ds
    pop es
    pop ds
    mov di, 0x0200
    mov cl, 0x2c
loop1:
    xor word [di], 0x11d7
    add di, 0x0005
    loop loop1
    mov ax, 0x1fff
label4:
    mov dx, 0xcccc
    int 0x87
label5:
    push cs
    pop ss
    lea di, [si-0x00e4]
    mov si, 0x02c0
    xor byte [bx], 0x10
    jz label6
    add si, 0xff72
label6:
    movsw
    sub ah, al
    mov cx, [bp-0x2af7]
    sub [bp-0x0495], cl
    mov [0x8314], ax
label7:
    db 0xC6, 0x3E, 0x50, 0xF0, 0x30 ;$7 mov byte [0xf050], 0x30
    in ax, dx
    mov al, dh
    mov ah, 0xa5
    add sp, dx
    jb label3
    mov cl, 0x08
    movsw
    and al, 0xb4
    mov di, bp
    db 0x80, 0xE8, 0x11 ;$1 sub al, 0x11
    jnz label8
    mov si, 0x13d7
    mov cl, 0x0a
label8:
    movsw
    cbw
    out dx, al
    in ax, 0xa5
    nop
    jb label2
    std
    movsw
    movsw
    jb label5
    add bp, 0xdf7c
    mov ah, 0xa5
    movsw
    movsw
label9:
    pop si
    db 0xFE, 0xA5, 0xFF, 0xE5
    jb label4
    add al, 0xa5
    db 0xF3, 0x72
    test ax, 0xab50
    lea si, [bx+di-0x6b]
    imul word [bp+di+0x66a5]
    sbb sp, [di-0x5a0d]
    out dx, al
    std
    jnz label10+1
    xor [di], ax
    nop
    in ax, dx
    db 0xD6
label10:
    adc dl, [bp-0x2c]
    jl label11
    mov [bx+si], di
    mov ah, 0xff
    in ax, 0x90
    jb label7+3
label11:
    pop ss
    movsw
    db 0xF3, 0x72
    cwd
    daa
    xchg di, ax
    mov cx, 0x14d3
    lea sp, [bp+0x2e8c]
    xchg sp, ax
    db 0xD2, 0x75, 0x04
    push si
    aad 0x38
    or al, 0x87
    add cl, [si+0x5f]
    shl di, cl
label12:
    pop si
    jb label12
    sub sp, 0xffd4
    out dx, ax
    int 0x75
    db 0xF2, 0x50
    les dx, [bx+0x2f38]
    mov [0x8312], ax
    out dx, al
    jo 516
    and word [di+0x0cb1], 0xe272
label13:
    movsw
    mov [bp+0x13de], bp
    mov [bp+0x2c6b], bp
    cbw
    db 0x6F
    add al, [bx+di+0x13b8]
    das
    db 0x02, 0xC7 ;$1 add al, bh
    rcl word [bx+byte 0x00], 1
    xor si, si
    jb label9
    movsw
    mov cl, 0x0b
    jb label13
    movsw
    mov ax, 0x72f3
    mov al, [0xba0a]
    db 0x8D, 0xD9
    pushf
    cmpsb
    push di
    sti
    pop si
    db 0xFE, 0xBE, 0x00, 0x02
    jb 552
    jmp bp
    nop
    movsw
    movsw
    movsw
    mov [bp+0x0217], bl
    movsw
    db 0xC6, 0xC2, 0x00 ;$1 mov dl, 0x00
    mov cx, 0x006e
    mov di, 0x0200
    rep movsw
    mov di, 0x0051
    mov cl, 0x04
    rep movsw
    push es
    push ds
    pop es
    db 0xC6, 0xC2, 0x00 ;$1 mov dl, 0x00
    mov cx, 0x006e
    mov di, 0x0200
    rep movsw
    mov di, 0x0051
    mov cl, 0x04
    rep movsw
    push es
    push ds
    pop es