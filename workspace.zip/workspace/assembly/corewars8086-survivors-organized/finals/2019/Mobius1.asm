    add ax, 0x0051
    jmp label1
    out dx, ax
    mov al, [0xcd00]
    xchg al, [bx]
    pop di
    mov cl, 0x0e
    rep movsw
    mov di, 0x0028
    mov al, 0xab
    stosb
    mov ax, 0x01a5
    mov dx, 0xabd4
    int 0x86
    lea si, [bp+0x00c2]
    mov cl, 0xa5
    int3
    int3
    int3
    stosw
    int3
    int3
    int3
    out dx, ax
    mov al, [0xcd00]
    xchg al, [bx]
    pop di
    mov cl, 0x0e
    rep movsw
    mov di, 0x0028
    mov al, 0xab
    stosb
    mov ax, 0x01a5
    mov dx, 0xabd4
    int 0x86
    lea si, [bp+0x00c2]
    mov cl, 0xa5
    int3
    int3
    int3
    stosw
    int3
    int3
    int3
label1:
    mov bp, ax
    mov di, 0x00cc
    stosw
    xor di, di
    lea si, [bp+0x009a]
    mov cl, 0x06
    rep movsw
    push di
    mov ax, 0xcccc
    mov dx, 0xcccc
    mov di, [0x9090]
    push es
    push ds
    pop es
    sub di, 0x00a0
    int 0x86
    pop es
    pop di
    mov cl, 0x0e
    rep movsw
    mov di, 0x0028
    mov al, 0xab
    stosb
    mov ax, 0x01a5
    mov dx, 0xabd4
    int 0x86
    lea si, [bp+0x00c2]
    mov cl, 0x40
label2:
    mov di, 0x0060
    rep movsw
    mov dl, 0xdc
    mov cl, 0x09
loop1:
    stosw
    xchg dx, ax
    stosw
    xchg dx, ax
    loop loop1
    mov cl, 0x10
label3:
    rep movsw
    push ds
    push es
    pop ds
    pop es
    xor di, di
    mov cl, 0x08
    call prcd1
    mov byte [0x03fc], 0x10
    mov di, 0x0060
    mov cl, 0x1a
    call prcd1
    mov di, 0x00e0
    mov si, 0x0028
    mov dx, 0xcccc
    mov ax, 0x1fff
    int 0x87
label4:
    mov ax, 0x0100
    push cs
    sub bp, ax
    pop ss
    mov dx, 0x75f0
    mov bx, 0xccab
    mov ax, 0xa553
    mov di, bp
    lea sp, [bp-0x02d8]
    movsb
    jmp bp
prcd1:
    xor word [di], 0x11d7
    add di, 0x0005
    loop prcd1
    ret
    jb label3+1
    movsw
label5:
    mov bp, [0x1229]
    movsw
    movsw
    movsw
    jb label2
    out dx, ax
    movsw
    push word [bp+si]
loop2:
    mov ah, 0xb1
    or [di-0x4bdc], sp
loop3:
    add bp, 0x0018
label6:
    adc [bx], dx
    cld
    add ax, [bx+si]
    adc [di+0x1e], dl
    add sp, dx
    pop dx
    mov bh, 0x28
    std
    movsb
    jb label4+1
    mov cl, 0x08
    movsw
    and al, 0xb4
    xor [0xd4fc], ah
    db 0x64
    or [bp-0x28d8], bh
    cbw
    out dx, ax
    movsb
    push word [bp+si]
    mov ah, 0x90
    movsw
    movsw
    jb prcd1+2
    add bp, 0xdf7c
    mov ah, 0xa5
    movsw
    movsw
    pop si
    db 0xFE, 0xA5, 0xFF, 0xE5
    jb label5+3
    movsw
    movsw
    lea si, [bx+di+0x31]
    clc
    movsw
    movsw
    db 0x6C
    popf
    inc cx
    movsw
    movsw
    db 0x66
    or sp, [di-0x5a0d]
    pop si
    mov di, 0xff6c
    mov [bx+di+0x65], di
    add [bx+di], di
    loop loop2+1
    adc ax, 0xec81
    or ch, dl
    xchg si, ax
    aad 0x87
    in al, dx
    inc ax
    test al, 0x04
    add ax, 0x718d
    db 0x62
label7:
    add [di+0x5f], bx
    add al, 0xf6
    mov [bp+di-0x03], sp
    push sp
    std
    db 0x03, 0xFE ;$1 add di, si
    int 0xa2
    jcxz loop3
    aad 0x97
    db 0x6F
    inc dx
    movsw
    xor ch, ch
    jb label6
    movsw
    mov cl, 0x05
    jb label7
    movsw
    lea sp, [bp-0x114d]
    mov di, bp
    movsw
    sub ah, dh
    nop
    movsw
    mov cl, 0x0d
    movsw
    rep movsw
    mov si, 0x00e0
    mov dx, [bp+0x0174]
    cmp [bp-0x0094], dx
    jz label8
    mov sp, bp
    add bp, bx
    mov si, 0x0096
label8:
    mov di, bp
    movsw
    jmp bp
    nop
    out dx, ax
    mov al, [0xcd00]
    xchg al, [bx]
    pop di
    mov cl, 0x0e
    rep movsw
    mov di, 0x0028
    mov al, 0xab
    stosb
    mov ax, 0x01a5
    mov dx, 0xabd4
    int 0x86
    lea si, [bp+0x00c2]
    mov cl, 0xa5
    int3
    int3
    int3
    stosw
    int3
    int3
    int3
    out dx, ax
    mov al, [0xcd00]
    xchg al, [bx]
    pop di
    mov cl, 0x0e
    rep movsw
    mov di, 0x0028
    mov al, 0xab
    stosb
    mov ax, 0x01a5
    mov dx, 0xabd4
    int 0x86
    lea si, [bp+0x00c2]
    mov cl, 0xa5
    int3
    int3
    int3
    stosw
    int3
    int3
    int3