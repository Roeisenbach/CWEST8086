    jmp label1+1
    nop
    xchg si, ax
    add dl, dl
    add [bx+si], ax
    add ah, ch
    add [bx+si], al
label1:
    add bh, al
    push es
    lds dx, [di]
    add [bp+si], dh
    mov word [0x15d5], 0x3200
    mov word [0x15e5], 0x3200
    mov word [0x15f5], 0x3200
    push ds
    push es
    pop ds
    mov [0x03e8], ax
    mov dx, [0x03ea]
    pop ds
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0003
    add [di], ax
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov [bx+0x0097], ax
    mov si, [0x15c7]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    mov [bx+0x00c7], ax
    nop
    mov word [si+0x28], 0xcccc
    db 0x8B, 0xD2 ;$1 mov dx, dx
    mov si, [0x15d7]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    nop
    mov word [si+0x28], 0xcccc
    mov si, [0x15b7]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    nop
    mov word [si+0x28], 0xcccc
    mov si, [0x15a7]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    nop
    mov word [si+0x28], 0xcccc
    jmp label7
label2:
    mov byte [bx+0x009c], 0x00
    jmp label4
    nop
    mov ax, 0xaf52
    db 0x8B, 0xD8 ;$1 mov bx, ax
    jmp label2
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, [bx+0x05]
    add word [bx+0x05], 0x0004
    mov cx, 0x0461
loop1:
    jmp label3
    nop
    int3
label3:
    add di, 0x0014
    loop loop1
    mov cx, 0x0461
    add di, 0x01e7
    jmp loop1
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov ax, 0x1234
    jmp word [bx+0x0113]
label4:
    mov ax, 0x1234
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov cx, 0x3f8b
    push cs
    pop dx
    sub dx, 0x0015
    add ax, 0x0150
    db 0x8B, 0xF8 ;$1 mov di, ax
    push ds
    pop ss
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x0150
    add [bx+0x09], di
    mov [bx+0x0b], dx
    call far [bx+0x09]
loop2:
    jmp label5
    nop
label5:
    loop loop2
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x0150
    mov cx, 0x3f8b
    jmp loop2
    mov ax, 0x1234
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xE0 ;$1 mov sp, ax
    mov cx, 0x3f8b
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add dx, 0x023c
    mov [bx+0x09], dx
    sub dx, 0x0003
    jmp dx
    push bx
label6:
    add [di-0x7f00], bx
    db 0xC7, 0x11, 0x03, 0xEB ;$2 mov word [bx+di], 0xeb03
    dec si
    nop
label7:
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov di, 0x0000
    mov cx, 0x00e9
    rep movsw
    push ax
    mov di, 0x00ab
    mov ax, 0x05c7
    stosw
    mov ax, 0xcccc
    stosw
    mov di, 0x00e9
    mov ax, 0x5fff
    stosw
    mov al, 0x09
    stosb
    pop ax
    jmp label8
    nop
label8:
    db 0x3B, 0xDA ;$1 cmp bx, dx
    jb label9
    jmp label10
    nop
label9:
    db 0x33, 0xD2 ;$1 xor dx, dx
    jmp label11
    nop
label10:
    db 0x2B, 0xDA ;$1 sub bx, dx
    mov dx, 0x8000
    db 0x2B, 0xD3 ;$1 sub dx, bx
label11:
    mov cx, 0x0064
    mov si, 0x0000
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x6050
    db 0x03, 0xFA ;$1 add di, dx
    db 0x33, 0xD2 ;$1 xor dx, dx
    cmp di, 0xfcee
    jnb label6+3
    loop $
    push es
    push ds
    pop es
    pop ds
    push di
    mov cx, 0x00e9
    rep movsw
    pop di
    push es
    push ds
    pop es
    pop ds
    db 0x8B, 0xF0 ;$1 mov si, ax
    add [si+0x0111], di
    inc bp
    cmp bp, 0x008b
    jnb label12
    mov word [di+0x05], 0x01d2
    mov [si+0x00c0], di
    add [si+0x0113], di
    mov byte [si+0x00b3], 0x0b
    mov [si+0x00fa], di
    mov byte [si+0x00ed], 0x0b
    db 0x8B, 0xC7 ;$1 mov ax, di
    jmp word [si+0x0111]
label12:
    mov word [di+0x05], 0xcccc
    mov word [si+0x00c0], 0xcccc
    add word [si+0x0113], 0xcccc
    mov word [si+0x00b2], 0xcccc
    mov word [si+0x00fa], 0xcccc
    mov word [si+0x00ec], 0xcccc
    db 0x8B, 0xC7 ;$1 mov ax, di
    jmp word [si+0x0111]