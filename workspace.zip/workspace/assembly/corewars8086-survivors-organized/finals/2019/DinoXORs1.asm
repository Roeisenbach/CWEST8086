    jmp label1+2
    mov cx, 0x9005
    nop
    nop
    nop
    nop
    push es
    push es
    pop ds
    xchg di, ax
    lodsw
    xchg di, ax
    push cs
    pop ds
    push cs
    pop es
    add ax, 0x00e2
    mov dx, di
    add di, 0x0054
    mov si, ax
    mov cx, 0x0037
    rep movsw
    mov si, dx
    pop es
    mov di, 0x0050
    mov cx, 0x0061
    rep movsw
    sub di, 0x00c2
    sub si, 0x006e
    xchg di, si
    jmp di
    push cs
    pop ds
    lea bx, [di+0x02ca]
    mov word [bx], 0xaaaa
    lea bx, [di-0x00b0]
    mov word [bx], 0xaaaa
    cmp word [di+0x02ca], 0xaaaa
    db 0x0F
    test di, ax
    add [bx+di+0x50bd], al
    jmp far [bp+si+0x0faa]
    test di, dx
    add cl, ch
    xchg dx, ax
    add [0x070e], al
    pop ds
    add di, ax
    mov cx, 0x0061
    rep movsw
    sub si, 0x00c2
    sub di, 0x006e
    push ds
    pop es
    jmp di
    push es
    pop ds
    mov ax, 0x02ca
    mov word [0x000a], 0x031e
    push cs
    pop ds
    mov bx, dx
    mov word [bx+0x0d], 0x9090
    add dx, 0x031e
    jmp label3
    push es
    pop ds
    mov ax, 0xfe8e
    mov word [0x000a], 0xfee2
    push cs
    pop ds
    mov bx, dx
    mov word [bx+0x0d], 0x9090
    add dx, 0xfee2
    jmp label3
label1:
    mov cx, 0x9005
    nop
    nop
    nop
    nop
    push es
    push es
    pop ds
    xchg di, ax
    lodsw
    xchg di, ax
    push cs
    pop ds
    push cs
    pop es
    add ax, 0x00e2
    mov dx, di
    add di, 0x0054
    mov si, ax
    mov cx, 0x0037
    rep movsw
    mov si, dx
    pop es
    mov di, 0x0050
    mov cx, 0x0061
    rep movsw
    sub di, 0x00c2
    sub si, 0x006e
    xchg di, si
    jmp di
    push cs
    pop ds
    lea bx, [di+0x02ca]
    mov word [bx], 0xabae
    lea bx, [di-0x00b0]
    mov word [bx], 0xabae
label2:
    cmp word [di+0x02ca], 0xabae
    jnz label4
    cmp word [di-0x00b0], 0xabae
    jnz label5
    jmp label2
label3:
    push es
    push cs
    pop es
    pop ds
    add di, ax
    mov cx, 0x0061
    rep movsw
    sub si, 0x00c2
    sub di, 0x006e
    push ds
    pop es
    jmp di
label4:
    push es
    pop ds
    mov ax, 0x02ca
    mov word [0x000a], 0x031e
    push cs
    pop ds
    mov bx, dx
    mov word [bx+0x0d], 0x9090
    add dx, 0x031e
    jmp label3
label5:
    push es
    pop ds
    mov ax, 0xfe8e
    mov word [0x000a], 0xfee2
    push cs
    pop ds
    mov bx, dx
    mov word [bx+0x0d], 0x9090
    add dx, 0xfee2
    jmp label3
    mov cx, 0x9005
    nop
    nop
    nop
    nop
    push es
    push es
    pop ds
    xchg di, ax
    lodsw
    xchg di, ax
    push cs
    pop ds
    push cs
    pop es
    add ax, 0x00e2
    mov dx, di
    add di, 0x0054
    mov si, ax
    mov cx, 0x0037
    rep movsw
    mov si, dx
    pop es
    mov di, 0x0050
    mov cx, 0x0061
    rep movsw
    sub di, 0x00c2
    sub si, 0x006e
    xchg di, si
    jmp di
    push cs
    pop ds
    lea bx, [di+0x02ca]
    mov word [bx], 0xaaaa
    lea bx, [di-0x00b0]
    mov word [bx], 0xaaaa
    cmp word [di+0x02ca], 0xaaaa
    db 0x0F
    test [bp+si-0x01], di
    cmp word [di-0x00b0], 0xaaaa
    jnz label5
    jmp label2
    push es
    push cs
    pop es
    pop ds
    add di, ax
    mov cx, 0x0061
    rep movsw
    sub si, 0x00c2
    sub di, 0x006e
    push ds
    pop es
    jmp di
    push es
    pop ds
    mov ax, 0x02ca
    mov word [0x000a], 0x031e
    push cs
    pop ds
    mov bx, dx
    mov word [bx+0x0d], 0x9090
    add dx, 0x031e
    jmp label3
    push es
    pop ds
    mov ax, 0xfe8e
    mov word [0x000a], 0xfee2
    push cs
    pop ds
    mov bx, dx
    mov word [bx+0x0d], 0x9090
    add dx, 0xfee2
    jmp label3