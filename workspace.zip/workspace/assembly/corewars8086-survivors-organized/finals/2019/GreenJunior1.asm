    dec cx
    inc sp
    inc bp
    inc cx
    dec sp
    or ax, 0x4d0a
    dec di
    inc sp
    inc bp
    dec sp
    and [si+0x69], dh
    db 0x6E
    jns label1
    or al, [bp+di+0x4f]
    inc sp
    inc bp
    push bx
    inc bp
    inc di
    or ax, 0x6f0a
    jb label4
label1:
    and [bx+di], dh
    xor [bx+si], dh
    db 0x68
    or ax, 0x730a
    jz label5+2
    jb label8+1
    cmp cl, [di]
    or ah, [bx+si]
    and [bx+si], ah
    and [bx+di+0x64], ah
    db 0x64
    and [bx+di+0x78], ah
    sub al, 0x63
    db 0x61
    db 0x6C
    db 0x6C
    pop di
    db 0x66
    db 0x61
    jb label2+1
    jnb label12+1
    db 0x61
    jb label14
    or ax, 0x200a
    and [bx+si], ah
    and [bx+si+0x75], dh
    jnb label13
    and [di+0x73], ah
    or ax, 0x200a
    and [bx+si], ah
    and [bx+si+0x6f], dh
    jo label3
    db 0x64
    jnb label2
    or ah, [bx+si]
    and [bx+si], ah
    and [di+0x6f], ch
    jbe label5+2
    db 0x62
    js label7
    aaa
label2:
    cmp [bx+si+0x0d], ch
    or ah, [bx+si]
    and [bx+si], ah
    and [di+0x6f], ch
    jbe label7+1
    pop bx
    db 0x62
    js label10
label3:
    xor bl, [di+0x2c]
    db 0x63
    jnb label6
    or ah, [bx+si]
label4:
    and [bx+si], ah
label5:
    and [di+0x6f], ch
    jbe label11
    pop bx
    db 0x62
    js 238
label6:
    sub al, 0x61
    js label9+1
    or ah, [bx+si]
    and [bx+si], ah
label7:
    and [bx+si+0x75], dh
    jnb 262
label8:
    and [bp+di+0x73], ah
label9:
    or ax, 0x200a
    and [bx+si], ah
    and [bx+si+0x6f], dh
label10:
    jo label15+1
    jnb 288
label11:
    or ax, 0x200a
    and [bx+si], ah
    and [di+0x6f], ch
    jbe label16+1
label12:
    jnb 297
label13:
    sub al, 0x61
label14:
    js label15
    or ah, [bp+di+0x61]
    db 0x6C
    db 0x6C
    pop di
    db 0x66
    db 0x61
    jb 257
    or ax, 0x200a
label15:
    and [bx+si], ah
    and [bp+di+0x61], ah
    db 0x6C
    db 0x6C
    and [bp+di+0x64], bl
    ja 325
label16:
    jb 316
    and [bp+si+0x78], ah
    pop bp
    or ax, 0x450a
    dec si
    inc sp
    and [bp+di+0x74], dh
    db 0x61
    jb 347
    or ax, 0x0d0a
    db 0x0A  ; or al, [bx+si]