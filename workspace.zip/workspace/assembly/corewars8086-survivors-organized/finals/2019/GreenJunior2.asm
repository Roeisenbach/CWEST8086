    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x011a
    push cs
    pop es
    push cs
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add di, 0x011a
    push cs
    pop ss
    db 0x8B, 0xE3 ;$1 mov sp, bx
    mov dx, 0xcccc
label1:
    push dx
    stosw
    jmp label1