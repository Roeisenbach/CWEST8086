    jmp label3+1
    cmp [bx+di], bp
    push bx
    mov ch, 0xdc
    mov [di], ax
    test al, 0xa5
    dec bx
    jg label1+1
    call 0x0b34:0x825d
    in ax, dx
    esc 0xd8
    loop -94
    cld
    in al, 0x12
    aaa
    esc 0xd8
label1:
    test ax, 0xeeb7
    movsw
    xlatb
label2:
    mov cx, 0x17c4
    js label2
    db 0x8A, 0xE5 ;$1 mov ah, ch
    cld
    xchg cx, ax
    db 0x8B, 0xC8 ;$1 mov cx, ax
    db 0x82, 0x85, 0xE2, 0xF5, 0xF0 ;$1 add byte [di-0x0a1e], 0xf0
    and [bp+si], al
    and ax, 0x979d
    dec sp
    hlt
    and ax, 0xe9df
    dec di
    push di
    dec cx
    pop sp
    retf 0xddbe
    cmp [0x8531], ax
    sbb [bp+si], cx
    sbb ax, [bx+di]
    mov si, 0x0327
    ss:
    cwd
    ja -32
    and bh, [bp+si-0x05e6]
    mov ch, 0xe1
    mov [di], bp
    esc 0xd8
    mov si, 0x8267
    db 0xF1
    db 0x67
    mov dl, 0xb6
    esc 0xde
    mov dl, 0xea
    call 2518
    daa
    call -16602
    db 0x0F
    add [0xceec], bx
    les dx, [bx+0x1f8b]
    rcr dl, cl
    push ss
    cmp word [bp+si-0x51], 0xf136
    adc bh, bl
    adc [bp+di], ax
    xor [bx+di-0x1284], dh
    scasb
    mov [0x0a09], ax
    db 0x69
    push ax
    test [si-0x0a], si
    hlt
    db 0x63
    and al, 0x46
    esc 0xd9
    mov si, 0xc364
    db 0x12, 0xF6 ;$1 adc dh, dh
    hlt
    db 0x6E
    and al, 0x37
    stc
    jz label5
    db 0x67
    db 0x8E, 0xB4, 0xDA, 0xB8 ;$1 mov ss, [si-0x4726]
    push ss
    mov cl, 0xba
    jmp 15611
    or [bp+si], cx
    call 14425
    db 0xC8
    db 0x82, 0xF1, 0xEE ;$1 xor cl, 0xee
    jbe label4
label3:
    xor dl, [bx+si-0x6f70]
    db 0x9B, 0x9B ;$1 nrg
    mov word [0x15b5], 0x1100
    mov word [0x15b5], 0x1100
    push es
    push ds
    pop es
    push ax
    mov ax, 0xa5f3
    mov dx, 0xff31
    mov ch, 0xcc
    mov cl, ch
    mov bx, cx
    int 0x87
    mov word [0x1597], 0x0000
    mov di, [0x9090]
    sub di, 0x0030
    mov ax, 0xcccc
    mov dx, 0xcccc
label4:
    int 0x86
    pop ax
    pop es
    mov si, ax
    add si, 0x0003
    mov cx, 0x0052
    push ds
label5:
    pop ss
    add ax, 0x00a6
    xor bx, bx
    xor di, di
loop1:
    and bx, 0x000f
    mov bp, ax
    add bp, bx
    mov dx, [bp+0x00]
    xor [si+word 0x0000], dx
    add bx, 0x0002
    movsw
    loop loop1
    mov cx, 0x0052
    sub ax, 0x5000
    push es
    push ds
    pop es
    pop ds
    xor si, si
    mov di, ax
    mov bp, ax
    sub bp, 0x0002
    mov word [bp+0x00], 0xa5f3
    mov bx, 0x0188
    mov [bx+word 0x0002], cs
    db 0x83, 0xE8, 0x02 ;$1 sub ax, 0x0002
    mov word [bp+0x50bd], 0x9090
    jmp bp
    mov bx, ss
    sub bx, 0x01c0
    mov es, bx
    mov di, 0x0000
    mov si, ax
    add si, 0x002e
    mov cx, 0x0034
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push es
    pop ss
    mov bp, ax
    add bp, 0x002e
    mov bx, 0x5200
    jmp $
    sub bp, 0x4ff5
    mov cx, 0x0034
    jmp label9
    mov ax, 0xbcb2
    mov di, bp
    add di, 0x0366
    mov cx, 0x0040
    rep stosw
    mov di, bp
    sub di, 0x0380
    mov cx, 0x0040
    rep stosw
    xor si, si
    mov cx, 0x0034
label6:
    dec bx
    jz label10
    add si, 0x0002
    and si, 0x007f
    mov dx, [bp+si+0x0366]
    cmp [bp+si-0x0380], dx
    jz label6
    cmp dx, 0xbcb2
    jnz label7
    lea dx, [bp+si-0x0380]
    jmp label8
label7:
    lea dx, [bp+si+0x0366]
label8:
    mov byte [bp-0x40], 0xba
    mov [bp-0x3f], dx
    mov byte [bp-0x3d], 0x90
    sub byte [bp-0x54], 0x01
    sub bp, 0x1000
label9:
    xor si, si
    mov di, bp
    mov word [bp-0x02], 0xa5f3
    mov ax, bp
    db 0x83, 0xE8, 0x02 ;$1 sub ax, 0x0002
    jmp ax
label10:
    int 0x03