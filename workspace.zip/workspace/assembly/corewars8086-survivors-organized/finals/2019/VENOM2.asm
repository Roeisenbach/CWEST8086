    push ds
    pop es
    push ax
    pop di
    push ax
    pop si
    add di, 0x0032
    add ax, 0x0032
    mov cx, 0x0015
    cld
    rep movsw
    db 0x8B, 0xD8 ;$1 mov bx, ax
    jmp bx