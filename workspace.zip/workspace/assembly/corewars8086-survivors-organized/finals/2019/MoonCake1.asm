    stosw
    push ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0014
    nop
    mov ax, 0xcccc
    db 0x9B, 0x9B ;$1 nrg
label1:
    add di, 0x000a
    stosw
    jmp label1