    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    dec cx
    inc sp
    inc bp
    inc cx
    dec sp
    or ax, 0x200a
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [di+0x4f], cl
    inc sp
    inc bp
    dec sp
    and [si+0x69], dh
    db 0x6E
    jns label1
    or ah, [bx+si]
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bp+di+0x4f], al
    inc sp
    inc bp
label1:
    push bx
    inc bp
    inc di
    or ax, 0x200a
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+0x72], ch
    db 0x67
    and [bx+di], dh
    xor [bx+si], dh
    db 0x68
    or ax, 0x530a
    jz label7+1
    jb label11+1
    cmp cl, [di]
    or cl, [bx+di]
    or [di+0x6f], bp
    jbe label3+2
    db 0x64
    db 0x69
    sub al, 0x20
    db 0x61
    js label2
    or cl, [bx+di]
    or [bx+di+0x64], sp
    db 0x64
    and [si+0x69], ah
    sub al, 0x20
    db 0x6F
    db 0x66
label2:
    db 0x66
    jnb label12+1
    jz label5+1
    db 0x65
    js end
    jz label4+1
label3:
    sub ax, 0x7320
    jz label13
    jb 237
    sub [di], cx
    or cl, [bx+di]
    or [di+0x6f], bp
    jbe label6
    db 0x64
    js label8+1
    and [bx+si], dh
    db 0x63
    db 0x63
    db 0x63
    db 0x63
    db 0x68
    or ax, 0x4c0a
    xor [bp+si], di
label4:
    or ax, 0x090a
label5:
    or [di+0x6f], bp
    jbe label10+1
    pop bx
    ja 267
    jb 258
    and [si+0x69], ah
    pop bp
label6:
    sub al, 0x20
    db 0x64
    js label9
    or cl, [bx+di]
label7:
    or [bx+di+0x64], sp
    db 0x64
    and [si+0x69], ah
label8:
    sub al, 0x20
    xor [bx+di], si
label9:
    db 0x68
    or ax, 0x090a
label10:
    or [bp+si+0x6d], bp
    jo 221
    dec sp
label11:
    xor [di], cx
    or cl, [di]
    or ah, [di+0x78]
    db 0x69
    jz 258
    or ax, 0x0d0a
    or al, [di+0x4e]
    inc sp
label12:
    and [bp+di+0x74], dh
    db 0x61
    jb 329
    or ax, 0x0d0a
label13:
    db 0x0A  ; or al, [bx+si]
end: