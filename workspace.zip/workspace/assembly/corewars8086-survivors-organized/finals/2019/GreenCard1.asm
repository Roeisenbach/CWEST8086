    push ds
    pop es
    xchg di, ax
    std
    push di
    mov ax, 0xa5a5
    mov dx, ax
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    cld
    mov cx, 0x0002
loop1:
    sub di, 0x1000
    int 0x86
    loop loop1
    pop di
    add di, 0x002a
    mov ax, 0xcccc
label1:
    stosw
    add di, 0x0004
    jmp label1
    nop
    nop