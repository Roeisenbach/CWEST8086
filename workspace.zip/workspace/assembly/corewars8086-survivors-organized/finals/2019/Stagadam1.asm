    mov word [0x1585], 0x6400
    mov word [0x1595], 0x6400
    mov word [0x15a5], 0x6400
    mov word [0x15b5], 0x6400
    mov word [0x15c5], 0x6400
    mov word [0x15d5], 0x6400
    mov word [0x15e5], 0x6400
    mov word [0x16f5], 0x6400
    push ax
    push es
    push cs
    pop es
    mov ax, 0xcccc
    mov dx, 0xa4a4
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop es
    pop ax
    mov bx, ax
    add bx, 0x03f0
    mov cx, 0x0002
label1:
    add bx, 0x000a
    cmp word [bx], 0xcccc
    jnz label2
    jmp label1
label2:
    cmp cx, 0x0000
    jz label3
    push cs
    pop es
    mov di, bx
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    mov bx, di
    dec cx
    xor dx, dx
    cmp cx, 0x0000
    jz label3
    jmp label1
label3:
    mov cx, 0x1500
loop1:
    cmp word [bx], 0xcccc
    jnz label4
    add bx, 0x0008
    loop loop1
    add bx, 0x02e2
    jmp label3
label4:
    push cx
    mov cx, 0x0010
loop2:
    mov word [bx], 0xcccc
    add bx, 0x0003
    loop loop2
    inc dx
    cmp dx, 0x0003
    jnb label5
    pop cx
    loop loop1
label5:
    add bx, 0x0014
    xor dx, dx
    pop cx
    loop loop1
    std
    cmp dx, 0x8bcc
    jnz label6
    jmp label12
label6:
    push bx
    push es
    push cs
    pop es
    mov ax, 0xa4a4
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    pop es
    pop bx
    push bx
    pop si
    sub bx, 0x0400
    mov cx, 0x0002
label7:
    sub bx, 0x000a
    cmp word [bx], 0xcccc
    jnz label8
    jmp label7
label8:
    push cs
    pop es
    mov di, bx
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    sub bx, 0x0101
    dec cx
    xor dx, dx
    cmp cx, 0x0000
    jz label9
    jmp label7
label9:
    mov cx, 0x1500
loop3:
    cmp word [bx], 0xcccc
    jnz label10
    sub bx, 0x0008
    loop loop3
    mov bx, 0x0174
    sub bx, 0x0009
    mov word [bx], 0x1234
    jmp label9
label10:
    push cx
    mov cx, 0x0010
loop4:
    mov word [bx], 0xcccc
    sub bx, 0x0003
    loop loop4
    inc dx
    cmp dx, 0x0003
    jnb label11
    pop cx
    jmp loop3
label11:
    sub bx, 0x0014
    xor dx, dx
    pop cx
    jmp loop3
label12:
    mov si, bx
    xor cx, cx
label13:
    sub bx, 0x0005
    cmp word [bx], 0xcccc
    jnz label15
    jmp label13
label14:
    add bx, 0x0005
    cmp word [bx], 0xcccc
    jnz label15
    jmp label14
label15:
    push cs
    pop es
    mov di, bx
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    inc cx
    cmp cx, 0x0002
    jz label16
    cld
    mov bx, si
    add bx, 0x0165
    jmp label14
label16:
    mov bx, si
    add bx, 0x0200
    mov ax, bx
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x0400
    mov bx, sp
    mov di, ax
    add di, 0x0426
    mov dx, di
    mov ax, 0xcccc
    mov cx, 0x3fff
loop5:
    push ax
    stosw
    loop loop5
    int 0x03
    push ds
    pop es
    db 0x83, 0xC0, 0x3C ;$1 add ax, 0x003c
    jmp ax
    mov si, [0x3141]
    lodsw
    mov bx, ax
    mul ax
    add bx, ax
    lodsw
    cmp ax, bx
    db 0x0F
    test [si-0x03], bp
    lodsw
    mov cx, ax
    lodsw
    mov dx, ax
    lodsw
    xchg bx, ax
    int 0x87
    lodsw
    mov bx, ax
    mul ax
    add bx, ax
    lodsw
    cmp ax, bx
    db 0x0F
    test [bx-0x03], bp
    lodsw
    mov cx, ax
    lodsw
    mov dx, ax
    lodsw
    xchg bx, ax
    int 0x87
    mov si, [0x3141]
    lodsw
    mov bx, ax
    mul ax
    add bx, ax
    lodsw
    cmp ax, bx
    db 0x0F
    test [di-0x03], bp
    lodsw
    mov cx, ax
    lodsw
    mov dx, ax
    lodsw
    xchg bx, ax
    int 0x87