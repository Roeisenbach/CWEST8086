    jmp label1
    mov cx, 0x7400
    mov bx, ax
    mov [bx+0x0185], ax
    mov [0x1585], cx
    nop
    add ax, 0x0184
    mov [0x1595], cx
    sub ax, 0x0386
    mov word [0x15b5], 0x1111
    mov [0x15a5], cx
    mov byte [0x0383], 0xe9
    mov [0x0384], ax
    mov [0x15b5], cx
    xchg bx, ax
    nop
    mov bx, [0x1567]
    mov word [bx+0x23], 0xe1ff
    nop
    mov bx, [0x1577]
    mov word [bx+0x23], 0xe1ff
    mov dx, 0xffff
    mov bx, [0x1587]
    mov word [bx+0x23], 0xe1ff
    mov si, ax
    mov bx, [0x1597]
    mov word [bx+0x23], 0xe1ff
    xor di, di
    push cs
    push ss
    pop es
    pop ss
    add si, 0x0166
    mov cx, 0x000f
    rep movsw
    sub ah, 0x07
    mov bx, 0x0500
    mov di, bx
    mov al, 0xa1
    stosw
    xchg bp, ax
    mov ax, 0x1002
    stosw
    mov si, es
    mov es, ax
    xchg di, bp
    mov word [di+0x20], 0xc429
    mov word [di+0x22], 0x1fff
    mov ds, si
    mov bp, 0x0700
    xor si, si
    mov sp, di
    mov cl, 0x0c
    inc di
    mov ax, 0x000c
    add si, 0x001a
    jmp label3
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    movsw
    xor si, si
    mov sp, di
    sub di, 0x0003
    sub sp, bx
    mov cl, 0x0c
    dec dl
    db 0x0F
    test dl, dl
    add bh, bh
    pop ds
    nop
    add sp, ax
    call far [bx]
    mov si, 0x0000
    mov dx, 0x0030
    jmp label2
label1:
    mov cx, 0x7400
    mov bx, ax
    mov [bx+0x0185], ax
    mov [0x1585], cx
    nop
    add ax, 0x0184
    mov [0x1595], cx
    sub ax, 0x0386
    mov word [0x15b5], 0x1111
    mov [0x15a5], cx
    mov byte [0x0383], 0xe9
    mov [0x0384], ax
    mov [0x15b5], cx
    xchg bx, ax
    nop
    mov bx, [0x1567]
    mov word [bx+0x23], 0xe1ff
    nop
    mov bx, [0x1577]
    mov word [bx+0x23], 0xe1ff
    mov dx, 0xffff
    mov bx, [0x1587]
    mov word [bx+0x23], 0xe1ff
    mov si, ax
    mov bx, [0x1597]
    mov word [bx+0x23], 0xe1ff
label2:
    xor di, di
    push cs
    push ss
    pop es
    pop ss
    add si, 0x0166
    mov cx, 0x000f
    rep movsw
    sub ah, 0x07
    mov bx, 0x0500
    mov di, bx
    mov al, 0xa1
    stosw
    xchg bp, ax
    mov ax, 0x1002
    stosw
    mov si, es
    mov es, ax
    xchg di, bp
    mov word [di+0x20], 0xc429
    mov word [di+0x22], 0x1fff
    mov ds, si
    mov bp, 0x0700
    xor si, si
    mov sp, di
    mov cl, 0x0c
    inc di
    mov ax, 0x000c
    add si, 0x001a
    jmp label3
    rep movsw
label3:
    sub [bx], bp
    mov di, [bx]
    movsw
    movsw
    xor si, si
    mov sp, di
    sub di, 0x0003
    sub sp, bx
    mov cl, 0x0c
    dec dl
    jz label4
    call far [bx]
    nop
    add sp, ax
    call far [bx]
    mov si, 0x0000
    mov dx, 0x0030
    jmp label2
label4:
    xor di, di
    push cs
    push ss
    pop es
    pop ss
    add si, 0x0166
    mov cx, 0x000f
    rep movsw
    sub ah, 0x07
    mov bx, 0x0500
    mov di, bx
    mov al, 0xa1
    stosw
    xchg bp, ax
    mov ax, 0x1002
    stosw
    mov si, es
    mov es, ax
    xchg di, bp
    mov word [di+0x20], 0xc429
    mov word [di+0x22], 0x1fff
    mov ds, si
    mov bp, 0x0700
    xor si, si
    mov sp, di
    mov cl, 0x0c
    inc di
    mov ax, 0x000c
    add si, 0x001a
    jmp label3
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    movsw
    xor si, si
    mov sp, di
    sub di, 0x0003
    sub sp, bx
    mov cl, 0x0c
    dec dl
    jz label4
    call far [bx]
    nop
    add sp, ax
    call far [bx]
    mov si, 0x0000
    mov dx, 0x0030
    jmp label2