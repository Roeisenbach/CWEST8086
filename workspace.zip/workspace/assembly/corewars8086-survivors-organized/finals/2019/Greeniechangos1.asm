    push ss
    pop es
    xor di, di
    mov si, ax
    add si, word 0x0050
    mov cl, 0x15
    rep movsw
    mov ax, 0x6789
    push ss
    pop ds
    mov bx, 0x002e
    mov word [bx], 0x2a54
    mov [bx+0x02], cs
    mov bp, [bx]
    or bp, 0x00ff
    and bp, 0xffa3
    mov dx, 0x0200
    mov cl, 0x05
    mov si, 0x0020
    mov di, [bx]
    push cs
    pop es
    dec di
    rep movsw
    sub bp, 0x0100
    push cs
    pop ds
    mov cl, 0x0f
    push cs
    push ss
    push cs
    pop es
    pop ds
    pop ss
    xor si, si
    mov [bp+si], ax
    sub di, 0x0007
    mov sp, 0x5da3
    call far [bx]
    inc bp
    rep movsw
    mov cl, 0x05
    mov di, [bp+0x00]
    stosw
    mov si, 0x0020
    add [bx], dx
    add bp, dx
    mov di, [bx]
    dec di
    rep movsw
    sub di, 0x0007
    xor si, si
    mov [bp+si], ax
    mov cl, 0x0f
    call far [bx]
    inc bp
label1:
    movsw
    cmp [bp+si], ax
    jnz label1
    call far [bx]
    call far [bx]