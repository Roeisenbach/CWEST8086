    jmp label6
    hlt
    push cx
    jnz -99
    mov ax, [0xa0d6]
    mov al, [bx+si]
    or [bx], cx
    cmpsb
    db 0x69
    aas
    std
    db 0xC9
    db 0xC6, 0x95, 0xFE, 0xC1, 0xF7 ;$2 mov byte [di-0x3e02], 0xf7
label1:
    mov [0x3041], ax
    xchg dx, ax
    call 0xc71d:0x1ed9
    test al, 0x44
    or [bx+0x5e], bp
    esc 0xd8
    idiv word [bp+si-0x4ca7]
    cs:
    db 0x8A, 0xF2 ;$1 mov dh, dl
    sub al, 0x11
    xchg di, ax
    db 0x8F, 0xDD  ; pop bp
    iret
    pop bp
    mov bx, 0x31b4
    stosw
label2:
    cmp ch, 0x4c
    or ax, 0xe027
    db 0x03, 0xD6 ;$1 add dx, si
    db 0xC1
    and ah, dh
    jle label3
    cmpsb
    db 0x64
    push bp
    mov si, 0x1b23
    db 0x65
    jnb -18
    db 0x6A
    adc ax, 0xdff1
    ja label7
    esc 0xdc
    xchg si, ax
    pushf
    db 0xD6
    mov dl, bh
    sbb sp, [di]
label3:
    db 0xF2, 0x58
    xchg sp, ax
    ror cl, 1
label4:
    and di, [bx-0x6e]
    into
    dec bp
    jz label9+1
    dec bp
    cbw
    sbb cx, [di+0x71]
    mov bh, 0x1f
    lodsb
    mov bx, 0x466a
    db 0x67
    hlt
    stc
    db 0x6B
    esc 0xde
    esc 0xdf
    lea dx, [bp+di+0x60b3]
    jbe label4
    db 0x61
    dec di
    dec sp
    mov cl, 0x95
    mov [bx+si+0x5574], al
    int3
    jb label1
    dec ax
    xchg bl, [di-0x70]
    inc si
    cmp [si], sp
    jnb label5
    in ax, 0x31
    mov bp, [bp+di+0x06cb]
    xchg dx, ax
    mov bx, 0xf304
    xchg sp, ax
    in al, dx
    retf
    daa
    jnz label11+1
    xchg di, ax
    ja label2
    ja label8
    jz label10+1
    dec bp
    mov [bp+si-0x0d76], dl
label5:
    pop ax
    sbb ax, 0x4814
    iret
label6:
    nop
label7:
    nop
    nop
    db 0x9B, 0x9B ;$1 nrg
    push es
    push ds
    pop es
    push ax
    mov ax, 0xa5f3
    mov dx, 0xff31
    mov ch, 0xcc
    mov cl, ch
label8:
    mov bx, cx
    int 0x87
    mov word [0x15a7], 0x0000
    mov di, [0x9090]
    sub di, 0x0030
    mov ax, 0xcccc
    mov dx, 0xcccc
label9:
    int 0x86
    pop ax
    pop es
    mov dx, ax
    add dx, 0x0139
    mov si, ax
    add si, 0x0003
    mov cx, 0x0052
    push ds
    pop ss
    add ax, 0x00a6
    xor bx, bx
    xor di, di
loop1:
    and bx, 0x000f
    mov bp, ax
label10:
    add bp, bx
    mov dx, [bp+0x00]
    xor [si+word 0x0000], dx
    add bx, 0x0002
    movsw
    loop loop1
    mov cx, 0x0052
label11:
    sub ax, 0x5000
    push es
    push ds
    pop es
    pop ds
    xor si, si
    mov di, ax
    mov bp, ax
    sub bp, 0x0002
    mov word [bp+0x00], 0xa5f3
    mov bx, 0x0184
    mov [bx+word 0x0002], cs
    db 0x83, 0xE8, 0x02 ;$1 sub ax, 0x0002
    mov word [bp+0x50bd], 0x9090
    jmp bp
    mov bx, ss
    sub bx, 0x0240
    mov es, bx
    mov di, 0x0000
    mov si, ax
    add si, 0x002e
    mov cx, 0x0034
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push es
    pop ss
    mov bp, ax
    add bp, 0x002e
    mov bx, 0x5200
    jmp $
    sub bp, 0x4ff5
    mov cx, 0x0034
    jmp label15
    mov ax, 0xc21e
    mov di, bp
    add di, 0x0366
    mov cx, 0x0040
    rep stosw
    mov di, bp
    sub di, 0x0380
    mov cx, 0x0040
    rep stosw
    xor si, si
    mov cx, 0x0034
label12:
    dec bx
    jz label16
    add si, 0x0002
    and si, 0x007f
    mov dx, [bp+si+0x0366]
    cmp [bp+si-0x0380], dx
    jz label12
    cmp dx, 0xc21e
    jnz label13
    lea dx, [bp+si-0x0380]
    jmp label14
label13:
    lea dx, [bp+si+0x0366]
label14:
    mov byte [bp-0x40], 0xba
    mov [bp-0x3f], dx
    mov byte [bp-0x3d], 0x90
    sub byte [bp-0x54], 0x01
    sub bp, 0x1000
label15:
    xor si, si
    mov di, bp
    mov word [bp-0x02], 0xa5f3
    mov ax, bp
    db 0x83, 0xE8, 0x02 ;$1 sub ax, 0x0002
    jmp ax
label16:
    int 0x03