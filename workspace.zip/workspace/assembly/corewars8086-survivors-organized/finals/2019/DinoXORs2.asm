    mov word [0x1595], 0x1100
    mov word [0x15a5], 0x1100
    mov word [0x15b5], 0x1100
    mov word [0x15c5], 0x1100
    mov word [0x15d5], 0x1100
    mov word [0x15e5], 0x1100
    mov word [0x15f5], 0x1100
    mov word [0x1585], 0x1100
    add ax, 0x0106
    stosw
    db 0x83, 0xC0, 0x27 ;$1 add ax, 0x0027
    nop
    nop
    nop
    nop
    nop
    mov bx, [0x1577]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    mov bx, [0x1587]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    mov bx, [0x1597]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    mov bx, [0x15a7]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    mov bx, [0x15b7]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    mov bx, [0x15c7]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    mov bx, [0x15d7]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    mov bx, [0x1567]
    mov word [bx+0x2a], 0xe6ff
    mov byte [bx+0x27], 0xbe
    mov [bx+0x28], ax
    mov word [bx+0x25], 0x9090
    db 0x83, 0xE8, 0x27 ;$1 sub ax, 0x0027
    xor bx, bx
    push es
    pop ds
    mov [bx+0x02], cs
    inc word [bx+0x02]
    mov [bx], ax
    add word [bx], 0x000d
    sub word [bx], 0x0010
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x0100
    db 0x83, 0xE8, 0x10 ;$1 sub ax, 0x0010
    jmp label1
    mov sp, ax
    sub sp, 0x007f
label1:
    mov si, 0x000c
    mov di, ax
    add di, 0x000f
    call far [bx]
    mov dx, [0x000a]
    add [bx], dx
    push cs
    pop ds
    mov si, ax
    mov [si+0x3c], dx
    mov word [si+0x38], 0x9090
    push es
    pop ds
    add ax, dx
    jmp ax
    mov bx, si
    add bx, 0x02fa
    add word [si+0x04], 0x0002
label2:
    mov word [bx], 0xcccc
    add bx, 0x0010
    jmp label2
    add si, 0x1000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    jmp si