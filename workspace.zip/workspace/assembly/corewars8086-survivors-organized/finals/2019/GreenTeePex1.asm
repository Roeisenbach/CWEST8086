    mov word [0x1585], 0x0000
    mov cx, ax
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    add ax, 0x0055
    mov bx, ax
    db 0x83, 0xC0, 0x02 ;$1 add ax, 0x0002
    mov [bx], ax
    mov bx, 0x0025
    add bx, [0x1567]
    mov word [bx], 0x26ff
    db 0x83, 0xE8, 0x02 ;$1 sub ax, 0x0002
    mov [bx+0x02], ax
    push ax
    push ds
    pop es
    mov di, ax
    add di, 0x0700
    int 0x86
    mov di, [0x0000]
    int 0x86
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    pop ax
    xchg di, ax
    mov ax, 0xab50
    push ds
    pop es
    push ds
    pop ss
    mov sp, di
    add di, word 0x0055
    stosw
    add [bx+si], al
    mov ax, 0xab50
    mov cx, 0xffff
    rep stosw
    hlt