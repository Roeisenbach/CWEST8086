    jmp label1+1
    nop
    xchg bp, ax
    add cl, dl
    add [bx+si], ax
    add bl, ch
    add [bx+si], al
label1:
    add bh, al
    push es
    mov ch, 0x15
    add [bp+si], dh
    mov word [0x15a5], 0x3200
    mov word [0x1595], 0x3200
    mov word [0x1585], 0x3200
    push ds
    push es
    pop ds
    mov [0x03ea], ax
    mov dx, [0x03e8]
    pop ds
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0003
    add [di], ax
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov [bx+0x0096], ax
    mov si, [0x1577]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    mov [bx+0x00c6], ax
    nop
    nop
    mov word [si+0x28], 0xcccc
    mov si, [0x1567]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    nop
    mov word [si+0x28], 0xcccc
    mov si, [0x1597]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    nop
    mov word [si+0x28], 0xcccc
    mov si, [0x1587]
    mov [si+0x28], di
    mov word [si+0x26], 0x26ff
    nop
    mov word [si+0x28], 0xcccc
    jmp label6+3
label2:
    mov byte [bx+0x009b], 0x00
    jmp label4
    nop
    mov ax, 0xaf52
    db 0x8B, 0xD8 ;$1 mov bx, ax
    jmp label2
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, [bx+0x05]
    add word [bx+0x05], 0x0004
    mov cx, 0x0461
loop1:
    jmp label3
    nop
    int3
label3:
    add di, 0x0014
    loop loop1
    mov cx, 0x0461
    add di, 0x01e6
    jmp loop1
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov ax, 0x1234
    jmp word [bx+0x0112]
label4:
    mov ax, 0x1234
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov cx, 0x3f8b
    push cs
    pop dx
    sub dx, 0x0015
    add ax, 0x0150
    db 0x8B, 0xF8 ;$1 mov di, ax
    push ds
    pop ss
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x0150
    add [bx+0x09], di
    mov [bx+0x0b], dx
    call far [bx+0x09]
loop2:
    jmp label5
    nop
label5:
    loop loop2
    db 0x8B, 0xE0 ;$1 mov sp, ax
    sub sp, 0x0150
    mov cx, 0x3f8b
    jmp loop2
    mov ax, 0x1234
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xE0 ;$1 mov sp, ax
    mov cx, 0x3f8b
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add dx, 0x023b
    mov [bx+0x09], dx
    sub dx, 0x0003
    jmp dx
    push dx
label6:
    add [si-0x7500], bx
    lock
    mov di, 0x0200
    mov cx, 0x00e9
    rep movsw
    push ax
    mov di, 0x02aa
    mov ax, 0x05c7
    stosw
    mov ax, 0xcccc
    stosw
    mov di, 0x02e8
    mov ax, 0x5fff
    stosw
    mov al, 0x09
    stosb
    pop ax
    jmp label8
    nop
label7:
    add di, 0x0310
    jmp label12
    nop
label8:
    db 0x3B, 0xDA ;$1 cmp bx, dx
    jb label9
    jmp label10
    nop
label9:
    db 0x33, 0xD2 ;$1 xor dx, dx
    jmp label11
    nop
label10:
    db 0x2B, 0xDA ;$1 sub bx, dx
    mov dx, 0x8000
    db 0x2B, 0xD3 ;$1 sub dx, bx
label11:
    mov cx, 0x0064
    mov si, 0x0200
    db 0x8B, 0xF8 ;$1 mov di, ax
    db 0x03, 0xFA ;$1 add di, dx
    add di, 0x6050
    db 0x33, 0xD2 ;$1 xor dx, dx
    cmp di, 0xfcef
    jnb label7
label12:
    loop $
    push es
    push ds
    pop es
    pop ds
    push di
    mov cx, 0x00e9
    rep movsw
    pop di
    push es
    push ds
    pop es
    pop ds
    db 0x8B, 0xF0 ;$1 mov si, ax
    add [si+0x0110], di
    inc bp
    cmp bp, 0x008b
    jnb label13
    mov word [di+0x05], 0x01d1
    mov [si+0x00bf], di
    add [si+0x0112], di
    mov byte [si+0x00b2], 0x0b
    mov [si+0x00f9], di
    mov byte [si+0x00ec], 0x0b
    db 0x8B, 0xC7 ;$1 mov ax, di
    jmp word [si+0x0110]
label13:
    mov word [di+0x05], 0xcccc
    mov word [si+0x00bf], 0xcccc
    add word [si+0x0112], 0xcccc
    mov word [si+0x00b1], 0xcccc
    mov word [si+0x00f9], 0xcccc
    mov word [si+0x00eb], 0xcccc
    db 0x8B, 0xC7 ;$1 mov ax, di
    jmp word [si+0x0110]