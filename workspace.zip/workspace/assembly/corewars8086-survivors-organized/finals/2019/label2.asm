    mov al, 0xcc
    mov bx, 0x0000
label1:
    mov [bx], al
    inc bx
    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0120
    mov dx, 0xcccc
    db 0x8B, 0xC2 ;$1 mov ax, dx
    int 0x86
    int 0x86
    mov [di], dx
    add di, 0x0003
    jmp label1