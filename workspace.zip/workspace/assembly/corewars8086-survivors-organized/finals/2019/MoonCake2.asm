    push ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0xcccc
    db 0x9B, 0x9B ;$1 nrg
label1:
    stosw
    sub di, 0x000a
    jmp label1