    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x000d
    mov al, 0xaa
    push ds
    pop es
    cld
    db 0x9B, 0x9B ;$1 nrg
    stosb