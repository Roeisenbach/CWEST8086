    push es
    pop ss
    db 0x33, 0xED ;$1 xor bp, bp
    mov cx, [bp+0x00]
    add ax, 0x0026
    mov bl, 0x12
    mov bh, [0x4367]
    mov [0x4367], bx
    mov [0x4367], ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x0014
    mov [0x0250], cx
    db 0xE9, 0x14, 0x00 ;$1 jmp 58
    mov di, [0x0250]
    add di, 0x0400
    add dx, 0x000c
    mov word [di], 0xcccc
    add di, 0x0009
    jmp dx
    mov cx, cs
    mov es, cx
    add si, 0x000b
    mov di, si
    inc di
    cld
    movsb