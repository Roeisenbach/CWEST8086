    push es
    push ds
    pop es
    add ax, 0x00c9
    mov si, ax
    mov bx, ax
    mov [0x01f4], bx
    mov di, 0x4345
    mov dx, 0xcccc
    int 0x86
    jmp label1
    add ax, 0x00c9
    mov si, ax
    mov bx, ax
    mov [0x01f4], bx
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    mov bp, 0x4231
    mov dx, 0xcccc
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    add ax, 0x00c9
    mov si, ax
    mov bx, ax
    mov [0x01f4], bx
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    mov bp, 0x4231
    mov dx, 0xcccc
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
label1:
    pop es
    xor di, di
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    mov bp, 0x36f0
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    add ax, 0x00c9
    mov si, ax
    mov bx, ax
    mov [0x01f4], bx
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    mov bp, 0x4231
    mov dx, 0xcccc
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    add ax, 0x00c9
    mov si, ax
    mov bx, ax
    mov [0x01f4], bx
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    mov bp, 0x4231
    mov dx, 0xcccc
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]