    push es
    push ax
    push cs
    pop es
    mov ax, 0x0e8b
    mov dx, 0x4367
    mov bx, 0xe3ff
    int 0x87
    pop ax
    pop es
    xor cx, cx
    db 0x83, 0xC0, 0x70 ;$1 add ax, 0x0070
    mov si, ax
    db 0x83, 0xC0, 0x3E ;$1 add ax, 0x003e
    stosw
    xor di, di
    push ss
    pop es
    mov cl, 0x1f
    rep movsw
    mov bx, di
    mov ax, 0x29a5
    mov dx, 0xabdc
    int 0x86
    sub di, 0x00b0
    mov cl, 0x21
    rep movsw
    movsb
    push ds
    push es
    pop ds
    pop es
    call prcd1
prcd1:
    pop bp
    push cs
    pop ss
    mov sp, bp
    sub sp, 0x00a0
    add bp, 0x0032
    mov si, bx
    mov bx, 0x8989
    mov di, bp
    mov dx, 0x007a
    mov ax, 0xa555
    mov [bp-0x0096], dl
    mov [bp+0x019c], dl
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    movsw
    movsw
    movsw
    mov cl, 0x11
    rep movsw
    mov cl, 0x0a
loop1:
    mov byte [bp+0x098c], 0xcc
    mov byte [bp+0x098c], 0xcc
    mov byte [bp+0x098c], 0xcc
    mov byte [bp+0x098c], 0xcc
    mov byte [bp+0x098c], 0xcc
    loop loop1
    add bp, 0x0026
    movsw
    movsw
    mov cl, 0x09
    rep movsw
    add bp, 0x0018
    mov sp, bp
    sub sp, 0x00d2
    mov [bp-0x0096], dl
    mov [bp+0x019c], dl
    movsw
    movsw
    movsw
    mov cl, 0x0c
    rep movsw
    cmp [bp-0x0096], dl
    jnz label1
    cmp [bp+0x019c], dl
    jnz label2
    mov si, 0x003e
    mov di, bp
    movsw
    jmp bp
label1:
    add si, 0x0012
label2:
    movsw
    movsw
    movsw
    mov cl, 0x06
    rep movsw
    add bp, 0x09aa
    mov si, 0x0026
    mov di, bp
    movsw
    jmp bp
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    movsw
    sub bp, 0x09aa
    xor si, si
    mov di, bp
    movsw
    jmp bp