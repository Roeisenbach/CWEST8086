    mov di, 0x0200
    xchg si, ax
    mov ax, 0xa59c
    jmp label1
    int3
    int3
    int3
    lea bx, [si+0x01b6]
    xchg bx, [0x30fe]
    add si, 0x00e1
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0254
    mov cl, 0x24
    rep movsw
    push cs
    push cs
    push es
    pop ds
    pop es
    pop ss
    mov si, 0x0254
    mov cl, 0x0f
loop1:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop1
    mov di, [0x0000]
    mov si, 0x0200
    movsw
    call bp
    mov [bp+0x0198], ax
    mov [bp-0x0198], ax
    int3
    int3
    int3
    lea bx, [si+0x01b6]
    xchg bx, [0x30fe]
    add si, 0x00e1
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0254
    mov cl, 0x24
    rep movsw
    push cs
    push cs
    push es
    pop ds
    pop es
    pop ss
    mov si, 0x0254
    mov cl, 0x0f
loop2:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop2
    mov di, [0x0000]
    mov si, 0x0200
    movsw
    call bp
    mov [bp+0x0198], ax
    mov [bp-0x0198], ax
    int3
    int3
    int3
label1:
    lea bx, [si+0x01b6]
    xchg bx, [0x30fe]
    add si, 0x00e1
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0254
    mov cl, 0x24
    rep movsw
    push cs
    push cs
    push es
    pop ds
    pop es
    pop ss
    mov si, 0x0254
    mov cl, 0x0f
loop3:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop3
    mov di, [0x0000]
    mov si, 0x0200
    mov bp, di
    lea sp, [di-0x0220]
    movsw
    movsw
    movsw
    movsw
    movsw
    call bp
    mov [bp+0x0198], ax
    mov [bp-0x0198], ax
    out 0xf2, al
    or al, 0xa5
    db 0xF3, 0xE6
    ret 0x8bec
    adc ax, 0xd5c8
    db 0x68
    db 0xFE, 0x3B
    aad 0xdb
    add [di+0x08], si
    retf 0x83ac
    out dx, al
    db 0x68
    out 0xbc, al
    aad 0xa5
    movsw
    db 0xF2, 0x4D
    movsw
    rep movsw
    std
    inc bx
    add bh, [bx+di]
    ret 0x4736
    add di, 0x4a90
    ret 0xc8ef
    add al, 0xca
    mov si, 0xa58d
    and [bx+di-0x1a], al
    movsw
    movsw
    movsw
    out 0xbc, al
    aad 0xcc
    int3
    int3
    lea bx, [si+0x01b6]
    xchg bx, [0x30fe]
    add si, 0x00e1
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0254
    mov cl, 0x24
    rep movsw
    push cs
    push cs
    push es
    pop ds
    pop es
    pop ss
    mov si, 0x0254
    mov cl, 0x0f
loop4:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop4
    mov di, [0x0000]
    mov si, 0x0200
    movsw
    call bp
    mov [bp+0x0198], ax
    mov [bp-0x0198], ax
    int3
    int3
    int3
    lea bx, [si+0x01b6]
    xchg bx, [0x30fe]
    add si, 0x00e1
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0254
    mov cl, 0x24
    rep movsw
    push cs
    push cs
    push es
    pop ds
    pop es
    pop ss
    mov si, 0x0254
    mov cl, 0x0f
loop5:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop5
    mov di, [0x0000]
    mov si, 0x0200
    movsw
    call bp
    mov [bp+0x0198], ax
    mov [bp-0x0198], ax
    mov word [0x3100], 0xabbf
    mov word [0x3102], 0x5050
    mov word [0x3104], 0x5b97
    mov word [0x3106], 0x170e
    mov byte [0x3108], 0x57
    mov word [0x3109], 0xab5c
    mov word [0x310b], 0xe3ff
    mov ch, 0x08
    mov cl, 0x08
label2:
    mov bx, 0x4347
label3:
    ror word [bx], cl
    mov word [bx], 0x3100
    add bl, 0x10
    cmp bl, 0xc7
    jnz label3
    dec ch
    jnz label2
    mov di, 0x3100
    jmp di