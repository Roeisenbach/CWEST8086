    add ax, 0x2127
    mov dx, ax
    mov di, 0x4347
    push es
    push ds
    pop es
    nop
    nop
    nop
    int 0x86
    jmp label3
label1:
    mul ax
    xor ax, dx
    cmp bx, cx
    jz label1
label2:
    mul ax
    xor ax, dx
    cmp bx, cx
    jz label2
    mov [0x4347], ah
    mov bx, [0x4347]
    mov cx, [0x4347]
    mov dx, [0x4347]
    mov [0x4357], ah
    mov bx, [0x4357]
    mov cx, [0x4357]
    mov dx, [0x4357]
    mov [0x4367], ah
    mov bx, [0x4367]
    mov cx, [0x4367]
    mov dx, [0x4367]
    mov [0x4377], ah
    mov bx, [0x4377]
    mov cx, [0x4377]
    mov dx, [0x4377]
    mov di, dx
    mov si, ax
    add si, 0xdf9b
    movsw
    movsw
    sub ax, 0x2127
    push cs
    push ss
    pop es
    pop ss
    mov si, ax
    add si, 0x00aa
    xor di, di
    mov cl, 0x0c
    rep movsw
    add di, 0x0040
    mov bx, di
    mov al, 0xa3
    stosw
    mov bp, ax
    mov ax, cs
    stosw
    mov di, bp
    mov word [di], 0x1fff
    mov si, es
    mov dx, ds
    mov es, dx
    mov ds, si
    mov bp, 0x0700
    mov dx, 0x0002
    xor si, si
    mov sp, di
    add sp, bp
    inc di
    call far [bx]
    movsw
    movsw
    mov cl, 0x08
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    xor si, si
    sub di, dx
    mov sp, di
    inc di
    add sp, bp
    call far [bx]
    call far [bx]
    jmp -7998
label3:
    mov di, dx
    mov si, ax
    add si, 0xdf9b
    movsw
    movsw
    sub ax, 0x2127
    push cs
    push ss
    pop es
    pop ss
    mov si, ax
    add si, 0x010f
    xor di, di
    mov cl, 0x0c
    rep movsw
    sub ah, 0x07
    add di, 0x0040
    mov bx, di
    mov al, 0xa3
    stosw
    mov bp, ax
    mov ax, cs
    stosw
    mov di, bp
    mov word [di], 0x1fff
    mov si, es
    mov dx, ds
    mov es, dx
    mov ds, si
    mov bp, 0x0700
    mov dx, 0x0002
    xor si, si
    mov sp, di
    add sp, bp
    inc di
    call far [bx]
    movsw
    movsw
    mov cl, 0x08
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    xor si, si
    sub di, dx
    mov sp, di
    inc di
    add sp, bp
    call far [bx]
    call far [bx]
    xor bx, bx
    mov si, 0xade5
    mov dx, 0xc0de
    mov [si], dx
    mov bp, si
label4:
    inc bx
    xchg bp, [si]
    cmp bp, dx
    jnz label4
    mov [si], dx
    call prcd1
prcd1:
    pop di
    add bl, bl
    xchg bl, bh
    add di, bx
    add di, 0x1000
    push ds
    pop es
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    int 0x03
label5:
    mul ax
    xor ax, dx
    cmp bx, cx
    jz label5
label6:
    mul ax
    xor ax, dx
    cmp bx, cx
    jz label6
    mov [0x4387], ah
    mov bx, [0x4387]
    mov cx, [0x4387]
    mov dx, [0x4387]
    mov [0x4397], ah
    mov bx, [0x4397]
    mov cx, [0x4397]
    mov dx, [0x4397]
    mov [0x43a7], ah
    mov bx, [0x43a7]
    mov cx, [0x43a7]
    mov dx, [0x43a7]
    mov [0x43b7], ah
    mov bx, [0x43b7]
    mov cx, [0x43b7]
    mov dx, [0x43b7]
    mov [0x847e], ax
    push cs
    push ss
    pop es
    pop ss
    mov si, ax
    add si, 0x01e4
    xor di, di
    mov cl, 0x0c
    rep movsw
    add di, 0x0040
    mov bx, di
    mov al, 0xa3
    stosw
    mov bp, ax
    mov ax, cs
    stosw
    mov di, bp
    mov word [di], 0x1fff
    mov si, es
    mov dx, ds
    mov es, dx
    mov ds, si
    mov bp, 0x0700
    mov dx, 0x0002
    xor si, si
    mov sp, di
    add sp, bp
    inc di
    call far [bx]
    movsw
    movsw
    mov cl, 0x08
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    xor si, si
    sub di, dx
    mov sp, di
    inc di
    add sp, bp
    call far [bx]
    call far [bx]