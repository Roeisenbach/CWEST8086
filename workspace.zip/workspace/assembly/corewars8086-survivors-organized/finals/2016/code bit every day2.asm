    add ax, 0x0103
    mov bp, ax
    add bp, 0x001e
    nop
    mov bx, 0xe3ff
    mov cx, 0xe3ff
    mov [0x4367], ax
    mov [0x4367], ax
    push es
    push cs
    pop es
    mov ax, 0x0e8b
    mov dx, 0x4387
    int 0x87
    mov [0x4387], bp
    mov [0x4387], bp
    pop es
    xor cx, cx
    push bp
    mov ax, bp
    sub ax, 0x009e
    mov di, ax
    push cs
    push es
    pop ds
    lodsw
    pop ds
    push ss
    pop es
    mov bp, ax
    mov si, di
    xor di, di
    mov cl, 0x1f
    rep movsw
    mov bx, di
    mov ax, 0x29a5
    mov dx, 0xabdc
    int 0x86
    sub di, 0x00b0
    mov cl, 0x21
    rep movsw
    movsb
    push ds
    push es
    pop ds
    pop es
    pop di
    mov ax, 0x0716
    add di, 0x001c
    stosw
    push cs
    pop ss
    mov sp, bp
    sub sp, 0x00fc
    mov si, bx
    mov bx, 0x8989
    mov di, bp
    mov dx, 0x007a
    mov ax, 0xa555
    mov [bp-0x00d4], dl
    mov [bp+0x015e], dl
    movsw
    jmp bp
    movsw
    movsw
    mov cl, 0x11
    rep movsw
    mov cl, 0x0a
loop1:
    mov byte [bp+0x096c], 0xcc
    mov byte [bp+0x096c], 0xcc
    mov byte [bp+0x096c], 0xcc
    mov byte [bp+0x096c], 0xcc
    mov byte [bp+0x096c], 0xcc
    loop loop1
    add bp, 0x0026
    movsw
    movsw
    mov cl, 0x09
    rep movsw
    add bp, 0x0018
    mov sp, bp
    sub sp, 0x00fc
    mov [bp-0x00d4], dl
    mov [bp+0x015e], dl
    movsw
    movsw
    movsw
    mov cl, 0x0c
    rep movsw
    cmp [bp-0x00d4], dl
    jnz label1
    cmp [bp+0x015e], dl
    jnz label2
    mov si, 0x003e
    mov di, bp
    movsw
    jmp bp
label1:
    add si, 0x0012
label2:
    movsw
    movsw
    movsw
    mov cl, 0x06
    rep movsw
    add bp, 0x09aa
    mov si, 0x0026
    mov di, bp
    movsw
    jmp bp
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    movsw
    sub bp, 0x09aa
    xor si, si
    mov di, bp
    movsw
    jmp bp
    add bx, 0x003a
    push ss
    pop bp
    push cs
    pop ss
    mov sp, 0x437a
    mov si, 0x4377
    push word [si]
    mov [si], bx
    mov ss, bp
    mov sp, 0x0800
    mov bp, dx
    mov dx, bx
    mov ax, bp
    jmp label3
    add bx, 0x001c
    push ss
    pop bp
    push cs
    pop ss
    mov sp, 0x439a
    mov si, 0x4397
    push word [si]
    mov [si], bx
    mov ss, bp
    mov sp, 0x0800
    mov bp, dx
    mov dx, bx
    mov ax, bp
label3:
    jmp $
    mov si, dx
    mul si
    mov bp, ax
    mov ax, 0xa550
    mov dx, 0xa550
    int 0x86
    int 0x86
    add si, 0x002c
    mov cx, 0x0007
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov sp, bp
    mov di, bp
    mov bx, 0x016c
    xor si, si
    movsw
    jmp sp
    movsw
    movsw
    mov cl, 0x04
    rep movsw
    dec bx
    jnz label4
    int3
    int3
label4:
    xor si, si
    movsw