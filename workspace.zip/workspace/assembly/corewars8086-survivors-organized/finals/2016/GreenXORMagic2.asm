    push es
    mov bp, ds
    mov es, bp
    mov bx, 0x26ff
    mov cx, 0xec19
    mov [0xec19], ax
    mov ax, 0x168b
    mov dx, 0x4387
    int 0x87
    mov ax, [0xec19]
    jmp label1
    mov bx, 0x17a8
    db 0x83, 0xC0, 0x5C ;$1 add ax, 0x005c
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    sub sp, 0x000f
    db 0x83, 0xC0, 0x1B ;$1 add ax, 0x001b
    mov di, ax
    movsw
    mov di, 0x4340
    int 0x86
    std
    int 0x86
    cld
    sub sp, ax
    mov ax, [0xec19]
    mov ss, bp
    mov dx, 0xa552
    mov di, ax
    add di, 0x0052
    mov ax, 0x52ab
    stosw
label1:
    mov bx, ax
    add bx, 0x0008
    mov word [bx], 0x2ceb
    pop ds
    mov bx, 0x17a8
    db 0x83, 0xC0, 0x5C ;$1 add ax, 0x005c
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    sub sp, 0x000f
    db 0x83, 0xC0, 0x1B ;$1 add ax, 0x001b
    mov di, ax
    movsw
    push es
    mov bp, ds
    mov es, bp
    mov bx, 0x26ff
    mov cx, 0xec19
    mov [0xec19], ax
    mov ax, 0x168b
    mov dx, 0x4387
    int 0x87
    mov ax, [0xec19]
    mov di, 0x4340
    nop
    int 0x86
    std
    int 0x86
    cld
    sub sp, ax
    mov ax, [0xec19]
    mov ss, bp
    mov dx, 0xa552
    mov di, ax
    mov ax, 0x52ab
    stosw
    mov bx, ax
    add bx, 0x0008
    mov word [bx], 0x11eb
    pop ds
    mov bx, 0x17a8
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    sub sp, 0x000f
    mov di, ax
    movsw
    push cs
    pop es
    int 0x87
    mov bx, ax
    mul ax
    xor ax, dx
    mov [0x4347], ah
    mov bx, [0x4347]
    mov cx, [0x4347]
    mov dx, [0x4347]
    cmp bx, cx
    db 0x0F
    test [di], bl
    db 0xFF, 0x39
    ror word [bx], 1
    test [bx], dl
    db 0xFF, 0x38
    jcxz loop1
    test [bx+di], dx
    db 0xFF, 0x38
    in ax, 0x0f
    test [bp+di], cx
    db 0xFF, 0xFF
    loop loop2+1
    pop es
    int 0x87
loop1:
    mov bx, ax
    mul ax
    xor ax, dx
    mov [0x4357], ah
loop2:
    mov bx, [0x4357]
    mov cx, [0x4357]
    mov dx, [0x4357]
    cmp bx, cx
    db 0x0F
    test cl, ch
    db 0xFE, 0x39
    ror word [bx], 1
    test bl, ah
    db 0xFE, 0x38
    jcxz loop3+1
    test bp, bx
    db 0xFE, 0x38
    in ax, 0x0f
    test di, dx
    db 0xFE, 0xFF
    loop loop6+2
    retf
    db 0x0F
loop3:
    test bh, cl
    db 0xFE, 0x39
    ror word [bx], 1
    test cl, cl
    db 0xFE, 0x38
    jcxz loop4
    test bx, ax
    db 0xFE, 0x38
    in ax, 0x0f
    test [di-word 0x0002], di
    loop loop5+1
    pop es
    int 0x87
loop4:
    mov bx, ax
    mul ax
    xor ax, dx
    mov [0x4347], ah
loop5:
    mov bx, [0x4347]
    mov cx, [0x4347]
    mov dx, [0x4347]
    mov [0x4357], ah
loop6:
    mov bx, [0x4357]
    mov cx, [0x4357]
    mov dx, [0x4357]
    mov [0x4367], ah
    mov bx, [0x4367]
    mov cx, [0x4367]
    mov dx, [0x4367]
    mov [0x4377], ah
    mov bx, [0x4377]
    mov cx, [0x4377]
    mov dx, [0x4377]
    mov [0x43a7], ah
    mov bx, [0x43a7]
    mov cx, [0x43a7]
    mov dx, [0x43a7]
    mov [0x43b7], ah
    mov bx, [0x43b7]
    mov cx, [0x43b7]
    mov dx, [0x43b7]
    mov [0x4347], ah
    mov bx, [0x4347]
    mov cx, [0x4347]
    mov dx, [0x4347]
    mov [0x4357], ah
    mov bx, [0x4357]
    mov cx, [0x4357]
    mov dx, [0x4357]
    mov [0x4367], ah
    mov bx, [0x4367]
    mov cx, [0x4367]
    mov dx, [0x4367]
    mov [0x4377], ah
    mov bx, [0x4377]
    mov cx, [0x4377]
    mov dx, [0x4377]