    stosw
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, es
    push cs
    pop ss
    push cs
    pop es
    mov bp, cx
    db 0x33, 0xFF ;$1 xor di, di
    mov ax, 0xa5a5
    db 0x8B, 0xD0 ;$1 mov dx, ax
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    xchg bx, ax
    xchg dx, cx
    mov di, 0x03e8
    int 0x86
    mov di, 0x07d0
    int 0x86
    mov es, bp
    mov bx, si
    add bx, 0x0049
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov di, 0x0000
    mov bx, 0x1ffd
    mov word [bx], 0x1fff
    mov ds, bp
    mov bx, 0x0002
    mov sp, ax
    and sp, 0xfffc
    sub sp, 0x1fff
    mov word [bx], 0x1ffd
    mov [bx+0x02], cs
    call far [bx]