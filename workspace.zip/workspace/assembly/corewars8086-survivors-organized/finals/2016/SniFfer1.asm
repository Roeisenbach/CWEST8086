    jmp label1+1
    nop
    inc di
    db 0x6F
    and [si+0x6f], dh
    and [di+0x6e], ah
    db 0x64
    and [bx+0x66], ch
    and [bp+di+0x6f], ah
    db 0x64
    db 0x65
    and [bx+di+0x6e], ah
    db 0x64
    and [si+0x6f], ch
    db 0x6F
    db 0x6B
    and [bp+0x6f], ah
    jb label3
    jnb label6+1
    jb label5+1
    db 0x6E
    db 0x67
label1:
    jnb label2
    pop ss
    db 0x8B, 0xE0 ;$1 mov sp, ax
    push cs
    pop es
    clc
    db 0x33, 0xFF ;$1 xor di, di
    mov ax, 0x86cd
    mov cx, 0xcccc
label2:
    db 0x8B, 0xD0 ;$1 mov dx, ax
    db 0x8B, 0xD9 ;$1 mov bx, cx
    int 0x87
    db 0x8B, 0xFC ;$1 mov di, sp
    db 0x8B, 0xD1 ;$1 mov dx, cx
label3:
    push cs
    db 0x8B, 0xC2 ;$1 mov ax, dx
    add di, 0x0600
    pop es
    sub sp, 0x0400
    int 0x86
    clc
    int 0x86
    mov ax, 0xab50
    mov [di], ax
    db 0x8B, 0xF7 ;$1 mov si, di
    inc di
    inc di
    jmp si
    inc dx
    inc di
    db 0x6F
    db 0x6E
    db 0x65
    db 0x6E
    and [bx+di+0x73], cl
    and [bx+0x75], cl
    jb label4
    inc di
    db 0x6F
    db 0x64
    and [bx+di+0x6e], ah
    db 0x64
    and [si+0x6f], cl
    jb label8+1
    and [di+0x79], ax
    db 0x61
    db 0x6C
    and [bx+0x61], dl
    jnb label7
    db 0x68
    db 0x65
    jb label9
    and [bp+si], bh
    sub [bx+di], bp
    and [bx+di], si
label4:
    pop cx
    db 0x65
label5:
    jb label12
    jbe label10
    db 0x61
    db 0x6D
    jnb label13
    db 0x69
label6:
    jb label11
    db 0x6C
    db 0x61
    db 0x61
    db 0x61
    db 0x61
    db 0x61
    db 0x61
    db 0x61
    db 0x64
label7:
    db 0x62
    db 0x64
    db 0x62
    db 0x67
    db 0x6F
    db 0x6E
    db 0x65
    db 0x6E
    and [bp+di+0x44], bl
    inc sp
    inc sp
    inc sp
    inc sp
    inc sp
    ja label16+1
    jb label14
    and [di+0x79], ah
    db 0x61
    db 0x6C
    pop bp
    cs:
    db 0x6F
    jnb label15+2
    pop di
    pop di
    pop di
    pop di
    pop di
    pop di
    pop di
    pop di
    pop di
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
label8:
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
label9:
    and [bx+si], ah
    and [si+0x5f], bl
    pop di
    pop di
    pop di
label10:
    pop di
    pop di
    and [bx+si], ah
    and [si+0x20], bl
label11:
    and [bx+0x5f], bl
    pop di
    pop di
label12:
    and [bx+si], ah
    and [bx+0x5f], bl
    pop di
    pop di
label13:
    and [bx+si], ah
    and [bx+0x5f], bl
    pop di
    pop di
    and [bx+si], ah
    and [bx+0x5f], bl
    pop di
    pop di
    and [bx+si], ah
    and [bx+0x5f], bl
    pop di
label14:
    pop di
    and [bx+si], ah
label15:
    and [si+0x20], bh
    and [bx+si], ah
label16:
    and [si+0x20], bh
    and [bx+0x2f], bl
    and [bx], ch
    and [bx+0x5f], bl
    pop di
    pop sp
    and [bx], ch
    and [bx+si], ah
    pop di
    and [si+0x20], bl
    das
    and [bx+si], ah
    and [bx+si], ah
    pop sp
    pop di
    das
    and [bx+0x5f], bl
    and [si+0x20], bl
    das
    and [bx+si], ah
    and [bx+si], ah
    pop sp
    and [bx+si], ah
    jl label17+1
    and [bx+si], ah
    and [si+0x20], bh
    and [bx+si], ah
    pop sp
    das
    and [bx], ch
    pop di
    das
    and [bx+si], ah
    ds:
    and [bx+si], ah
    cmp al, 0x5f
    ds:
    and [bx+di], ch
    and [bx+si], ah
    and [si+0x20], bh
    and [si+0x20], bl
label17:
    and [bx+0x5f], bl
    pop di
    das
    jl label18
    and [bx+si], ah
    jl label19
    and [si+0x20], bl
    and [si+0x5f], bh
    pop di
    pop di
    pop di
    pop di
    pop di
    and [bx+si], ah
    das
    pop sp
    pop di
    pop di
    pop di
    and [bx+si], ah
    das
    and [si+0x5f], bl
    pop di
    pop di
    pop di
    das
label18:
    jl 502
    pop di
    pop di
label19:
    jl label20+1
    and [bx], ch
    pop sp
    pop di
    pop di
    pop di
    and [bx+si], ah
    ds:
    pop di
    pop di
    pop di
    jl label21
    and [bx], ch
    or [bx+di], cx
    pop sp
    das
    das
    pop di
    pop di
    pop di
    pop di
    pop di
    das
    and [bx+si], ah
    and [bx+si], ah
label20:
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [bx+si], ah
    and [si+0x2f], bl
    and [bx+si], ah
    and [bx+si], ah
label21:
    and [si+0x2f], bl
    and [bx+si], ah
    and [bx+si], ah
    and [si+0x2f], bl
    db 0x20  ; and [bx+si], al