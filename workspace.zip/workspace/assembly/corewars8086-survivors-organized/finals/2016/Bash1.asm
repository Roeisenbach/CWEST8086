    mov dx, 0xd139
    mov bx, 0x16ff
    mov cx, 0x30fe
    jmp label1
    int3
    int3
    int3
    push es
    push cs
    pop es
    xchg si, ax
    mov ax, 0xe874
    int 0x87
    pop es
    mov di, 0x0002
    mov ax, 0xa59c
    add si, 0x010c
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0056
    mov cx, 0x0024
    rep movsw
    push cs
    push cs
    push es
    pop ds
    add si, 0x00c0
    lea di, [si-0x0100]
    xchg si, [0x0000]
    mov si, 0x0056
    mov cl, 0x0d
loop1:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop1
    pop es
    lea sp, [di+0x0220]
    movsw
    mov [bp-0x0198], ax
    mov [bp+0x0198], ax
    int3
    int3
    int3
    push es
    push cs
    pop es
    xchg si, ax
    mov ax, 0xe874
    int 0x87
    pop es
    mov di, 0x0002
    mov ax, 0xa59c
    add si, 0x010c
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0056
    mov cx, 0x0024
    rep movsw
    push cs
    push cs
    push es
    pop ds
    add si, 0x00c0
    lea di, [si-0x0100]
    xchg si, [0x0000]
    mov si, 0x0056
    mov cl, 0x0d
loop2:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop2
    pop es
    lea sp, [di+0x0220]
    movsw
    mov [bp-0x0198], ax
    mov [bp+0x0198], ax
    int3
    int3
    int3
label1:
    push es
    push cs
    pop es
    xchg si, ax
    mov ax, 0xe874
    int 0x87
    pop es
    mov di, 0x0002
    mov ax, 0xa59c
    add si, 0x010c
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0056
    mov cx, 0x0020
    rep movsw
    push cs
    push cs
    push es
    pop ds
    add si, 0x00c0
    lea di, [si-0x0100]
    xchg si, [0x0000]
    mov si, 0x0056
    mov cl, 0x0d
loop3:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop3
    pop es
    pop ss
    mov bp, di
    mov si, 0x000a
    lea sp, [di+0x0220]
    movsw
    mov [bp-0x0198], ax
    mov [bp+0x0198], ax
    out 0xf2, al
    or al, 0xa5
    db 0xF3, 0xE6
    ret 0x23c4
    push ss
    db 0xC8
    aad 0x98
    add [bp+di], di
    aad 0x2b
    db 0xFE, 0x75, 0x08
    retf 0xbeac
    or al, [bx+si]
    out 0xbc, al
    aad 0xa5
    movsw
    db 0xF2, 0x4D
    movsw
    rep movsw
    std
    inc cx
    add [bx+di], bh
    ret 0x4736
    add di, 0xb570
    ret 0x38ef
    sti
    retf 0x8dbe
    movsw
    and [bx+di-0x1a], al
    movsw
    movsw
    movsw
    out 0xbc, al
    aad 0xcc
    int3
    int3
    push es
    push cs
    pop es
    xchg si, ax
    mov ax, 0xe874
    int 0x87
    pop es
    mov di, 0x0002
    mov ax, 0xa59c
    add si, 0x010c
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0056
    mov cx, 0x0024
    rep movsw
    push cs
    push cs
    push es
    pop ds
    add si, 0x00c0
    lea di, [si-0x0100]
    xchg si, [0x0000]
    mov si, 0x0056
    mov cl, 0x0d
loop4:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop4
    pop es
    lea sp, [di+0x0220]
    movsw
    mov [bp-0x0198], ax
    mov [bp+0x0198], ax
    int3
    int3
    int3
    push es
    push cs
    pop es
    xchg si, ax
    mov ax, 0xe874
    int 0x87
    pop es
    mov di, 0x0002
    mov ax, 0xa59c
    add si, 0x010c
    movsw
    movsw
    movsw
    movsw
    mov dx, ax
    int 0x86
    mov ax, 0x5000
    mov di, 0x0056
    mov cx, 0x0024
    rep movsw
    push cs
    push cs
    push es
    pop ds
    add si, 0x00c0
    lea di, [si-0x0100]
    xchg si, [0x0000]
    mov si, 0x0056
    mov cl, 0x0d
loop5:
    xor word [si], 0x4343
    add si, 0x0005
    loop loop5
    pop es
    lea sp, [di+0x0220]
    movsw
    mov [bp-0x0198], ax
    mov [bp+0x0198], ax