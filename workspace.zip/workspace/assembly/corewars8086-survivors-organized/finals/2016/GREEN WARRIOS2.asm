    jmp label1
    mov si, ax
    add si, 0x0094
    push cs
    pop ss
    mov ax, [0x01f4]
    mov di, 0x0114
    mov cl, 0x0f
    rep movsw
    mov cx, 0x0772
    mov bp, 0x05dc
    push cs
    push es
    pop ds
    pop es
    add ax, 0x018e
    mov bx, 0x0190
    mov [bx+0x02], cs
    mov [bx], ax
    mov di, ax
    mov sp, ax
    add sp, 0x0640
    mov ax, 0x1fff
    stosw
    mov si, 0x0114
    mov dx, si
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    mov sp, [bx]
    mov si, dx
    sub sp, bp
    mov di, sp
    push ax
    mov [bx], sp
    sub sp, cx
    call far [bx]
label1:
    mov si, ax
    add si, 0x0094
    push cs
    pop ss
    mov di, 0x0114
    mov cl, 0x0f
    mov ax, [0x01f4]
    rep movsw
    mov cx, 0x1994
    mov bp, 0x05dc
    push cs
    push es
    pop ds
    pop es
    mov di, ax
    add di, 0x0800
    mov dx, 0xcccc
    int 0x86
    add ax, 0x018e
    mov bx, 0x0190
    mov [bx+0x02], cs
    mov [bx], ax
    mov sp, ax
    mov di, ax
    mov ax, 0x1fff
    add sp, 0x0640
    stosw
    mov si, 0x0114
    mov dx, si
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov sp, [bx]
    mov si, dx
    sub sp, bp
    mov di, sp
    push ax
    mov [bx], sp
    sub sp, cx
    call far [bx]
    jmp label1
    mov si, ax
    add si, 0x0094
    push cs
    pop ss
    mov ax, [0x01f4]
    mov di, 0x0114
    mov cl, 0x0f
    rep movsw
    mov cx, 0x0772
    mov bp, 0x05dc
    push cs
    push es
    pop ds
    pop es
    add ax, 0x018e
    mov bx, 0x0190
    mov [bx+0x02], cs
    mov [bx], ax
    mov di, ax
    mov sp, ax
    add sp, 0x0640
    mov ax, 0x1fff
    stosw
    mov si, 0x0114
    mov dx, si
    call far [bx]
    movsw
    movsw
    movsw
    movsw
    mov sp, [bx]
    mov si, dx
    sub sp, bp
    mov di, sp
    push ax
    mov [bx], sp
    sub sp, cx
    call far [bx]