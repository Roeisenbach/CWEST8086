    push es
    mov bp, ds
    mov es, bp
    mov bx, 0x26ff
    mov cx, 0xc6fd
    mov [0xc6fd], ax
    mov ax, 0x168b
    mov dx, 0x4397
    int 0x87
    mov ax, [0xc6fd]
    jmp label1
    mov si, ax
    mov dx, ax
    int 0x86
    mov ax, si
    rep movsw
    push es
    pop ds
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    mov di, ax
    mov ax, di
    xor si, si
    movsw
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    add ax, bx
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, ax
    movsw
    mov si, ax
    mov dx, ax
    int 0x86
    mov ax, si
    rep movsw
    push es
    pop ds
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    mov di, ax
    mov ax, di
    xor si, si
    movsw
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    add ax, bx
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, ax
    movsw
    mov di, 0x4340
    nop
    int 0x86
    std
    int 0x86
    cld
    sub sp, ax
    mov ax, [0xc6fd]
    mov ss, bp
    mov dx, 0xa552
    mov di, ax
    add di, 0x009c
    mov ax, 0x52ab
    stosw
label1:
    mov bx, ax
    add bx, 0x0008
    mov word [bx], 0x74eb
    pop es
    mov bx, 0x17a8
    add ax, 0x00a6
    mov si, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    mov ax, si
    add si, 0x0031
    mov cx, 0x000a
    rep movsw
    push es
    pop ds
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    mov di, ax
    add di, 0x0031
    mov ax, di
    xor si, si
    movsw
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    add ax, bx
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, ax
    movsw
    call ax
    mov si, ax
    mov dx, ax
    int 0x86
    mov ax, si
    rep movsw
    push es
    pop ds
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    mov di, ax
    mov ax, di
    xor si, si
    movsw
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    add ax, bx
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, ax
    movsw
    mov si, ax
    mov dx, ax
    int 0x86
    mov ax, si
    rep movsw
    push es
    pop ds
    mov es, bp
    mov ss, bp
    mov dx, 0xcccc
    mov cx, 0x18a8
    mov sp, ax
    mov di, ax
    mov ax, di
    xor si, si
    movsw
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    add ax, bx
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, ax
    movsw