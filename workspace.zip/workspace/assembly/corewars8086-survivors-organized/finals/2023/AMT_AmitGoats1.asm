    nop
    push ds
    pop es
    mov di, ax
    add di, 0x0017
    mov ax, 0xcccc
label1:
    stosw
    db 0x9B, 0x9B ;$1 nrg
    stosw
    jmp label1
    nop
    nop