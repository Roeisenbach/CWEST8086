    nop
    mov si, ax
    add si, 0x003b
    mov di, 0x0018
    xor cx, cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0102
    mov word [bx], 0xffac
    mov di, 0xffac
    add di, 0x000d
    inc di
    inc di
    inc di
    nop
    push di
    mov ax, 0xcccc
    mov dx, ax
    mov di, 0x8000
    int 0x86
    mov di, 0x9000
    int 0x86
    pop di
    mov cx, 0x0008
    mov si, 0x0018
    add di, 0x0050
    add word [bx], 0x0060
    rep movsw
    jmp word [bx]