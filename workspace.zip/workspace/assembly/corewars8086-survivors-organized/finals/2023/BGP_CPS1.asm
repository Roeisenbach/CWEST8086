    nop
    mov bx, bp
    push es
    mov cx, ss
    pop ss
    mov di, [bp+0x00]
    add di, 0x0003
    jmp di
    mov word [0xecef], 0x1cff
    mov word [0xeced], 0xcc29
    mov ss, cx
    mov di, 0x0000
    mov cx, 0x0704
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x0ddf
    nop
    nop
    nop
    nop
    mov word [si], 0x1cfd
    mov word [si+0x02], 0x1cff
    call far [si]