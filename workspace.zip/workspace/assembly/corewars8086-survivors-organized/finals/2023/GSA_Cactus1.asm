    nop
    jmp label2
    pop es
    add si, 0x00af
    mov cx, 0x0011
    rep movsw
    mov dx, 0x10a5
    push dx
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov ax, bx
    mov bx, 0x0022
    mov [bx], ax
    mov sp, ax
    add sp, 0x0a52
    mov word [bx+0x02], 0x10a5
    xor si, si
    mov di, 0x00af
    nop
    mov cx, 0x000f
    add di, ax
    add di, bp
    movsw
    mov cs, dx
    rep movsw
label1:
    add word [bx], 0x1700
    add sp, 0x1900
    cmp word [bx], 0xf596
    cmp word [bx], 0xf596
    ja label1
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0000
    mov cx, 0x000f
    call far [bx]
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    mov bx, [0x0206]
    jmp label3
label2:
    mov bx, ax
    add bx, word 0x0067
label3:
    push es
    push ds
    pop es
    mov ax, 0x5ecc
    mov dx, 0xee81
    mov cx, 0x26ff
    mov [0x0206], bx
    int 0x87
    std
    cld
    nop
    pop es
    mov si, bx
    add si, 0x0058
    mov cx, 0x0011
    rep movsw
    mov dx, 0x10a5
    push dx
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov ax, bx
    mov bx, 0x0022
    mov [bx], ax
    mov sp, ax
    add sp, 0x0a52
    mov word [bx+0x02], 0x10a5
    xor si, si
    mov di, 0x0058
    nop
    nop
    mov cx, 0x000f
    add di, ax
    add di, bp
    movsw
    mov cs, dx
    rep movsw
label4:
    add word [bx], 0x1700
    add sp, 0x1900
    cmp word [bx], 0xf596
    cmp word [bx], 0xf596
    ja label4
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0000
    mov cx, 0x000f
    call far [bx]
    call far [bx]
    nop
    mov cx, 0x000f
    add di, ax
    add di, bp
    movsw
    mov cs, dx
    rep movsw
label5:
    add word [bx], 0x1700
    add sp, 0x1900
    cmp word [bx], 0xf596
    cmp word [bx], 0xf596
    ja label5
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0000
    mov cx, 0x000f
    call far [bx]
    call far [bx]
    nop
    pop es
    mov si, bx
    add si, 0x0058
    mov cx, 0x0011
    rep movsw
    mov dx, 0x10a5
    push dx
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov ax, bx
    mov bx, 0x0022
    mov [bx], ax
    mov sp, ax
    add sp, 0x0a52
    mov word [bx+0x02], 0x10a5
    xor si, si
    mov di, 0x0058
    nop
    nop