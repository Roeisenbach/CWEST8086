    nop
    jmp label1
    push cs
    pop ss
    int3
    int3
    pop ds
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    push cs
    pop ss
    int3
    int3
    pop ds
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    push cs
    pop ss
    int3
    int3
    pop ds
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    push cs
    pop ss
    int3
    int3
    pop ds
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    push cs
    pop ss
    nop
label1:
    mov si, ax
    add si, word 0x0055
    mov cx, 0x000d
    mov di, 0x0050
    rep movsw
    mov byte [di], 0xa5
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0080
    mov [bx], di
    mov [bx+0x02], cs
    inc di
    nop
    mov si, 0x0050
    mov cx, 0x000c
    call far [bx]
    rep movsw
    nop
    nop
    nop
    nop
    add di, 0x0100
    mov si, 0x0050
    mov cx, 0x000d
    rep movsw
    mov [bx], di
    sub word [bx], 0x0018
    call far [bx]
    push cs
    pop ss
    int3
    int3
    pop ds
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    push cs
    pop ss
    int3
    int3
    pop ds
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    push cs
    pop ss
    int3
    int3
    push cs
    nop
    pop ds
    db 0xFF, 0xCC ;$1 dec sp
    int3
    push cs
    pop ss
    int3
    int3
    pop ds
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp