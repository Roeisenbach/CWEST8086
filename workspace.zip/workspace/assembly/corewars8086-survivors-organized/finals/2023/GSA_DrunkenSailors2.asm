    nop
    jmp label2
    stosw
    db 0x83, 0xC0, 0x01 ;$1 add ax, 0x0001
    db 0x83, 0xF8, 0x01 ;$1 cmp ax, 0x0001
    push ax
    pop bx
    brk
    brk
    brk
    cmp dx, 0x2710
    jz label1
    db 0x83, 0xC0, 0xFF ;$1 add ax, 0xffff
label1:
    sub bx, 0x0001
    mov byte [bx], 0xeb
    sub bx, 0x0001
    mov byte [bx], 0x12
    jmp label1
    nop
    stosw
    db 0x83, 0xC0, 0x01 ;$1 add ax, 0x0001
    db 0x83, 0xF8, 0x01 ;$1 cmp ax, 0x0001
    push ax
    pop bx
label2:
    add dx, 0x2710
    push ax
    pop bx
    add bx, 0x0002
    mov byte [bx], 0x12
    push cs
    pop es
    push cs
    pop ss
    mov sp, ax
    mov di, ax
    add di, word 0x004f
    mov ax, 0xab50
    stosw