    nop
    nop
    jmp label2+2
    push ds
    mov word [0x1234], 0xcccc
    pop es
    mov di, ax
    mov ax, 0xcccc
    stosw
    add di, 0x000f
    brk
label1:
    push ds
    pop es
    mov di, ax
label2:
    mov ax, 0xcccc
    add di, 0x000f
    jmp label1
    push ds
    pop es
    mov di, ax
    mov ax, 0xcccc
    jmp label3
    nop
    nop
    nop
    nop
label3:
    nop
    nop
    nop
    nop
label4:
    nop
    nop
    add di, 0x0083
    mov cx, 0x000d
label5:
    stosw
    mov word [0x1234], 0xcccc
    dec cx
    add di, 0x000f
    cmp cx, 0x0000
    jnz label5
    jmp label6
    push ds
    pop es
    mov di, ax
    stosw
    add di, 0x000f
    jmp label4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
label6:
    stosw
    mov ax, 0xcccc
    add di, 0x000f
    jmp label6
    push ds
    pop es
    mov di, ax
    mov word [0x1234], 0xcccc
    add di, 0x000f
    nop
    nop
    nop
    nop
    stosw
    add di, 0x000b