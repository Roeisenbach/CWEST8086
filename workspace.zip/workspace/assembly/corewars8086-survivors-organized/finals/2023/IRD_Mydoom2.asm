start:
    nop
    jmp label1
    nop
    nop
    mov bx, 0x5651
    mov cx, 0x5350
    mov cx, 0x0020
    loop loop1+1
    mov dx, 0x000f
    push es
    pop ds
    push cs
    pop es
    xchg di, ax
    lodsw
    mov cx, ax
    rep movsw
    call start
    push cs
    nop
    pop ss
    mov si, 0xd429
    mov bx, 0x5651
    nop
    mov cx, 0x5350
    mov sp, ax
    sub sp, 0x1024
    mov ax, 0xd4ff
    push ax
    push bx
    push cx
    push si
    call sp
label1:
    mov cx, 0x0020
loop1:
    loop $
    mov dx, 0x000f
    push es
    pop ds
    push cs
    pop es
    xchg di, ax
    lodsw
    mov cx, ax
    rep movsw
    call start
    push cs
    nop
    pop ss
    mov si, 0xd429
    mov bx, 0x5651
    mov cx, 0x5350
    mov sp, ax
    sub sp, 0x1024
    mov ax, 0xd4ff
    push ax
    push bx
    push cx
    push si
    call sp
    mov cx, 0x0020
    loop loop1+1
    mov dx, 0x000f
    push es
    pop ds
    push cs
    pop es
    xchg di, ax
    lodsw
    nop
    nop
    mov cx, ax
    rep movsw
    call start
    push cs
    nop
    pop ss
    mov si, 0xd429
    mov bx, 0x5651
    mov cx, 0x5350
    mov sp, ax
    sub sp, 0x1024
    mov ax, 0xd4ff
    push ax
    push bx
    push cx
    push si
    call sp
    pop es
    xchg di, ax
    lodsw
    mov cx, ax
    db 0xF3