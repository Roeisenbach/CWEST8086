    nop
    jmp label1
    push es
    pop ds
    brk
    lodsw
    mov bx, ax
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xf1ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx-0x0bfb]
    lea ax, [bx+0x76ff]
    mov bx, 0x00c4
    nop
    nrg
    nop
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov word [bx-0x02], 0x0ffb
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    mov ax, 0x51a5
    mov dx, 0x00fc
    mov cl, 0x07
    mov si, 0x001b
    mov di, [bx]
    dec di
    movsw
    movsw
    movsw
    sub di, 0x0004
    push cx
    call far [bx]
    int3
    int3
    int3
    nop
    nop
    db 0x9B, 0x9B ;$1 nrg
    push es
    pop ds
    brk
    lodsw
    mov bx, ax
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xf1ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx-0x0bfb]
    lea ax, [bx+0x76ff]
    mov bx, 0x00c4
    nop
    nrg
    nop
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov word [bx-0x02], 0x0ffb
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    mov ax, 0x51a5
    mov dx, 0x00fc
    mov cl, 0x08
    mov si, 0x001b
    mov di, [bx]
    dec di
    movsw
    movsw
    movsw
    sub di, 0x0004
    push cx
    call far [bx]
    int3
    int3
    int3
    nop
    nop
label1:
    db 0x9B, 0x9B ;$1 nrg
    push es
    pop ds
    brk
    lodsw
    mov bx, ax
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xf1ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx-0x0bfb]
    lea ax, [bx+0x76ff]
    mov bx, 0x00c4
    nop
    nrg
    nop
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov word [bx-0x02], 0x0ffb
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    mov ax, 0x51a5
    mov dx, 0x00fc
    mov cl, 0x08
    mov si, 0x001a
    mov di, [bx]
    dec di
    movsw
    movsw
    movsw
    sub di, 0x0004
    push cx
    call far [bx]
    int3
    int3
    int3
    nop
    nop
    jmp label1
    push es
    pop ds
    brk
    lodsw
    mov bx, ax
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xf1ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx-0x0bfb]
    lea ax, [bx+0x76ff]
    mov bx, 0x00c4
    nop
    nrg
    nop
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov word [bx-0x02], 0x0ffb
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    mov ax, 0x51a5
    mov dx, 0x00fc
    mov cl, 0x07
    mov si, 0x001b
    mov di, [bx]
    dec di
    movsw
    movsw
    movsw
    sub di, 0x0004
    push cx
    call far [bx]
    int3
    int3
    int3
    nop
    nop
    db 0x9B, 0x9B ;$1 nrg
    push es
    pop ds
    brk
    lodsw
    mov bx, ax
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xf1ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx-0x0bfb]
    lea ax, [bx+0x76ff]
    mov bx, 0x00c4
    nop
    nrg
    nop
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov word [bx-0x02], 0x0ffb
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    mov ax, 0x51a5
    mov dx, 0x00fc
    mov cl, 0x07
    mov si, 0x001b
    mov di, [bx]
    dec di
    movsw
    movsw
    movsw
    sub di, 0x0004
    push cx
    call far [bx]