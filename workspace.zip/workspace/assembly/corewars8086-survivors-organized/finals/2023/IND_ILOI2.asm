    nop
    push es
    push ds
    pop es
    pop ds
    mov di, ax
    add di, 0x000f
    mov cx, 0x0080
    rep movsw