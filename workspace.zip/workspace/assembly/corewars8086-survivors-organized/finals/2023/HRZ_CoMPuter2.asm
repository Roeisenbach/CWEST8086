    nop
    jmp label1
    push ax
    call sp
    nop
    stosw
    push ds
    pop es
    sub sp, dx
    push si
    push bx
    nop
    push cx
    push ax
    call sp
    nop
    nop
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    nop
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    nop
    int 0x87
    push cs
    pop ss
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    nop
    nop
    nop
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    stosw
    push ds
    pop es
    std
    nop
    nop
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    nop
label1:
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    nop
    push cx
    push ax
    call sp
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    nop
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    nop
    nop
    nop
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    mov sp, di
    mov si, 0xd4ff
    nop
    nop
    nop
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    stosw
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    push cs
    pop ss
    nop
    nop
    mov sp, di
    mov si, 0xd4ff
    mov ax, 0xd429
    mov cx, 0x5356
    mov bx, 0x5051
    mov dx, 0x000f
    sub sp, dx
    push si
    push bx
    push cx
    push ax
    call sp
    sub sp, dx
    push si
    push bx
    nop
    push cx
    push ax
    call sp
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    push ax
    call sp
    nop
    stosw
    push ds
    pop es
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop