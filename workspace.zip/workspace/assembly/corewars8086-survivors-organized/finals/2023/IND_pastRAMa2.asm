    nop
    push es
    pop ds
    lodsw
    jmp ax