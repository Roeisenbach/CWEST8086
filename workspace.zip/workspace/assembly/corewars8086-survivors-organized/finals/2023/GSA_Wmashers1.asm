    nop
    push ds
    pop es
    mov di, ax
    mov ax, 0xcccc
label1:
    stosw
    add di, 0x000c
    jmp label1