    nop
loop1:
    db 0x32, 0xEF ;$1 xor ch, bh
    mov bx, ax
    inc bx
    cmp byte [bx], 0x32
    loopnz loop1
    jmp label1+1
    nop
    db 0xF6, 0x89, 0x93, 0x56
    cmc
    sub [bx+di-0x760d], cx
    movsw
label1:
    dec byte [bp+di-0x47]
    or al, 0x00
loop2:
    add di, 0x0029
    mov dl, [bx+si+word 0x000d]
    mov [bx+di], dl
    inc si
    loop loop2
    nop
    nop
    nop
    nop
    add ax, 0x003a
    push es
    push ds
    pop es
    mov di, [0x0206]
    int 0x86
    pop es
    push ax
    jmp label6
    movsw
    mov cl, 0x07
    movsw
    movsw
    rep movsw
    mov [bp-0x0196], ax
    mov [bp+0x03ca], ax
    xchg dx, ax
    mov ax, 0xa552
    xor [bx+si-0x4e5b], dx
    cmp al, [bx-0x0221]
    rep stosw
    mov di, bx
    cld
    movsw
    xchg sp, bx
    cmp word [bp+si], 0x00de
    mov ax, 0x6a6c
    mov bp, dx
    movsw
    mov ax, 0x0000
    mov dx, 0x0000
    int 0x87
    add bp, 0xb000
    lea sp, [bp-0x0194]
    nop
    out dx, ax
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6a6c
    push dx
    mov [bp+0x03ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    push ds
    push es
    push es
    pop es
    pop ds
    pop ss
    mov cx, 0xffff
    mov bl, 0xa3
loop3:
    nrg
    mul bx
    nop
    cmp bl, 0xa3
    ja label2
    mov bl, 0xa3
label2:
    mov word [bx], 0xcccc
    loop loop3
    mov di, dx
    cmp di, 0x2000
    jnb label3
    add di, 0x2100
    jmp label4
label3:
    cmp di, 0xe000
    jbe label4
    sub di, 0x2100
label4:
    int 0x56
    int 0x90
    mov cx, 0xffff
    nrg
    mul bx
    xchg bx, ax
    cmp bl, 0xa3
    ja label5
    mov bl, 0xa3
label5:
    mov word [bx], 0xcccc
    loop $
    jmp word [0xffff]
label6:
    db 0x83, 0xC0, 0x5F ;$1 add ax, 0x005f
    mov [0x9090], ax
    mov bx, 0x3200
    mov cx, 0x0004
    mov si, 0x1590
loop4:
    mov [si], bx
    sub si, 0x0020
    loop loop4
    mov bx, 0x15d7
    mov di, [bx]
    mov cx, 0x0004
loop5:
    mov di, [bx]
    add di, 0x0025
    mov word [di], 0x27ff
    sub bx, 0x0020
    loop loop5
    pop ax
    xor di, di
    mov si, 0xa5ab
    mov dx, 0xd429
    add ax, 0x0190
    xchg si, ax
    push ss
    pop es
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x70
    rep movsw
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0x0000
    mov dx, 0x0000
    int 0x87
    add bp, 0xeb50
    lea sp, [bp-0x0194]
    nop
    out dx, ax
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6a6c
    push dx
    mov [bp+0x03ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    int3
    int3
    int3
    movsw
    movsw
    movsw
    mov di, bp
    movsb
    jmp bp
    movsw
    movsw
    mov cl, 0x06
    movsw
    movsw
    nop
    movsw
    mov bx, [bp+0x03ca]
    cmp [bp-0x0196], bx
    jnz label7
    xor si, si
label7:
    movsw
    movsw
    mov cl, 0x0d
    movsw
    rep movsw
    cmp bx, dx
    lea bx, [bp+0x03c7]
    jnz label8
    sub bp, 0x2000
    sub bx, 0x0560
label8:
    add bp, 0x1000
    nop
    out dx, ax
    movsw
    jmp bp
    db 0x64
    movsw
    mov cl, 0x0c
    movsw
    rep movsw
    mov cx, 0x0504
    xchg bx, sp
    mov dx, bp
    xchg si, ax
label9:
    pop si
    pop bp
    shl bp, cl
    mov [bp+si-0x03], bx
    sub sp, 0x0003
    dec ch
    jnz label9
    xchg si, ax
    movsw
    movsw
    mov cl, 0x06
    movsw
    db 0xF3, 0x90
    xchg sp, bx
    add bx, 0x00de
    mov ax, 0x6a6c
    mov bp, dx
    movsw
    movsw
    mov cl, 0x05
    movsw
    movsw
    rep movsw
    mov cl, 0x3a
    xchg bx, di
    std
    rep stosw
    mov di, bx
    cld
    movsw
    movsw
    mov cl, 0x07
    movsw
    movsw
    rep movsw
    mov [bp-0x6f96], ax
    mov [bp+0x03ca], ax
    xchg dx, ax
    mov ax, 0xa552
    xor si, si
    movsw
    movsw
    mov cl, 0x07
    movsw
    movsw
    rep movsw