    nop
    jmp label2
    add ax, 0x014e
    push es
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xc681
    mov cx, 0x26ff
    mov [0x0206], di
    mov ax, 0x5ecc
    mov [0x0206], di
    mov [0x0206], di
    mov dx, [0x0206]
    int 0x87
    pop ds
    lodsw
    mov bx, ax
    push cs
    pop ds
    nop
    sub di, 0x0063
    mov byte [bx-0x14], 0xbc
    mov [bx-0x13], di
    add di, 0x0063
    cmp dx, di
    jz label1
    mov bx, dx
    mov word [bx+0x51], 0xcccc
label1:
    mov bx, [0xcccc]
    mov word [bx+0x0102], 0xcccc
    push cs
    pop ss
    mov sp, di
    sub sp, 0x014e
    nop
    nop
    nop
label2:
    add ax, 0x014e
    push es
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xc681
    mov cx, 0x26ff
    mov [0x0206], di
    mov ax, 0x5ecc
    mov [0x0206], di
    mov dx, [0x0206]
    mov [0x0206], di
    mov [0x0206], di
    mov [0x0206], di
    nop
    nop
    nop
    mov [0x0206], di
    mov [0x0206], di
    mov [0x0206], di
    int 0x87
    pop ds
    lodsw
    mov bx, ax
    push cs
    pop ds
    sub di, 0x0063
    mov byte [bx-0x2e], 0xbc
    mov [bx-0x2d], di
    mov word [bx-0x2b], 0xd4ff
    add di, 0x0063
    cmp dx, di
    jz label3
    mov bx, dx
    nop
    mov word [bx+0x51], 0xcccc
label3:
    mov bx, [0xcccc]
    mov word [bx+0x0102], 0xcccc
    push cs
    pop ss
    mov sp, di
    sub sp, 0x014e
    mov cx, 0x000f
    mov si, 0x41d4
    mov di, 0xff50
    mov bx, 0x5253
    mov dx, 0x5756
    mov ax, 0xcc29
    sub sp, cx
    push si
    nop
    push di
    push bx
    push dx
    push ax
    call sp
    inc cx
    nop
    nop
    add sp, 0x8000
    mov cx, 0x000f
    mov si, 0x41d4
    mov di, 0xff50
    mov bx, 0x5253
    mov dx, 0x5756
    mov ax, 0xcc29
    sub sp, cx
    push si
    push di
    push bx
    push dx
    push ax
    call sp
    inc cx
    add ax, 0x014e
    nop
    push es
    push ds
    pop es
    std
    mov di, ax
    mov dx, 0xc681
    mov cx, 0x26ff
    mov [0x0206], di
    mov ax, 0x5ecc
    mov [0x0206], di
    mov [0x0206], di
    int 0x87
    pop ds
    lodsw
    mov bx, ax
    push cs
    pop ds
    sub di, 0x0063
    mov byte [bx-0x14], 0xbc
    nop
    nop
    nop
    mov [bx-0x13], di
    add di, 0x0063
    cmp dx, di
    nop
    nop
    nop
    nop
    add [bx+si], al
    nop
    nop
    nop
    nop
    mov si, [0x0206]
    mov bx, ax
    mov byte [bx+0x0b], 0x00
    mov di, si
    mov ax, 0x5ecc
    mov dx, 0xc681
    push ds
    pop es
    cmp word [si-0x06], 0x0003
    jb label5
    nop
    cmp word [si-0x06], 0x0005
    jb label4
    push bx
    mov ax, 0xd4ff
    mov dx, 0xcccc
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop bx
    jmp label6
label4:
    mov dh, 0xee
label5:
    mov cx, 0x26ff
    std
    mov [0x0206], si
    int 0x87
    inc word [si-0x06]
    mov [0x0206], si
    nop
    nop
    mov [0x0206], si
    mov [0x0206], si
    mov [0x0206], si
    mov [0x0206], si
    mov [0x0206], si
    mov [0x0206], si
    mov [0x0206], si
    mov [0x0206], si
label6:
    mov ax, 0x5350
    push ax
    pop es
    mov ax, 0xcc01
    push ax
    pop ds
    nop
    nop
    nop
    mov dx, 0x5255
    mov si, 0x75f9
    mov di, 0x3941
    mov bp, 0x1e06
    mov ax, 0xd4ff
    push cs
    pop ss
    mov sp, bx
    mov bx, 0x5756
    xor cx, cx
    inc cx
    cmp cx, di
    jnz label7
    int3
label7:
    push ax
    push bx
    push bp
    push dx
    push es
    push ds
    push si
    push di
    call sp
    inc cx