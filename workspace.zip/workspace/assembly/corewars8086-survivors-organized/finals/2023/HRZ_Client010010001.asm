    nop
    jmp label1
    push ax
    push es
    mov bx, ax
    add bx, 0x00a5
    push ds
    pop es
    std
    mov dx, 0xc681
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    jmp label2
    mov bx, 0x0100
    pop ax
    push cs
    pop ss
    push ax
    mov [bx+0x02], cs
    nop
    nop
    add ax, ax
    mov al, 0xa1
    mov [bx], ax
    pop ax
    cld
    mov cx, 0x0008
    loop $
    mov di, [bx]
    mov sp, [bx]
    add sp, 0x2afc
    movsw
    movsw
    mov cx, 0x0011
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afc
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    push ax
    nop
    push es
    mov bx, ax
    add bx, 0x00a5
    push ds
    pop es
    std
    mov dx, 0xc681
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    jmp label2
    mov bx, 0x0100
    pop ax
    push cs
    pop ss
    push ax
    mov [bx+0x02], cs
    add ax, ax
    mov al, 0xa1
    mov [bx], ax
    nop
label1:
    push ax
    push es
    mov bx, ax
    add bx, 0x00a5
    push ds
    pop es
    std
    mov dx, 0xc681
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    brk
label2:
    mov bx, 0x0100
    pop ax
    push cs
    pop ss
    push ax
    mov [bx+0x02], cs
    add ax, ax
    mov al, 0xa1
    nop
    nop
    mov [bx], ax
    pop ax
    cld
    mov cx, 0x0008
    loop $
    mov di, [bx]
    mov sp, [bx]
    add sp, 0x2afc
    movsw
    movsw
    mov cx, 0x0011
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afc
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    push ax
    push es
    mov bx, ax
    nop
    nop
    add bx, 0x00a5
    push ds
    pop es
    std
    mov dx, 0xc681
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    jmp label2
    mov bx, 0x0100
    pop ax
    push cs
    pop ss
    push ax
    mov [bx+0x02], cs
    add ax, ax
    mov al, 0xa1
    mov [bx], ax
    pop ax
    cld
    nop
    nop
    mov cx, 0x0008
    loop $
    mov di, [bx]
    mov sp, [bx]
    add sp, 0x2afc
    movsw
    movsw
    mov cx, 0x0011
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afc
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    push ax
    push es
    mov bx, ax
    add bx, 0x00a5
    push ds
    nop
    pop es
    std
    mov dx, 0xc681
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    jmp label2
    mov bx, 0x0100
    pop ax
    push cs
    pop ss
    push ax
    mov [bx+0x02], cs
    add ax, ax
    mov al, 0xa1
    mov [bx], ax
    pop ax
    cld
    mov cx, 0x0008
    loop $
    nop
    mov di, [bx]
    mov sp, [bx]
    add sp, 0x2afc
    movsw
    movsw
    mov cx, 0x0011
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afc
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    call far [bx]
    call far [bx]
    mov cx, 0x0011
    mov sp, ax
    mov ax, 0x0500
    nop
    nop
    nop
    add sp, 0x2afc
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    call far [bx]
    call far [bx]
    mov cx, 0x0011
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afc
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    call far [bx]
    call far [bx]
    mov cx, 0x0011
    nop
    nop
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afc
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    mov cx, 0x0011
    nop
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afc
    mov bp, 0x002b
    nop
    nop
    mov dx, 0x0000
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    db 0xFF  ; inc word [bx+si]