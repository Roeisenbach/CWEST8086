    nop
    jmp label2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    mov cx, 0x0015
    mov si, ax
    add si, 0x00f4
    push ds
    push es
    push ss
    pop es
    rep movsw
    nop
    mov si, ax
    add si, 0xfac2
    mov word [si], 0x26ff
    mov word [si+0x02], 0x0030
    pop ds
    mov si, [0x0000]
    add si, 0xfa50
    add si, 0x8000
    pop ds
    mov word [si], 0x0fa5
    xchg si, di
    push cs
    push cs
    push ss
    pop ds
    pop es
    nop
    pop ss
    mov [si], di
    mov word [si+0x02], 0x0fa5
    mov [0x0030], di
    sub word [0x0030], 0xfa50
    inc di
    mov bx, si
    xor si, si
    mov cx, 0x0015
    mov dx, 0x0fa5
    mov cs, dx
    rep movsw
    mov cx, 0x0015
    sub word [bx], 0x1200
    nop
    jb label1
    add word [bx], 0x0e00
label1:
    mov di, [bx]
    add di, 0xfa50
    mov ax, 0x1fff
    stosw
    add di, 0x0400
    mov sp, di
    sub di, 0x0401
    xor si, si
    call far [bx]
    nop
label2:
    mov cx, 0x0015
    mov si, ax
    add si, 0x00f4
    nop
    push ds
    push es
    push ss
    pop es
    rep movsw
    mov si, ax
    add si, 0xfb44
    mov word [si], 0x26ff
    mov word [si+0x02], 0x0030
    pop ds
    mov si, [0x0000]
    add si, 0xfa50
    add si, 0x8000
    pop ds
    mov word [si], 0x0fa5
    nop
    nop
    xchg si, di
    push cs
    push cs
    push ss
    pop ds
    pop es
    pop ss
    mov [si], di
    mov word [si+0x02], 0x0fa5
    mov [0x0030], di
    sub word [0x0030], 0xfa50
    inc di
    mov bx, si
    xor si, si
    mov cx, 0x0015
    mov dx, 0x0fa5
    mov cs, dx
    rep movsw
    nop
    mov cx, 0x0015
    sub word [bx], 0x1200
    jb label3
    add word [bx], 0x0e00
label3:
    mov di, [bx]
    add di, 0xfa50
    mov ax, 0x1fff
    stosw
    add di, 0x0400
    mov sp, di
    sub di, 0x0401
    xor si, si
    call far [bx]
    nop
    nop
    nop
    nop
    mov cx, 0x0015
    mov si, ax
    add si, 0x00f4
    push ds
    push es
    push ss
    pop es
    rep movsw
    mov si, ax
    add si, 0xfbca
    mov word [si], 0x26ff
    mov word [si+0x02], 0x0030
    pop ds
    mov si, [0x0000]
    add si, 0xfa50
    nop
    nop
    add si, 0x8000
    pop ds
    mov word [si], 0x0fa5
    xchg si, di
    push cs
    push cs
    push ss
    pop ds
    pop es
    pop ss
    mov [si], di
    mov word [si+0x02], 0x0fa5
    mov [0x0030], di
    sub word [0x0030], 0xfa50
    inc di
    mov bx, si
    xor si, si
    nop
    nop
    mov cx, 0x0015
    mov dx, 0x0fa5
    mov cs, dx
    rep movsw
    mov cx, 0x0015
    sub word [bx], 0x1200
    jb label4
    add word [bx], 0x0e00
label4:
    mov di, [bx]
    add di, 0xfa50
    mov ax, 0x1fff
    stosw
    add di, 0x0400
    mov sp, di
    nop
    nop
    sub di, 0x0401
    xor si, si
    call far [bx]
    nop