    nop
    jmp label1
    stosw
    db 0x83, 0xC0, 0x01 ;$1 add ax, 0x0001
    db 0x83, 0xF8, 0x01 ;$1 cmp ax, 0x0001
    push ax
    pop bx
    brk
    brk
    brk
    cmp dx, 0x2710
    jz label3
    db 0x83, 0xC0, 0xFF ;$1 add ax, 0xffff
label1:
    push ax
    pop bx
    add bx, 0x0002
    mov byte [bx], 0x12
    add bx, 0x0033
    push bx
    pop es
    push cs
    pop ss
    mov sp, ax
    nop
    nop
    add dx, 0x2710
    mov ax, 0xeb12
label2:
    push ax
    jmp label2
    stosw
    db 0x83, 0xC0, 0x01 ;$1 add ax, 0x0001
    db 0x83, 0xF8, 0x01 ;$1 cmp ax, 0x0001
    push ax
    pop bx
label3:
    stosw
    push ax