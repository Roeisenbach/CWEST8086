    nop
    jmp label1
    mov cx, 0x0051
    sub ax, 0x07dd
    loop $
    mov [0x1234], ax
    mov [0x1234], ax
    mov [0x1234], ax
    add ax, 0x07dd
    mov cx, 0x00ff
    mov bx, 0x00a1
loop1:
    mov word [bx], 0xcccc
    add bh, 0x01
    loop loop1
    xor bx, bx
    mov si, ax
    nop
    nop
    nop
    add si, word 0x005d
    mov cx, 0x0009
    push ss
    pop es
    rep movsw
    mov di, ax
    sub di, 0x1400
    mov word [di], 0xc783
    mov word [di+0x02], 0xf305
    mov byte [di+0x04], 0xa5
    push ds
    push ss
    pop ds
    pop ss
    push cs
    pop es
    mov sp, ax
    mov cx, 0x0009
    xor si, si
    nop
    nop
    jmp di
    xor si, si
    add di, 0x1152
    mov cx, 0x0009
    rep movsw
    sub di, 0x0012
    jmp di
    mov cx, 0x0051
    sub ax, 0x07dd
    loop $
    mov [0x1234], ax
    mov [0x1234], ax
    mov [0x1234], ax
    add ax, 0x07dd
    mov cx, 0x00ff
    mov bx, 0x00a1
    nop
loop2:
    mov word [bx], 0xcccc
    add bh, 0x01
    loop loop2
    xor bx, bx
    mov si, ax
    add si, word 0x005d
    mov cx, 0x0009
    push ss
    pop es
    rep movsw
    mov di, ax
    sub di, 0x1400
    mov word [di], 0xc783
    mov word [di+0x02], 0xf305
    mov byte [di+0x04], 0xa5
    push ds
    nop
    push ss
    pop ds
    pop ss
    push cs
    pop es
    mov sp, ax
    mov cx, 0x0009
    xor si, si
    jmp di
    xor si, si
    add di, 0x1152
    mov cx, 0x0009
    rep movsw
    sub di, 0x0012
    jmp di
label1:
    mov cx, 0x0051
    sub ax, 0x07dd
    loop $
    mov [0x1234], ax
    mov [0x1234], ax
    nop
    mov [0x1234], ax
    add ax, 0x07dd
    mov cx, 0x00ff
    mov bx, 0x00a1
loop3:
    mov word [bx], 0xcccc
    add bh, 0x01
    loop loop3
    xor bx, bx
    mov si, ax
    add si, word 0x005d
    mov cx, 0x0009
    push ss
    pop es
    rep movsw
    mov di, ax
    sub di, 0x1400
    nop
    nop
    nop
    mov word [di], 0xc783
    mov word [di+0x02], 0xf305
    mov byte [di+0x04], 0xa5
    push ds
    push ss
    pop ds
    pop ss
    push cs
    pop es
    mov sp, ax
    mov cx, 0x0009
    xor si, si
    jmp di
    xor si, si
    add di, 0x1152
    mov cx, 0x0009
    rep movsw
    sub di, 0x0012
    jmp di
    nop
    mov cx, 0x0051
    sub ax, 0x07dd
    loop $
    mov [0x1234], ax
    mov [0x1234], ax
    mov [0x1234], ax
    add ax, 0x07dd
    mov cx, 0x00ff
    mov bx, 0x00a1
loop4:
    mov word [bx], 0xcccc
    add bh, 0x01
    loop loop4
    xor bx, bx
    mov si, ax
    add si, word 0x005d
    nop
    nop
    mov cx, 0x0009
    push ss
    pop es
    rep movsw
    mov di, ax
    sub di, 0x1400
    mov word [di], 0xc783
    mov word [di+0x02], 0xf305
    mov byte [di+0x04], 0xa5
    push ds
    push ss
    pop ds
    pop ss
    push cs
    pop es
    mov sp, ax
    mov cx, 0x0009
    xor si, si
    jmp di
    xor si, si
    nop
    nop
    add di, 0x1152
    mov cx, 0x0009
    rep movsw
    sub di, 0x0012
    jmp di
    mov cx, 0x0051
    sub ax, 0x07dd
    loop $
    mov [0x1234], ax
    mov [0x1234], ax
    mov [0x1234], ax
    add ax, 0x07dd
    mov cx, 0x00ff
    mov bx, 0x00a1
loop5:
    mov word [bx], 0xcccc
    nop
    add bh, 0x01
    loop loop5
    xor bx, bx
    mov si, ax
    add si, word 0x005d
    mov cx, 0x0009
    push ss
    pop es
    rep movsw
    mov di, ax
    sub di, 0x1400
    mov word [di], 0xc783
    mov word [di+0x02], 0xf305
    mov byte [di+0x04], 0xa5
    push ds
    push ss
    pop ds
    pop ss
    push cs
    nop
    pop es
    mov sp, ax
    mov cx, 0x0009
    xor si, si
    jmp di
    xor si, si
    add di, 0x1152