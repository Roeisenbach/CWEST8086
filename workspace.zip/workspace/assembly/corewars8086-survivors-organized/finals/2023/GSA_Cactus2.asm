    nop
    jmp label1
    mov bx, [0x0206]
    jmp label2
    mov bx, ax
    add bx, word 0x002a
    push ds
    pop es
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0x26ff
    std
    mov [0x0206], bx
    int 0x87
    push ds
    pop ss
    mov di, bx
    add di, 0x1567
    nop
    mov bx, [0x0206]
    jmp label2
label1:
    mov bx, ax
    add bx, word 0x002a
label2:
    push ds
    pop es
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0x26ff
    std
    mov [0x0206], bx
    int 0x87
    push ds
    pop ss
    mov di, bx
    add di, 0x1567
    int 0x86
    nop
    sub di, 0x3067
    int 0x86
    mov sp, di
    sub sp, 0x0100
    mov sp, si
label3:
    sub sp, 0x0041
    push bx
    jmp label3
    sub di, 0x3067
    int 0x86
    mov sp, di
    sub sp, 0x0100
    mov sp, si
label4:
    sub sp, 0x0041
    push bx
    jmp label4
    nop
    mov bx, ax
    add bx, word 0x002a
    push ds
    pop es
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0x26ff
    std
    mov [0x0206], bx
    int 0x87
    push ds
    pop ss
    mov di, bx
    add di, 0x1567
    int 0x86