    nop
    mov di, ax
    sub di, 0x0100
    mov cx, 0x001c
label1:
    mov word [0x1234], 0x83d4
    dec cx
    jnz label1
label2:
    mov word [di], 0x009b
    sub di, 0x0004
    jmp label2