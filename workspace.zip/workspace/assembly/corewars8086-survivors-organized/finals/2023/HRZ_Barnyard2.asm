    nop
    stosw
    mov word [0x8afd], 0x1cff
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x8cdd
    mov word [si], 0x1cfd
    mov word [si+0x02], 0x16e0
    call far [si]