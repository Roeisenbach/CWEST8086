    nop
    mov cx, 0x00cc
    mov bx, 0x0000
label1:
    mov [bx], cx
    add bx, 0x0004
    jmp label1
    nop
    nop