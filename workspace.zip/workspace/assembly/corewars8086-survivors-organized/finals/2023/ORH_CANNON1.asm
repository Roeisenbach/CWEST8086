    nop
    jmp label2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    stosw
    xor di, di
    mov cx, 0x0014
    mov si, ax
    add si, 0x00b7
    push ss
    pop es
    rep movsw
    nop
    mov si, ax
    add si, 0xfaa4
    mov word [si], 0x0fa5
    xchg si, di
    push ds
    push ds
    push ss
    pop ds
    pop es
    pop ss
    mov [si], di
    mov word [si+0x02], 0x0fa5
    inc di
    mov bx, si
    xor si, si
    mov cx, 0x0014
    mov dx, 0x0fa5
    mov cs, dx
    rep movsw
    mov cx, 0x0014
    nop
    nop
    sub word [bx], 0x1200
    jb label1
    add word [bx], 0x0e00
label1:
    mov di, [bx]
    add di, 0xfa50
    mov ax, 0x1fff
    stosw
    add di, 0x0400
    mov sp, di
    sub di, 0x0401
    xor si, si
    call far [bx]
    nop
label2:
    stosw
    xor di, di
    mov cx, 0x0014
    mov si, ax
    nop
    nop
    add si, 0x00b7
    push ss
    pop es
    rep movsw
    mov si, ax
    add si, 0xfb07
    mov word [si], 0x0fa5
    xchg si, di
    push ds
    push ds
    push ss
    pop ds
    pop es
    pop ss
    mov [si], di
    mov word [si+0x02], 0x0fa5
    inc di
    mov bx, si
    xor si, si
    mov cx, 0x0014
    mov dx, 0x0fa5
    nop
    mov cs, dx
    rep movsw
    mov cx, 0x0014
    sub word [bx], 0x1200
    jb label3
    add word [bx], 0x0e00
label3:
    mov di, [bx]
    add di, 0xfa50
    mov ax, 0x1fff
    stosw
    add di, 0x0400
    mov sp, di
    sub di, 0x0401
    xor si, si
    call far [bx]
    nop
    stosw
    nop
    nop
    xor di, di
    mov cx, 0x0014
    mov si, ax
    add si, 0x00b7
    push ss
    pop es
    rep movsw
    mov si, ax
    add si, 0xfb69
    mov word [si], 0x0fa5
    xchg si, di
    push ds
    push ds
    push ss
    pop ds
    pop es
    pop ss
    mov [si], di
    mov word [si+0x02], 0x0fa5
    inc di
    mov bx, si
    nop
    nop
    xor si, si
    mov cx, 0x0014
    mov dx, 0x0fa5
    mov cs, dx
    rep movsw
    mov cx, 0x0014
    sub word [bx], 0x1200
    jb label3
    add word [bx], 0x0e00
    mov di, [bx]
    add di, 0xfa50
    mov ax, 0x1fff
    stosw
    add di, 0x0400
    mov sp, di
    nop
    nop
    nop
    nop
    sub di, 0x0401
    xor si, si
    call far [bx]
    nop