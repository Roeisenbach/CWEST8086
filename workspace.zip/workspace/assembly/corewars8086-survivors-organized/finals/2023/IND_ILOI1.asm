    nop
    mov bp, 0x030f
    mov bx, ax
    lea si, [bx+word 0x0046]
    mov cx, 0x0007
    rep movsw
    db 0x83, 0xE0, 0x03 ;$1 and ax, 0x0003
    mov dx, 0x1000
    add ax, dx
    mov bx, 0x0300
    xchg si, di
    push ax
    push es
    pop ds
    pop es
    mov [bx+0x02], ax
    xor si, si
    mov ax, 0x1fff
    and di, 0xff00
    nop
    nop
    nop
    sub di, 0x005d
    mov [bx], di
    stosw
    dec di
    mov ss, dx
    lea sp, [di+0x0500]
    and sp, 0xfffc
    or sp, 0x0003
    mov cl, 0x06
    call far [bx]
    rep movsw
    mov cl, 0x06
    sub di, bp
    xor si, si
    mov [bx], di
    stosw
    dec di
    call far [bx]