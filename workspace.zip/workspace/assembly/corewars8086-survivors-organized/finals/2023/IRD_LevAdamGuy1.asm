    nop
    push ds
    pop es
    mov bx, ax
    add bx, word 0x0017
    mov si, bx
    lea di, [si+0x0a]
    mov dx, 0x0005
    mov bp, 0xf900
    lea bx, [bp+0x00]
    add di, bp
    mov cx, dx
    rep movsw
    add si, bx
    jmp si
    mov ax, 0x000a