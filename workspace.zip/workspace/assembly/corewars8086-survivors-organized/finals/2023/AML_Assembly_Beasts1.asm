    nop
    jmp label3
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call prcd1
prcd1:
    pop si
    sub si, 0x0003
    mov [0x0206], si
    push ds
    pop es
    std
    mov di, ax
    int 0x86
    int 0x86
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    int 0x87
    mov bx, 0xfff1
    nop
    mov cx, 0xf1ff
    mov bp, 0x000f
label1:
    stosw
    stosw
    sub di, bp
    cmp [di], bx
    jz label2
    cmp [di], cx
    jnz label1
label2:
    jmp word [bx]
label3:
    mov cl, 0x0f
    mov bp, 0xcccc
    mov si, 0x0206
    add ax, 0x000b
    mov [0x2023], ax
loop1:
    cmp [si], bp
    loopz loop1
    mov si, [si]
    mov word [si], 0x26ff
    nop
    mov word [si+0x02], 0x2023
    mov bx, ax
    add bh, 0x11
    mov bl, 0xa3
    mov word [bx], 0x1fff
    mov word [bx+0x02], 0x1fff
    mov word [bx+0x04], 0x1fff
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    mov sp, bx
    mov cl, 0x0c
    add sp, 0x0200
    mov bp, 0xa700
    std
    nop
    xor si, si
    mov di, bx
    sub di, 0x000a
    int 0x86
    int 0x86
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    cld
    mov dx, bx
    mov bx, 0x0060
    mov [bx], dx
    mov [bx+0x02], cs
    mov ax, 0xa500
    mov di, dx
    inc di
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    nop
    rep movsw
    sub dx, bp
    sub sp, ax
    mov di, dx
    sub di, 0x0004
    mov cl, 0x05
    rep movsw
    mov cl, 0x0c
    mov [bx], dx
    sub di, 0x0005
    xor si, si
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    rep movsw
    xor si, si
    add bh, 0x18
    nop
    nop
    mov bx, ax
    mov bl, 0xa3
    mov word [bx], 0x1fff
    mov word [bx+0x02], 0x1fff
    mov word [bx+0x04], 0x1fff
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    mov sp, bx
    add sp, 0x0200
    mov bp, 0xa700
    mov cl, 0x0c
    mov di, bx
    sub di, 0x000a
    std
    int 0x86
    nop
    nop
    int 0x86
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    cld
    mov dx, bx
    mov bx, 0x0050
    mov [bx], dx
    mov [bx+0x02], cs
    mov ax, 0xa500
    mov di, dx
    inc di
    call far [bx]
    rep movsw
    sub dx, bp
    sub sp, ax
    mov di, dx
    sub di, 0x0004
    mov cl, 0x05
    rep movsw
    nop
    mov cl, 0x0c
    mov [bx], dx
    sub di, 0x0005
    xor si, si
    call far [bx]
    call far [bx]
    call far [bx]
    nop