    nop
    jmp label2
    push ax
    mov ax, 0xcccc
    int3
    int3
    int3
    int 0x1f
    call far [bx]
    db 0xFF, 0xCC ;$1 dec sp
    int3
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    nop
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcc90
    int3
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    nop
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0x90cc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x90
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcc90
    mov dx, 0xcccc
    mov dx, 0xcccc
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    nop
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    int3
    rep movsw
label1:
    add word [bx], 0x1900
    add sp, 0x1a00
    cmp [bx], ax
    ja label1
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0002
    mov cx, 0x000c
    call far [bx]
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
label2:
    stosw
    mov si, ax
    add si, 0x00ae
    mov cl, 0x12
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov di, ax
    add di, 0x0b60
    mov bx, 0x0020
    mov [bx], ax
    mov word [bx+0x02], 0x10a5
    push cs
    pop ss
    nop
    nop
    mov sp, ax
    nop
    nop
    add sp, 0x0110
    mov si, 0x0004
    mov cl, 0x0c
    rep movsw
    mov ax, 0xf596
    mov dx, 0x10a5
    add sp, 0x0962
    mov es, dx
    mov cs, dx
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0x9090
    int 0x1f
    pop es
    push ax
    mov ax, 0xcc90
    mov dx, 0xcccc
    nop
    inc sp
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0x90cc
    mov dx, 0x90cc
    int 0x90
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0x90cc
    int3
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    nop
    int3
    int3
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0x9090
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcc90
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcc90
    int 0x1f
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x1f
    pop es
    push ax
    mov ax, 0x071f
    mov ax, 0x071f
    mov ax, 0x901f
    nop
    nop
    mov ax, 0x901f
    pop es
    movsw
    add word [bx], 0x1900
    add sp, 0x1b00
    cmp [bx+si-0x0b89], dx
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0002
    mov cx, 0x000c
    call far [bx]
    call far [bx]
    stosw
    mov si, ax
    add si, 0x00b4
    mov cx, 0x001c
    shr cx, 1
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov di, ax
    nop
    and word [bx+si+0x0b], 0x2090
    add [bx+di-0x38f9], cl
    inc di
    add ah, [di+0x0e10]
    pop ss
    mov sp, ax
    add sp, 0x0110
    db 0xBE, 0x04  ; mov si, 0x0004