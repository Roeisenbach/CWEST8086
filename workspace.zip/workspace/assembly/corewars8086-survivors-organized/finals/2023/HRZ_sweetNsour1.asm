    nop
    db 0xE9, 0x7D, 0x00 ;$1 jmp 129
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov si, ax
    add si, word 0x0057
    mov cx, 0x000c
    rep movsw
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    mov bx, ax
    xchg di, ax
    add di, 0x5000
    mov dx, 0xcccc
    mov ax, dx
    nop
    nop
    int 0x86
    nop
    sub di, 0xa000
    int 0x86
    nop
    xchg bx, ax
    mov bx, 0x0060
    mov al, 0xa3
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    mov sp, ax
    add sp, 0x03fc
    mov di, [bx]
    xor si, si
    movsw
    mov cx, 0x000a
    mov si, 0x0002
    nop
    dec di
    call far [bx]
    call far [bx]
    nop
    nop
    rep movsw
    sub ax, 0x0400
    mov [bx], ax
    mov di, [bx]
    xor si, si
    movsw
    mov cx, 0x000a
    mov si, 0x0002
    dec di
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov si, ax
    add si, 0x00c9
    nop
    mov cx, 0x000c
    rep movsw
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    mov bx, ax
    xchg di, ax
    add di, 0x5000
    mov dx, 0xcccc
    mov ax, dx
    int 0x86
    sub di, 0xa000
    int 0x86
    xchg bx, ax
    mov bx, 0x0060
    mov al, 0xa3
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    nop
    mov sp, ax
    add sp, 0x03fc
    mov di, [bx]
    xor si, si
    movsw
    mov cx, 0x000a
    mov si, 0x0002
    dec di
    call far [bx]
    call far [bx]
    rep movsw
    sub ax, 0x0400
    mov [bx], ax
    mov di, [bx]
    xor si, si
    movsw
    mov cx, 0x000a
    mov si, 0x0002
    dec di
    call far [bx]
    nop
    nop
    nop
    nop
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov si, ax
    add si, 0x013a
    nop
    nop
    nop
    mov cx, 0x000c
    rep movsw
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    mov bx, ax
    xchg di, ax
    add di, 0x5000
    mov dx, 0xcccc
    mov ax, dx
    int 0x86
    nop
    sub di, 0xa000
    int 0x86
    nop
    xchg bx, ax
    mov bx, 0x0060
    mov al, 0xa3
    mov [bx], ax
    nop
    mov word [bx+0x02], 0x1000
    mov sp, ax
    add sp, 0x03fc
    mov di, [bx]
    xor si, si
    movsw
    nop
    nop
    mov cx, 0x000a
    mov si, 0x0002
    dec di
    call far [bx]
    nop
    nop
    call far [bx]
    rep movsw
    sub ax, 0x0400
    mov [bx], ax
    nop
    mov di, [bx]
    xor si, si
    nop
    movsw
    mov cx, 0x000a
    mov si, 0x0002
    dec di
    call far [bx]