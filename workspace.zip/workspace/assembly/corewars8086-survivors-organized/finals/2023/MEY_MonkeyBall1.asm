    nop
    jmp label1
    mov bx, sp
    mov dx, ax
    add dx, 0x013c
    mov byte [bx], 0xea
    mov [bx+0x01], dx
    mov [bx+0x03], cs
    push es
    pop ds
    mov word [si+0x66], 0x3e89
    mov word [si+0x68], 0x03fe
    mov word [si+0x6a], 0xcccc
    mov word [si+0x6e], 0x0400
    nop
    nop
    nop
    mov word [si+0x70], 0x0300
    mov word [si+0x72], 0x8100
    push es
    push cs
    pop es
    std
    mov di, ax
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0xe4ff
    int 0x87
    cld
    pop es
    push cs
    pop ss
    mov bx, si
    mov bp, [bx]
    mov dx, 0x1fff
    mov sp, 0xc429
    mov [bp-0x06], sp
    nop
    mov [bp-0x04], dx
    mov [bp-0x02], sp
    mov [bp+0x04], sp
    mov [bp+0x06], dx
    mov [bp+0x08], sp
    mov [bp+0x00], sp
    mov [bp+0x02], dx
    mov sp, bp
    add sp, 0x0400
    push cs
    pop es
    mov di, bp
    inc di
    mov si, 0x0008
    mov cx, 0x000c
    mov ax, 0x13ec
    call far [bx]
    nop
    nop
    push es
    pop ds
    mov bx, ax
    mov cx, ax
    mov bl, bh
    mov bh, dh
    mov cl, 0xa3
    mov si, bx
    mov [bx], cx
    mov [bx+0x02], cs
    jmp label2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
label1:
    nop
    mov bx, sp
    mov dx, ax
    add dx, 0x013c
    mov byte [bx], 0xea
    mov [bx+0x01], dx
    mov [bx+0x03], cs
    push es
    pop ds
    mov word [si+0x66], 0x3e89
    mov word [si+0x68], 0x03fe
    mov word [si+0x6a], 0xcccc
    mov word [si+0x6e], 0x0400
    nop
    nop
    nop
    mov word [si+0x70], 0x0300
    mov word [si+0x72], 0x8100
label2:
    push es
    push cs
    pop es
    std
    mov di, ax
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0xe4ff
    int 0x87
    cld
    pop es
    push cs
    pop ss
    mov bx, si
    mov bp, [bx]
    mov dx, 0x1fff
    mov sp, 0xc429
    mov [bp-0x06], sp
    nop
    mov [bp-0x04], dx
    mov [bp-0x02], sp
    mov [bp+0x04], sp
    mov [bp+0x06], dx
    mov [bp+0x08], sp
    mov [bp+0x00], sp
    mov [bp+0x02], dx
    mov sp, bp
    add sp, 0x0400
    push cs
    pop es
    mov di, bp
    inc di
    mov si, 0x0008
    mov cx, 0x000c
    mov ax, 0x13ec
    call far [bx]
    nop
    nop
    push es
    pop ds
    mov bx, ax
    mov cx, ax
    mov bl, bh
    mov bh, dh
    mov cl, 0xa3
    mov si, bx
    mov [bx], cx
    mov [bx+0x02], cs
    jmp label2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    mov bx, sp
    mov dx, ax
    add dx, 0x013c
    mov byte [bx], 0xea
    mov [bx+0x01], dx
    mov [bx+0x03], cs
    push es
    pop ds
    mov word [si+0x66], 0x3e89
    mov word [si+0x68], 0x03fe
    mov word [si+0x6a], 0xcccc
    mov word [si+0x6e], 0x0400
    nop
    nop
    nop
    mov word [si+0x70], 0x0300
    mov word [si+0x72], 0x8100
    push es
    push cs
    pop es
    std
    mov di, ax
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0xe4ff
    int 0x87
    cld
    pop es
    push cs
    pop ss
    mov bx, si
    mov bp, [bx]
    mov dx, 0x1fff
    mov sp, 0xc429
    mov [bp-0x06], sp
    nop
    mov [bp-0x04], dx
    mov [bp-0x02], sp
    mov [bp+0x04], sp
    mov [bp+0x06], dx
    mov [bp+0x08], sp
    mov [bp+0x00], sp
    mov [bp+0x02], dx
    mov sp, bp
    add sp, 0x0400
    push cs
    pop es
    mov di, bp
    inc di
    mov si, 0x0008
    mov cx, 0x000c
    mov ax, 0x13ec
    call far [bx]
    nop
    nop
    push es
    pop ds
    mov bx, ax
    mov cx, ax
    mov bl, bh
    mov bh, dh
    mov cl, 0xa3
    mov si, bx
    mov [bx], cx