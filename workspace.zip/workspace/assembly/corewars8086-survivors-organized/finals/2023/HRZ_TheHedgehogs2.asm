    nop
    jmp label1
    xor di, di
    lea si, [bx+0x00fd]
    mov cl, 0x19
    rep movsw
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xd4ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx+0x7405]
    db 0x9B, 0x9B ;$1 nrg
    nop
    nop
    lea ax, [bx-0x0901]
    mov bx, 0x00b4
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    xor dx, dx
    mov dl, 0xfc
    mov word [bx-0x02], 0x0ffb
    mov ax, 0x51a5
    mov cl, 0x08
    mov si, 0x001a
    mov di, [bx]
    dec di
    nop
    movsw
    movsw
    movsw
    sub di, 0x0004
    push ax
    call far [bx]
    push ax
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    movsw
    push cx
    dec di
    dec di
    call far [bx]
    push cx
    sub sp, dx
    call far [bx]
    push cx
    rep movsw
    nop
    mov dx, 0x4b02
    sub bx, 0x0004
    mov cl, 0x0a
    dec sp
    mov si, 0x0007
    rep movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    int3
    int3
    int3
    nop
label1:
    stosw
    mov bx, ax
    xor di, di
    lea si, [bx+0x00fd]
    mov cl, 0x19
    rep movsw
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xd4ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx+0x7405]
    db 0x9B, 0x9B ;$1 nrg
    nop
    nop
    lea ax, [bx-0x0901]
    mov bx, 0x00b4
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    xor dx, dx
    mov dl, 0xfc
    mov word [bx-0x02], 0x0ffb
    mov ax, 0x51a5
    mov cl, 0x08
    mov si, 0x001a
    mov di, [bx]
    dec di
    nop
    movsw
    movsw
    movsw
    sub di, 0x0004
    push ax
    call far [bx]
    push ax
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    movsw
    push cx
    dec di
    dec di
    call far [bx]
    push cx
    sub sp, dx
    call far [bx]
    push cx
    rep movsw
    nop
    mov dx, 0x4b02
    sub bx, 0x0004
    mov cl, 0x0a
    dec sp
    mov si, 0x0007
    rep movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    stosw
    mov bx, ax
    xor di, di
    lea si, [bx+0x00fd]
    mov cl, 0x19
    rep movsw
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    xchg bx, sp
    mov ax, 0xd4ff
    mov dx, 0xcccc
    int 0x87
    xchg bx, sp
    mov bl, 0xa2
    lea sp, [bx+0x7405]
    db 0x9B, 0x9B ;$1 nrg
    nop
    nop
    lea ax, [bx-0x0901]
    mov bx, 0x00b4
    mov [bx], ax
    mov word [bx+0x02], 0x1000
    db 0x83, 0xC0, 0x07 ;$1 add ax, 0x0007
    mov [bx-0x04], ax
    xor dx, dx
    mov dl, 0xfc
    mov word [bx-0x02], 0x0ffb
    mov ax, 0x51a5
    mov cl, 0x08
    mov si, 0x001a
    mov di, [bx]
    dec di
    nop
    movsw
    movsw
    movsw
    sub di, 0x0004
    push ax
    call far [bx]
    push ax
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    movsw
    push cx
    dec di
    dec di
    call far [bx]
    push cx
    sub sp, dx
    call far [bx]
    push cx
    rep movsw
    nop
    mov dx, 0x4b02
    sub bx, 0x0004
    mov cl, 0x0a
    dec sp
    mov si, 0x0007
    rep movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop