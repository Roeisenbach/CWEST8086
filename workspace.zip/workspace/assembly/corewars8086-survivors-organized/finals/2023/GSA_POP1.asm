    nop
    jmp label1
    stosw
    push es
    pop ds
    xchg bx, ax
    nop
    nop
    lodsw
    xchg bx, ax
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    int 0x86
    mov ax, 0xabab
    mov dx, 0xabab
    mov cx, 0xcccc
    std
    nop
    nop
    int 0x87
    xchg si, ax
    push cs
    pop ss
    push cs
    pop ds
    cmp ax, bx
    db 0x0F
    mov ax, ss
    add cl, ch
    in ax, 0x00
    mov sp, ax
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0121
    add bx, 0x0123
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    mov sp, di
    add sp, 0x0200
    nop
    mov bx, ax
    add ax, 0x0137
    add bx, 0x013e
    mov [bx], ax
    mov [bx+0x02], cs
    add sp, 0x000b
    call far [bx]
    stosw
    push es
    pop ds
    xchg bx, ax
    nop
    nop
    lodsw
    xchg bx, ax
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    nop
    nop
    add di, 0x0400
    int 0x86
    mov ax, 0xabab
    mov dx, 0xabab
    mov cx, 0xcccc
    std
    int 0x87
    xchg si, ax
    push cs
    pop ss
    push cs
    pop ds
    cmp ax, bx
    jl label2
    jmp label3
    mov sp, ax
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0121
    add bx, 0x0123
    nop
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    mov sp, di
    add sp, 0x0200
    mov bx, ax
    add ax, 0x0137
    add bx, 0x013e
    mov [bx], ax
    mov [bx+0x02], cs
    add sp, 0x000b
    call far [bx]
label1:
    stosw
    push es
    pop ds
    xchg bx, ax
    nop
    nop
    lodsw
    xchg bx, ax
    push cs
    pop es
    mov di, ax
    nop
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    int 0x86
    mov ax, 0xabab
    mov dx, 0xabab
    mov cx, 0xcccc
    std
    int 0x87
    xchg si, ax
    push cs
    pop ss
    push cs
    pop ds
    cmp ax, bx
    jl label2
    jmp label3
label2:
    mov sp, ax
    nop
    nop
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0121
    add bx, 0x0123
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
label3:
    mov sp, di
    add sp, 0x0200
    mov bx, ax
    add ax, 0x0137
    add bx, 0x013e
    mov [bx], ax
    mov [bx+0x02], cs
    add sp, 0x000b
    nop
    nop
    call far [bx]
    stosw
    push es
    pop ds
    xchg bx, ax
    nop
    nop
    lodsw
    xchg bx, ax
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    int 0x86
    mov ax, 0xabab
    mov dx, 0xabab
    mov cx, 0xcccc
    std
    int 0x87
    nop
    xchg si, ax
    push cs
    pop ss
    push cs
    pop ds
    cmp ax, bx
    jl label2
    jmp label3
    mov sp, ax
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0121
    add bx, 0x0123
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    mov sp, di
    add sp, 0x0200
    mov bx, ax
    add ax, 0x0137
    nop
    add bx, 0x013e
    mov [bx], ax
    mov [bx+0x02], cs
    add sp, 0x000b
    call far [bx]
    stosw
    push es
    pop ds
    xchg bx, ax
    nop
    nop
    lodsw
    xchg bx, ax
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    int 0x86
    nop
    mov ax, 0xabab
    mov dx, 0xabab
    mov cx, 0xcccc
    std
    int 0x87
    xchg si, ax
    push cs
    pop ss
    push cs
    pop ds
    cmp ax, bx
    db 0x0F
    db 0x8C, 0x31 ;$1 mov [bx+di], ss
    db 0xFF, 0xE9
    inc si
    dec word [bx+di-0x7e3c]
    in al, dx
    add [si], al
    mov bx, ax
    add ax, 0x0121
    add bx, 0x0123
    mov [bx], ax
    nop
    nop
    mov [bx+0x02], cs
    call far [bx]
    mov sp, di
    add sp, 0x0200
    mov bx, ax
    add ax, 0x0137