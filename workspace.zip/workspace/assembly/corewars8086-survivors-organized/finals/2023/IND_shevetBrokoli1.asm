    nop
    push ds
    pop es
    xchg di, ax
    mov ax, 0xab90
label1:
    stosw
    add di, 0x0002
    jmp label1