    nop
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add ax, 0x0018
    add di, ax
    mov ax, 0xab50
    int 0x86
    int 0x86
    mov bx, di
    stosw
    jmp bx