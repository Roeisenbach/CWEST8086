    nop
    mov si, ax
    add si, 0x0042
    xor cx, cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    inc cx
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0100
    mov word [bx], 0xffec
    mov di, 0xffec
    add di, 0x0002
    inc di
    inc di
    inc di
    inc di
    inc di
    inc di
    inc di
    inc di
    inc di
    inc di
    nop
    mov si, 0x000c
    push di
    mov ax, 0xcccc
    mov dx, ax
    mov di, 0x8500
    int 0x86
    mov di, 0x9500
    int 0x86
    pop di
    xchg cx, si
    add di, 0x0055
    add word [bx], 0x0061
    rep movsb
    jmp word [bx]