    nop
    mov word [0x8aa2], 0x5ecc
    mov word [0x8aa4], 0x1000
    brk
    mov word [0x1000], 0xfeeb
    mov bx, ax
    mov dx, 0xc681
    mov cx, 0xc31e
    std
    mov [bx], ax
    add word [bx], 0x0144
    jmp label1
    nop
    nop
    nop
    nop
label1:
    mov word [0x1000], 0x26ff
    mov ax, 0x5ecc
    push ds
    pop es
    mov [0x1002], bx
    xchg bx, di
    int 0x87
    push ss
    pop dx
    sub dx, 0x00c0
    push dx
    pop ds
    lodsw
    push cs
    pop ds
    mov bx, di
    mov [bx+0x0147], ax
    brk
    nop
    nop
    nop
    mov word [bx+0x0144], 0x170e
    mov si, ax
    add si, 0x004d
    mov di, si
    sub di, 0x6200
    int 0x86
    int 0x86
    cld
    mov bx, ax
    sub bx, 0x0004
    mov dx, 0x003d
    mov word [bx+0x06], 0xfceb
    mov word [bx+0x08], 0xc389
    nop
    mov word [bx+0x0a], 0xccb8
    mov word [bx+0x0c], 0x89cc
    mov word [bx+0x0e], 0xb9f7
    mov word [bx+0x10], 0x0c31
    mov word [bx+0x12], 0xabf3
    mov word [bx+0x14], 0x834a
    mov word [bx+0x16], 0x00fa
    mov word [bx+0x18], 0x1c74
    nop
    mov word [bx+0x1a], 0x07c7
    mov word [bx+0x1c], 0xdc89
    mov word [bx+0x1e], 0x07c7
    mov word [bx+0x20], 0x1fff
    mov word [bx+0x22], 0x87c7
    mov word [bx+0x24], 0x7ff3
    mov word [bx+0x26], 0xc489
    mov word [bx+0x28], 0x87c7
    nop
    mov word [bx+0x2a], 0x7ff3
    mov word [bx+0x2c], 0x1fff
    mov word [bx+0x2e], 0xf789
    mov word [bx+0x30], 0x64b9
    mov word [bx+0x32], 0xe90c
    mov word [bx+0x34], 0xffdc
    mov word [bx+0x36], 0x07c7
    mov word [bx+0x38], 0xcccc
    nop
    mov word [bx+0x3a], 0x87c7
    mov word [bx+0x3c], 0x7ff3
    mov word [bx+0x3e], 0xcccc
    mov word [bx+0x40], 0x47c7
    mov word [bx+0x42], 0x000c
    mov word [bx+0x44], 0xc73e
    mov word [bx+0x46], 0x1047
    mov word [bx+0x48], 0xf6e9
    nop
    mov word [bx+0x4a], 0x47c6
    mov word [bx+0x4c], 0xff12
    mov word [bx+0x4e], 0xbce9
    mov byte [bx+0x50], 0xff
    xchg bx, di
    mov [bx+0x0142], di
    add word [bx+0x0142], 0x0008
    jmp word [bx+0x0142]
    int3
    int3
    jmp $
    mov bx, 0x90cc
    mov di, bx
    sub di, 0x61af
    push ds
    pop es
    int 0x86
    int 0x86
    sub bx, 0x0004
    mov word [bx+0x04], 0x1fff
    mov sp, bx
    mov [bx], bx
    add word [bx], 0x0004
    mov word [bx+0x02], 0x1000
    call far [bx]