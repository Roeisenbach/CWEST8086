    nop
    mov dx, 0xee81
    mov cx, 0xc31e
    les ax, [0x8aa2]
    std
    int 0x87
    call prcd1
prcd1:
    pop ax
    mov bx, ax
    db 0x83, 0xC0, 0x79 ;$1 add ax, 0x0079
    mov [bx], ax
    mov [0x1002], bx
    sub ax, 0x008a
    mov bx, ax
    mov [bx+0x009a], ax
    mov dx, ss
    sub dx, 0x0040
    jmp label1
    nop
label1:
    mov es, dx
    add ax, 0x80d2
    stosw
    push ds
    pop es
    mov di, ax
    add di, 0x183b
    int 0x86
    int 0x86
    sub ax, 0x7c00
    mov dx, 0x003d
    cld
label2:
    mov di, ax
    mov cx, 0x0c65
    rep stosw
    dec dx
    cmp dx, 0x0000
    jz label3
    mov word [bx+0x00c5], 0xc489
    nop
    mov word [bx+0x00c5], 0x1fff
    mov word [bx-0x7f2e], 0xdc89
    mov word [bx-0x7f2e], 0x1fff
    jmp label2
label3:
    mov word [bx+0x00c5], 0xcccc
    mov word [bx-0x7f2e], 0xcccc
    mov word [bx+word 0x004a], 0x3e00
    mov word [bx+word 0x004e], 0xf7eb
    nop
    jmp label2
    push ds
    pop es
    mov ax, 0x5ecc
    mov dx, 0xee81
    mov cx, 0xc31e
    std
    int 0x87
    cld
    mov ax, 0xcccc
    mov di, ax
    sub di, 0x66ef
    int 0x86
    int 0x86
    mov bx, ax
    sub ax, 0x0400
    push ds
    pop ss
    mov sp, ax
    jmp label4
    nop
    nop
    nop
    nop
label4:
    add bx, 0x00c5
    mov [bx-0x04], bx
    sub bx, 0x0004
    jmp label5
    int3
    int3
    add [bx+si], dl
label5:
    call far [bx]
    jmp label5
label6:
    mov di, bx
    mov cx, 0x7c00
    rep stosw
    jmp label6