    nop
    call prcd1
    nop
    nop
    nop
    nop
    push ds
    pop es
    xchg bp, ax
    mov dx, 0x0690
    nop
    mov ax, 0xa5f3
    int 0x87
    mov di, bp
    sub di, 0x0500
    push cs
    pop es
    nop
    int 0x86
    sub di, 0x0400
    int 0x86
    sub di, 0x0200
    nop
    push cs
    pop ss
    mov sp, di
    mov dx, 0x000e
    mov ax, 0xd4ff
    mov bx, 0x5651
    nop
    mov cx, 0x5350
    nop
    mov si, 0xd429
    sub sp, dx
    push ax
    push bx
    push cx
    push si
    nop
    call sp
    nop
prcd1:
    nop
    nop
    nop
    push ds
    pop es
    xchg bp, ax
    mov dx, 0x0690
    nop
    mov ax, 0xa5f3
    int 0x87
    mov di, bp
    sub di, 0x0500
    push cs
    pop es
    nop
    int 0x86
    sub di, 0x0400
    int 0x86
    sub di, 0x0200
    nop
    push cs
    pop ss
    mov sp, di
    mov dx, 0x000e
    mov ax, 0xd4ff
    mov bx, 0x5651
    nop
    mov cx, 0x5350
    nop
    mov si, 0xd429
    sub sp, dx
    push ax
    push bx
    push cx
    push si
    nop
    call sp
    nop
    nop
    nop
    nop
    push ds
    pop es
    xchg bp, ax
    mov dx, 0x0690
    nop
    mov ax, 0xa5f3
    int 0x87
    mov di, bp
    sub di, 0x0500
    push cs
    pop es
    nop
    int 0x86
    sub di, 0x0400
    int 0x86
    sub di, 0x0200
    nop
    push cs
    pop ss
    mov sp, di
    mov dx, 0x000e
    mov ax, 0xd4ff
    mov bx, 0x5651
    nop
    mov cx, 0x5350
    nop
    mov si, 0xd429
    sub sp, dx
    push ax
    push bx
    push cx
    push si
    nop
    call sp
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop