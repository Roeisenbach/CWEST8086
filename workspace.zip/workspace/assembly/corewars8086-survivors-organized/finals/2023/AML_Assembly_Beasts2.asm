    nop
    mov cl, 0x12
    mov si, ax
    add si, 0x00ce
    jmp label1
    rep movsw
    xor si, si
    mov bx, ax
    add bh, 0x11
    mov bl, 0xa3
    mov word [bx], 0x1fff
    mov word [bx+0x02], 0x1fff
    mov word [bx+0x04], 0x1fff
    push ds
    push ds
    push es
    pop ds
    pop es
    nop
    pop ss
    mov sp, bx
    add sp, 0x0200
    mov bp, 0xa700
    mov cl, 0x0c
    std
    mov di, bx
    sub di, 0x000a
    int 0x86
    int 0x86
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    cld
    mov dx, bx
    mov bx, 0x0050
    mov di, dx
    mov [bx], dx
    nop
    mov [bx+0x02], cs
    mov ax, 0xa500
    inc di
    call far [bx]
    rep movsw
    sub dx, bp
    sub sp, ax
    mov di, dx
    sub di, 0x0004
    mov cl, 0x05
    rep movsw
    mov cl, 0x0c
    mov [bx], dx
    sub di, 0x0005
    xor si, si
    call far [bx]
    call far [bx]
    call far [bx+0x01]
    nop
label1:
    rep movsw
    xor si, si
    mov bx, ax
    add bh, 0x11
    mov bl, 0xa3
    mov word [bx], 0x1fff
    mov word [bx+0x02], 0x1fff
    mov word [bx+0x04], 0x1fff
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    mov sp, bx
    add sp, 0x0200
    mov bp, 0xa700
    nop
    mov cl, 0x0c
    std
    mov di, bx
    sub di, 0x000a
    int 0x86
    int 0x86
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    cld
    mov dx, bx
    mov bx, 0x0050
    mov [bx], dx
    mov [bx+0x02], cs
    mov ax, 0xa500
    mov di, dx
    inc di
    call far [bx]
    nop
    nop
    rep movsw
    sub dx, bp
    sub sp, ax
    mov di, dx
    sub di, 0x0004
    mov cl, 0x05
    rep movsw
    mov cl, 0x0c
    mov [bx], dx
    sub di, 0x0005
    xor si, si
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    call far [bx]
    rep movsw
    xor si, si
    nop
    mov bx, ax
    add bh, 0x11
    mov bl, 0xa3
    mov word [bx], 0x1fff
    mov word [bx+0x02], 0x1fff
    mov word [bx+0x04], 0x1fff
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    mov sp, bx
    add sp, 0x0200
    mov bp, 0xa700
    mov cl, 0x0c
    mov di, bx
    nop
    std
    sub di, 0x000a
    int 0x86
    int 0x86
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    cld
    mov dx, bx
    mov bx, 0x0050
    mov [bx], dx
    mov [bx+0x02], cs
    mov ax, 0xa500
    mov di, dx
    inc di
    call far [bx]
    nop
    rep movsw
    sub dx, bp
    nop
    sub sp, ax
    mov di, dx
    sub di, 0x0004
    mov cl, 0x05
    rep movsw
    mov cl, 0x0c
    mov [bx], dx
    sub di, 0x0005
    xor si, si
    call far [bx]
    call far [bx]
    call far [bx]
    nop