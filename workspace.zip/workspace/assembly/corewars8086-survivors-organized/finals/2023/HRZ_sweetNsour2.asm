    nop
    db 0xE9, 0x66, 0x00 ;$1 jmp 106
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    mov byte [0x0800], 0xea
    add ax, 0x005b
    mov [0x0801], ax
    mov [0x0803], cs
    std
    mov ax, 0x5ecc
    mov dx, 0xee81
    mov cx, 0xe4ff
    int 0x87
    nop
    mov bx, ax
    xchg di, ax
    add di, 0x5000
    mov dx, 0xcccc
    mov ax, dx
    int 0x86
    sub di, 0xa000
    int 0x86
    push cs
    pop ss
    mov ax, 0xe4ff
    mov cx, 0x5350
    mov dx, 0xf429
    xchg sp, bx
    mov bx, 0x5251
    mov si, 0x000c
    nop
    nop
    sub sp, si
    push ax
    push bx
    push cx
    push dx
    jmp sp
label1:
    mov word [di], 0xcccc
    inc di
    jmp label1
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    mov byte [0x0800], 0xea
    add ax, 0x00b8
    mov [0x0801], ax
    mov [0x0803], cs
    nop
    std
    mov ax, 0x5ecc
    mov dx, 0xee81
    mov cx, 0xe4ff
    int 0x87
    mov bx, ax
    xchg di, ax
    add di, 0x5000
    mov dx, 0xcccc
    mov ax, dx
    int 0x86
    sub di, 0xa000
    int 0x86
    push cs
    pop ss
    mov ax, 0xe4ff
    mov cx, 0x5350
    nop
    mov dx, 0xf429
    xchg sp, bx
    mov bx, 0x5251
    mov si, 0x000c
    sub sp, si
    push ax
    push bx
    push cx
    push dx
    jmp sp
label2:
    mov word [di], 0xcccc
    inc di
    jmp label2
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    nop
    nop
    nop
    nop
    nop
    mov byte [0x0800], 0xea
    add ax, 0x011a
    mov [0x0801], ax
    mov [0x0803], cs
    std
    mov ax, 0x5ecc
    mov dx, 0xee81
    mov cx, 0xe4ff
    int 0x87
    mov bx, ax
    xchg di, ax
    add di, 0x5000
    mov dx, 0xcccc
    mov ax, dx
    nop
    nop
    int 0x86
    sub di, 0xa000
    int 0x86
    push cs
    pop ss
    mov ax, 0xe4ff
    mov cx, 0x5350
    mov dx, 0xf429
    xchg sp, bx
    mov bx, 0x5251
    mov si, 0x000c
    sub sp, si
    push ax
    push bx
    push cx
    push dx
    jmp sp
label3:
    mov word [di], 0xcccc
    inc di
    nop
    jmp label3