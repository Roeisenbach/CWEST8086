    nop
    jmp label1
    mov word [0x1cfd], 0x1cff
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edd
    mov word [di], 0x1cfd
    mov word [di+0x02], 0x1000
    call far [di]
    mov word [0x1cfd], 0x1cff
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edd
    mov word [di], 0x1cfd
    nop
    nop
    mov word [di+0x02], 0x1000
    call far [di]
label1:
    mov word [0x1cfd], 0x1cff
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edd
    mov word [di], 0x1cfd
    mov word [di+0x02], 0x1000
    call far [di]
    mov word [0x1cfd], 0x1cff
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edd
    nop
    mov word [di], 0x1cfd
    mov word [di+0x02], 0x1000
    call far [di]