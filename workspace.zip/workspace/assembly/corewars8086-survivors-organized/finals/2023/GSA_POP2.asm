    nop
    jmp label1
    push es
    pop ds
    xchg bx, ax
    lodsw
    xchg bx, ax
    stosw
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    int 0x86
    mov ax, 0xab50
    mov dx, 0xab50
    mov cx, 0xcccc
    nop
    std
    int 0x87
    xchg si, ax
    cmp ax, bx
    db 0x0F
    db 0x8C, 0xB5, 0x00, 0xE9 ;$1 mov [di-0x1700], ss
    into
    add [0x0e17], cl
    pop ds
    mov sp, ax
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0103
    add bx, 0x0105
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    nop
    nop
    add di, 0x0200
    mov ax, 0xcccc
    stosw
    add di, 0x0007
    jmp label4
    push es
    pop ds
    xchg bx, ax
    lodsw
    xchg bx, ax
    stosw
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    nop
    int 0x86
    mov ax, 0xab50
    mov dx, 0xab50
    mov cx, 0xcccc
    std
    int 0x87
    xchg si, ax
    cmp ax, bx
    jl label2
    jmp label3
    push cs
    pop ss
    push cs
    pop ds
    mov sp, ax
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0103
    add bx, 0x0105
    nop
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    add di, 0x0200
    mov ax, 0xcccc
    stosw
    add di, 0x0007
    jmp label4
label1:
    push es
    pop ds
    xchg bx, ax
    lodsw
    xchg bx, ax
    stosw
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    nop
    int 0x86
    add di, 0x0400
    int 0x86
    mov ax, 0xab50
    mov dx, 0xab50
    mov cx, 0xcccc
    std
    int 0x87
    xchg si, ax
    cmp ax, bx
    jl label2
    jmp label3
label2:
    push cs
    pop ss
    push cs
    pop ds
    mov sp, ax
    sub sp, 0x0400
    mov bx, ax
    nop
    nop
    add ax, 0x0103
    add bx, 0x0105
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
label3:
    add di, 0x0200
    mov ax, 0xcccc
label4:
    stosw
    add di, 0x0007
    jmp label4
    push es
    pop ds
    xchg bx, ax
    lodsw
    xchg bx, ax
    stosw
    push cs
    pop es
    mov di, ax
    mov si, 0xcccc
    nop
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    int 0x86
    mov ax, 0xab50
    mov dx, 0xab50
    mov cx, 0xcccc
    std
    int 0x87
    xchg si, ax
    cmp ax, bx
    jl label2
    jmp label3
    push cs
    pop ss
    push cs
    pop ds
    mov sp, ax
    nop
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0103
    add bx, 0x0105
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    add di, 0x0200
    mov ax, 0xcccc
    stosw
    add di, 0x0007
    jmp label4
    push es
    pop ds
    xchg bx, ax
    lodsw
    xchg bx, ax
    stosw
    push cs
    nop
    pop es
    mov di, ax
    mov si, 0xcccc
    xchg si, ax
    mov dx, ax
    add di, 0x0600
    int 0x86
    add di, 0x0400
    int 0x86
    mov ax, 0xab50
    mov dx, 0xab50
    mov cx, 0xcccc
    std
    int 0x87
    xchg si, ax
    cmp ax, bx
    db 0x0F
    mov [bx-0x01], cs
    nop
    jmp label3
    push cs
    pop ss
    push cs
    pop ds
    mov sp, ax
    sub sp, 0x0400
    mov bx, ax
    add ax, 0x0103
    add bx, 0x0105
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    add di, 0x0200
    mov ax, 0xcccc
    stosw
    add di, 0x0007
    nop
    jmp label4