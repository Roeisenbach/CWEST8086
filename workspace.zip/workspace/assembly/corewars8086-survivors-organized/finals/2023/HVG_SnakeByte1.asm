    nop
    jmp label1
    mov si, 0x00a5
    mov bl, 0x21
    push ss
    db 0x03, 0xF3 ;$1 add si, bx
    in ax, 0x89
    xor [bx+si], ax
label1:
    mov bx, ax
    mov cx, 0x000f
loop1:
    add di, 0x002d
    mov dl, [bx+si+word 0x0003]
    mov [bx+di], dl
    inc si
    loop loop1
    add ax, 0x0023
    push ax
    add ax, 0x008e
    mov bx, 0x3200
    mov cx, 0x0004
    nop
    in ax, 0x15
loop2:
    mov [si], bx
    mov [0x9090], ax
    sub si, 0x0020
    loop loop2
    mov bx, 0x15c7
    mov di, [bx]
    mov cx, 0x0004
loop3:
    mov [0x9090], ax
    mov di, [bx]
    add di, 0x0025
    mov word [di], 0x27ff
    sub bx, 0x0020
    loop loop3
    jmp label6
    movsw
    mov cl, 0x07
    movsw
    nop
    rep movsw
    mov [bp-0x0196], ax
    mov [bp+0x03ca], ax
    xchg dx, ax
    mov ax, 0xa552
    xor si, si
    movsw
    mov cl, 0x3a
    xchg bx, di
    std
    rep stosw
    mov di, bx
    cld
    movsw
    xchg sp, bx
    add bx, 0x00de
    mov ax, 0x6a6c
    mov bp, dx
    movsw
    mov ax, 0x0000
    mov dx, 0x0090
    int 0x87
    add bp, 0xef00
    lea sp, [bp-0x0194]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6a6c
    push dx
    mov [bp+0x03ca], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov cx, 0xffff
    nop
loop4:
    mov [0x9b9b], ax
    db 0x9B, 0x9B ;$1 nrg
    mul bx
    xchg bx, ax
    cmp bl, 0xa3
    ja label2
    mov bl, 0xa3
label2:
    mov word [bx], 0xcccc
    loop loop4+1
    mov di, dx
    cmp di, 0x2000
    jnb label3
    add di, 0x2100
    jmp label4
label3:
    cmp di, 0xe000
    jbe label4
    sub di, 0x9000
label4:
    int 0x86
    int 0x86
    mov cx, 0xffff
loop5:
    nrg
    mul bx
    xchg bx, ax
    cmp bl, 0xa3
    ja label5
    mov bl, 0xa3
label5:
    mov word [bx], 0xcccc
    loop loop5
    jmp word [0xffff]
label6:
    pop ax
    xor di, di
    mov si, 0xa5ab
    mov dx, 0xd429
    add ax, 0x0124
    xchg si, ax
    nop
    pop es
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x74
    rep movsw
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    add bp, 0xef00
    lea sp, [bp-0x0194]
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x6a6c
    push dx
    mov [bp-0x6f36], dx
    mov word [bp+0x13], 0xe1ff
    movsb
    jmp bp
    int3
    int3
    int3
    movsw
    movsw
    movsw
    mov di, bp
    movsb
    jmp bp
    movsw
    movsw
    mov cl, 0x06
    movsw
    movsw
    rep movsw
    mov bx, [bp+0x03ca]
    cmp [bp-0x0196], bx
    jnz label7
    xor si, si
label7:
    movsw
    movsw
    mov cl, 0x0d
    movsw
    nop
    movsw
    cmp bx, dx
    lea bx, [bp+0x03c7]
    jnz label8
    sub bp, 0x2000
    sub bx, 0x0560
label8:
    add bp, 0x1000
    mov di, bp
    movsw
    jmp bp
    db 0x64
    movsw
    mov cl, 0x0c
    movsw
    rep movsw
    mov cx, 0x0504
    xchg bx, sp
    mov dx, bp
    xchg si, ax
label9:
    pop si
    pop bp
    rcl word [bx+si+0x5a89], cl
    std
    sub sp, 0x0003
    dec ch
    jnz label9
    xchg si, ax
    movsw
    movsw
    mov cl, 0x06
    movsw
    rep movsw
    xchg sp, bx
    add bx, 0x00de
    mov ax, 0x6a6c
    mov bp, dx
    movsw
    movsw
    mov cl, 0x05
    movsw
    movsw
    rep movsw
    mov cl, 0x3a
    xchg bx, di
    std
    rep stosw
    nop
    esc 0xdf
    cld
    movsw
    movsw
    mov cl, 0x07
    movsw
    movsw
    rep movsw
    mov [bp-0x0196], ax
    mov [bp+0x03ca], ax
    xchg dx, ax
    mov ax, 0xa552
    xor si, si
    movsw
    movsw
    mov cl, 0x07
    movsw
    movsw
    rep movsw
    mov [bp-0x0196], ax
    mov [bp+0x03ca], ax
    xchg dx, ax
    mov ax, 0xa552
    nop
    mul byte [di+0x3ab1]
    xchg bx, di
    std
    rep stosw
    mov di, bx
    cld
    movsw