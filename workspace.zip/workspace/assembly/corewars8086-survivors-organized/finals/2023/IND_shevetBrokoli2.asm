    nop
    mov ax, 0x1500
    push ax
    pop es
label1:
    stosw
    jmp label1