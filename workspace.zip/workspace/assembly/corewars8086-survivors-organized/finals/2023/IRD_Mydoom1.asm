    nop
    push es
    push ds
    pop es
    std
    mov bx, ax
    add bx, 0x00ba
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0xc30e
    mov di, 0xa500
    mov byte [0x1000], 0xea
    mov [0x1001], bx
    mov [0x1003], cs
    int 0x87
    nop
    cld
    xor di, di
    pop es
    xchg si, bx
    nop
    add si, 0xff82
    mov ax, 0x000b
    stosw
    mov cx, 0x000b
    rep movsw
    jmp label1
    mov ax, 0x1fff
    mov bx, 0xcccc
    mov cx, 0xcccc
    mov dx, 0xcccc
    int 0x87
    mov dx, 0x000f
    mov ax, 0xa000
    ret
label1:
    mov dl, 0xcc
    cmp dl, [0x0206]
    jz label2
    nop
    nop
    mov di, [bx]
    int 0x86
label2:
    mov dl, 0xcc
    cmp dl, [0xcccc]
    jz label3
    mov di, [bx]
    int 0x86
    jmp label3
    nop
    nop
label3:
    mov word [0x0069], 0xd429
    mov word [0x006b], 0x5350
    mov word [0x006d], 0x5651
    mov word [0x006f], 0xd4ff
    nop
    mov word [0xff69], 0xd429
    mov word [0xff6b], 0x5350
    mov word [0xff6d], 0x5651
    push cs
    pop ss
    mov ax, 0xd4ff
    mov si, 0xd429
    mov cx, 0x5350
    mov sp, bx
    sub sp, 0x6350
    mov bx, 0x5651
    mov dx, 0x000f
    sub sp, dx
    push ax
    nop
    push bx
    push cx
    push si
    call sp
    push ax
    call prcd1
prcd1:
    pop bx
    sub bx, 0x0004
    mov ax, bx
    stosw
    push ds
    pop es
    std
    mov bp, 0x0100
    inc word [bx+0x10]
    cmp bp, 0x0300
    jge label4
    call prcd2
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0xc30e
    nop
    nop
    xchg bx, di
    mov byte [0x1000], 0xea
    mov [0x1001], bx
    mov [0x1003], cs
    int 0x87
    jmp label5
    nop
    nop
label4:
    call prcd2
    mov ax, 0x5ecc
    mov dx, 0xee81
    mov cx, 0xc30e
    xchg bx, di
    mov byte [0x1000], 0xea
    mov [0x1001], bx
    nop
    mov [0x1003], cs
    int 0x87
    xchg bx, di
    mov word [bx-0x04], 0xee81
    mov word [bx-0x06], 0x5ecc
    jmp label6
label5:
    xchg bx, di
    mov word [bx], 0xc681
    mov word [bx-0x02], 0x5ecc
label6:
    push cs
    pop ss
    mov di, 0xa000
    mov bx, di
    add bx, 0x0100
    add bx, bp
    nop
    mov ax, di
    add ax, 0x0a0e
    sub ax, bp
    xchg sp, ax
    mov ax, 0x0100
    xchg bp, ax
    mov dx, 0x0000
    div bp
    sub sp, ax
    xchg bp, ax
    mov ax, 0x1100
    mul bp
    xchg bp, ax
    xchg sp, ax
    mov sp, di
    sub sp, bp
    sub sp, 0x3004
    xchg bx, ax
    nop
    nop
    nop
    nop
    mov word [bx], 0xec29
    nop
    mov word [bx+0x02], 0x1fff
    xchg bx, ax
    mov [bx], ax
    mov [bx+0x02], cs
    mov bp, 0x0011
    sub sp, bp
    call far [bx]
prcd2:
    pop dx
    pop ax
    mov di, ax
    add di, 0x0100
    int 0x86
    xchg bx, di
    jmp dx