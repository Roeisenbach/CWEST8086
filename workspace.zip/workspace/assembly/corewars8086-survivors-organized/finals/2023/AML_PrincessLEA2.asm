    nop
    jmp label1
    xor si, di
    xor ax, bx
    mov cx, dx
    call cx
    mov cx, bx
    call cx
    call bx
    mov dx, 0x0004
    mov ax, 0xabab
    push es
    push ds
    pop es
    mov bx, ax
    mov ax, 0xcccc
    mov di, bx
    add di, 0x7500
    int 0x86
    push es
    nop
    pop ds
    pop es
    xor di, di
    mov ax, 0xa5a5
    mov cl, 0x04
    rep stosw
    mov ax, 0xef29
    stosw
    mov ax, 0xa5a5
    stosw
    mov ax, 0xef83
    stosw
    mov ax, 0xff04
    stosw
    mov ax, 0xcce7
    stosw
    mov ax, 0xc783
    stosw
    mov ax, 0xa504
    stosw
    nop
    nop
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov ax, 0x51a5
    stosw
    mov ax, 0xa55e
    stosw
    mov di, bx
    add di, 0x00e9
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bp, 0xd34e
    mov ax, 0xa552
    movsw
    xor si, di
    xor ax, bx
    nop
    nop
    mov cx, dx
    call cx
    mov cx, bx
    call cx
    call bx
    mov dx, 0x0004
    mov ax, 0xabab
label1:
    push es
    push ds
    pop es
    mov bx, ax
    mov ax, 0xcccc
    mov di, bx
    add di, 0x7500
    int 0x86
    push es
    pop ds
    pop es
    xor di, di
    mov ax, 0xa5a5
    nop
    mov cl, 0x04
    rep stosw
    mov ax, 0xef29
    stosw
    mov ax, 0xa5a5
    stosw
    mov ax, 0xef83
    stosw
    mov ax, 0xff04
    stosw
    mov ax, 0xcce7
    stosw
    mov ax, 0xc783
    stosw
    mov ax, 0xa504
    stosw
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    nop
    mov ax, 0x51a5
    stosw
    mov ax, 0xa55e
    stosw
    mov di, bx
    add di, 0x00e9
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bp, 0xd34e
    mov ax, 0xa552
    movsw
    xor si, di
    xor ax, bx
    mov cx, dx
    call cx
    mov cx, bx
    call cx
    nop
    nop
    call bx
    mov dx, 0x0004
    mov ax, 0xabab
    push es
    push ds
    pop es
    mov bx, ax
    mov ax, 0xcccc
    mov di, bx
    add di, 0x7500
    int 0x86
    push es
    pop ds
    pop es
    xor di, di
    mov ax, 0xa5a5
    mov cl, 0x04
    rep stosw
    mov ax, 0xef29
    stosw
    nop
    mov ax, 0xa5a5
    stosw
    mov ax, 0xef83
    stosw
    mov ax, 0xff04
    stosw
    mov ax, 0xcce7
    stosw
    mov ax, 0xc783
    stosw
    mov ax, 0xa504
    stosw
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov ax, 0x51a5
    stosw
    mov ax, 0xa55e
    stosw
    nop
    mov di, bx
    add di, 0x00e9
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bp, 0xd34e
    mov ax, 0xa552
    movsw
    xor si, di
    xor ax, bx
    mov cx, dx
    call cx
    mov cx, bx
    call cx
    call bx