    nop
    jmp label1
    push ds
    push es
    pop ds
    nop
    mov ax, [di]
    pop ds
    jmp ax
    push ds
    push es
    pop ds
    nop
    mov ax, [di]
    pop ds
    jmp ax
label1:
    push ds
    push es
    pop ds
    nop
    mov ax, [di]
    pop ds
    jmp ax
    push ds
    push es
    pop ds
    nop
    mov ax, [di]
    pop ds
    jmp ax
    push ds
    push es
    nop
    pop ds
    nop
    mov ax, [di]
    pop ds
    jmp ax
    movsw
    rep movsw
    sub [bx], dx
    mov di, [bx]
    movsw
    xor si, si
    dec di
    mov cl, 0x06
    call far [bx]
    sub sp, ax
    call far [bx]
    movsw
    rep movsw
    sub [bx], dx
    mov di, [bx]
    movsw
    xor si, si
    dec di
    mov cl, 0x06
    nop
    nop
    call far [bx]
    sub sp, ax
    call far [bx]
    push ds
    pop es
    push ax
    mov cx, bp
    add ah, cl
    add ah, cl
    add ax, 0x0800
    mov di, ax
    mov ax, bx
    mov dx, ax
    int 0x86
    int 0x86
    pop ax
    push cs
    push cs
    push ss
    pop ds
    pop es
    pop ss
    cmp bp, 0x0000
    jz label2
    nop
    sub ah, 0x10
    jmp label3
label2:
    sub ah, 0xa2
label3:
    mov al, 0xa1
    mov bx, 0x0042
    mov [bx], ax
    mov [bx+0x02], cs
    add ah, 0x10
    sub al, 0x02
    mov sp, ax
    mov dx, 0x0e00
    mov ax, 0x0018
    mov cx, 0x0006
    mov di, [bx]
    mov bp, 0xffff
    movsw
    nop
    movsw
    xor si, si
    dec di
    call far [bx]