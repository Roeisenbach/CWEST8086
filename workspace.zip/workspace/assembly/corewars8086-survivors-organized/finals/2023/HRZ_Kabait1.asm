    nop
    mov si, ax
    mov dx, 0xffff
    push es
    pop ds
    mov bx, [bx]
    db 0x83, 0xC0, 0x3D ;$1 add ax, 0x003d
    push cs
    pop ds
    mov byte [bx-0x25], 0xbe
    mov [bx-0x24], ax
    mov word [bx-0x22], 0xc356
    add si, 0x0065
    push es
    push ds
    pop es
    std
    mov dx, 0xc681
    mov cx, 0x27ff
    mov ax, 0x5ecc
    jmp label1
    nop
label1:
    mov [0xcccc], si
    int 0x87
    sub si, 0x0065
    pop es
    xor cx, cx
    cld
    jmp label3
    add si, 0x0053
    push ax
    push es
    push ds
    pop es
    std
    mov dx, 0xee81
    mov cx, 0x25ff
    mov ax, 0x5ecc
    mov [0x0000], si
    int 0x87
    sub si, 0x0090
    pop es
    pop ax
    nop
    mov dx, 0xffff
    push cs
    pop ds
    xor cx, cx
    cld
    jmp label3
    push ax
    mov si, [0xcccc]
    mov bx, ax
    mov byte [bx+0x0b], 0x00
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0x27ff
    push es
    push ds
    pop es
    std
    int 0x87
    pop es
    pop ax
    cld
    sub si, 0x0065
    jmp label2
    nop
label2:
    mov dx, 0x0100
    xor cx, cx
    jmp label6
    push ax
    mov si, [0x0000]
    mov bx, ax
    mov byte [bx+0x0b], 0x00
    mov ax, 0x5ecc
    mov dx, 0xee81
    mov cx, 0x25ff
    push es
    push ds
    pop es
    std
    int 0x87
    pop es
    pop ax
    cld
    sub si, 0x0090
    mov dx, 0x0100
    nop
    nop
    xor cx, cx
    jmp label6
label3:
    xor di, di
    push ss
    pop es
    add si, 0x00ef
    mov cl, 0x12
    mov bx, [0x0400]
    mov word [bx+0x0104], 0xcccc
    rep movsw
    mov di, 0x0200
    mov bx, di
    mov al, 0xa1
    stosw
    mov ax, 0x0ff4
    stosw
    push cs
    push ss
    pop ds
    pop ss
    nop
    nop
    mov es, ax
    mov si, 0x0020
    mov ax, 0x11ea
    mov bp, 0x001d
    jmp label4
    rep movsw
label4:
    dec dx
    jz label5
    sub word [bx], 0x0800
    cmp word [bx], 0x00c0
    jbe label4
    mov di, [bx]
    mov sp, di
    mov cl, 0x0f
    sub sp, ax
    movsw
    movsw
    xor si, si
    dec di
    call far [bx]
label5:
    int3
    nop
    add sp, bp
    call far [bx]
label6:
    push cs
    pop ss
    mov sp, ax
    mov si, 0xd4ff
    mov ax, 0xfc29
    mov cx, 0x5356
    mov bx, 0x5051
    nop
    mov di, 0x0005
    sub sp, di
    push si
    push bx
    push cx
    push ax
    call sp