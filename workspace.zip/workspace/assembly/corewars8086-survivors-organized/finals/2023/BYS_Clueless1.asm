    nop
    call prcd1
prcd1:
    push ds
    pop es
    xchg bp, ax
    mov dx, 0x1fff
    mov ax, 0x5104
    int 0x87
    mov di, bp
    sub di, 0x0500
    push cs
    pop es
    int 0x86
    sub di, 0x0400
    int 0x86
    sub di, 0x0200
    push cs
    pop ss
    mov sp, di
    mov dx, 0x000e
    mov ax, 0xd4ff
    nop
    mov bx, 0x5651
    mov cx, 0x5350
    mov si, 0xd429
    sub sp, dx
    push ax
    push bx
    push cx
    push si
    call sp
    push ds
    pop es
    xchg bp, ax
    mov dx, 0x1fff
    mov ax, 0x5104
    int 0x87
    mov di, bp
    sub di, 0x0500
    push cs
    pop es
    int 0x86
    sub di, 0x0400
    int 0x86
    nop
    sub di, 0x0200
    push cs
    pop ss
    mov sp, di
    mov dx, 0x000e
    mov ax, 0xd4ff
    mov bx, 0x5651
    mov cx, 0x5350
    mov si, 0xd429
    sub sp, dx
    push ax
    push bx
    push cx
    push si
    call sp
    push ds
    pop es
    xchg bp, ax
    mov dx, 0x1fff
    mov ax, 0x5104
    int 0x87
    mov di, bp
    nop
    sub di, 0x0500
    push cs
    pop es
    int 0x86
    sub di, 0x0400
    int 0x86
    sub di, 0x0200
    push cs
    pop ss
    mov sp, di
    mov dx, 0x000e
    mov ax, 0xd4ff
    mov bx, 0x5651
    mov cx, 0x5350
    mov si, 0xd429
    sub sp, dx
    push ax
    push bx
    push cx
    push si
    nop
    nop
    call sp
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop