    nop
    add ax, 0x0012
    stosw
    push cs
    pop es
    mov di, ax
    add di, 0x001c
    mov ax, 0xabab
    stosw
    jmp end
    push cs
    push cs
    pop ds
    pop ss
    mov sp, ax
    db 0x83, 0xC0, 0x13 ;$1 add ax, 0x0013
    mov bx, ax
    add bx, 0x0005
    mov [bx], ax
    mov [bx+0x02], cs
    sub sp, 0x0017
    call far [bx]
    nop
    nop
    nop
    nop
end: