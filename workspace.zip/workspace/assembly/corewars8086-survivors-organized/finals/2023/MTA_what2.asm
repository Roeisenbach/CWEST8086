    nop
    jmp label2
    push ds
    pop es
    mov di, ax
    mov ax, 0xcccc
    stosw
    add di, 0x000f
    jmp label1
    push ds
    pop es
    mov di, ax
    mov ax, 0xcccc
label1:
    stosw
    add di, 0x000f
    jmp label1
label2:
    push ds
    pop es
    mov di, ax
    mov ax, 0xcccc
    jmp label3
    nop
    nop
    nop
    nop
label3:
    stosw
    add di, 0x000f
    jmp label3
    push ds
    pop es
    mov di, ax
    stosw
    add di, 0x000f
    jmp label1
    push ds
    pop es
    mov di, ax
    add di, 0x000f
    mov ax, 0xcccc
    stosw
    add di, 0x000b
    jmp label1