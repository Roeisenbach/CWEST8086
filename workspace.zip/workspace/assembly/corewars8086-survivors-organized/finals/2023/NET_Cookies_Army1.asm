    nop
    mov word [0x0402], 0x5ecc
    mov word [0x0400], 0xc681
    brk
    mov si, ax
    add ax, 0x00a3
    mov [si], ax
    xchg si, ax
    mov [si], ax
    xchg si, ax
    push cs
    push cs
    push es
    pop ds
    pop es
    pop ss
    mov ax, 0x26ff
    mov dx, si
    mov di, [bp+0x0206]
    sub di, 0x0030
    nop
    nop
    int 0x86
    mov di, [bp+di+0x02]
    sub di, 0x0030
    int 0x86
    mov bx, 0x26ff
    mov cx, si
    add si, word 0x006a
    mov [0x03fe], si
    mov [0x03fc], si
    mov ax, 0xd4ff
    mov dx, 0xcccc
    int 0x87
    nop
    nop
    mov si, 0x0030
    mov bl, 0xa7
    lodsw
    nop
    nop
    mov bh, ah
    lea sp, [bx-0x0bfb]
    lea ax, [bx+0x76ff]
    mov bx, 0x00c4
    jmp label1
    mov di, ax
    mov ax, 0x1fff
    mov dx, 0xcccc
    int 0x87
    mov ax, di
label1:
    mov [bx], ax
    mov [bx+0x02], cs
    db 0x83, 0xC0, 0x02 ;$1 add ax, 0x0002
    mov word [bx-0x02], 0x0ffb
    mov [bx-0x04], ax
    nop
    nop
    mov ax, 0x51a4
    mov dx, 0x00fc
    mov cx, 0x0007
    mov si, 0x0019
    mov di, [bx]
    mov bp, 0x0002
    dec di
    movsw
    movsw
    movsw
    sub di, bp
    call far [bx]
    call far [bx]
    push cx
    nop
    pop es
    mov ax, 0x9090
    mov cx, 0x9090
    int 0x87