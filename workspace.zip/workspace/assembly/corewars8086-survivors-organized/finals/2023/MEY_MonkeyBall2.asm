    nop
    jmp label1
    push es
    pop ds
    push cs
    push es
    push cs
    pop es
    mov word [di+0x08], 0xa5f3
    mov si, ax
    mov al, 0xa3
    add ax, [di+0x70]
    mov bp, ax
    std
    mov di, ax
    mov ax, [bx+0x66]
    mov dx, [bx+0x68]
    mov cx, [bx+0x6c]
    mov bx, [bx+0x6a]
    int 0x87
    nop
    cld
    mov bx, 0x0004
    mov [bx-0x04], bp
    mov [bx-0x02], cs
    sub bp, [bx+0x6e]
    mov [bx], bp
    mov [bx+0x02], cs
    pop es
    pop ds
    mov cx, 0x000c
    mov di, 0x000a
    add si, 0x0120
    rep movsw
    push cs
    pop ss
    mov dx, 0x1fff
    mov [bp-0x04], dx
    nop
    mov [bp-0x02], dx
    mov [bp+0x02], dx
    mov [bp+0x04], dx
    mov [bp+0x00], dx
    push es
    pop ds
    push cs
    pop es
    mov sp, bp
    add sp, [bx+0x6a]
    mov di, bp
    inc di
    mov si, 0x0008
    mov cx, 0x000c
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sub bp, [si+0x4e]
    mov [bp+0x00], dx
    mov [bx], bp
    mov si, 0x0008
    mov sp, bp
    add sp, [si+0x66]
    mov di, bp
    inc di
    mov cx, 0x000c
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
label1:
    push es
    pop ds
    push cs
    push es
    push cs
    pop es
    mov word [di+0x08], 0xa5f3
    mov si, ax
    mov al, 0xa3
    add ax, [di+0x70]
    mov bp, ax
    std
    mov di, ax
    mov ax, [bx+0x66]
    mov dx, [bx+0x68]
    mov cx, [bx+0x6c]
    mov bx, [bx+0x6a]
    int 0x87
    nop
    cld
    mov bx, 0x0004
    mov [bx-0x04], bp
    mov [bx-0x02], cs
    sub bp, [bx+0x6e]
    mov [bx], bp
    mov [bx+0x02], cs
    pop es
    pop ds
    mov cx, 0x000c
    mov di, 0x000a
    add si, 0x0120
    rep movsw
    push cs
    pop ss
    mov dx, 0x1fff
    mov [bp-0x04], dx
    nop
    mov [bp-0x02], dx
    mov [bp+0x02], dx
    mov [bp+0x04], dx
    mov [bp+0x00], dx
    push es
    pop ds
    push cs
    pop es
    mov sp, bp
    add sp, [bx+0x6a]
    mov di, bp
    inc di
    mov si, 0x0008
    mov cx, 0x000c
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sub bp, [si+0x4e]
    mov [bp+0x00], dx
    mov [bx], bp
    mov si, 0x0008
    mov sp, bp
    add sp, [si+0x66]
    mov di, bp
    inc di
    mov cx, 0x000c
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    push es
    pop ds
    push cs
    push es
    push cs
    pop es
    mov word [di+0x08], 0xa5f3
    mov si, ax
    mov al, 0xa3
    add ax, [di+0x70]
    mov bp, ax
    std
    mov di, ax
    mov ax, [bx+0x66]
    mov dx, [bx+0x68]
    mov cx, [bx+0x6c]
    mov bx, [bx+0x6a]
    int 0x87
    nop
    cld
    mov bx, 0x0004
    mov [bx-0x04], bp
    mov [bx-0x02], cs
    sub bp, [bx+0x6e]
    mov [bx], bp
    mov [bx+0x02], cs
    pop es
    pop ds
    mov cx, 0x000c
    mov di, 0x000a
    add si, 0x0120
    rep movsw
    push cs
    pop ss
    mov dx, 0x1fff
    mov [bp-0x04], dx
    nop
    mov [bp-0x02], dx
    mov [bp+0x02], dx
    mov [bp+0x04], dx
    mov [bp+0x00], dx
    push es
    pop ds
    push cs
    pop es
    mov sp, bp
    add sp, [bx+0x6a]
    mov di, bp
    inc di
    mov si, 0x0008
    mov cx, 0x000c
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sub bp, [si+0x4e]
    mov [bp+0x00], dx
    mov [bx], bp
    mov si, 0x0008
    mov sp, bp
    add sp, [si+0x66]
    mov di, bp
    inc di
    mov cx, 0x000c
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop