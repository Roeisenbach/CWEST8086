    nop
    stosw
    jmp label1
    jmp label2
label1:
    mov di, 0x0000
    mov cx, 0x0704
    mov word [0xfdef], 0x1cff
    mov word [0xfded], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edf
    mov word [di], 0x1dfd
    nop
    nop
    nop
    nop
    nop
    nop
    nop
label2:
    mov word [di+0x02], 0x1dff
    call far [di]
    db 0x83, 0xC0, 0x0E ;$1 add ax, 0x000e
    jmp ax