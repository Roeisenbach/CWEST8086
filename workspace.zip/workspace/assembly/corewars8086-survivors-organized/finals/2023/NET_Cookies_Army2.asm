    nop
    mov word [0xfbfe], 0x5ecc
    mov word [0xfc00], 0xc681
    jmp label1
    int3
    int3
    int3
    mov si, ax
    add si, 0x00d8
    mov cl, 0x18
    rep movsw
    mov al, 0xa7
    mov di, ax
    lea sp, [di+0x7405]
    lea ax, [di-0x0901]
    nop
    mov bl, 0xb4
    jmp word [0x03fe]
    push ax
    call far [bx]
    push ax
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    movsw
    sub di, bp
    call far [bx]
    sub sp, dx
    call far [bx]
    nop
    movsw
    rep movsw
    nop
    nop
    mov dx, 0x4b00
    sub bl, 0x04
    mov cx, 0x0009
    mov si, 0x0007
    rep movsw
    int3
    int3
    int3
    mov si, ax
    add si, 0x00d8
    mov cl, 0x18
    rep movsw
    stosw
    mov al, 0xa7
    mov di, ax
    nop
    push es
    pop ds
    push cs
    push cs
    pop es
    mov bl, 0xb4
    nop
    pop ss
    jmp word [0x03fe]
    push ax
    call far [bx]
    push ax
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    nop
    movsw
    sub di, bp
    call far [bx]
    sub sp, dx
    call far [bx]
    movsw
    rep movsw
    nop
    nop
    nop
    mov dx, 0x4b00
    sub bl, 0x04
    mov cx, 0x0009
    mov si, 0x0007
    rep movsw
label1:
    mov si, ax
    add si, 0x00d8
    mov cl, 0x18
    rep movsw
    stosw
    mov al, 0xa7
    mov di, ax
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    lea sp, [di+0x7405]
    nop
    nop
    lea ax, [di-0x0901]
    mov bl, 0xb4
    jmp word [0x03fe]
    nop
    call far [bx]
    nop
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    movsw
    sub di, bp
    call far [bx]
    nop
    sub sp, dx
    call far [bx]
    nop
    movsw
    rep movsw
    mov dx, 0x4b00
    sub bl, 0x04
    mov cx, 0x0009
    mov si, 0x0007
    rep movsw
    int3
    int3
    int3
    mov si, ax
    add si, 0x00d8
    mov cl, 0x18
    rep movsw
    stosw
    mov al, 0xa7
    mov di, ax
    push es
    pop ds
    push cs
    push cs
    pop es
    nop
    pop ss
    lea sp, [di+0x7405]
    lea ax, [di-0x0901]
    mov bl, 0xb4
    jmp word [0x03fe]
    push ax
    call far [bx]
    push ax
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    movsw
    sub di, bp
    call far [bx]
    nop
    sub sp, dx
    call far [bx]
    nop
    movsw
    rep movsw
    mov dx, 0x4b00
    sub bl, 0x04
    mov cx, 0x0009
    mov si, 0x0007
    rep movsw
    int3
    int3
    int3
    mov si, ax
    add si, 0x00d8
    mov cl, 0x18
    rep movsw
    stosw
    mov al, 0xa7
    mov di, ax
    nop
    push es
    pop ds
    push cs
    push cs
    pop es
    pop ss
    lea sp, [di+0x7405]
    lea ax, [di-0x0901]
    mov bl, 0xb4
    jmp word [0x03fe]
    push ax
    call far [bx]
    push ax
    movsw
    rep movsw
    sub [bx+0x01], ah
    sub sp, dx
    les di, [bx]
    dec di
    mov cl, 0x09
    xor si, si
    movsw
    nop
    movsw
    sub di, bp
    call far [bx]
    nop
    sub sp, dx
    call far [bx]
    nop
    movsw
    rep movsw
    mov dx, 0x4b00
    sub bl, 0x04
    mov cx, 0x0009
    mov si, 0x0007
    rep movsw