    nop
    jmp label1
    nop
    nop
    db 0x83, 0xC0, 0x34 ;$1 add ax, 0x0034
    stosw
    push es
    push ds
    pop es
    mov si, ax
    mov bx, ax
    pop es
    xor di, di
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    nop
    nop
    mov sp, bx
    mov ax, 0xa552
    mov bp, 0x36f0
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    db 0x83, 0xC0, 0x34 ;$1 add ax, 0x0034
    stosw
    push es
    push ds
    pop es
    mov si, ax
    mov bx, ax
    pop es
    xor di, di
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    nop
    nop
    mov bp, 0x36f0
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
label1:
    nop
    add ax, 0x00d9
    stosw
    push es
    push ds
    pop es
    mov si, ax
    mov bx, ax
    pop es
    xor di, di
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    nop
    nop
    mov bp, 0x36f0
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    db 0x83, 0xC0, 0x34 ;$1 add ax, 0x0034
    stosw
    push es
    push ds
    pop es
    mov si, ax
    mov bx, ax
    pop es
    xor di, di
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    nop
    nop
    mov bp, 0x36f0
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    db 0x83, 0xC0, 0x34 ;$1 add ax, 0x0034
    stosw
    push es
    push ds
    pop es
    mov si, ax
    mov bx, ax
    pop es
    xor di, di
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    mov cl, 0x0a
    rep movsw
    mov di, bx
    push cs
    pop ss
    push ds
    push es
    pop ds
    pop es
    mov sp, bx
    mov ax, 0xa552
    nop
    nop
    mov bp, 0x36f0
    mov si, 0x0000
    mov cx, 0x0772
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    mov sp, di
    movsw
    jmp sp
    movsw
    movsw
    movsw
    xor si, si
    movsw
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop