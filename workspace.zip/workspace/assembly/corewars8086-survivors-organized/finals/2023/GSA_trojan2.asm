    nop
    jmp label1
    int3
    stosw
    xor di, di
    mov bx, 0x1fff
    mov [0x0000], bx
    mov cx, 0x000c
    mov si, ax
    add si, word 0x0038
    movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0020
    mov al, 0xa3
    mov [bx], ax
    mov [bx+0x02], cs
    nop
    nop
    nop
    mov cx, 0x000a
    mov si, 0x0002
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0bb0
    rep movsw
    sub word [bx], 0x1200
    mov di, [bx]
    sub sp, 0x0650
    movsw
    dec di
    xor si, si
    mov cx, 0x000a
    call far [bx]
    int3
    call far [bx]
    stosw
    nop
    nop
    xor di, di
    mov bx, 0x1fff
    mov [0x0000], bx
    mov cx, 0x000c
    mov si, ax
    add si, word 0x0038
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0020
    mov al, 0xa3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    nop
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0bb0
    rep movsw
    sub word [bx], 0x1200
    mov di, [bx]
    sub sp, 0x0650
    movsw
    dec di
    xor si, si
    mov cx, 0x000a
    call far [bx]
    int3
    call far [bx]
label1:
    stosw
    xor di, di
    mov bx, 0x1fff
    nop
    nop
    nop
    nop
    mov [0x0000], bx
    mov cx, 0x000c
    mov si, ax
    add si, word 0x0038
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0020
    mov al, 0xa3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    push cs
    pop ss
    mov sp, ax
    nop
    add sp, 0x0bb0
    rep movsw
    sub word [bx], 0x1200
    mov di, [bx]
    sub sp, 0x0650
    movsw
    dec di
    xor si, si
    mov cx, 0x000a
    call far [bx]
    int3
    call far [bx]
    stosw
    xor di, di
    mov bx, 0x1fff
    mov [0x0000], bx
    nop
    nop
    nop
    mov cx, 0x000c
    mov si, ax
    add si, word 0x0038
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0020
    mov al, 0xa3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0bb0
    nop
    nop
    rep movsw
    sub word [bx], 0x1200
    mov di, [bx]
    sub sp, 0x0650
    movsw
    dec di
    xor si, si
    mov cx, 0x000a
    call far [bx]
    int3
    call far [bx]
    stosw
    xor di, di
    mov bx, 0x1fff
    mov [0x0000], bx
    mov cx, 0x000c
    mov si, ax
    nop
    nop
    nop
    nop
    add si, word 0x0038
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov bx, 0x0020
    mov al, 0xa3
    mov [bx], ax
    mov [bx+0x02], cs
    mov cx, 0x000a
    mov si, 0x0002
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0bb0
    rep movsw
    nop
    nop
    nop
    sub word [bx], 0x1200
    mov di, [bx]
    sub sp, 0x0650
    movsw
    dec di
    xor si, si
    mov cx, 0x000a
    call far [bx]
    int3
    call far [bx]