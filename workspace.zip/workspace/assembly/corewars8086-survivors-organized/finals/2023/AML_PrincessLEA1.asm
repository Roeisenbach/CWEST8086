    nop
    push ax
    mov bx, ax
    add bx, 0x0077
    push es
    push ds
    pop es
    std
    mov ax, 0x5ecc
    mov dx, 0xc681
    mov cx, 0x26ff
    mov [0x0206], cx
    mov [0x26ff], cx
    int 0x87
    mov word [0x2701], 0xfdff
    mov [0xfdff], bx
    cld
    pop es
    xor di, di
    nop
    nop
    mov ax, 0xa5a5
    mov cx, 0x0004
    rep stosw
    mov ax, 0xef29
    stosw
    mov ax, 0xa5a5
    stosw
    mov ax, 0xef83
    stosw
    mov ax, 0xff04
    stosw
    mov ax, 0xcce7
    stosw
    mov ax, 0xc783
    stosw
    mov ax, 0xa504
    stosw
    mov ax, 0x29a5
    mov dx, 0xabec
    int 0x86
    nop
    mov ax, 0x51a5
    stosw
    mov ax, 0xa55e
    stosw
    pop di
    add di, 0x00bd
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bp, 0xe9a1
    mov ax, 0xa552
    movsw
    jmp end
    mov bx, ax
    mov si, [0x0206]
    push ds
    pop es
    std
    mov ax, 0x5ecc
    mov dx, 0xee81
    nop
    nop
    mov cx, 0x26ff
    mov [0x0206], si
    int 0x87
    mov di, [0xfdff]
    sub di, 0x7500
    int 0x86
    add di, 0x238a
    int 0x86
    push cs
    pop ss
    mov di, 0x000a
    mov sp, bx
    mov ax, 0xd4ff
    mov bx, 0x5651
    mov cx, 0x5350
    mov si, 0xfc29
    nop
    sub sp, di
    push ax
    push bx
    push cx
    push si
    call sp
end: