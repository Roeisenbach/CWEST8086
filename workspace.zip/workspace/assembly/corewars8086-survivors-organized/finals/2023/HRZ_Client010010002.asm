    nop
    jmp label1
    push ax
    push es
    mov bx, [0x0206]
    mov word [0x0206], 0xcccc
    mov di, ax
    push ds
    pop es
    std
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    xor ah, ah
    mov bx, ax
    nop
    nop
    pop ax
    mov bx, 0x0070
    jmp label4
    mov bx, 0x0050
    pop ax
    push cs
    pop ss
    xor si, si
    mov word [si], 0xec29
    mov word [si+0x02], 0x1fff
    mov word [si+0x04], 0xa5f3
    mov [bx+0x02], cs
    add ax, ax
    mov al, 0xa1
    mov [bx], ax
    mov di, ax
    nop
    cld
    movsw
    movsw
    movsw
    sub di, 0x0005
    xor si, si
    mov word [si], 0xf3a5
    mov word [si+0x02], 0xf3a5
    mov word [si+0x04], 0x29a5
    mov word [si+0x1c], 0x1fff
    call far [bx]
    mov word [si+0x22], 0xa5f3
    xor si, si
    mov cx, 0x0011
    nop
label1:
    push ax
    push es
    mov bx, ax
    add bx, 0x0099
    push ds
    pop es
    std
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    jmp label3
    push ax
    push es
    mov bx, [0x0206]
    jmp label2
    nop
    nop
    nop
    nop
label2:
    mov word [0x0206], 0xcccc
    mov di, ax
    push ds
    pop es
    std
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    xor ah, ah
    mov bx, ax
    pop ax
    mov bx, 0x0070
    jmp label4
label3:
    mov bx, 0x0050
    nop
    pop ax
label4:
    push cs
    pop ss
    xor si, si
    mov word [si], 0xec29
    mov word [si+0x02], 0x1fff
    mov word [si+0x04], 0xa5f3
    mov [bx+0x02], cs
    add ax, ax
    mov al, 0xa1
    mov [bx], ax
    mov di, ax
    cld
    movsw
    movsw
    movsw
    sub di, 0x0005
    xor si, si
    nop
    nop
    mov word [si], 0xf3a5
    mov word [si+0x02], 0xf3a5
    mov word [si+0x04], 0x29a5
    mov word [si+0x06], 0x8b07
    mov word [si+0x08], 0xb13f
    mov word [si+0x0a], 0xbe11
    mov word [si+0x0c], 0x001e
    mov word [si+0x0e], 0xa5a5
    nop
    nop
    mov word [si+0x10], 0x31a5
    mov word [si+0x12], 0x8bf6
    mov word [si+0x14], 0x8127
    mov word [si+0x16], 0xfac4
    mov word [si+0x18], 0x832a
    mov word [si+0x1a], 0x05ef
    mov word [si+0x1c], 0x1fff
    mov word [si+0x1e], 0xec29
    nop
    mov word [si+0x20], 0x1fff
    mov word [si+0x22], 0xa5f3
    xor si, si
    mov cx, 0x0011
    mov sp, ax
    mov ax, 0x0500
    add sp, 0x2afa
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    push ax
    push es
    mov bx, [0x0206]
    nop
    nop
    nop
    mov word [0x0206], 0xcccc
    mov di, ax
    push ds
    pop es
    std
    mov dx, 0xee81
    mov cx, 0x26ff
    mov ax, 0x5ecc
    mov [0x0206], bx
    int 0x87
    pop ds
    xor ah, ah
    mov bx, ax
    pop ax
    mov bx, 0x0070
    jmp label4
    nop
    nop
    nop
    mov bx, 0x0050
    pop ax
    push cs
    pop ss
    xor si, si
    mov word [si], 0xec29
    mov word [si+0x02], 0x1fff
    mov word [si+0x04], 0xa5f3
    mov [bx+0x02], cs
    add ax, ax
    mov al, 0xa1
    mov [bx], ax
    mov di, ax
    cld
    movsw
    movsw
    movsw
    sub di, 0x0005
    nop
    xor si, si
    mov word [si], 0xf3a5
    mov word [si+0x02], 0xf3a5
    mov word [si+0x04], 0x29a5
    mov word [si+0x1e], 0xec29
    mov word [si+0x20], 0x1fff
    mov word [si+0x22], 0xa5f3
    xor si, si
    mov cx, 0x0011
    mov sp, ax
    nop
    nop
    nop
    mov ax, 0x0500
    add sp, 0x2afa
    mov bp, 0x002b
    mov dx, 0x0000
    call far [bx]
    call far [bx]
    call far [bx]