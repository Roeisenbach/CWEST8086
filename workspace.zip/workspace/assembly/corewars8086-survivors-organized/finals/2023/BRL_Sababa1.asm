    nop
    push cs
    push cs
    pop es
    pop ss
    mov bp, 0x1234
    mov cx, 0x00ff
    mov si, 0xcccc
loop1:
    mov di, [bp+0x00]
    cmp si, di
    jnz label1
    loop loop1
label1:
    mov cx, 0x000f
loop2:
    shr di, 1
    jnb label2
    xor di, 0x8016
label2:
    loop loop2
    mov [bp+0x00], si
    xor di, 0x002d
    mov sp, ax
    nop
    nop
    mov dx, 0xe0d1
    mov ax, 0xf6e3
    mov cx, 0x86cd
    mov bx, 0x86cd
    add di, 0x0025
    int 0x87
    mov ax, sp
    add ax, 0x0052
    mov di, ax
    mov ax, 0xab9c
    int 0x86
    int 0x86
    mov bx, di
    stosw
    jmp bx