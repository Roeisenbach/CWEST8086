    nop
    jmp label5
    std
    push ds
    pop es
    push ds
    pop ss
    db 0x83, 0xC0, 0x22 ;$1 add ax, 0x0022
    mov bx, ax
    mov cx, 0x0010
    loop $
    mov di, 0x1cff
    int 0x86
    mov di, 0x1dff
    int 0x86
    mov dx, 0x0050
    mov bp, 0xdead
    mov ax, 0x0000
    nop
    nop
    nop
    nop
    lea di, [bx+0x00a0]
    mov [di], bp
    lea si, [bx-0x00a0]
    mov [si], bp
    xor ax, ax
    mov sp, si
label1:
    add ax, [di]
    sub ax, [si]
    jnz label2
    nrg
    push ax
    jmp label1
label2:
    lea si, [bx+0x2e]
    lea di, [bx-0x1000]
    mov cx, 0x0018
    nop
    nop
    rep movsw
    inc di
    inc di
    mov bx, di
    jmp bx
    nop
    mov ax, 0x0000
    mov ax, 0x0031
    std
    push ds
    pop es
    push ds
    pop ss
    db 0x83, 0xC0, 0x22 ;$1 add ax, 0x0022
    mov bx, ax
    mov cx, 0x0010
    loop $
    mov di, 0x1cff
    int 0x86
    mov di, 0x1dff
    int 0x86
    nop
    mov dx, 0x0050
    mov bp, 0xdead
    mov ax, 0x0000
    lea di, [bx+0x00a0]
    mov [di], bp
    lea si, [bx-0x00a0]
    mov [si], bp
    xor ax, ax
    mov sp, si
label3:
    add ax, [di]
    sub ax, [si]
    jnz label4
    nrg
    push ax
    jmp label3
label4:
    nop
    nop
    nop
    lea si, [bx+0x2e]
    lea di, [bx-0x1000]
    mov cx, 0x0018
    rep movsw
    inc di
    inc di
    mov bx, di
    jmp bx
    nop
    mov ax, 0x0000
    mov ax, 0x0031
label5:
    std
    push ds
    pop es
    push ds
    pop ss
    add ax, 0x00d7
    mov bx, ax
    mov dx, 0x02bc
    nop
    nop
    nop
    mov bp, 0xdead
    nop
    nop
    nop
    mov ax, 0x0000
    lea di, [bx+0x0584]
    lea si, [bx-0x0200]
    mov [di], bp
    mov [di-0x06], bp
    mov [di-0x0c], bp
    mov [di-0x12], bp
    mov [si], bp
    mov [si+0x06], bp
    mov [si+0x0c], bp
    mov [si+0x12], bp
    nop
    nop
    xor ax, ax
    mov sp, si
label6:
    add ax, [di]
    nop
    add ax, [di-0x06]
    add ax, [di-0x0c]
    add ax, [di-0x12]
    add ax, [di-0x18]
    sub ax, [si]
    sub ax, [si+0x06]
    sub ax, [si+0x0c]
    sub ax, [si+0x12]
    sub ax, [si+0x18]
    jz label6
    lea si, [bx+0x57]
    nop
    nop
    nop
    lea di, [bx-0x1000]
    mov cx, 0x002d
    rep movsw
    inc di
    nop
    inc di
    mov bx, di
    jmp bx
    mov ax, 0x0001
    mov ax, 0x0059