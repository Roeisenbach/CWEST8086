    nop
    jmp label4
    push ss
    pop es
    mov si, ax
    add si, 0x0196
    rep movsw
    push cs
    pop es
    int 0x86
    int 0x86
    pop ax
    mov bx, ax
    add byte [bx+0x008f], 0x10
    sub ah, 0x30
    mov al, 0xa1
    push cs
    push ds
    push ss
    pop ds
    pop es
    pop ss
    inc bp
    nop
    nop
    mov si, 0xcccc
    nop
    sub si, 0x00f2
    mov di, ax
    cmp bp, 0x0001
    jz label1
    mov ax, 0x5ecc
    mov dx, 0xc681
    add si, word 0x0029
    jmp label2
label1:
    mov ax, 0x5ecc
    mov dx, 0xee81
    add si, word 0x0027
label2:
    mov cx, 0x17ff
    push ds
    pop es
    std
    mov [bx], si
    int 0x87
    pop ax
    nop
    cld
    mov ax, si
    sub ax, 0x0029
    add ax, bp
    add ax, bp
    push ss
    pop es
    mov si, ax
    add si, 0x00bf
    xor di, di
    mov cx, 0x000e
    rep movsw
    push ax
    add ax, 0x1000
    mov di, ax
    mov ax, bx
    mov dx, ax
    push cs
    pop es
    int 0x86
    int 0x86
    pop ax
    mov bx, ax
    nop
    add byte [bx+0x008f], 0x10
    sub ah, 0x30
    mov al, 0xa1
    push cs
    push ds
    push ss
    pop ds
    pop es
    pop ss
    mov bx, 0x0042
    mov [bx], ax
    mov [bx+0x02], cs
    add ah, 0x10
    sub al, 0x02
    mov sp, ax
    mov dx, 0x0e00
    mov ax, 0x0018
    mov cl, 0x0a
    mov di, [bx]
    mov si, 0x0018
    nop
    movsw
    movsw
    xor si, si
    dec di
    mov bp, 0x00f0
    call far [bx]
    movsw
    rep movsw
    sub [bx], dx
    mov di, [bx]
    movsw
    movsw
    dec bp
    xor si, si
    cmp bp, si
    jz label3
    dec di
    mov cl, 0x0a
    call far [bx]
label3:
    int3
    int3
    int3
    sub sp, ax
    call far [bx]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
label4:
    push es
    pop ds
    add ax, 0x00f2
    mov [di], ax
    inc bp
    mov bx, ax
    push cs
    pop ds
    mov [bx-0x00c7], bx
    nop
    nop
    sub ax, 0x00f2
    push ax
    mov di, ax
    cmp bp, 0x0001
    jz label5
    mov ax, 0x5ecc
    mov dx, 0xc681
    add di, word 0x0029
    jmp label6
label5:
    mov ax, 0x5ecc
    nop
    mov dx, 0xee81
    add di, word 0x0027
    nop
    nop
    nop
    nop
    nop
label6:
    mov cx, 0x17ff
    push ds
    pop es
    std
    mov bx, 0xcccc
    mov [bx], di
    int 0x87
    pop ax
    cld
    push ss
    pop es
    mov si, ax
    add si, 0x0196
    xor di, di
    mov cx, 0x000a
    rep movsw
    push ds
    pop es
    nop
    push ax
    mov cx, bp
    add ah, cl
    add ah, cl
    add ax, 0x0800
    mov di, ax
    mov ax, bx
    mov dx, ax
    int 0x86
    int 0x86
    pop ax
    push cs
    push cs
    push ss
    pop ds
    pop es
    pop ss
    cmp bp, 0x0000
    jz label7
    sub ah, 0x10
    jmp label8
label7:
    sub ah, 0xa2
label8:
    mov al, 0xa1
    nop
    nop
    nop
    mov bx, 0x0042
    nop
    mov [bx], ax
    mov [bx+0x02], cs
    add ah, 0x10
    sub al, 0x02
    mov sp, ax
    mov dx, 0x0e00
    mov ax, 0x0018
    mov cx, 0x0006
    mov di, [bx]
    mov bp, 0xffff
    mov si, 0x0010
    movsw
    movsw
    xor si, si
    dec di
    call far [bx]
    sub sp, ax
    call far [bx]
    nop
    movsw
    rep movsw
    sub [bx], dx
    mov di, [bx]
    movsw
    movsw
    xor si, si
    dec di
    mov cl, 0x06
    call far [bx]
    sub sp, ax
    call far [bx]
    push ss
    pop es
    mov si, ax
    add si, 0x0196
    rep movsw
    add ax, 0x1000
    mov di, ax
    mov ax, bx
    mov dx, ax
    push cs
    pop es
    int 0x86
    nop
    nop
    int 0x86
    pop ax
    mov bx, ax
    add byte [bx+0x008f], 0x10
    sub ah, 0x30
    mov al, 0xa1
    push cs
    push ds
    push ss
    pop ds
    pop es
    pop ss
    int3
    pop si
    add si, 0x5ecc
    sub si, 0x5ecc
    add si, 0x5ecc
    sub si, 0x5ecc
    add si, 0x9090
    nop
    nop
    int3
    pop si
    sub si, 0x5ecc
    add si, 0x5ecc
    sub si, 0x5ecc
    db 0x81, 0xC6  ; add si, word 0x0000