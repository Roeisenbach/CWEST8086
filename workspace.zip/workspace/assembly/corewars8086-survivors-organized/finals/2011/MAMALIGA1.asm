    jmp label2
    int3
    int3
    int3
    add ax, 0x00ed
    mov si, ax
    push es
    push ds
    pop es
    db 0x83, 0xC0, 0x4A ;$1 add ax, 0x004a
    mov [0x4242], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x4242
    std
    int 0x87
    cld
    pop es
    mov bx, es
    mov [si+0x25], bx
    mov bx, si
    mov ax, 0xa550
    add di, 0x0300
    mov cx, 0x0025
    rep movsw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    xor si, si
    mov sp, bx
    mov di, bx
    and di, 0xfffe
    movsw
    nop
    movsw
    movsw
    mov cx, 0x1000
    movsw
    movsw
    mov ss, cx
    movsw
    movsw
    mov es, cx
    movsw
    movsw
    movsw
    and sp, 0xfffe
    movsw
    movsw
    movsw
    movsw
    sub sp, 0xa120
    movsw
    movsw
    movsw
    mov ax, 0xa550
    movsw
    movsw
    movsw
    mov cx, 0x4242
    movsw
    movsw
    movsw
    and dx, 0x007f
    movsw
    dec dx
    movsw
    movsw
    movsw
    movsw
    jnz label1
    mov ds, cx
label1:
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, 0xf700
    movsw
    jmp -2161
    movsw
    xor si, si
    movsw
    call prcd1
prcd1:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3
label2:
    add ax, 0x00ed
    mov si, ax
    push es
    push ds
    pop es
    db 0x83, 0xC0, 0x4A ;$1 add ax, 0x004a
    mov [0x4242], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x4242
    std
    int 0x87
    cld
    pop es
    mov bx, es
    mov [si+0x25], bx
    mov bx, si
    mov ax, 0xa550
    add di, 0x0300
    mov cx, 0x0025
    rep movsw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    xor si, si
    mov sp, bx
    mov di, bx
    and di, 0xfffe
    movsw
    nop
    movsw
    movsw
    mov cx, 0x1000
    movsw
    movsw
    mov ss, cx
    movsw
    movsw
    mov es, cx
    movsw
    movsw
    movsw
    and sp, 0xfffe
    movsw
    movsw
    movsw
    movsw
    sub sp, 0xa120
    movsw
    movsw
    movsw
    mov ax, 0xa550
    movsw
    movsw
    movsw
    mov cx, 0x4242
    movsw
    movsw
    movsw
    and dx, 0x007f
    movsw
    dec dx
    movsw
    movsw
    movsw
    movsw
    jnz label3
    mov ds, cx
label3:
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, 0xf700
    movsw
    jmp -1997
    movsw
    xor si, si
    movsw
    call prcd2
prcd2:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3
    add ax, 0x00ed
    mov si, ax
    push es
    push ds
    pop es
    db 0x83, 0xC0, 0x4A ;$1 add ax, 0x004a
    mov [0x4242], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x4242
    std
    int 0x87
    cld
    pop es
    mov bx, es
    mov [si+0x25], bx
    mov bx, si
    mov ax, 0xa550
    add di, 0x0300
    mov cx, 0x0025
    rep movsw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    xor si, si
    mov sp, bx
    mov di, bx
    and di, 0xfffe
    movsw
    nop
    movsw
    movsw
    mov cx, 0x1000
    movsw
    movsw
    mov ss, cx
    movsw
    movsw
    mov es, cx
    movsw
    movsw
    movsw
    and sp, 0xfffe
    movsw
    movsw
    movsw
    movsw
    sub sp, 0xa120
    movsw
    movsw
    movsw
    mov ax, 0xa550
    movsw
    movsw
    movsw
    mov cx, 0x4242
    movsw
    movsw
    movsw
    and dx, 0x007f
    movsw
    dec dx
    movsw
    movsw
    movsw
    movsw
    jnz label4
    mov ds, cx
label4:
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, 0xf700
    movsw
    jmp -1833
    movsw
    xor si, si
    movsw
    call prcd3
prcd3:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3
    jz 614
    jns 534
    jz 615
    and [di+0x61], ah
    jz 541
    db 0x6D
    db 0x65