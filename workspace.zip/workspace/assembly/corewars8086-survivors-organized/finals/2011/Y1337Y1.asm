    stosw
    push ax
    mov ax, 0x004f
    stosw
    mov ax, 0x0031
    stosw
    pop ax
    mov si, 0x005c
    add si, ax
    mov bx, si
    add bx, 0x0002
    mov [si], bx
    sub bx, 0x0002
    add si, word 0x0020
    add si, 0x0002
    mov [si], bx
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x0031
    mov cx, 0x004f
    shr cx, 1
    rep movsw
    movsb
    push cs
    pop es
    mov si, 0x005c
    add si, ax
    mov bx, si
    add bx, 0x0002
    mov [si], bx
    sub bx, 0x0002
    add si, word 0x0020
    add si, 0x0002
    mov [si], bx
label1:
    mov si, 0x007c
    add si, ax
    mov di, si
    add di, 0x0004
    mov cx, 0x3e00
    rep movsw
    jmp label1
    mov ax, ax
    push cs
    pop es
    pop di
    add di, 0x0002
    mov si, [di]
    add si, word 0x0020
    mov di, si
    add di, 0x0004
    mov cx, 0x3f00
    rep movsw
    add di, 0x0200
    db 0x8B, 0xC7 ;$1 mov ax, di
    int 0x80
    call word [0x0000]