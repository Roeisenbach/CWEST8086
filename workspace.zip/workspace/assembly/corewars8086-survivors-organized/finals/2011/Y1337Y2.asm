    push es
    pop ds
    lodsw
    mov bp, ax
    nop
    nop
    nop
    nop
    lodsw
    mov cx, ax
    lodsw
    db 0x8B, 0xD0 ;$1 mov dx, ax
    db 0x8B, 0xF5 ;$1 mov si, bp
    shr cx, 1
    mov bp, cx
    push cs
    pop ds
    push cs
    pop es
    db 0x03, 0xF2 ;$1 add si, dx
    mov di, si
    add di, 0x7e80
    rep movsw
    sub di, bp
    db 0x8B, 0xC7 ;$1 mov ax, di
    jmp di