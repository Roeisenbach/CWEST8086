    db 0xE9, 0x22, 0x00 ;$1 jmp 37
    int3
    int3
    int3
    rep movsw
    int3
    int3
    int3
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    int 0x86
    db 0x33, 0xFF ;$1 xor di, di
    mov cx, 0x0006
    rep movsw
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    inc bx
    inc bx
    inc bx
    inc bx
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x0064
    mov bx, si
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    int 0x86
    db 0x33, 0xFF ;$1 xor di, di
    mov cx, 0x0006
    rep movsw
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    db 0x8B, 0xE3 ;$1 mov sp, bx
    add sp, word 0x000b
    pop bp
    sub sp, word 0x000f
    db 0x8B, 0xFC ;$1 mov di, sp
    mov si, 0xfffe
    mov bx, 0x5200
    lea dx, [bx+0x0200]
    inc bx
    inc bx
    inc bx
    inc bx
    mov ax, 0x0200
    db 0x33, 0xC9 ;$1 xor cx, cx
    std
    inc ch
    db 0x03, 0xFA ;$1 add di, dx
    add si, ax
    add sp, bx
    push bp
    call sp
    rep movsw
    int3
    int3
    int3
    rep movsw
    int3
    int3
    int3
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    int 0x86
    db 0x33, 0xFF ;$1 xor di, di
    mov cx, 0x0006
    rep movsw
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    inc bx
    inc bx
    inc bx
    inc bx
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    db 0x00  ; add [bx+si], al