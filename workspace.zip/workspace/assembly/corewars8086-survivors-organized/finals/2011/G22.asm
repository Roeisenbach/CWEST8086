    push cs
    pop es
    xor di, di
    mov ax, 0x4187
    mov dx, 0x8820
    mov cx, 0xcccc
    mov bx, cx
    int 0x87
    jmp $