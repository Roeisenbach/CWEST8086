    push cs
    pop es
    xor di, di
label1:
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    jmp label1