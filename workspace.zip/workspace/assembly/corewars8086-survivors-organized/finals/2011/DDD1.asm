    std
    push cs
    push cs
    pop ds
    pop es
    mov dx, 0x002a
    xor bx, dx
    mov cx, 0x0030
    sub dx, 0x0002
    xor si, ax
    add si, 0x0033
    xor di, si
    add di, dx
    add di, dx
    add si, dx
    add dx, dx
    add dx, cx
    add di, cx
    mov ax, 0x002a
    mov bl, 0x02
    div bl
    mov bl, al
    xor bh, 0x00
    mov cx, bx
    jmp loop1
    nrg
    nrg
    nrg
    nrg
    nrg
    nrg
    nrg
    add di, dx
    add si, dx
    mov cx, bx
    std
loop1:
    movsw
    loop loop1
    cld
    movsw
    jmp di