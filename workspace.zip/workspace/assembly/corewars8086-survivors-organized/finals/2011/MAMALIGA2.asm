    jmp label1
    int3
    int3
    int3
    add ax, 0x0100
    mov si, ax
    push es
    push ds
    pop es
    mov word [0x4249], 0x0040
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x1324], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x1324
    std
    int 0x87
    cld
    pop es
    mov ax, 0xa550
    mov dx, ax
    int 0x86
    mov cx, 0x0080
    int 0x86
    rep stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, si
    mov di, si
    xor si, si
    and di, 0xfffe
    movsw
    nop
    call prcd1
prcd1:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3
    add ax, 0x0100
    mov si, ax
    push es
    push ds
    pop es
    mov word [0x4249], 0x0040
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x1324], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x1324
    std
    int 0x87
    cld
    pop es
    mov ax, 0xa550
    mov dx, ax
    int 0x86
    mov cx, 0x0080
    int 0x86
    rep stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, si
    mov di, si
    xor si, si
    and di, 0xfffe
    movsw
    nop
    call prcd2
prcd2:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3
label1:
    add ax, 0x0100
    mov si, ax
    push es
    push ds
    pop es
    mov word [0x4249], 0x0040
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x1324], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x1324
    std
    int 0x87
    cld
    pop es
    mov ax, 0xa550
    mov dx, ax
    int 0x86
    mov cx, 0x0080
    int 0x86
    rep stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, si
    mov di, si
    xor si, si
    and di, 0xfffe
    movsw
    nop
    call prcd3
prcd3:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3
    add ax, 0x0100
    mov si, ax
    push es
    push ds
    pop es
    mov word [0x4249], 0x0040
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x1324], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x1324
    std
    int 0x87
    cld
    pop es
    mov ax, 0xa550
    mov dx, ax
    int 0x86
    mov cx, 0x0080
    int 0x86
    rep stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, si
    mov di, si
    xor si, si
    and di, 0xfffe
    movsw
    nop
    call prcd4
prcd4:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3
    add ax, 0x0100
    mov si, ax
    push es
    push ds
    pop es
    mov word [0x4249], 0x0040
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x1324], ax
    mov ax, 0xfb73
    mov dx, 0x4db8
    mov bx, 0x26ff
    mov cx, 0x1324
    std
    int 0x87
    cld
    pop es
    mov ax, 0xa550
    mov dx, ax
    int 0x86
    mov cx, 0x0080
    int 0x86
    rep stosw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, si
    mov di, si
    xor si, si
    and di, 0xfffe
    movsw
    nop
    call prcd5
prcd5:
    pop bx
    add bx, 0x000f
    and bx, 0xfffe
    xor dx, dx
    mov ax, 0x204d
    stosw
    jmp bx
    jmp bx
    int3
    int3
    int3