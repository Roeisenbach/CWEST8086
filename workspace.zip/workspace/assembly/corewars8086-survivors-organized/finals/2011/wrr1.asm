    push cs
    pop es
    mov bp, ax
    mov ax, 0xb8cc
    mov dx, 0xccab
    mov bx, 0xa5f3
    mov cx, bx
    int 0x87
    mov di, bp
    std
    sub di, 0x13e8
    mov ax, 0xa5f3
    mov dx, ax
    int 0x86
    sub di, 0x13e8
    int 0x86
    shl di, 1
    mov si, bp
label1:
    mov cx, 0x0256
    rep movsw
    sub di, 0x0340
    jmp label1