    mov bx, ax
    add bx, 0x000e
    mov cl, 0xcc
label1:
    mov [bx], cl
    add bx, 0x0008
    jmp label1