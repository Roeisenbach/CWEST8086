    push ds
    pop es
    xchg di, ax
    add di, 0x000c
    mov dx, 0x0000
    mov bx, 0x0000
    mov bl, 0xcc
    mov cx, [di-0x01]
    mov si, di
    add si, 0x000a
    std
    call prcd1
prcd1:
    push bx
    pop dx
    sub dx, 0x001a
    mov bx, 0x00cc
    mov dx, bx
    dec di
    dec di
    mov [di], cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov cx, [di-0x01]
    inc di
    inc di
    jmp di