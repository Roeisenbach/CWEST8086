    mov bx, ax
    push cs
    pop es
    xor di, di
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    mov bx, ax
    add bx, 0x0023
    mov al, 0xcc
    mov cl, 0x20
loop1:
    nrg
    loop loop1
label1:
    mov [bx], al
    add bx, 0x0005
    jmp label1