    mov dx, 0x0000
    push dx
    push ax
    mov bx, ax
    mov cx, 0x003e
loop1:
    mov ax, [bx]
    push bx
    mov bx, dx
    mov [bx], ax
    add bx, 0x8888
    mov [bx], ax
    sub bx, 0xff50
    inc dx
    pop bx
    inc bx
    loop loop1
    pop ax
    pop dx
    mov bx, dx
    add bx, 0x0029
    jmp bx
    add bx, 0x003e
label1:
    push bx
    mov dx, 0xcccc
    mov cx, 0x3200
loop2:
    mov [bx], dx
    add bx, 0x0005
    loop loop2
    pop bx
    inc bx
    jmp label1