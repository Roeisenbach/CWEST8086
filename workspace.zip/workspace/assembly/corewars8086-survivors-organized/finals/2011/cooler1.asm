    push ds
    pop es
    mov di, ax
    add di, 0x0011
    mov ax, 0xcccc
label1:
    mov cx, 0xffff
    rep stosw
    jmp label1