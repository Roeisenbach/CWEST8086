    db 0x8B, 0xD0 ;$1 mov dx, ax
    db 0x8B, 0xE8 ;$1 mov bp, ax
    push es
    push cs
    pop es
    add bp, 0x000a
    pop ds
    lea bx, [bp+0x6d]
    mov [0x0000], bx
    push ds
    push cs
    pop ds
    db 0x8B, 0xC2 ;$1 mov ax, dx
    lea di, [bp-0x0350]
    mov cx, 0x0008
loop1:
    stosw
    add di, 0x0020
    loop loop1
    lea di, [bp+0x0350]
    mov cx, 0x0008
loop2:
    stosw
    add di, 0x0020
    loop loop2
label1:
    lea si, [bp-0x0350]
    mov cx, 0x0008
loop3:
    lodsw
    db 0x3B, 0xC2 ;$1 cmp ax, dx
    jnz label2
    add si, 0x0020
    loop loop3
    lea si, [bp+0x0350]
    mov cx, 0x0008
loop4:
    lodsw
    db 0x3B, 0xC2 ;$1 cmp ax, dx
    jnz label3
    add si, 0x0020
    loop loop4
    jmp label1
label2:
    db 0x8B, 0xF5 ;$1 mov si, bp
    lea di, [bp-0x0980]
    mov cx, 0x0041
    rep movsw
    lea bp, [bp-0x0980]
    jmp bp
label3:
    db 0x8B, 0xF5 ;$1 mov si, bp
    lea di, [bp+0x0980]
    mov cx, 0x0041
    rep movsw
    lea bp, [bp+0x0980]
    jmp bp
    mov cx, 0x0050
    rep stosw
    pop ds
    mov bx, [0x0000]
    push ds
    push cs
    pop ds
    db 0x3B, 0xDD ;$1 cmp bx, bp
    jz label4
    xchg bx, bp
label4:
    jmp bp