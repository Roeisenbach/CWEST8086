    mov bx, ax
    add bx, 0x000e
    mov cl, 0xcc
label1:
    sub bx, 0x0008
    mov [bx], cl
    jmp label1