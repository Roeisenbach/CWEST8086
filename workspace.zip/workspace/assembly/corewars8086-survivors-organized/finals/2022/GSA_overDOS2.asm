    jmp label3
    pop ax
    xor si, si
    mov dx, ax
    push cs
    push es
    pop ds
    lodsw
    sub ax, 0xdeef
    push ax
    push cs
    pop ds
    mov si, dx
    add si, 0x014d
    mov di, 0x00a0
    mov cx, 0x0019
    push ss
    pop es
    rep movsw
    push ss
    push ds
    pop es
    mov ax, dx
    mov cx, 0x0024
    mov si, ax
    add si, 0x003f
    xor dx, dx
    add ax, 0x017e
    push ax
    push ax
    mov di, 0x0004
    mov bx, 0xb60f
    div di
    shl dl, 1
    mov si, 0x2503
    pop ds
    pop ax
    pop ss
    mov dx, 0x0013
    mov di, ax
    mov si, 0x00a0
    movsw
    jmp ax
    movsw
    movsw
    movsw
    mov cx, 0x0015
    rep movsw
    mov sp, ax
    mov bp, ax
label1:
    add ax, 0x9600
    cmp ax, 0x0a70
    jb label1
    sub bp, 0x003c
label2:
    mov si, 0x00a0
    mov [bp+0x00], si
    mov di, [bp+si]
    cmp di, [bp+0x00]
    jz label2
    mov di, ax
    movsw
    jmp ax
label3:
    mov si, ax
    add si, 0x008f
    mov cx, 0x0009
    rep movsw
    push es
    pop ds
    push ax
    mov al, 0xa3
    add ax, 0x0600
    stosw
    jmp label4
    rep movsw
    add sp, [bx+si]
    add [bx], ax
    les di, [bx]
    mov cl, 0x07
    movsw
    xor si, si
    dec di
    call far [bx+si]
    call far [bx+si]
label4:
    push cs
    pop ds
    mov cx, 0x0005
    mov ax, 0x00a5
loop1:
    mov word [bx], 0x18ff
    add bx, 0x0010
    loop loop1
    add bx, 0xe000
    mov cx, 0x0005
loop2:
    mov word [bx], 0x18ff
    add bx, 0x0010
    loop loop2
    pop ax
    xor si, si
    mov dx, ax
    push cs
    push es
    pop ds
    lodsw
    sub ax, 0xdeef
    push ax
    push cs
    pop ds
    mov si, dx
    add si, 0x014d
    mov di, 0x00a0
    mov cx, 0x0019
    push ss
    pop es
    rep movsw
    push ss
    push ds
    pop es
    mov ax, dx
    mov cx, 0x0024
    mov si, ax
    add si, 0x003f
    xor dx, dx
    add ax, 0x017e
    push ax
    push ax
    mov bx, 0xb60f
    nop
    nop
    nop
    mov ax, 0xe33f
    push ax
    push bx
    std
    xor di, di
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    cld
    pop bx
    pop ax
    mov cx, 0x0026
    loop $
    pop [0xe247]
    mov cx, 0x0004
loop3:
    mov si, 0x2503
    mul word [bx]
    add si, ax
    xor si, 0xfaeb
    mov word [si+0x49], 0x26ff
    add bh, 0x02
    mov ax, 0xe33f
    loop loop3
    pop [0xe247]
    mov [0xe247], cx
    pop ds
    pop ax
    pop ss
    mov dx, 0x0013
    mov di, ax
    mov si, 0x00a0
    movsw
    jmp ax
    movsw
    movsw
    movsw
    mov cx, 0x0015
    rep movsw
    mov sp, ax
    mov bp, ax
label5:
    add ax, 0x9600
    cmp ax, 0x0a70
    jb label5
    sub bp, 0x003c
    mov si, 0x00a0
    mov [bp+0x00], si
    mov [bp+si], si
label6:
    sub sp, dx
    push dx
    sub sp, dx
    push dx
    mov di, [bp+si]
    cmp di, [bp+0x00]
    jz label6
    mov di, ax
    movsw
    jmp ax
    call prcd1
prcd1:
    xor di, di
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    pop ax
    sub ax, 0x009a
    push ss
    pop es
    mov si, ax
    add si, 0x00dd
    mov di, 0x00ed
    mov cx, 0x001e
    rep movsw
    push ds
    push es
    mov si, di
    pop ds
    pop es
    push cs
    pop ss
    mov word [si], 0x00ed
    mov word [si+0x02], 0x1000
    mov dx, ds
    sub ax, 0x6500
    mov sp, ax
    mov di, ax
    mov si, 0x00ed
    movsw
    jmp ax
    movsw
    movsw
    mov cx, 0x001a
    movsw
    rep movsw
    mov cx, 0x0004
    sub di, 0x0080
    mov bx, di
    sub ax, 0x6500
    lds si, [si]
    mov [bx], si
    mov [bx+si], si
label7:
    pop di
    pop bp
    add sp, [bx]
    shl bp, cl
    mov word [bp+di-0x02], 0x07b1
    mov word [bp+di], 0xeba5
    mov word [bp+di+0x02], 0x00fc
    mov bp, [bx]
    cmp [bx+si], bp
    jz label7
    mov ds, dx
    mov di, ax
    movsw
    jmp ax