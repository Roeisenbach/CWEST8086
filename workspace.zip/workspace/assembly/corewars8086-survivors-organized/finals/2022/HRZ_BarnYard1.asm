    stosw
    xor di, di
    db 0xE9, 0x21, 0x00 ;$1 jmp 39
    mov cx, 0x0688
    mov word [0xecef], 0x1cff
    mov word [0xeced], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x0ddf
    mov word [si], 0x1cfd
    mov word [si+0x02], 0x1cff
    call far [si]
    mov cx, 0x0688
    mov word [0xece9], 0xcc29
    mov word [0xeceb], 0x1cff
    mov word [0xecef], 0x1cff
    mov word [0xeced], 0xcc29
    mov word [0xecf1], 0xcc29
    mov word [0xecf3], 0x1cff
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x0ddf
    mov word [si], 0x1cfd
    mov word [si+0x02], 0x1cff
    call far [si]
    mov cx, 0x0688
    mov word [0xecef], 0x1cff
    mov word [0xeced], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x0ddf
    mov word [si], 0x1cfd
    mov word [si+0x02], 0x1cff
    call far [si]