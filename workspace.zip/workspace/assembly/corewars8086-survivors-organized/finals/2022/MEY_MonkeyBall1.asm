    jmp label2
    dec word [0xcc17]
    mov si, ax
    add si, 0x0002
    add si, word 0x007a
    mov cx, 0x000e
    xor di, di
    rep movsw
    mov cx, 0x0040
    int3
    mov bp, 0x1000
    mov dx, ax
    mov dl, 0xa3
    int3
    mov bx, 0x0250
    db 0xF3, 0xB8
    add [bx], al
    push es
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label1+1
    int3
    rep movsw
    push ds
    pop es
label1:
    sub dx, bp
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    clc
    dec di
    int3
    db 0xF3, 0x01
    ret 0xd489
    xor si, si
    mov cx, 0x0010
    call far [bx]
    int3
    movsw
    rep movsw
label2:
    push cs
    pop ss
    mov si, ax
    add si, word 0x007a
    mov cx, 0x000e
    rep movsw
    mov cx, 0x0040
    mov bp, 0x1000
    mov dx, ax
    mov dl, 0xa3
    mov bx, 0x0250
    mov ax, 0x0700
    push es
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label3
    rep movsw
    push ds
    pop es
    sub dx, bp
label3:
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    dec di
    add dx, ax
    mov sp, dx
    xor si, si
    mov cx, 0x0010
    call far [bx]
    int3
    int3
    push cs
    pop ss
    dec word [bx+di-0x7e3a]
    db 0xC6, 0x7A, 0x00, 0xB9 ;$7 mov byte [bp+si+byte 0x00], 0xb9
    push cs
    add bl, dh
    movsw
    mov cx, 0x0040
    hlt
    mov bp, 0x1000
    int3
    mov dx, ax
    mov dl, 0xa3
    mov bx, 0x0250
    mov ax, 0x0700
    clc
    push es
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label4
    rep movsw
    push ds
    pop es
    rep movsw
label4:
    int3
    sub dx, bp
    hlt
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    dec di
    clc
    add dx, ax
    int3
    int3
    mov sp, dx
    xor si, si
    mov cx, 0x0010
    int3
    call far [bx]
    int3
    int3
    push cs
    xor di, di
    pop ss
    dec word [bx+di-0x7e3a]
    db 0xC6, 0x7A, 0x00, 0xB9 ;$7 mov byte [bp+si+byte 0x00], 0xb9
    push cs
    add bl, dh
    movsw
    mov cx, 0x0040
    hlt
    mov bp, 0x1000
    int3
    mov dx, ax
    mov dl, 0xa3
    mov bx, 0x0250
    mov ax, 0x0700
    clc
    push cs
    pop ss
    int3
    mov si, ax
    add si, 0x0002
    add si, word 0x007a
    mov cx, 0x000e
    rep movsw
    mov cx, 0x0040
    int3
    mov bp, 0x1000
    mov dx, ax
    mov dl, 0xa3
    int3
    mov bx, 0x0250
    db 0xF3, 0x31
    db 0xFF, 0xB8, 0x00, 0x07
    push es
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label5+1
    int3
    rep movsw
    push ds
    pop es
label5:
    sub dx, bp
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    clc
    push es
    xor di, di
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label6
    rep movsw
    push ds
    pop es
    int3
    int3
label6:
    push cs
    pop ss
    dec word [bx+di-0x7e3a]
    db 0xC6, 0x7A, 0x00, 0xB9 ;$7 mov byte [bp+si+byte 0x00], 0xb9
    push cs
    add bl, dh
    movsw
    mov cx, 0x0040
    hlt
    mov bp, 0x1000
    int3
    mov dx, ax
    mov dl, 0xa3
    mov bx, 0x0250
    mov ax, 0x0700
    clc
    push es
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label7
    rep movsw
    push ds
    pop es
    rep movsw
label7:
    int3
    sub dx, bp
    hlt
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    dec di
    clc
    add dx, ax
    int3
    int3
    mov sp, dx
    xor si, si
    mov cx, 0x0010
    int3
    call far [bx]
    rep movsw
    int3
    sub dx, bp
    hlt
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    dec di
    clc
    add dx, ax
    int3
    int3
    mov sp, dx
    xor si, si
    mov cx, 0x0010
    int3
    mov bp, 0x1000
    mov dx, ax
    mov dl, 0xa3
    int3
    mov bx, 0x0250
    db 0xF3, 0xB8
    add [bx], al
    push es
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label8+1
    int3
    rep movsw
    push ds
    pop es
label8:
    sub dx, bp
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    clc
    dec di
    int3
    db 0xF3, 0x01
    ret 0xd489
    xor si, si
    mov cx, 0x0010
    call far [bx]
    int3
    movsw
    rep movsw
    rep movsw
    int3
    sub dx, bp
    hlt
    db 0x89  ; mov [bx+si], ax