    nop
    jmp label1
    int3
    int3
    sub sp, bp
    call far [bx]
    int3
    int3
    add ax, 0x0067
    add di, 0x0001
    stosw
    xor di, di
    mov al, 0xb9
    stosb
    add di, 0x0002
    mov ax, 0xe1ff
    stosw
    pop di
    add di, 0x020b
    push es
    push cs
    pop es
    mov bx, 0xe33f
    mov cl, 0x94
    rep movsw
    nrg
    xchg ax, [0xb60f]
    xchg si, [0xb80f]
    xchg bp, [0xba0f]
    xchg dx, [0xbc0f]
    pop ds
    push ax
    push si
    push bp
    push dx
    mov cl, 0x04
loop1:
    xor si, si
    pop ax
    sub ax, 0xbec3
    mul bx
    mov di, 0xfaeb
    xor di, ax
    add di, 0x004e
    movsw
    movsw
    movsw
    loop loop1
    xor dx, dx
    mov di, 0xbe11
    jmp word [0x0001]
    push ax
    xor di, di
    pop ax
    push cs
    pop ds
    xor dh, dh
    mov al, 0xa1
    push ss
    pop es
    xor di, di
    rep movsw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, ax
    mov [bx], ax
    mov [bx+0x02], cs
    sub sp, bp
    add sp, 0x0002
    xor si, si
    rep movsw
    add [bx], ax
    mov di, [bx]
    movsw
    movsw
    dec di
    add sp, [si]
    dec dx
    xor si, si
    call far [bx]
    sub sp, bp
    call far [bx]
label1:
    push ax
    add ax, 0x0107
    add di, 0x0001
    stosw
    xor di, di
    mov al, 0xb9
    stosb
    add di, 0x0002
    mov ax, 0xe1ff
    stosw
    pop di
    add di, 0x020b
    push es
    push cs
    pop es
    mov bx, 0xe33f
    mov cl, 0x94
    rep movsw
    nrg
    xchg dx, [0xbc0f]
    xchg bp, [0xba0f]
    xchg si, [0xb80f]
    xchg ax, [0xb60f]
    mov di, [0x11bf]
    sub di, 0x0100
    int 0x86
    int 0x86
    pop ds
    push ax
    push si
    push bp
    push dx
    mov cl, 0x04
loop2:
    xor si, si
    pop ax
    sub ax, 0xbec3
    mul bx
    mov di, 0xfaeb
    xor di, ax
    add di, 0x004e
    movsw
    movsw
    movsw
    loop loop2
    xor bx, bx
    mov di, 0xbf11
    jmp word [0x0001]
    mov ax, di
    shl ax, 1
    shl ax, 1
    shl ax, 1
    shl ax, 1
    push ax
    xor di, di
    mov ax, 0xcccc
    mov dx, 0x01cc
    mov ch, 0xcc
    int 0x87
    pop ax
    xor cx, cx
    push cs
    pop ds
    mov dx, bx
    xor dh, dh
    call prcd1
prcd1:
    pop si
    add ax, si
    add si, 0x003a
    mov al, 0xa1
    push ss
    pop es
    xor di, di
    mov cl, 0x0d
    rep movsw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, ax
    mov bx, 0x0050
    mov [bx], ax
    mov ax, 0x0ffe
    mov [bx+0x02], ax
    mov es, ax
    add sp, 0xffe0
    mov ax, 0xa100
    mov bp, 0x001e
    sub sp, bp
    add sp, 0x0002
    xor si, si
    add si, 0x0014
    jmp label2
    rep movsw
label2:
    mov cl, 0x09
    add [bx], ax
    mov di, [bx]
    movsw
    movsw
    dec di
    add sp, [si]
    dec dx
    jz label3
    xor si, si
    call far [bx]
    sub sp, bp
    call far [bx]
    xor al, 0xc2
    add ax, 0x01cd
    add di, 0x0001
    stosw
    xor di, di
    mov al, 0xb9
    stosb
    add di, 0x0002
    mov ax, 0xe1ff
    stosw
    pop di
label3:
    add di, 0x020b
    push es
    push cs
    pop es
    mov bx, 0xe33f
    mov cl, 0x94
    rep movsw
    nrg
    xchg ax, [0xb60f]
    xchg si, [0xb80f]
    xchg bp, [0xba0f]
    xchg dx, [0xbc0f]
    pop ds
    push ax
    push si
    push bp
    push dx
    mov cl, 0x04
loop3:
    xor si, si
    pop ax
    sub ax, 0xbec3
    mul bx
    mov di, 0xfaeb
    xor di, ax
    add di, 0x004e
    movsw
    movsw
    movsw
    loop loop3
    xor dx, dx
    mov di, 0xbf11
    jmp word [0x0001]
    push ax
    xor di, di
    pop ax
    push cs
    pop ds
    xor dh, dh
    mov al, 0xa1
    push ss
    pop es
    xor di, di
    rep movsw
    push es
    push cs
    pop es
    pop ds
    push cs
    pop ss
    mov sp, ax
    mov [bx], ax
    mov [bx+0x02], cs
    sub sp, bp
    add sp, 0x0002
    xor si, si
    rep movsw
    db 0x01  ; add [bx+si], ax