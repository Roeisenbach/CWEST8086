    mov bx, [0xe129]
    add dx, [0xe129]
    jz label1
    mov bx, dx
label1:
    push bx
    push es
    pop ds
    xchg bx, ax
    lodsw
    push cs
    pop ds
    lea si, [bx+0x0081]
    mov [bx], si
    xchg bx, ax
    mov [bx+0x0f], ax
    mov word [bx+0x0d], 0x26ff
    pop bx
    mov si, ax
    mov [si], ax
    add word [si], 0x011e
    mov [bx+0x00c5], ax
    mov word [bx+0x00c3], 0x26ff
    mov cl, 0x03
    mov bp, cs
    mov di, cs
    loop $
    xchg bp, [0x07fe]
    xchg di, [0x07fe]
    mov bx, ax
    add bx, 0x0127
    nop
    nop
    mov [0x0250], bx
    mov [0x0252], cs
    cmp di, 0x1000
    jz label2
    jmp label3
label2:
    xchg di, bp
label3:
    mov si, ax
    add si, 0x012a
    mov [si], di
    mov si, ax
    add word [si], 0x0003
    mov cl, 0x07
    loop $
    mov bx, [0x8801]
    mov [bx-0x7d], ax
    mov word [bx-0x7f], 0x26ff
    push ax
    push ss
    pop es
    jmp label4
    push ax
    call prcd1
prcd1:
    pop ax
    sub ax, 0x0085
    mov cl, 0x25
    loop $
label4:
    push ss
    pop es
    xor di, di
    mov si, ax
    add si, 0x00f4
    mov cl, 0x14
    rep movsw
    pop dx
    push dx
    cmp ax, dx
    jz label5
    mov di, 0xbc0f
    mov si, 0xba0f
    jmp label6
label5:
    mov di, 0xb80f
    mov si, 0xb60f
    nop
label6:
    mov bx, ax
    mov bp, ax
    add ax, 0x0123
    mov [bx], ax
    mov cl, 0x49
    loop $
    mov cl, 0x02
    xchg di, [di]
    xchg si, [si]
loop1:
    mov ax, 0xe33f
    mul di
    sub ax, 0xdafd
    xor ax, 0xfaeb
    xchg bx, ax
    mov ax, 0x26ff
    mov [bx+0x4e], bp
    mov [bx+0x4c], ax
    xchg di, si
    loop loop1
    pop ax
    push ds
    push ds
    push ss
    pop ds
    pop es
    pop ss
    mov al, 0xe3
    dec ah
    mov bx, 0x0100
    mov [bx+0x02], ss
    mov [bx], ax
    mov ax, 0x0007
    jmp label7
    int3
    movsw
    rep movsw
    sub word [bx], 0x0400
label7:
    mov bp, [bx]
    mov sp, bp
    add sp, 0x036c
    lea di, [bp-0x01]
    xor si, si
    mov cl, 0x12
    mov byte [bp-0x01], 0xa5
    mov word [bp+0x00], 0xc429
    mov word [bp+0x02], 0x18ff
    call far [bx+si]
    xchg bx, ax
    jmp label8
    push ss
    pop es
    xchg dx, ax
    jmp label8
    push ss
    pop es
    jmp label8
    xchg dx, ax
    add si, 0xcccc
    mov ss, si
    mov sp, 0x0100
label8:
    call prcd2
prcd2:
    pop si
    add si, 0x0045
    mov di, ax
    push cs
    pop es
    mov cl, 0x23
    rep movsw
    push cs
    pop ss
    xchg bx, ax
    jmp bx
label9:
    mov ax, 0xcccc
    lea di, [bx+0x0200]
    mov cl, 0x05
    rep stosw
    lea di, [bx+0x0300]
    mov cl, 0x05
    rep stosw
label10:
    lea si, [bx+0x0200]
    lea di, [bx+0x0300]
    mov cl, 0x06
    rep cmpsw
    cmp cl, 0x00
    jz label10
    cmp word [si], 0xcccc
    jnz label11
    xchg si, di
label11:
    lea sp, [si-0x03]
    mov cl, 0x04
    mov si, 0x0010
loop2:
    pop di
    pop ax
    mul si
    xchg bp, ax
    mov word [bp+di-0x02], 0xe7ff
    sub sp, 0x0003
    loop loop2
    jmp label9