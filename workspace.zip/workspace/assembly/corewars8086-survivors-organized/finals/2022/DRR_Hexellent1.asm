    add ax, 0x00b1
    jmp label6
    int3
    int3
    int3
    stosw
    push ax
label1:
    xor di, di
    push ss
    pop es
    mov si, ax
    add si, 0x007a
    mov cl, 0x0e
    rep movsw
    push cs
    pop es
    mov bx, 0x26ff
    mov cx, ax
    mov si, ax
    add ax, 0x0097
    mov [si], ax
    mov ax, 0x432d
    mov dx, 0xf747
    int 0x87
    xchg dx, bp
    xor cx, cx
    pop di
    cmp si, di
    jnz label3
    mov cl, 0x80
    loop $
    mov si, 0xde3f
    xchg ax, [0xba0f]
    xchg bp, [0xbc0f]
label2:
    mov cl, 0x35
loop1:
    add ax, 0xb8bd
    mul si
    loop loop1
    xchg bx, ax
    xor bx, 0xfaeb
    mov word [bx+0x4c], 0x26ff
    mov [bx+0x4e], di
    cmp ax, 0x26ff
    xchg bp, ax
    jz label2
    xor dx, dx
label3:
    mov ax, di
    push cs
    push ss
    pop ds
    pop ss
    dec ah
    mov al, 0xa3
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cs
    mov sp, ax
    add sp, 0x03ec
    xchg di, ax
    inc di
    mov ax, 0x0114
    jmp label4
    rep movsw
    sub sp, ax
    sub word [bx], 0x0500
    sub di, 0x051c
label4:
    xor si, si
    mov cl, 0x0d
    dec dx
    jz label5
    mov bp, [bx]
    mov word [bp+0x00], 0x1fff
    call far [bx]
label5:
    int3
    mov bp, 0x02c3
    push ax
    call prcd1
prcd1:
    pop ax
    sub ax, 0x009e
    jmp label1
    int3
    int3
    int3
label6:
    stosw
    push ax
label7:
    xor di, di
    push ss
    pop es
    mov si, ax
    add si, 0x007a
    mov cl, 0x0e
    rep movsw
    push cs
    pop es
    mov bx, 0x26ff
    mov cx, ax
    mov si, ax
    add ax, 0x0097
    mov [si], ax
    mov ax, 0x432d
    mov dx, 0xf747
    int 0x87
    xchg dx, bp
    xor cx, cx
    pop di
    cmp si, di
    jnz label9
    mov cl, 0x80
    loop $
    mov si, 0xde3f
    xchg ax, [0xba0f]
    xchg bp, [0xbc0f]
label8:
    mov cl, 0x35
loop2:
    add ax, 0xb8bd
    mul si
    loop loop2
    xchg bx, ax
    xor bx, 0xfaeb
    mov word [bx+0x4c], 0x26ff
    mov [bx+0x4e], di
    cmp ax, 0x26ff
    xchg bp, ax
    jz label8
    xor dx, dx
label9:
    mov ax, di
    push cs
    push ss
    pop ds
    pop ss
    dec ah
    mov al, 0xa3
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cs
    mov sp, ax
    add sp, 0x03ec
    xchg di, ax
    inc di
    mov ax, 0x0114
    jmp label10
    rep movsw
    sub sp, ax
    sub word [bx], 0x0500
    sub di, 0x051c
label10:
    xor si, si
    mov cl, 0x0d
    dec dx
    jz label11
    mov bp, [bx]
    mov word [bp+0x00], 0x1fff
    call far [bx]
label11:
    int3
    mov bp, 0x02c3
    push ax
    call prcd2
prcd2:
    pop ax
    sub ax, 0x009e
    jmp label7
    int3
    int3
    int3
    stosw
    push ax
label12:
    xor di, di
    push ss
    pop es
    mov si, ax
    add si, 0x007a
    mov cl, 0x0e
    rep movsw
    push cs
    pop es
    mov bx, 0x26ff
    mov cx, ax
    mov si, ax
    add ax, 0x0097
    mov [si], ax
    mov ax, 0x432d
    mov dx, 0xf747
    int 0x87
    xchg dx, bp
    xor cx, cx
    pop di
    cmp si, di
    jnz label14
    mov cl, 0x80
    loop $
    mov si, 0xde3f
    xchg ax, [0xba0f]
    xchg bp, [0xbc0f]
label13:
    mov cl, 0x35
loop3:
    add ax, 0xb8bd
    mul si
    loop loop3
    xchg bx, ax
    xor bx, 0xfaeb
    mov word [bx+0x4c], 0x26ff
    mov [bx+0x4e], di
    cmp ax, 0x26ff
    xchg bp, ax
    jz label13
    xor dx, dx
label14:
    mov ax, di
    push cs
    push ss
    pop ds
    pop ss
    dec ah
    mov al, 0xa3
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cs
    mov sp, ax
    add sp, 0x03ec
    xchg di, ax
    inc di
    mov ax, 0x0114
    jmp label15
    rep movsw
    sub sp, ax
    sub word [bx], 0x0500
    sub di, 0x051c
label15:
    xor si, si
    mov cl, 0x0d
    dec dx
    jz label16
    mov bp, [bx]
    mov word [bp+0x00], 0x1fff
    call far [bx]
label16:
    int3
    mov bp, 0x02c3
    push ax
    call prcd3
prcd3:
    pop ax
    sub ax, 0x009e
    jmp label12
    int3
    int3