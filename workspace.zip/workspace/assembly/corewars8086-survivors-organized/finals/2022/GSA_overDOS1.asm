    jmp label1
    mov cx, 0x000e
    loop $
    push es
    pop ds
    nop
    mov si, 0x0012
    lodsw
    add ax, 0x8800
    xor si, si
    xor di, di
    push cs
    pop es
    mov bx, 0x0058
    mov [bx+0x02], cs
    mov [bx], ax
    mov word [bx+0x10], 0x1e00
    mov cx, 0x0064
    loop $
    push ax
    xor di, di
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    pop ax
    inc ax
    mov di, ax
    mov cx, 0x0007
    dec ax
    mov dx, cs
    push ds
    mov ds, dx
    mov dx, 0x0008
    mov bx, ax
    mov word [bx], 0x18ff
    mov bx, 0x0058
    pop ds
    push cs
    pop ss
    add ax, 0x0500
    mov sp, ax
    mov ax, 0x1900
    call far [bx+si]
    int3
    int3
    int3
    jmp label1
    mov cx, 0x000e
    loop $
    push es
    pop ds
    nop
    mov si, 0x0012
    lodsw
    add ax, 0x8800
    xor si, si
    xor di, di
    push cs
    pop es
    mov bx, 0x0058
    mov [bx+0x02], cs
    mov [bx], ax
    mov word [bx+0x10], 0x1e00
    mov cx, 0x0064
    loop $
    push ax
    xor di, di
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    pop ax
    inc ax
    mov di, ax
    mov cx, 0x0007
    dec ax
    mov dx, cs
    push ds
    mov ds, dx
    mov dx, 0x0008
    mov bx, ax
    mov word [bx], 0x18ff
    mov bx, 0x0058
    pop ds
    push cs
    pop ss
    add ax, 0x0500
    mov sp, ax
    mov ax, 0x1900
    call far [bx+si]
    int3
    int3
    int3
    brk
label1:
    mov cx, 0x000e
    loop $
    push es
    pop ds
    nop
    mov si, 0x0012
    lodsw
    add ax, 0x8800
    xor si, si
    xor di, di
    push cs
    pop es
    mov bx, 0x0058
    mov [bx+0x02], cs
    mov [bx], ax
    mov word [bx+0x10], 0x1e00
    mov cx, 0x0064
    loop $
    push ax
    xor di, di
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    pop ax
    inc ax
    mov di, ax
    mov cx, 0x0007
    dec ax
    mov dx, cs
    push ds
    mov ds, dx
    mov dx, 0x0008
    mov bx, ax
    mov word [bx], 0x18ff
    mov bx, 0x0058
    pop ds
    push cs
    pop ss
    add ax, 0x0500
    mov sp, ax
    mov ax, 0x1900
    call far [bx+si]
    int3
    int3
    int3
    jmp label1
    mov cx, 0x000e
    loop $
    push es
    pop ds
    nop
    mov si, 0x0012
    lodsw
    add ax, 0x8800
    xor si, si
    xor di, di
    push cs
    pop es
    mov bx, 0x0058
    mov [bx+0x02], cs
    mov [bx], ax
    mov word [bx+0x10], 0x1e00
    mov cx, 0x0064
    loop $
    push ax
    xor di, di
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    pop ax
    inc ax
    mov di, ax
    mov cx, 0x0007
    dec ax
    mov dx, cs
    push ds
    mov ds, dx
    mov dx, 0x0008
    mov bx, ax
    mov word [bx], 0x18ff
    mov bx, 0x0058
    pop ds
    push cs
    pop ss
    add ax, 0x0500
    mov sp, ax
    mov ax, 0x1900
    call far [bx+si]
    int3
    int3
    int3
    jmp label1
    mov cx, 0x000e
    loop $
    push es
    pop ds
    nop
    mov si, 0x0012
    lodsw
    add ax, 0x8800
    xor si, si
    xor di, di
    push cs
    pop es
    mov bx, 0x0058
    mov [bx+0x02], cs
    mov [bx], ax
    mov word [bx+0x10], 0x1e00
    mov cx, 0x0064
    loop $
    push ax
    xor di, di
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, 0xcccc
    mov cx, bx
    int 0x87
    pop ax
    inc ax
    mov di, ax
    mov cx, 0x0007
    dec ax
    mov dx, cs
    push ds
    mov ds, dx
    mov dx, 0x0008
    mov bx, ax
    mov word [bx], 0x18ff
    mov bx, 0x0058
    pop ds
    push cs
    pop ss
    add ax, 0x0500
    mov sp, ax
    mov ax, 0x1900
    call far [bx+si]