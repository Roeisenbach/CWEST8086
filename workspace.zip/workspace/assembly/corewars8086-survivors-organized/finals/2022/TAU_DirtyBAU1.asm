    jmp label1
    mov ax, 0x01f9
    mov bx, 0x01f9
    mov cl, 0x0c
    shr ax, cl
    db 0x83, 0xE0, 0x0C ;$1 and ax, 0x000c
    mov dx, ax
    mov ax, bx
    add dx, 0x0ff8
    mov ch, bh
    add ch, 0x50
    mov cl, 0xa2
    mov [bx+0x0168], dx
    mov [bx+0x016b], cx
    push ds
    push ss
    pop ds
    mov bx, 0x0200
    mov [bx], cx
    mov [bx+0x02], dx
    mov di, 0x0050
    mov ax, cx
    stosw
    mov ax, dx
    stosw
    push si
    push cx
    push ds
    push ds
    push cs
    pop ds
    pop es
    lea si, [bp+0x0152]
    xor di, di
    mov cx, 0x0009
    rep movsw
    pop ds
    pop cx
    pop si
    pop ax
    pop cx
    push ax
    push bx
    push dx
    push ds
    mov bx, cs
    mov ds, bx
    mov dx, cx
    mov ax, 0xe33f
    mov cx, 0x007d
    loop $
    mov cx, dx
    mul word [0xb60f]
    add ax, 0x2503
    xor ax, 0xfaeb
    xchg cx, ax
    mov bx, ax
    add ax, 0x0164
    lea bx, [bx+0x0165]
    mov [bx], ax
    mov ax, bx
    mov bx, cx
    add bx, 0x004e
    mov [bx], ax
    mov word [bx-0x02], 0x26ff
    pop ds
    pop dx
    pop bx
    push dx
    pop es
    pop ss
    mov dx, 0x7300
    mov ax, 0x1fff
    les di, [bx]
    stosw
    dec di
    lea sp, [bx+di-0x01]
    mov cx, 0x0007
    call far [bx]
    movsw
    rep movsw
    mov cl, 0x07
    add [bx], dx
    les di, [bx]
    lea sp, [bx+di]
    xor si, si
    stosw
    dec di
    call far [bx]
    int3
label1:
    mov bp, ax
    push ax
    mov bx, ax
    mov cl, 0x0c
    shr ax, cl
    db 0x83, 0xE0, 0x0C ;$1 and ax, 0x000c
    mov dx, ax
    mov ax, bx
    add dx, 0x0ff8
    mov ch, bh
    add ch, 0x50
    mov cl, 0xa2
    mov [bx+0x0168], dx
    mov [bx+0x016b], cx
    push ds
    push ss
    pop ds
    mov bx, 0x0200
    mov [bx], cx
    mov [bx+0x02], dx
    mov di, 0x0050
    mov ax, cx
    stosw
    mov ax, dx
    stosw
    push si
    push cx
    push ds
    push ds
    push cs
    pop ds
    pop es
    lea si, [bp+0x0152]
    xor di, di
    mov cx, 0x0009
    rep movsw
    pop ds
    pop cx
    pop si
    pop ax
    pop cx
    push ax
    push bx
    push dx
    push ds
    mov bx, cs
    mov ds, bx
    mov dx, cx
    mov ax, 0xe33f
    mov cx, 0x007d
    loop $
    mov cx, dx
    mul word [0xb60f]
    add ax, 0x2503
    xor ax, 0xfaeb
    xchg cx, ax
    mov bx, ax
    add ax, 0x0164
    lea bx, [bx+0x0165]
    mov [bx], ax
    mov ax, bx
    mov bx, cx
    add bx, 0x004e
    mov [bx], ax
    mov word [bx-0x02], 0x26ff
    pop ds
    pop dx
    pop bx
    push dx
    pop es
    pop ss
    mov dx, 0x7300
    mov ax, 0x1fff
    les di, [bx]
    stosw
    dec di
    lea sp, [bx+di-0x01]
    mov cx, 0x0007
    call far [bx]
    movsw
    rep movsw
    mov cl, 0x07
    add [bx], dx
    les di, [bx]
    lea sp, [bx+di]
    xor si, si
    stosw
    dec di
    call far [bx]
    int3
    mov ax, 0xffff
    mov dx, 0xffff
    mov cx, 0xffff
    add cx, 0x3000
    push ds
    push ss
    pop ds
    mov bx, 0x01e4
    mov [bx], cx
    mov [bx+0x02], dx
    mov word [0x0000], 0xf3a5
    mov word [0x0002], 0xb1a5
    mov word [0x0004], 0x010b
    mov word [0x0006], 0xc417
    mov word [0x0008], 0x8d3f
    mov word [0x000a], 0xff21
    mov word [0x000c], 0x8104
    mov word [0x000e], 0x303c
    mov word [0x0010], 0x7405
    mov word [0x0012], 0x3106
    mov word [0x0014], 0xabf6
    mov word [0x0016], 0xff4f
    mov word [0x0018], 0xcc1f
    push dx
    pop es
    pop ss
    mov dx, 0x7300
    mov ax, 0x1fff
    les di, [bx]
    stosw
    dec di
    lea sp, [bx+di-0x01]
    mov cx, 0x000b
    call far [bx]
    movsw
    rep movsw
    mov cl, 0x0b
    add [bx], dx
    les di, [bx]
    lea sp, [bx+di]
    inc word [si]
    cmp word [si], 0x0520
    jz label2
    xor si, si
    stosw
    dec di
    call far [bx]
label2:
    int3