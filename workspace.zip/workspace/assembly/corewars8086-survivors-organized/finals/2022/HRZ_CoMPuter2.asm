    mov si, ax
    mov bx, ax
    add ax, 0x0097
    mov [bx], ax
    push cs
    pop es
    mov ax, 0xd4ff
    mov dx, 0xcc0e
    mov cx, bx
    mov bx, 0x26ff
    int 0x87
    mov [si+0x0098], si
    mov bp, si
    add bp, 0x006f
    mov bx, 0xe33f
    mov cx, 0x0098
    rep movsw
    db 0x9B, 0x9B ;$1 nrg
    xchg ax, [0xb80f]
    xchg si, [0xba0f]
    xchg di, [0xb60f]
    xchg dx, [0xbc0f]
    push ax
    push si
    push di
    push dx
    mov cl, 0x04
loop1:
    xor si, si
    pop ax
    sub ax, 0xbec3
    mul bx
    mov di, 0xfaeb
    xor di, ax
    add di, 0x004c
    mov byte [di], 0xb9
    mov [di+0x01], bp
    mov word [di+0x03], 0xe1ff
    loop loop1
    push cs
    pop ss
    mov cx, 0x5153
    mov bx, 0xd4ff
    mov sp, bp
    sub sp, 0x006f
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov sp, ax
    mov ax, 0x891f
    mov dx, 0xd1dd
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    mov dx, 0x5350
    mov cx, 0x5251
    mov bx, 0xff90
    mov ax, 0x90d4
    push ax
    push bx
    push cx
    push dx
    nop
    call sp
    nop
    mov bp, 0x0000
    push ax
    add bp, 0x006f
    mov bx, 0xe33f
    mov cx, 0x0097
    rep movsw
    db 0x9B, 0x9B ;$1 nrg
    xchg dx, [0xbc0f]
    xchg di, [0xb60f]
    xchg si, [0xba0f]
    xchg ax, [0xb80f]
    push dx
    push di
    push si
    push ax
    mov cl, 0x04
loop2:
    xor si, si
    pop ax
    sub ax, 0xbec3
    mul bx
    mov di, 0xfaeb
    xor di, ax
    add di, 0x004c
    mov byte [di], 0xb9
    mov [di+0x01], bp
    mov word [di+0x03], 0xe1ff
    loop loop2
    push cs
    pop ss
    push cs
    pop es
    mov ax, 0xe8e0
    mov dx, 0xcccc
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    mov cx, 0x5153
    mov bx, 0xd4ff
    pop ax
    mov sp, ax
    push bx
    push cx
    call sp