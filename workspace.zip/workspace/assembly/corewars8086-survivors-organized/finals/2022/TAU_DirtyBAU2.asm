    mov bx, [0xe129]
    mov cx, [0xe129]
    mov word [bx+0x29], 0x0000
    xchg bx, cx
    mov word [bx+0x29], 0x0000
    mov word [bx+0x00b5], 0xcccc
    xchg bx, cx
    mov word [bx+0x00b5], 0xcccc
    jmp label1
    xchg bx, cx
    mov word [bx+0x29], 0x0000
    mov word [bx+0x00b5], 0xcccc
    xchg bx, cx
    mov word [bx+0x00b5], 0xcccc
    push ax
    mov dx, ax
    mov ax, 0xe33f
    mov cx, 0x00ab
    loop $
    mov cx, dx
    mul word [0xbc0f]
    add ax, 0x2503
    xor ax, 0xfaeb
    xchg cx, ax
    mov bx, ax
    add ax, 0x0158
    lea bx, [bx+0x015b]
    mov [bx], ax
    mov ax, bx
    mov bx, cx
    add bx, 0x004e
label1:
    mov cx, 0x001e
    loop $
    push ax
    push ds
    push es
    pop ds
    mov dl, [0x0052]
    mov cl, 0x04
    shl dx, cl
    add dl, 0x9c
    pop ds
    mov bx, ax
    mov dh, 0x02
    mov [bx+0x0199], dx
    mov bx, ax
    mov dh, ah
    add dh, 0x41
    mov dl, 0x1c
    mov [bx+0x0175], dx
    mov dx, ax
    mov ax, 0xe33f
    mov cx, 0x00a5
    loop $
    mov cx, dx
    mul word [0xbc0f]
    add ax, 0x2503
    xor ax, 0xfaeb
    xchg cx, ax
    mov bx, ax
    add ax, 0x0158
    lea bx, [bx+0x015b]
    mov [bx], ax
    mov ax, bx
    mov bx, cx
    add bx, 0x004e
    mov [bx], ax
    mov word [bx-0x02], 0x26ff
    pop ax
    mov cl, 0x08
    add ax, 0x0104
    mov si, ss
    mov bx, ss
    and bx, 0x0010
    lea si, [bx+si+0x04]
    xchg si, ax
    mov es, ax
    mov di, 0x0066
    mov cl, 0x2a
    mov ch, 0x00
    rep movsw
    mov ds, ax
    lea dx, [si+0x3ea8]
    mov dl, 0x0d
    add dx, bp
    mov dl, 0xfe
    mov bx, dx
    add bx, 0x001f
    push cs
    pop es
    push cs
    pop ss
    mov si, 0x0084
    mov [0x00ba], ax
    mov ax, 0xa5a5
    lea di, [bx-0x01]
    lea sp, [bx+0x68]
    mov bp, di
    mov cl, 0x16
    movsw
    jmp bp
    rep movsw
    mov cx, 0x0404
    lea sp, [bx+0x64]
    mov bx, di
label2:
    pop di
    pop bp
    shl bp, cl
    mov [bp+di-0x02], ax
    sub sp, 0x0003
    dec ch
    jnz label2
    mov di, bx
    rep movsw
    mov cl, 0x14
    rep movsw
    add di, 0x003b
    movsw
    sub di, 0x0068
    mov bx, di
    movsw
    mov cx, [si+0x04]
    lds si, [si]
    add dh, 0x40
    nop
label3:
    pop di
    pop bp
    shl bp, cl
    mov [bp+di-0x02], ax
    add sp, [bx]
    mov di, [bx]
    cmp [bx+si], di
    jz label3
    mov ds, cx
    mov di, dx
    mov cx, 0x000d
    movsw
    jmp dx
    add dx, [bx+0x03]
    push di
    db 0x66
    add [bx+si], al
    adc [0xb807], dl
    db 0xFF, 0xFF
    mov si, ax
    add si, 0x0037
    xor di, di
    mov cx, 0x001f
    rep movsw
    push ss
    pop ds
    xor si, si
    push cs
    pop es
    push cs
    pop ss
    mov dx, 0xa5f3
    mov ax, 0xffff
    db 0x83, 0xE8, 0x1E ;$1 sub ax, 0x001e
    db 0x83, 0xE8, 0x3E ;$1 sub ax, 0x003e
    mov sp, ax
    mov di, sp
    mov ax, 0x218d
    mov cx, 0x001e
    loop $
    mov cx, 0x001f
    push dx
    jmp sp
    lea bp, [di+0x0087]
    and di, 0xff00
    add di, 0x1111
    mov bx, [bp+0x00]
    add sp, 0x4002
    mov cx, 0x0300
    cmp word [si], 0x5337
    jle end
loop1:
    inc word [si]
    xor ax, 0xa37c
    stosw
    add di, 0x000e
    cmp [bp+0x00], bx
    jnz label4
    loop loop1
    mov [bp+0x00], cx
    mov cx, 0x0032
    loop $
label4:
    xor si, si
    mov cx, 0x001f
    mov di, sp
    push dx
    jmp sp
end: