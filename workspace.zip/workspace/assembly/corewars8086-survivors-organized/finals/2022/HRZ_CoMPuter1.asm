    jmp label1
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    int3
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    int3
    push cx
    call sp
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    int3
    push cx
    call sp
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    int3
    push cx
    call sp
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    int3
    push cx
    call sp
label1:
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    int3
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    int3
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    int3
    push cx
    call sp
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    int3
    push cx
    call sp
    int3
    push cs
    pop ss
    push cs
    pop es
    int3
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    push bx
    push cx
    call sp
    push cs
    pop ss
    push cs
    pop es
    int3
    mov cx, 0x5153
    mov bx, 0xd4ff
    db 0x83, 0xC0, 0x0F ;$1 add ax, 0x000f
    mov sp, ax
    int3
    push cx
    call sp
    int3