    push es
    push cs
    pop es
    push ax
    int 0x86
    int 0x86
    mov ax, 0x3fb8
    mov dx, 0xb9e3
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop ax
    pop es
    push cs
    pop ss
    mov si, ax
    add si, word 0x003e
    mov cx, 0x000e
    rep movsw
    mov cx, 0x0040
    mov bp, 0x1000
    mov dx, ax
    mov dl, 0xa3
    mov bx, 0x0350
    mov ax, 0x0700
    push es
    pop ds
    mov word [bx+0x02], 0x0ffb
    jmp label1
    rep movsw
    push ds
    pop es
    sub dx, bp
label1:
    mov [bx], dx
    les di, [bx]
    mov si, 0x0018
    movsw
    dec di
    add dx, ax
    mov sp, dx
    xor si, si
    mov cx, 0x0010
    call far [bx]