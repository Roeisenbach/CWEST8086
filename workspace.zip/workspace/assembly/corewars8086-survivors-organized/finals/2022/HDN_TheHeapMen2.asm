    jmp label2+1
loop1:
    call sp
    push cs
    int3
    nrg
    call far [bx]
    sub ax, 0x5fe3
    push ax
    mov cx, 0x0024
    mov [bx+0x00a0], di
    mov cx, 0x0019
    push ss
    movsw
    jmp ax
    movsw
    movsw
    jmp ax
    movsw
    movsw
    jmp ax
    movsw
    movsw
    movsw
    mov cx, 0x0015
    rep movsw
    mov [di], ax
label1:
    add [bp+0x703d], dl
    or dh, [bp+si-0x08]
    mov di, [bp+si]
    cmp di, [bp+0x00]
    jz label1+1
    mov di, ax
    movsw
    dec word [bx+di-0x5a39]
    jmp ax
    db 0xC7, 0xA5, 0xFF, 0xE0, 0xE8, 0x00 ;$4 mov word [di-0x1f01], 0x00e8
    add [bx+si], al
    rep movsw
    push ds
    mov word [si], 0x00ed
    mov word [si+0x02], 0x1000
    loopnz loop1
    movsw
    mov cx, 0x0017
    movsw
    rep movsw
    sub di, 0x0080
    mov bx, di
    add sp, [bx]
    pop di
    pop bp
    cmp bp, 0x10a5
    jnb label2+3
    shl bp, cl
label2:
    mov [0xc289], cx
    push es
    pop ds
    lodsw
    push cs
    mov bx, ax
    sub ax, 0x5fe3
    pop ds
    push ax
    push ds
    pop es
    mov word [bx+0x00dd], 0x15e9
    mov byte [bx+0x00df], 0x01
    lea di, [bx+0x01f5]
    mov cx, 0x0024
    mov si, dx
    mov [si+0x01bf], dx
    add si, 0x01b3
label3:
    rep movsw
    mov di, 0xb60f
    xchg di, [si-0x29]
    xchg di, [si-0x1d]
    mov di, 0xba0f
    xchg di, [si-0x21]
    xchg di, [si-0x25]
    mov word [si-0x02], 0xfef1
    sub si, 0x0004
    mov byte [si], 0x90
    mov si, dx
    mov di, 0x00a0
    mov cx, 0x0019
    push ss
    add si, 0x0111
    pop es
    push ss
    rep movsw
    push ds
    pop es
    push dx
    mov cx, 0x0008
    mov bx, 0x0000
loop2:
    mov word [bx], 0x1fff
    add bx, 0x2000
    loop loop2
    mov cx, 0x0020
    jmp label8
    pop ax
    mov si, [0xc781]
    mov word [si-0x14], 0xffff
    mov si, [0xc781]
    mov word [si-0x14], 0xffff
    mov si, [0x0011]
    pop ds
    mov si, 0x00a0
    pop ax
    mov di, ax
    mov dx, 0x0013
    pop ss
    movsw
    jmp ax
    movsw
    movsw
    movsw
    mov cx, 0x0015
    rep movsw
    mov bp, ax
    mov sp, ax
label4:
    add ax, 0x9600
    cmp ax, 0x0a70
    jb label4
    mov si, 0x00a0
    sub bp, 0x003c
    mov [bp+si], si
    mov [bp+0x00], si
    mov di, ax
label5:
    sub sp, dx
    push cx
    sub sp, dx
    push cx
    mov bx, [bp+si]
    cmp bx, [bp+0x00]
    jz label5
    movsw
    jmp ax
    call prcd1
prcd1:
    mov bx, ax
    pop ax
    push ss
    sub ax, 0x0145
    pop es
    mov cx, 0x001b
    mov si, ax
    mov di, 0x00ed
    add si, 0x017d
    rep movsw
    push ds
    mov si, di
    push es
    pop ds
    pop es
    mov word [si], 0x00ed
    push cs
    pop ss
    mov dx, ds
    mov word [si+0x02], 0x1000
    sub ax, 0x7343
    mov si, 0x00ed
    mov sp, ax
    add ax, bx
    mov di, ax
    movsw
    jmp ax
    movsw
    movsw
    mov cx, 0x0017
    movsw
    rep movsw
    sub di, 0x0080
    mov bx, di
    mov cx, 0x0004
    lds si, [si]
    sub ax, 0x7343
    mov [bx+si], si
    mov [bx], si
label6:
    add sp, [bx]
    pop di
    pop bp
    cmp bp, 0x10a5
    jnb label7
    shl bp, cl
    mov [bp+di-0x02], si
label7:
    mov bp, [bx]
    cmp [bx+si], bp
    jz label6
    mov di, ax
    mov ds, dx
    movsw
    jmp ax
    push ds
    push cs
    mov cx, 0x0084
    pop ds
label8:
    loop $
    mov di, 0xe33f
    mov dx, 0xcccc
    add dx, 0x0142
    mov cx, 0x0004
    mov [0xc781], dx
    nrg
    xchg ax, [0xbc0f]
    xchg si, [0xba0f]
    xchg bp, [0xb80f]
    xchg bx, [0xb60f]
    push ax
    push si
    push bp
    push bx
loop3:
    pop ax
    mul di
    mov si, 0x2503
    add si, ax
    xor si, 0xfaeb
    mov word [si+0x4c], 0x26ff
    loop loop3
    pop ds
    jmp label3