    xchg si, [0xe129]
    xchg di, [0xe129]
    jmp label2
    int3
    int3
    int3
    stosw
    int3
    int3
    int3
    stosw
    push dx
    movsw
    int3
    int3
    int3
    call far [bx]
    int3
    int3
    int3
    int3
    call far [bx]
    int3
    int3
    cmp di, 0xcccc
    jz label1
    mov di, si
label1:
    push cs
    pop es
    mov dx, 0xcccc
    int 0x86
    push ax
    mov cl, 0xcc
    mov ax, 0x5153
    mov dx, 0xd4ff
    int 0x87
    pop ax
    xor di, di
    mov si, 0xa5ab
    mov dx, 0xd401
    add ax, 0x00e6
    xchg si, ax
    push ss
    pop es
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    mov bp, 0x6465
    xor [bp-0x6465], bp
    xor [bp-0x6461], bp
loop1:
    movsw
    movsw
    xor [bp+di-0x6469], bp
    loop loop1
    xchg bp, bx
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov bp, 0x454e
    lea sp, [bp-0x0094]
    mov word [0x03fe], 0xaaaa
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x3c88
    push dx
    mov [bp+0x02ca], dx
    movsb
    jmp bp
label2:
    cmp di, 0xcccc
    jz label3
    cmp di, 0x0000
    jnz label4
label3:
    mov di, si
label4:
    push es
    push cs
    pop es
    mov dx, 0xcccc
    int 0x86
    xor di, di
    mov si, 0xa5ab
    mov dx, 0xd401
    add ax, 0x0111
    xchg si, ax
    push ss
    pop es
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    mov bp, 0x6465
    xor [bp-0x6465], bp
    xor [bp-0x6461], bp
loop2:
    movsw
    movsw
    xor [bp+di-0x6469], bp
    loop loop2
    push ax
    push cx
    push dx
    push es
    push cs
    pop es
    mov cl, 0xcc
    mov ax, 0xcccc
    mov dx, 0xffcc
    int 0x87
    pop es
    pop dx
    pop cx
    pop ax
    pop ax
    xchg bp, bx
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov bp, 0x7f4e
    lea sp, [bp-0x0094]
    mov word [0x03fe], 0xaaaa
    mov di, bp
    mov ax, 0xa552
    mov si, 0x0008
    mov dx, 0x3c88
    push dx
    mov [bp+0x02ca], dx
    movsb
    jmp bp
    db 0xC0
    db 0xC1
    movsw
    mov [bp+si-word 0x0040], cx
    in ax, 0xc0
    db 0xC1
    mov cl, 0x06
    db 0xC0
    db 0xC1
    rep movsw
    out dx, al
    cli
    retf 0x5c02
    cli
    db 0x6A
    call word [bx+si]
    db 0x66
    xor si, si
    db 0xC0
    db 0xC1
    mov cl, 0x0d
    db 0xC0
    xchg di, ax
    movsw
    cmp [bp-0x6117], si
    db 0xC7, 0x67, 0x11, 0x08, 0x81 ;$4 mov word [bx+0x11], 0x8108
    mov [si+0x0a], ah
    or word [bp+0x0304], 0xa081
    db 0x64
    add ax, 0x8a89
    db 0xC1
    jmp bp
    add cx, ax
    mov cl, 0x0c
    db 0xC0
    xchg di, ax
    movsw
    mov cx, 0x6161
loop3:
    xchg bx, sp
    in al, dx
    mov ss, [bp+0x385e]
    mov bh, 0xe5
    mov [bx], di
    cwd
    sub sp, 0x0066
    call 0xf297:0x75cd
    movsw
    movsw
    aam 0x62
    movsw
    db 0xF3, 0xC0
    jcxz loop3
    and word [bp+0x00ba], 0xedb8
    pop ax
    mov bp, dx
    db 0xC0
    db 0xC1
    mov cl, 0x05
    db 0xC0
    db 0xC1
    rep movsw
    aam 0x5e
    xchg bx, di
    cbw
    xchg di, ax
    stosw
    mov [bp+si-0x5a68], di
    movsw
    aam 0x63
    movsw
    movsw
    xchg si, ax
    db 0xC1
    mov [bp-0x64f1], ax
    mov [bp+0x66af], ax
    xchg dx, ax
    mov ax, 0xc137
    xor si, si
    db 0xC0
    cmp di, 0xcccc
    jz label5
    mov di, si
label5:
    push cs
    pop es
    mov dx, 0xcccc
    int 0x86
    push ax
    mov cl, 0xcc
    mov ax, 0x5153
    mov dx, 0xd4ff
    int 0x87
    pop ax
    xor di, di
    mov si, 0xa5ab
    mov dx, 0xd401
    add ax, 0x00e6
    xchg si, ax
    push ss
    pop es
    movsw
    movsw
    movsw
    movsw
    int 0x86
    sub di, 0x00b8
    mov cl, 0x47
    mov bp, 0x6465
    xor [bp-0x6465], bp
    xor [bp-0x6461], bp
loop4:
    movsw
    movsw
    xor [bp+di-0x6469], bp
    loop loop4
    xchg bp, bx
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov bp, 0xec4e
    lea sp, [bp-0x0094]
    db 0xC7, 0x06, 0xFE  ; mov word [0x00fe], 0x0000