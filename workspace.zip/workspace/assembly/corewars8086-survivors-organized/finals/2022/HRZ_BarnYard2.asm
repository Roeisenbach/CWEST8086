    nop
    nop
    db 0xE9, 0x21, 0x00 ;$1 jmp 38
    mov cx, 0x0688
    mov word [0xfdef], 0x1cff
    mov word [0xfded], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edf
    mov word [di], 0x1dfd
    mov word [di+0x02], 0x1dff
    call far [di]
    mov cx, 0x0688
    mov word [0xfde9], 0xcc29
    mov word [0xfdeb], 0x1cff
    mov word [0xfdef], 0x1cff
    mov word [0xfded], 0xcc29
    mov word [0xfdf1], 0xcc29
    mov word [0xfdf3], 0x1cff
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edf
    mov word [di], 0x1dfd
    mov word [di+0x02], 0x1dff
    call far [di]
    mov cx, 0x0688
    mov word [0xfdef], 0x1cff
    mov word [0xfded], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x1edf
    mov word [di], 0x1dfd
    mov word [di+0x02], 0x1dff
    call far [di]