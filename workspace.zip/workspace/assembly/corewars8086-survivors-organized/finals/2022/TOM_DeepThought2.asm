    stosw
    jmp label1
    jmp label4
    jmp label2
    jmp label3
prcd1:
    sub ax, 0xbec3
    mov bx, 0xe33f
    mul bx
    xor ax, 0xfaeb
    mov bx, ax
    ret
label1:
    mov cl, 0xa3
    loop $
    push ax
    mov ax, 0xcccc
    mov cx, 0xcccc
    db 0x9B, 0x9B ;$1 nrg
    xchg cx, [0xba0f]
    xchg ax, [0xbc0f]
    call prcd1
    pop ax
    db 0x83, 0xC0, 0x06 ;$1 add ax, 0x0006
    mov [0xe172], ax
    mov word [bx+0x4e], 0xe172
    mov word [bx+0x4c], 0x26ff
    push ax
    mov ax, cx
    call prcd1
    pop ax
    db 0x83, 0xC0, 0x02 ;$1 add ax, 0x0002
    mov [0x1234], ax
    mov word [bx+0x4e], 0x1234
    mov word [bx+0x4c], 0x26ff
    mov di, 0x0000
    mov cx, 0xee04
    mov word [0xf0ef], 0x1cff
    mov word [0xf0ed], 0xcc29
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x11df
    mov word [di], 0x10fd
    mov word [di+0x02], 0x1dff
    call far [di]
label2:
    mov word [0xddef], 0x1cff
    mov word [0xdded], 0xcc29
    mov cx, 0xee04
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x817d
    mov word [si], 0x0dfd
    mov word [si+0x02], 0x1cff
    call far [si]
label3:
    mov word [0xeeef], 0x1cff
    mov word [0xeeed], 0xcc29
    mov cx, 0xee04
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x593f
    mov word [si], 0x1efd
    mov word [si+0x02], 0x1cff
    call far [si]
    mov word [0xd3ed], 0x1cff
    mov word [0xd3eb], 0xcc29
    mov cx, 0xee04
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x9583
    mov word [si], 0x03fb
    mov word [si+0x02], 0x1cff
    call far [si]
    mov word [0xcffb], 0x1cff
    mov word [0xcff9], 0xcc29
    mov cx, 0xee04
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x575e
    mov word [si], 0x0009
    mov word [si+0x02], 0x1cff
    call far [si]
label4:
    mov si, cx
    mov cx, 0x009c
    loop $
    push ax
    mov ax, 0xcccc
    mov cx, 0xcccc
    db 0x9B, 0x9B ;$1 nrg
    xchg cx, [0xb60f]
    xchg ax, [0xb80f]
    call prcd1
    pop ax
    add di, 0x00bc
    mov [0x2222], di
    mov word [bx+0x4e], 0x2222
    mov word [bx+0x4c], 0x26ff
    push ax
    mov ax, cx
    call prcd1
    pop ax
    add di, 0x0021
    mov [0x3333], di
    mov word [bx+0x4e], 0x3333
    mov word [bx+0x4c], 0x26ff
    mov word [0xdfef], 0x1cff
    mov word [0xdfed], 0xcc29
    mov ss, si
    mov si, 0x0000
    mov di, 0x0000
    mov cx, 0xee04
    push ss
    pop ds
    push cs
    pop ss
    mov sp, 0x00df
    mov word [si], 0x0ffd
    mov word [si+0x02], 0x1cff
    call far [si]