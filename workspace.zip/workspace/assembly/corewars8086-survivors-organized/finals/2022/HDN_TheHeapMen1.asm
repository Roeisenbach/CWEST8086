    jmp label3
    int3
    int3
    int3
    stosw
    mov si, ax
    add si, word 0x0044
    mov cx, 0x000e
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x87
    pop ax
    mov di, ax
    add di, 0x0a94
    mov bx, 0x0020
    mov [bx], ax
    mov word [bx+0x02], 0x10a5
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0a52
    mov si, 0x0004
    mov cx, 0x000c
    rep movsw
    mov ax, 0xf596
    mov dx, 0x10a5
    mov es, dx
    mov cs, dx
    rep movsw
label1:
    add word [bx], 0x1900
    add sp, 0x1b00
    cmp [bx], ax
    ja label1
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0002
    mov cx, 0x000c
    call far [bx]
    call far [bx]
    int3
    int3
    int3
    stosw
    mov si, ax
    add si, word 0x0044
    mov cx, 0x000e
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x87
    pop ax
    mov di, ax
    add di, 0x0a94
    mov bx, 0x0020
    mov [bx], ax
    mov word [bx+0x02], 0x10a5
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0a52
    mov si, 0x0004
    mov cx, 0x000c
    rep movsw
    mov ax, 0xf596
    mov dx, 0x10a5
    mov es, dx
    mov cs, dx
    rep movsw
label2:
    add word [bx], 0x1900
    add sp, 0x1b00
    cmp [bx], ax
    ja label2
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0002
    mov cx, 0x000c
    call far [bx]
    call far [bx]
    int3
    int3
    int3
label3:
    stosw
    mov si, ax
    add si, 0x0110
    mov cx, 0x000e
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x87
    pop ax
    mov di, ax
    add di, 0x0b60
    mov bx, 0x0020
    mov [bx], ax
    mov word [bx+0x02], 0x10a5
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0a52
    mov si, 0x0004
    mov cx, 0x000c
    rep movsw
    mov ax, 0xf596
    mov dx, 0x10a5
    mov es, dx
    mov cs, dx
    rep movsw
label4:
    add word [bx], 0x1900
    add sp, 0x1b00
    cmp [bx], ax
    ja label4
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0002
    mov cx, 0x000c
    call far [bx]
    call far [bx]
    int3
    int3
    int3
    stosw
    mov si, ax
    add si, word 0x0044
    mov cx, 0x000e
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x87
    pop ax
    mov di, ax
    add di, 0x0a94
    mov bx, 0x0020
    mov [bx], ax
    mov word [bx+0x02], 0x10a5
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0a52
    mov si, 0x0004
    mov cx, 0x000c
    rep movsw
    mov ax, 0xf596
    mov dx, 0x10a5
    mov es, dx
    mov cs, dx
    rep movsw
label5:
    add word [bx], 0x1900
    add sp, 0x1b00
    cmp [bx], ax
    ja label5
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0002
    mov cx, 0x000c
    call far [bx]
    call far [bx]
    int3
    int3
    int3
    stosw
    mov si, ax
    add si, word 0x0044
    mov cx, 0x000e
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push ax
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x87
    pop ax
    mov di, ax
    add di, 0x0a94
    mov bx, 0x0020
    mov [bx], ax
    mov word [bx+0x02], 0x10a5
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0a52
    mov si, 0x0004
    mov cx, 0x000c
    rep movsw
    mov ax, 0xf596
    mov dx, 0x10a5
    mov es, dx
    mov cs, dx
    rep movsw
label6:
    add word [bx], 0x1900
    add sp, 0x1b00
    cmp [bx], ax
    ja label6
    mov di, [bx]
    movsw
    dec di
    mov si, 0x0002
    mov cx, 0x000c
    call far [bx]
    call far [bx]
    int3
    int3
    int3