    mov [0x75ce], cs
    add ax, 0x001b
    mov [0x75cc], ax
    mov si, ax
    nop
    add [si+word 0x0005], si
    mov ax, 0xffee
    xchg bx, [di]
    add ax, bx
    jmp label1
    mov cl, 0x13
    loop $
    mov si, 0x0000
    mov ax, 0x1000
    jmp label2
    add [si+0x08], ax
    mov dx, ss
    mov es, dx
    add si, word 0x0073
    xor di, di
    mov cx, 0x0011
    rep movsw
    mov ds, dx
    mov cx, cs
    mov ss, cx
    sub ax, 0x0500
    and al, 0x07
    sub al, 0x08
    mov ch, 0x0f
    mov cl, al
    shl al, 1
    shl al, 1
    shl al, 1
    shl al, 1
    mov sp, ax
    mov al, 0xa1
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cx
    mov di, ax
    sub sp, 0x055f
    mov es, cx
    xor si, si
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    sub di, 0x0200
    mov ax, 0xd401
    stosw
    mov ax, 0x1fff
    stosw
    sub di, 0x0003
    mov ax, 0x0d00
    mov dx, 0x27d0
    mov bp, 0x0800
    xor cx, cx
    call far [bx]
    movsw
    movsw
    mov cl, 0x0c
    rep movsw
    sub [bx], bp
    add ax, 0x5920
    sub sp, ax
    add dx, 0x0160
    mov di, [bx]
    movsw
    movsw
    sub di, 0x0003
    xor si, si
    call far [bx]
    call far [bx]
    add sp, dx
    call far [bx]
label1:
    add [si+0x08], ax
label2:
    mov dx, ss
    mov es, dx
    add si, word 0x0073
    xor di, di
    mov cx, 0x0011
    rep movsw
    mov ds, dx
    mov cx, cs
    mov ss, cx
    sub ax, 0x0500
    and al, 0x07
    sub al, 0x08
    mov ch, 0x0f
    mov cl, al
    shl al, 1
    shl al, 1
    shl al, 1
    shl al, 1
    mov sp, ax
    mov al, 0xa1
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cx
    mov di, ax
    sub sp, 0x055f
    mov es, cx
    xor si, si
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    sub di, 0x0200
    mov ax, 0xd401
    stosw
    mov ax, 0x1fff
    stosw
    sub di, 0x0003
    mov ax, 0x0d00
    mov dx, 0x27d0
    mov bp, 0x0800
    xor cx, cx
    call far [bx]
    movsw
    movsw
    mov cl, 0x0c
    rep movsw
    sub [bx], bp
    add ax, 0x5920
    sub sp, ax
    add dx, 0x0160
    mov di, [bx]
    movsw
    movsw
    sub di, 0x0003
    xor si, si
    call far [bx]
    call far [bx]
    add sp, dx
    call far [bx]
    add [si+0x08], ax
    mov dx, ss
    mov es, dx
    add si, word 0x0073
    xor di, di
    mov cx, 0x0011
    rep movsw
    mov ds, dx
    mov cx, cs
    mov ss, cx
    sub ax, 0x0500
    and al, 0x07
    sub al, 0x08
    mov ch, 0x0f
    mov cl, al
    shl al, 1
    shl al, 1
    shl al, 1
    shl al, 1
    mov sp, ax
    mov al, 0xa1
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cx
    mov di, ax
    sub sp, 0x055f
    mov es, cx
    xor si, si
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    sub di, 0x0200
    mov ax, 0xd401
    stosw
    mov ax, 0x1fff
    stosw
    sub di, 0x0003
    mov ax, 0x0d00
    mov dx, 0x27d0
    mov bp, 0x0800
    xor cx, cx
    call far [bx]
    movsw
    movsw
    mov cl, 0x0c
    rep movsw
    sub [bx], bp
    add ax, 0x5920
    sub sp, ax
    add dx, 0x0160
    mov di, [bx]
    movsw
    movsw
    sub di, 0x0003
    xor si, si
    call far [bx]
    call far [bx]
    add sp, dx
    call far [bx]
    and ax, 0xdd59
    db 0xF1
    aad 0xc9
    or ax, 0x85e1
    cmp [di], di
    db 0xD1, 0x35
    test ax, 0xc16d
    in ax, 0x19
    popf
    mov cl, 0x95
    mov bp, cx
    mov ax, [0xf945]
    std
    xchg cx, ax
    cmc
    db 0x69
    sub ax, 0xa581
    esc 0xd9
    pop bp
    jno 570
    dec cx
    lea sp, [bx+di+0x05]
    mov cx, 0x51bd
    mov ch, 0x29
    in ax, dx
    inc cx
    db 0x65
    cwd
    sbb ax, 0x1531
    or [di+0x21], cx
    lds di, [bx+di+0x7d]
    adc [di-0x17], si
    int3
    int3