    add ax, 0x000d
    push ds
    pop ss
    push cs
    pop es
    mov sp, ax
    sub sp, 0x0401
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add ax, 0x0005
    sub sp, 0x0088
    call ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    add ax, 0x2334
    db 0x3B, 0xE0 ;$1 cmp sp, ax
    jb label1
    mov sp, ax
    sub sp, 0x4768
label1:
    sub si, 0x0005
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov cl, 0x12
    rep movsw
    call ax