    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x0047
    mov cx, 0x000a
    rep movsw
    push es
    pop ds
    mov dx, 0x10a5
    push dx
    pop es
    push cs
    pop ss
    mov di, 0xccaa
    mov sp, 0xba64
    db 0x33, 0xF6 ;$1 xor si, si
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    mov bx, 0x0190
    mov ax, [bx]
    add di, ax
    db 0x03, 0xE0 ;$1 add sp, ax
    mov bx, 0x0064
    sub di, 0x0002
    nop
    nop
    nop
    mov ax, 0xd429
    stosw
    mov ax, 0x1fff
    stosw
    dec di
    mov cx, 0x2022
    mov dx, 0x0ee8
    call far [bx]
    movsw
    movsb
    sub [bx], cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov di, [bx]
    stosw
    dec di
    db 0x33, 0xF6 ;$1 xor si, si
    call far [bx]
    db 0x00  ; add [bx+si], al