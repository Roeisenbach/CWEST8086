    jmp label10
    int3
    int3
    int3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label1:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label2
    mov [bx], dl
label2:
    xchg dh, dl
    jmp label1
    int3
    int3
    int3
label3:
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label4:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label5
    mov [bx], dl
label5:
    xchg dh, dl
    jmp label4
    int3
    int3
    int3
    jmp label10
    db 0x8B, 0xF0 ;$1 mov si, ax
    push es
    push ds
    pop es
    mov ax, 0xa5f3
    mov dx, 0xda8e
    int 0x87
    pop es
    add si, word 0x003a
    push si
    mov cx, 0x0010
    rep movsw
    add di, 0x0052
    mov cx, 0x001f
    rep movsw
    mov di, 0x0020
    mov ax, 0xa4a4
    mov cx, 0x0029
    rep stosw
    mov bp, 0x007d
    mov si, 0x00de
    pop di
    push ds
    push es
    pop ds
    pop es
    movsw
    movsw
    movsw
    movsw
    pop di
    scasw
    pop di
    movsw
    movsw
    movsw
    movsw
    jz label6
    db 0x8B, 0xF5 ;$1 mov si, bp
label6:
    movsw
    movsw
    movsw
    pop di
    scasw
    pop di
    movsw
    movsw
    movsw
    movsw
    jz label7
    db 0x8B, 0xF5 ;$1 mov si, bp
label7:
    movsw
    movsw
    db 0x2B, 0xE1 ;$1 sub sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    pop di
    movsb
    jmp label3
    movsw
    movsw
    movsw
    mov cx, 0x000e
    rep movsw
    sub sp, 0x0004
    pop bx
    pop ax
    push bp
    cmp ax, bx
    mov bp, 0x0001
    ja label9
    not bp
label8:
    add di, 0x0e0e
label9:
    sub di, 0x07b3
    movsb
    dec di
    jmp di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov cx, 0x001a
    rep movsw
    push es
    push di
    push ds
    push es
label10:
    db 0x8B, 0xF0 ;$1 mov si, ax
    push es
    push ds
    pop es
    mov ax, 0xa5f3
    mov dx, 0xda8e
    int 0x87
    pop es
    add si, 0x0105
    push si
    mov cx, 0x0010
    rep movsw
    add di, 0x0052
    mov cx, 0x001f
    rep movsw
    mov di, 0x0020
    mov ax, 0xa4a4
    mov cx, 0x0029
    rep stosw
    mov bp, 0x007d
    mov si, 0x00de
    pop di
    push ds
    push es
    pop ds
    pop es
    movsw
    movsw
    movsw
    movsw
    pop di
    scasw
    pop di
    movsw
    movsw
    movsw
    movsw
    jz label11
    db 0x8B, 0xF5 ;$1 mov si, bp
label11:
    movsw
    movsw
    movsw
    pop di
    scasw
    pop di
    movsw
    movsw
    movsw
    movsw
    jz label12
    db 0x8B, 0xF5 ;$1 mov si, bp
label12:
    movsw
    movsw
    db 0x2B, 0xE1 ;$1 sub sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    pop di
    movsb
    jmp label8+1
    movsw
    movsw
    movsw
    mov cx, 0x000e
    rep movsw
    sub sp, 0x0004
    pop bx
    pop ax
    push bp
    cmp ax, bx
    mov bp, 0x0001
    ja label13
    not bp
    add di, 0x0e0e
label13:
    sub di, 0x07b3
    movsb
    dec di
    jmp di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov cx, 0x001a
    rep movsw
    push es
    push di
    push ds
    push es
    jmp label10
    db 0x8B, 0xF0 ;$1 mov si, ax
    push es
    push ds
    pop es
    mov ax, 0xa5f3
    mov dx, 0xda8e
    int 0x87
    pop es
    add si, word 0x003a
    push si
    mov cx, 0x0010
    rep movsw
    add di, 0x0052
    mov cx, 0x001f
    rep movsw
    mov di, 0x0020
    mov ax, 0xa4a4
    mov cx, 0x0029
    rep stosw
    mov bp, 0x007d
    mov si, 0x00de
    pop di
    push ds
    push es
    pop ds
    pop es
    movsw
    movsw
    movsw
    movsw
    pop di
    scasw
    pop di
    movsw
    movsw
    movsw
    movsw
    jz label14
    db 0x8B, 0xF5 ;$1 mov si, bp
label14:
    movsw
    movsw
    movsw
    pop di
    scasw
    pop di
    movsw
    movsw
    movsw
    movsw
    jz label15
    db 0x8B, 0xF5 ;$1 mov si, bp
label15:
    movsw
    movsw
    db 0x2B, 0xE1 ;$1 sub sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    pop di
    movsb
    jmp label13
    movsw
    movsw
    movsw
    mov cx, 0x000e
    rep movsw
    sub sp, 0x0004
    pop bx
    pop ax
    push bp
    cmp ax, bx
    mov bp, 0x0001
    ja label16
    not bp
    add di, 0x0e0e
label16:
    sub di, 0x07b3
    movsb
    dec di
    jmp di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov cx, 0x001a
    rep movsw
    push es
    push di
    push ds
    push es