    db 0x33, 0xFF ;$1 xor di, di
    mov [di], ax
    push cs
    pop ss
    mov sp, ax
    sub sp, 0x0100
    push cs
    pop es
    mov [si], cx
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov bx, 0xcccc
    mov cx, 0xcccc
    mov ax, 0xa5f3
    mov dx, 0x8eda
    int 0x87
    add di, 0x0100
    mov ax, cx
    db 0x8B, 0xD1 ;$1 mov dx, cx
    add di, 0x2000
    int 0x86
    add di, 0x2760
    int 0x86
    sub di, 0x4760
prcd1:
    mov bx, [di]
    mov [bx], cx
    movsw
    call prcd2
prcd2:
    movsw
    call prcd3
prcd3:
    movsw
    call prcd1
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label1:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label2
    mov [bx], dl
label2:
    xchg dh, dl
    jmp label1
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label3:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label4
    mov [bx], dl
label4:
    xchg dh, dl
    jmp label3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label5:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label6
    mov [bx], dl
label6:
    xchg dh, dl
    jmp label5
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label7:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label8
    mov [bx], dl
label8:
    xchg dh, dl
    jmp label7
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label9:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label10
    mov [bx], dl
label10:
    xchg dh, dl
    jmp label9
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label11:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label12
    mov [bx], dl
label12:
    xchg dh, dl
    jmp label11
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label13:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label14
    mov [bx], dl
label14:
    xchg dh, dl
    jmp label13
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label15:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label16
    mov [bx], dl
label16:
    xchg dh, dl
    jmp label15
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label17:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label18
    mov [bx], dl
label18:
    xchg dh, dl
    jmp label17
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label19:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label20
    mov [bx], dl
label20:
    xchg dh, dl
    jmp label19