    mov ax, 0x078b
    mov es, [0x75ce]
    mov dx, 0xcc3d
    mov cx, 0x2eff
    int 0x87
    call prcd2
    pop ax
    mov [si], ax
    mov dx, ss
    mov es, dx
    mov si, ax
    add si, word 0x0056
    mov cx, 0x0009
    rep movsw
    mov ds, dx
    mov dx, cs
    mov ss, dx
    sub ax, 0x1712
    and al, 0x07
    sub al, 0x08
    mov dl, al
    mov bh, ah
    mul dh
    mov dh, 0x0f
    mov ah, bh
    mov sp, ax
    mov al, 0xa3
    mov bx, 0x00ea
    mov [bx], ax
    mov [bx+0x02], dx
    mov di, ax
    sub sp, 0xf85d
    mov es, dx
    xor si, si
    mov ax, 0xcccc
    mov dx, ax
    sub di, 0x0200
    int 0x86
    int 0x86
    mov ax, 0x1fff
    stosw
    dec di
    mov bp, 0x0800
    call far [bx]
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    dec di
    xor si, si
    call far [bx]
    call far [bx]
    call prcd1
prcd1:
    pop ax
    mov [si], ax
    mov dx, ss
    mov es, dx
    mov si, ax
    add si, word 0x0056
    mov cx, 0x0009
    rep movsw
    mov ds, dx
    mov dx, cs
    mov ss, dx
    sub ax, 0x1712
    and al, 0x07
    sub al, 0x08
    mov dl, al
    mov bh, ah
    mul dh
    mov dh, 0x0f
    mov ah, bh
    mov sp, ax
    mov al, 0xa3
    mov bx, 0x00ea
    mov [bx], ax
    mov [bx+0x02], dx
    mov di, ax
    sub sp, 0xf85d
    mov es, dx
    xor si, si
    mov ax, 0xcccc
    mov dx, ax
    sub di, 0x0200
    int 0x86
    int 0x86
    mov ax, 0x1fff
    stosw
    dec di
    mov bp, 0x0800
    call far [bx]
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    dec di
    xor si, si
    call far [bx]
    call far [bx]
    call prcd2
prcd2:
    pop ax
    mov [si], ax
    mov dx, ss
    mov es, dx
    mov si, ax
    add si, 0x012c
    mov cx, 0x0009
    rep movsw
    mov ds, dx
    mov dx, cs
    mov ss, dx
    sub ax, 0x1712
    and al, 0x07
    sub al, 0x08
    mov dl, al
    mov bh, ah
    mul dh
    mov dh, 0x0f
    mov ah, bh
    mov sp, ax
    mov al, 0xa3
    mov bx, 0x00ea
    mov [bx], ax
    mov [bx+0x02], dx
    mov di, ax
    sub sp, 0xf85d
    mov es, dx
    xor si, si
    mov ax, 0xcccc
    mov dx, ax
    sub di, 0x0200
    int 0x86
    int 0x86
    mov ax, 0x1fff
    stosw
    dec di
    mov bp, 0x0800
    call far [bx]
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    dec di
    xor si, si
    call far [bx]
    call far [bx]
    call prcd3
prcd3:
    pop ax
    mov [si], ax
    mov dx, ss
    mov es, dx
    mov si, ax
    add si, word 0x0056
    mov cx, 0x0009
    rep movsw
    mov ds, dx
    mov dx, cs
    mov ss, dx
    sub ax, 0x1712
    and al, 0x07
    sub al, 0x08
    mov dl, al
    mov bh, ah
    mul dh
    mov dh, 0x0f
    mov ah, bh
    mov sp, ax
    mov al, 0xa3
    mov bx, 0x00ea
    mov [bx], ax
    mov [bx+0x02], dx
    mov di, ax
    sub sp, 0xf85d
    mov es, dx
    xor si, si
    mov ax, 0xcccc
    mov dx, ax
    sub di, 0x0200
    int 0x86
    int 0x86
    mov ax, 0x1fff
    stosw
    dec di
    mov bp, 0x0800
    call far [bx]
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    dec di
    xor si, si
    call far [bx]
    call far [bx]
    and ax, 0xdd59
    db 0xF1
    aad 0xc9
    or ax, 0x85e1
    cmp [di], di
    db 0xD1, 0x35
    test ax, 0xc16d
    in ax, 0x19
    popf
    mov cl, 0x95
    mov bp, cx
    mov ax, [0xf945]
    std
    xchg cx, ax
    cmc
    db 0x69
    sub ax, 0xa581
    esc 0xd9
    pop bp
    jno 565
    dec cx
    lea sp, [bx+di+0x05]
    mov cx, 0x51bd
    mov ch, 0x29
    in ax, dx
    inc cx
    db 0x65
    cwd
    sbb ax, 0x1531
    or [di+0x21], cx
    lds di, [bx+di+0x7d]
    adc [di-0x17], si
    lodsw
    add [di], sp
    pop cx
    esc 0xdd
    int3
    int3