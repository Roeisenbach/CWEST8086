    jmp label7
    int3
    int3
    int3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label1:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label2
    mov [bx], dl
label2:
    xchg dh, dl
    jmp label1
    int3
    int3
    int3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label3:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label4
    mov [bx], dl
label4:
    xchg dh, dl
    jmp label3
    int3
    int3
    int3
    jmp label7
    db 0x8B, 0xF0 ;$1 mov si, ax
    push es
    push ds
    pop es
    mov ax, 0xa5f3
    mov dx, 0xda8e
    int 0x87
    pop es
    add si, word 0x002a
    push si
    mov di, 0x00b0
    mov cx, 0x0032
    rep movsw
    mov bp, 0x007d
    mov si, 0x00de
    pop di
    push ds
    push es
    pop ds
    pop es
    movsw
    pop ds
    sub bx, 0x0003
    mov cx, 0x0005
loop1:
    mov ax, [bx+0x02]
    mov dx, 0x0010
    mul dx
    add ax, [bx]
    db 0x12, 0xD6 ;$1 adc dl, dh
    dec dx
    jnz label5
    les di, [bx]
    sub di, 0x0002
    mov ax, 0xcccc
    dec bp
    stosw
label5:
    inc bx
    loop loop1
    dec bp
    jnz label6
    mov di, bx
    int 0x86
label6:
    pop ds
    pop di
    pop es
    pop bp
    movsw
    movsw
    mov cx, 0x0015
    movsw
    movsw
    movsw
    rep movsw
    mov ax, 0xffff
    mov cx, ds
    push es
    pop ds
    mov bx, di
    add bx, 0x0015
    push bx
    sub bx, 0x0415
    mov [bx], ax
    push bx
    add bx, 0x0407
    push bx
    add bx, 0x03f5
    mov [bx], ax
    push bx
    push di
    add sp, 0x0002
    mov ds, cx
    mov cx, 0x000a
    db 0x33, 0xF6 ;$1 xor si, si
    movsb
label7:
    db 0x8B, 0xF0 ;$1 mov si, ax
    push es
    push ds
    pop es
    mov ax, 0xa5f3
    mov dx, 0xda8e
    int 0x87
    pop es
    add si, 0x00eb
    push si
    mov di, 0x00b0
    mov cx, 0x0032
    rep movsw
    mov bp, 0x007d
    mov si, 0x00de
    pop di
    push ds
    push es
    pop ds
    pop es
    movsw
    pop ds
    sub bx, 0x0003
    mov cx, 0x0005
loop2:
    mov ax, [bx+0x02]
    mov dx, 0x0010
    mul dx
    add ax, [bx]
    db 0x12, 0xD6 ;$1 adc dl, dh
    dec dx
    jnz label8
    les di, [bx]
    sub di, 0x0002
    mov ax, 0xcccc
    dec bp
    stosw
label8:
    inc bx
    loop loop2
    dec bp
    jnz label9
    mov di, bx
    int 0x86
label9:
    pop ds
    pop di
    pop es
    pop bp
    movsw
    movsw
    mov cx, 0x0015
    movsw
    movsw
    movsw
    rep movsw
    mov ax, 0xffff
    mov cx, ds
    push es
    pop ds
    mov bx, di
    add bx, 0x0015
    push bx
    sub bx, 0x0415
    mov [bx], ax
    push bx
    add bx, 0x0407
    push bx
    add bx, 0x03f5
    mov [bx], ax
    push bx
    push di
    add sp, 0x0002
    mov ds, cx
    mov cx, 0x000a
    db 0x33, 0xF6 ;$1 xor si, si
    movsb
    jmp label7
    db 0x8B, 0xF0 ;$1 mov si, ax
    push es
    push ds
    pop es
    mov ax, 0xa5f3
    mov dx, 0xda8e
    int 0x87
    pop es
    add si, word 0x002a
    push si
    mov di, 0x00b0
    mov cx, 0x0032
    rep movsw
    mov bp, 0x007d
    mov si, 0x00de
    pop di
    push ds
    push es
    pop ds
    pop es
    movsw
    pop ds
    sub bx, 0x0003
    mov cx, 0x0005
loop3:
    mov ax, [bx+0x02]
    mov dx, 0x0010
    mul dx
    add ax, [bx]
    db 0x12, 0xD6 ;$1 adc dl, dh
    dec dx
    jnz label10
    les di, [bx]
    sub di, 0x0002
    mov ax, 0xcccc
    dec bp
    stosw
label10:
    inc bx
    loop loop3
    dec bp
    jnz label11
    mov di, bx
    int 0x86
label11:
    pop ds
    pop di
    pop es
    pop bp
    movsw
    movsw
    mov cx, 0x0015
    movsw
    movsw
    movsw
    rep movsw
    mov ax, 0xffff
    mov cx, ds
    push es
    pop ds
    mov bx, di
    add bx, 0x0015
    push bx
    sub bx, 0x0415
    mov [bx], ax
    push bx
    add bx, 0x0407
    push bx
    add bx, 0x03f5
    mov [bx], ax
    push bx
    push di
    add sp, 0x0002
    mov ds, cx
    mov cx, 0x000a
    db 0x33, 0xF6 ;$1 xor si, si
    movsb