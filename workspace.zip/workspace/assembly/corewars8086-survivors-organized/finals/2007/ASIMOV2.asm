    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x004e
    mov cx, 0x000a
    rep movsw
    push es
    pop ds
    mov dx, 0x10a5
    push dx
    pop es
    push cs
    pop ss
    mov di, 0x68aa
    mov sp, 0x620e
    db 0x33, 0xF6 ;$1 xor si, si
    db 0x33, 0xD2 ;$1 xor dx, dx
    mov bx, 0x0040
    div bx
    db 0x33, 0xD2 ;$1 xor dx, dx
    mul bx
    mov bx, 0x0190
    mov [bx], ax
    add di, ax
    db 0x03, 0xE0 ;$1 add sp, ax
    mov bx, 0x0064
    sub di, 0x0002
    mov word [bx+0x02], 0x10a5
    mov [bx], di
    mov ax, 0xd429
    stosw
    mov ax, 0x1fff
    stosw
    dec di
    mov cx, 0x2022
    mov dx, 0x0ee8
    call far [bx]
    movsw
    movsb
    sub [bx], cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov di, [bx]
    stosw
    dec di
    db 0x33, 0xF6 ;$1 xor si, si
    call far [bx]
    db 0x00  ; add [bx+si], al