    push es
    pop bp
    push cs
    pop es
    mov dx, 0xc180
    mov bx, 0xe188
    xchg bx, ax
    int 0x87
    push es
    pop ss
    xchg bx, ax
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, word 0x0038
    mov bx, [bx]
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov di, bx
    sub di, 0x0002
    db 0x8B, 0xE7 ;$1 mov sp, di
    sub sp, 0x0700
    mov [di], bx
    push bp
    pop ds
    mov bx, 0x0004
    mov [bx], di
    mov [bx+0x02], cs
    add di, 0x0002
    int 0x86
    int 0x86
    call far [bx]