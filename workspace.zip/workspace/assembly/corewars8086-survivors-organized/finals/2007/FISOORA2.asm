    push ds
    pop es
    push ds
    pop ss
label1:
    db 0x8B, 0xF0 ;$1 mov si, ax
    cmp word [0x0100], 0xcb0f
    jnz label1
    mov ax, [0x0102]
    add ax, 0x0100
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov cx, 0x0060
    shr cx, 1
    rep movsw
    mov word [0x0100], 0xcccc
    mov cx, ax
    add cx, word 0x002b
    jmp cx
    mov dx, 0x0013
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, word 0x0060
    mov word [bx], 0x3e81
    mov word [bx+0x02], 0x0100
    mov word [bx+0x04], 0xcb0f
    mov word [bx+0x06], 0xf174
    mov word [bx+0x08], 0xd429
    mov word [bx+0x0a], 0x009a
    mov [bx+0x0b], bx
    mov [bx+0x0d], cs
    jmp bx
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add dx, 0x0004
    jmp dx