    push ds
    pop es
    mov [0x0102], ax
    mov word [0x0100], 0xcb0f
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov cx, 0x0064
    shr cx, 1
loop1:
    mov word [di-0x1000], 0x8989
    mov word [di+0x1000], 0x8989
    add di, 0x0002
    loop loop1
label1:
    mov cx, 0x0064
    shr cx, 1
    db 0x8B, 0xF8 ;$1 mov di, ax
loop2:
    cmp word [di-0x1000], 0x8989
    jnz label3
    cmp word [di+0x1000], 0x8989
    jnz label4
    add di, 0x0002
    loop loop2
    jmp label1
label2:
    db 0x8B, 0xF0 ;$1 mov si, ax
    db 0x03, 0xFA ;$1 add di, dx
    mov [0x0102], di
    mov word [0x0100], 0xcb0f
    db 0x8B, 0xC7 ;$1 mov ax, di
    mov cx, 0x0064
    shr cx, 1
    rep movsw
    jmp ax
label3:
    mov dx, 0xd8bc
    jmp label2
label4:
    mov dx, 0x2744
    jmp label2