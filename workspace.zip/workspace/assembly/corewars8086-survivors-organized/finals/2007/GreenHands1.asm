    db 0xE9, 0x06, 0x00 ;$1 jmp 9
    mov ax, ax
    mov ax, ax
    mov ax, ax
    db 0xE9, 0x06, 0x00 ;$1 jmp 18
    mov ax, ax
    mov ax, ax
    mov ax, ax
    db 0xE9, 0x04, 0x00 ;$1 jmp 25
    mov ax, ax
    mov ax, ax
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x7faa
    mov word [bx], 0xfeeb
    jmp bx