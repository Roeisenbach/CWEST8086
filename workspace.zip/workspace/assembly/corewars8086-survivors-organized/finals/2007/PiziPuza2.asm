    mov bx, 0x003b
    push cs
    pop ss
    db 0x33, 0xFF ;$1 xor di, di
    add bx, [di]
    push cs
    pop es
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    mov si, 0x011e
    db 0x03, 0xF3 ;$1 add si, bx
    mov di, bx
    sub di, 0x0160
    add di, 0xabcd
    int 0x86
    add di, 0xc43d
    int 0x86
    mov di, bx
    sub di, 0x0160
    mov dx, 0x0100
label1:
    db 0x8B, 0xCA ;$1 mov cx, dx
    add si, cx
    sub di, cx
loop1:
    dec si
    inc di
    mov [si], ax
    mov [di], ax
    loop loop1
    jmp label1
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xD0 ;$1 mov dx, ax
label2:
    add bx, 0x0102
    mov ax, [bx]
    cmp ax, 0xcccc
    jnz label3
    mov [bx], dl
label3:
    xchg dh, dl
    jmp label2