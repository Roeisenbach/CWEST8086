    add ax, 0x000d
    push ds
    pop ss
    push cs
    pop es
    mov sp, ax
    sub sp, 0x4768
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add ax, 0x0005
    sub sp, 0x0015
    call ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    add ax, 0x2334
    db 0x3B, 0xE0 ;$1 cmp sp, ax
    jb label1
    mov sp, ax
    sub sp, 0x4768
label1:
    sub si, 0x0005
    mov cl, 0x11
    rep movsw
    call ax