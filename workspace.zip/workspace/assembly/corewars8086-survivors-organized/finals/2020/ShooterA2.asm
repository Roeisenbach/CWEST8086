    les ax, [0x783d]
    int 0x86
    jmp label1
    add al, ch
    add [bx+si-0x3334], bh
    mov dx, 0xdc29
    int 0x87
    mov ax, dx
    xor di, di
    nop
    nop
    int 0x86
    mov bp, 0x0eeb
    push ss
    pop es
    xchg bp, ax
    int 0x86
    std
    sub di, 0x0002
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov si, 0xfffe
    mov ax, 0x0200
    mov bp, 0xa5f3
    mov bx, 0x5204
    add si, ax
    add sp, bx
    lea di, [bx+di+0x01fe]
    mov cl, 0x20
    mov bp, di
    movsw
    call bp
    inc ch
    push bp
    jmp sp
    add al, ch
    add [bx+si-0x3334], bh
    mov dx, 0xdc29
    int 0x87
    mov ax, dx
    xor di, di
    nop
    nop
    int 0x86
    mov bp, 0x0eeb
    push ss
    pop es
    xchg bp, ax
    int 0x86
    std
    sub di, 0x0002
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov si, 0xfffe
    mov ax, 0x0200
    mov bp, 0xa5f3
    mov bx, 0x5204
    add si, ax
    add sp, bx
    lea di, [bx+di+0x01fe]
    mov cl, 0x20
    mov bp, di
    movsw
    call bp
    inc ch
    push bp
    jmp sp
label1:
    mov dx, 0x8f49
    xor di, di
    xor ax, ax
    nop
    nop
    int 0x86
    call prcd1
prcd1:
    pop bx
    sub bx, 0x00a1
    add bx, 0x00ca
    mov [0x8f49], bx
    mov [0x8f4b], cs
    mov bx, 0xdfe7
    mov word [bx], 0x1dff
    mov bx, 0xea69
    mov word [bx], 0xcb89
    mov word [bx+0x02], 0x1fff
    mov sp, 0x0400
    jmp label2
    push ds
    pop es
    mov di, [di]
    add di, 0x0114
    mov ax, 0xcccc
    mov dx, 0xdc29
label2:
    mov bp, 0x0eeb
    push ss
    pop es
    call prcd2
prcd2:
    pop si
    mov ax, si
    add si, 0x009b
    xor di, di
    mov dx, 0x0eeb
    xchg bp, ax
    mov cx, 0x007f
    rep stosw
    push es
    push ds
    pop es
    mov ax, 0xcccc
    mov dx, 0xdc29
    int 0x87
    pop es
    std
    sub di, 0x0002
    mov cx, 0x000e
    rep movsw
    mov ax, 0x9090
    mov cl, 0x0b
    rep stosw
    lea si, [bp+0x00b7]
    xor di, di
    cmp sp, 0x0400
    jnz label3
    add di, 0x0014
    mov cl, 0x0b
    jmp label4
label3:
    add di, 0x001a
    mov cl, 0x0e
label4:
    rep movsw
    push ss
    pop dx
    push ds
    push ds
    push es
    pop ds
    pop es
    pop ss
    mov sp, si
    mov di, si
    mov si, 0xfffe
    mov ax, 0x0200
    mov bp, 0xa5f3
    mov bx, 0x5204
    add si, ax
    add sp, bx
    lea di, [bx+di+0x01fe]
    mov cl, 0x20
loop1:
    add sp, dx
    add di, dx
    loop loop1
    inc ch
    push bp
    push ax
    pop ax
    add sp, 0x0004
    push ax
    sub sp, 0x0002
    mov dx, 0x0050
    jmp sp
    cmp dx, 0x6b6b
    jnz label5
    mov si, 0x0041
    mov bp, di
    movsw
    call bp
label5:
    mov ch, 0x02
    push ds
    pop es
    xor di, di
    mov ax, 0xcccc
    rep stosw
    int 0x03
    nop
    dec dx
    jnz label6
    int 0x03
    nop
label6:
    inc ch
    add si, ax
    add sp, bx
    lea di, [bx+di+0x01fe]
    push bp
    push ax
    pop ax
    add sp, 0x0004
    push ax
    sub sp, 0x0002
    jmp sp
    add al, ch
    add [bx+si-0x3334], bh
    mov dx, 0xdc29
    int 0x87
    mov ax, dx
    xor di, di
    nop
    nop
    int 0x86
    mov bp, 0x0eeb
    push ss
    pop es
    xchg bp, ax
    int 0x86
    std
    sub di, 0x0002
    rep movsw
    push ds
    push es
    pop ds
    pop es
    mov si, 0xfffe
    mov ax, 0x0200
    mov bp, 0xa5f3
    mov bx, 0x5204
    add si, ax
    add sp, bx
    lea di, [bx+di+0x01fe]
    mov cl, 0x20
    mov bp, di
    movsw
    call bp
    inc ch
    push bp
    jmp sp