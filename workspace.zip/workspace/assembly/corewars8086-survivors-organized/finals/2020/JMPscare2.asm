    jmp label1
    mov bx, ax
    shr dl, 1
    sub dl, 0x03
    mov bp, dx
    dec dl
    sub bp, 0x0022
    mov [bx+0x008d], dl
    mov [bx+0x56], dl
    inc dl
    inc dl
    mov [bx+0x59], dl
    dec dl
    dec dl
    mov cx, 0xff95
    inc cx
    shr cx, 1
    mov si, ax
    add si, 0x0072
    rep movsw
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov bx, 0x0064
    sub bp, 0x0100
    mov ax, bp
    mov cx, 0x0622
    add ax, cx
    db 0x83, 0xE8, 0x04 ;$1 sub ax, 0x0004
    mov [bx+0x04], cs
    mov [bx+0x02], ax
    mov [bx+0x08], bp
    mov [bx+0x08], cs
    mov di, bp
    inc di
    mov si, 0x002e
    mov dx, 0x0600
    mov sp, bp
    add sp, 0x0624
    mov ax, 0x0004
    mov byte [bp+0x00], 0xa5
    jmp bp
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    movsw
    call far [bx+0x02]
    nop
    movsw
    movsw
    add sp, ax
    movsw
    movsw
    movsw
    movsw
    sub [bx+0x02], dx
    movsw
    movsw
    movsw
    sub [bx+0x08], dx
    movsw
    movsw
    mov si, 0x0022
    movsw
label1:
    add ax, 0x008d
    mov dx, ax
    mov bx, ax
    shr dl, 1
    sub dl, 0x03
    mov bp, dx
    dec dl
    sub bp, word 0x0022
    mov [bx+0x008d], dl
    mov [bx+0x56], dl
    inc dl
    inc dl
    mov [bx+0x59], dl
    dec dl
    dec dl
    mov cx, 0x0022
    inc cx
    shr cx, 1
    mov si, ax
    add si, word 0x0072
    mov di, 0x0022
    rep movsw
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov bx, 0x012c
    sub bp, 0x0100
    mov ax, bp
    mov cx, 0x0622
    add ax, cx
    db 0x83, 0xE8, 0x04 ;$1 sub ax, 0x0004
    mov [bx+0x04], cs
    mov [bx+0x02], ax
    mov [bx+0x08], bp
    mov [bx+0x08], cs
    mov di, bp
    inc di
    mov si, 0x002e
    mov dx, 0x0600
    mov sp, bp
    add sp, 0x0624
    mov ax, 0x0004
    mov byte [bp+0x00], 0xa5
    jmp bp
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    movsw
    call far [bx+0x02]
    nop
    movsw
    movsw
    add sp, ax
    movsw
    movsw
    movsw
    movsw
    sub [bx+0x02], dx
    movsw
    movsw
    movsw
    sub [bx+0x08], dx
    movsw
    movsw
    mov si, 0x0022
    movsw
    mov bx, ax
    shr dl, 1
    sub dl, 0x03
    mov bp, dx
    dec dl
    sub bp, 0x0022
    mov [bx+0x008d], dl
    mov [bx+0x56], dl
    inc dl
    inc dl
    mov [bx+0x59], dl
    dec dl
    dec dl
    mov cx, 0xff95
    inc cx
    shr cx, 1
    mov si, ax
    add si, 0x0072
    rep movsw
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov bx, 0x0064
    sub bp, 0x0100
    mov ax, bp
    mov cx, 0x0622
    add ax, cx
    db 0x83, 0xE8, 0x04 ;$1 sub ax, 0x0004
    mov [bx+0x04], cs
    mov [bx+0x02], ax
    mov [bx+0x08], bp
    mov [bx+0x08], cs
    mov di, bp
    inc di
    mov si, 0x000c
    mov dx, 0x0600
    mov sp, bp
    add sp, 0x0624
    mov ax, 0x0004
    mov byte [bp+0x00], 0xa5
    jmp bp
    movsw
    movsw
    movsw
    movsw
    sub di, cx
    movsw
    call far [bx+0x02]
    nop
    movsw
    movsw
    add sp, ax
    movsw
    movsw
    movsw
    movsw
    sub [bx+0x02], dx
    movsw
    movsw
    movsw
    sub [bx+0x08], dx
    movsw
    movsw
    mov si, 0x0000
    movsw