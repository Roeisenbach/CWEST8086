    mov si, ax
    nop
    nop
    nop
    xchg cx, ax
    mov di, 0x20a0
    push es
    push ds
    pop es
    int 0x86
    int 0x86
    pop es
    xchg cx, ax
    add ax, 0x0097
    mov di, ax
    mov ax, 0xcccc
    push es
    push ds
    pop es
    mov dx, 0xcccc
    mov cx, 0x000b
label1:
    stosw
    dec cx
    jcxz loop1
    jmp label1
loop1:
    stosw
    stosw
    stosw
    stosw
    pop es
    xor di, di
    push es
    push ss
    pop es
    mov dx, sp
    add si, word 0x0076
    mov cl, 0x0d
    mov cx, 0x0011
    rep movsw
    mov sp, dx
    pop es
    push ds
    push es
    pop ds
    mov dx, [0x0000]
    add dx, 0x0500
    mov dl, 0xa3
    pop ds
    push ds
    push ss
    pop ds
    mov bx, 0x0040
    mov [bx+0x02], cs
    mov [bx], dx
    pop ds
    mov ax, 0x1fff
    push ss
    push ds
    pop es
    mov di, dx
    stosw
    pop ds
    push cs
    pop ss
    add dx, 0x0300
    mov sp, dx
    dec di
    xor si, si
    mov cl, 0x11
    call far [bx]
    rep movsw
    sub sp, 0x2e00
    mov cl, 0x11
    mov ax, 0x1fff
    sub di, 0x3125
    mov dx, di
    mov [bx], di
    stosw
    xor si, si
    dec di
    mov di, di
    mov di, di
    mov di, di
    mov di, di
    jmp dx