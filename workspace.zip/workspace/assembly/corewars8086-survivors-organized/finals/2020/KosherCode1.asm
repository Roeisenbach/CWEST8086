    push es
    pop ss
    std
    mov bp, 0x0000
    mov di, [bp+0x00]
    mov dx, 0xfef0
    mov bx, di
    add bx, 0x0028
    add di, 0x0006
    jmp di