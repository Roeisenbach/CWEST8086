    jmp label2
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    push cs
label1:
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label1
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    push cs
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label1
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp
label2:
    push word [0x9211]
    push ss
    pop es
    xchg bp, ax
    mov cl, 0x29
    lea si, [bp+0x00c5]
    rep movsw
    xchg bp, ax
    xor bp, bp
    push cs
    pop es
    push ss
    pop ds
    mov word [0x0223], 0x0ffe
    mov bp, 0x0080
    push cs
    pop ss
    mov bx, 0x4e04
    pop ax
    mov sp, ax
    add sp, bx
    mov ax, 0x01fe
    mov si, 0x0234
    mov di, sp
    add di, ax
    sub di, 0x0002
    inc ch
    std
    mov dx, 0xa5f3
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label4+3
    movsw
    dec di
    xor si, si
    call far [bx]
    call far [bx]
    mov bx, 0x0221
    mov ax, sp
    mov al, 0xa3
    mov [bx], ax
    les ax, [bx]
    mov sp, ax
    sub sp, 0x0020
    mov dx, 0x3000
    mov ax, 0x2e00
    cld
    mov si, 0x0000
    mov cl, 0x09
    add di, 0x0042
    movsw
    dec bp
    jnz label3
    add di, 0x002a
    mov cl, 0x10
    rep movsw
label3:
    add sp, bx
    add di, 0x5000
    inc ch
label4:
    add si, 0x0200
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    push cs
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label4+3
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    push cs
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label4+3
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp