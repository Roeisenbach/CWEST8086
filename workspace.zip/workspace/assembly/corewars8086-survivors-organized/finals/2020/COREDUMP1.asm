    mov word [0x9385], 0x1210
    mov es, [0x9385]
    mov ax, 0x16d7
    int 0x86
    call prcd1
    rep movsw
    add [bx+si], dl
    int3
    int3
    rep movsw
    add [bx+si], dl
    int3
    int3
    rep movsw
    add [bx+si], dl
    int3
    int3
    rep movsw
    add [bx+si], dl
    int3
    int3
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label1:
    jnz label1+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label2:
    jnz label2+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label3:
    jnz label3+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label4:
    jnz label4+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label5:
    jnz label5+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label6:
    jnz label6+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label7:
    jnz label7+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label8:
    jnz label8+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label9:
    jnz label9+1
    rep movsw
    sub [bx], ax
    rep movsw
    sub [bx], ax
    rep movsw
    sub [bx], ax
    rep movsw
    sub [bx], ax
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    mov dx, 0x061e
    int 0x87
    mov dx, 0x061e
    int 0x87
prcd1:
    xor di, di
    mov dx, 0x16d7
    int 0x86
    mov [0x2122], ax
    mov [0x2132], ax
    pop si
    add si, 0x00ec
    push cs
    push dx
    les ax, [si+0x47]
    mov dx, 0x061e
    int 0x87
    lea ax, [si+0x18]
label10:
    mov cx, 0x000c
    push ss
    les di, [bp+0x07f8]
    rep movsw
    mov word [0x16d7], 0x8573
    mov [0x9583], ax
    sub ah, 0x40
    mov bl, 0x40
    pop ds
    mov al, 0xa1
    pop dx
    pop ss
    mov [bx], ax
    mov word [bx+0x02], 0x0fff
    les di, [bx]
    mov bp, 0x002b
    mov ax, 0x2000
    mov cl, 0x09
    mov word [bx+0x16], 0xfaea
    mov si, 0x0014
    movsw
    movsw
    dec di
    lea sp, [di+0x24da]
    xor si, si
    call far [bx+si]
    rep movsw
    sub [bx], ax
    les di, [bx]
    movsw
    sub sp, [bx+si]
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label11:
    jnz label11+1
    sbb ah, cl
    sub sp, bp
    call far [bx+si]
    call prcd2
prcd2:
    pop si
    add si, 0xffe5
    les ax, [si+0x4b]
    mov dx, 0x061e
    int 0x87
    mov ax, ss
    mov cx, 0x0080
    xor dx, dx
    div cx
    db 0x83, 0xE0, 0x07 ;$1 and ax, 0x0007
    inc ax
    xor dx, dx
    mov cx, 0x4bce
    mul cx
    add ax, si
    mov dx, 0x01c2
    xor bp, bp
    push cs
    push dx
    jmp label10
    rep movsw
    add [bx+si], dl
    rep movsw
    add [bx+si], dl
    int3
    int3
    rep movsw
    add [bx+si], dl
    int3
    int3
    rep movsw
    add [bx+si], dl
    int3
    int3
    rep movsw
    add [bx+si], dl
    int3
    int3
    rep movsw
    add [bx+si], dl
    int3
    int3
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label12:
    jnz label12+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label13:
    jnz label13+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label14:
    jnz label14+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label15:
    jnz label15+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label16:
    jnz label16+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label17:
    jnz label17+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label18:
    jnz label18+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label19:
    jnz label19+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label20:
    jnz label20+1
    rep movsw
    sub [bx], ax
    rep movsw
    sub [bx], ax
    rep movsw
    sub [bx], ax
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    mov dx, 0x061e
    int 0x87
    mov dx, 0x061e
    int 0x87
    les ax, [si+0x47]
    mov dx, 0x061e
    int 0x87
    les ax, [si+0x47]
    mov dx, 0x061e
    int 0x87
    les ax, [si+0x47]
    mov dx, 0x061e
    int 0x87
    les ax, [si+0x47]
    mov dx, 0x061e
    int 0x87