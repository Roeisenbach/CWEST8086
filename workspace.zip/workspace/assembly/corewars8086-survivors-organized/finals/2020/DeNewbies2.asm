    jmp label2
    nop
    jmp label1
    nop
label1:
    int3
label2:
    push es
    push ax
    push cs
    pop es
    mov ax, 0x3141
    mov di, 0x2102
    int 0x86
    db 0x33, 0xC0 ;$1 xor ax, ax
    db 0x33, 0xD2 ;$1 xor dx, dx
    mov di, 0x2102
    mov cx, 0x0004
    loop $
    int 0x86
    mov cx, 0x000b
    loop $
    pop ax
    add ax, 0x0002
    mov byte [0xdfe7], 0xea
    mov [0xdfe8], ax
    mov [0xdfea], cs
    mov cx, 0x000b
    loop $
    mov byte [0xdfe7], 0xea
    mov [0xdfe8], ax
    mov [0xdfea], cs
    pop es
    sub ax, 0x0002
    push cs
    pop ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x008d
    mov di, 0x0000
    mov cx, 0x0014
    rep movsw
    mov ax, es
    and ax, 0x0fff
    shl ax, 1
    shl ax, 1
    shl ax, 1
    shl ax, 1
    add ax, 0x0700
    mov bp, 0xf800
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov ax, 0x29cc
    mov dx, 0xffdc
    mov cx, 0xcccc
    push es
    push cs
    pop es
    int 0x87
    pop es
    sub bx, 0x1100
    mov bl, 0xa3
    db 0x8B, 0xD3 ;$1 mov dx, bx
    mov bx, 0x0200
    jmp label3
    nop
    rep movsw
    push ds
    pop es
    db 0x2B, 0xD5 ;$1 sub dx, bp
label3:
    push es
    pop ds
    mov [bx], dx
    mov word [bx+0x02], 0x0fff
    les di, [bx]
    mov si, 0x0024
    movsw
    movsw
    sub di, 0x0003
    add dx, 0x0600
    db 0x8B, 0xE2 ;$1 mov sp, dx
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x0014
    call far [bx+si]