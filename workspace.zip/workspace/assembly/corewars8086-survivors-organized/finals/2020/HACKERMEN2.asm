    mov bx, 0x2172
    mov di, 0xfacc
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    add bl, 0x02
    mov word [bx], 0x3600
    nop
    nop
    nop
    nop
    mov bx, 0x217c
    mov di, 0x3600
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    mov [bx], cx
    mov bx, 0x2184
    mov word [bx], 0xfacc
    mov ax, 0x0000
    mov word [0xe86f], 0x26ff
    mov word [0xe871], 0x26ff
    mov dx, ax
    push es
    push ds
    pop es
    mov di, 0x2116
    int 0x86