    mov es, [0x9385]
    int 0x86
    call prcd1
    or al, 0x00
    add [bx+si], dl
    or al, 0x00
    add [bx+si], dl
    or al, 0x00
    add [bx+si], dl
    or al, 0x00
    add [bx+si], dl
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label1:
    jnz label1+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label2:
    jnz label2+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label3:
    jnz label3+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label4:
    jnz label4+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label5:
    jnz label5+1
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
prcd1:
    xor di, di
    mov dx, 0x16d7
    int 0x86
    pop si
    add si, 0x00f1
    mov word [0x2142], 0x16d7
    mov word [0x2152], 0x16d7
    les cx, [si+0x18]
    push cs
    push ss
    mov ax, 0xa5f3
    mov dx, 0x061e
    int 0x87
    les di, [bp+0x07fa]
    rep movsw
    mov bl, 0x40
    xor dx, dx
    mov bp, 0x002b
    mov word [0x0891], 0x25ff
    mov word [0x8573], 0x26ff
    mov word [0x8575], 0x9583
    mov ax, [0x9583]
    sub ax, 0xa60f
    mov al, 0xa1
    pop ds
    pop ss
    mov [bx], ax
    mov word [bx+0x02], 0x0fff
    les di, [bx]
    mov ax, 0x2000
    mov cl, 0x09
    mov word [bx+0x16], 0xfaea
    mov si, 0x0014
    movsw
    movsw
    dec di
    lea sp, [di+0x24da]
    xor si, si
    call far [bx+si]
    rep movsw
    sub [bx], ax
    les di, [bx]
    movsw
    sub sp, [bx+si]
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label6:
    jnz label6+1
    sbb ah, cl
    sub sp, bp
    call far [bx+si]
    or al, 0x00
    add [bx+si], dl
    mov cl, 0x09
    dec dx
    jmp word [di+0x314f]
    div byte [bx+di+0x4a09]
label7:
    jnz label7+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label8:
    jnz label8+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label9:
    jnz label9+1
    movsw
    dec di
    xor si, si
    mov cl, 0x09
    dec dx
label10:
    jnz label10+1
    or al, 0x00
    add [bx+si], dl
    int3
    int3
    or al, 0x00
    add [bx+si], dl
    int3
    int3
    or al, 0x00
    add [bx+si], dl
    int3
    int3
    or al, 0x00
    add [bx+si], dl
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    movsw
    movsw
    dec di
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e
    mov ax, 0xa5f3
    mov dx, 0x061e