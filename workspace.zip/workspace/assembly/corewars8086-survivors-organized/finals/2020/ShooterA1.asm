    mov word [0x783f], 0x1210
    mov es, [0x783f]
    mov ax, 0x8f49
    int 0x86
    jmp label1
    mov ax, 0xa5ab
    mov dx, 0xd429
    int 0x86
    push ax
    xchg bx, ax
    int 0x86
    pop ax
    mov bx, ax
    push ss
    pop es
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov ax, 0xcccc
    mov dx, 0xdc29
    int 0x87
    movsw
    movsw
    xor si, si
    movsw
    nop
    movsw
    rep movsw
    mov cx, 0x0504
    xchg bx, sp
    xchg dx, bp
    xchg si, ax
    pop si
    pop bp
    shl bp, cl
    mov [bp+si-0x02], bx
    sub sp, 0x0003
    dec ch
    db 0x0F
    test [bx+si-0x6a00], sp
    movsw
    mov di, bp
    movsb
    jmp bp
    movsb
    jmp bp
    nop
    mov ax, 0xa5ab
    mov dx, 0xd429
    int 0x86
    push ax
    xchg bx, ax
    int 0x86
    pop ax
    mov bx, ax
    push ss
    pop es
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov ax, 0xcccc
    mov dx, 0xdc29
    int 0x87
    movsw
    movsw
    xor si, si
    movsw
    nop
    movsw
    rep movsw
    mov cx, 0x0504
    xchg bx, sp
    xchg dx, bp
    xchg si, ax
    pop si
    pop bp
    shl bp, cl
    mov [bp+si-0x02], bx
    sub sp, 0x0003
    dec ch
    db 0x0F
    test [di+byte 0x00], dx
    xchg si, ax
    movsw
    mov di, bp
    movsb
    jmp bp
    movsb
    jmp bp
    nop
label1:
    call prcd1
prcd1:
    pop ax
    sub ax, 0x00ab
    mov bx, ax
    add ax, 0x016b
    xchg si, ax
    push ss
    pop es
    xor di, di
    mov cl, 0x04
    rep movsw
    mov ax, 0xa5ab
    mov dx, 0xd429
    int 0x86
    mov di, 0x0040
    lea si, [bx+0x00f8]
    mov cl, 0x3a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov ax, 0xcccc
    mov dx, 0xdc29
    int 0x87
    mov bp, 0xeeee
    mov ax, 0xa552
    mov si, 0x0008
    mov di, bp
    lea sp, [bp-0x0100]
    mov dx, 0x6b6b
    push dx
    mov [bp+0x0250], dx
    movsb
    jmp bp
    movsw
    movsw
    movsw
    mov cl, 0x07
    rep movsw
    mov bx, [bp+0x0250]
    cmp bx, [bp-0x0102]
    jnz label2
    xor si, si
label2:
    movsw
    nop
    movsw
    movsw
    mov cl, 0x0d
    rep movsw
    cmp bx, dx
    lea bx, [bp+0x0250]
    jnz label3
    sub bp, 0x0a00
    sub bx, 0x0352
label3:
    add bp, 0x0500
    mov di, bp
    movsw
    jmp bp
    nop
    movsw
    mov cl, 0x0c
    movsw
    rep movsw
    mov cx, 0x0504
    xchg bx, sp
    xchg dx, bp
    xchg si, ax
label4:
    pop si
    pop bp
    shl bp, cl
    mov [bp+si-0x02], bx
    sub sp, 0x0003
    dec ch
    jnz label4
    xchg si, ax
    movsw
    movsw
    mov cl, 0x0d
    movsw
    rep movsw
    mov ax, 0xa552
    xchg bp, dx
    mov dx, 0x6b6b
    mov di, bp
    mov si, 0x0008
    lea sp, [bp-0x0100]
    push dx
    mov [bp+0x0250], dx
    movsb
    jmp bp
    nop
    movsw
    movsw
    movsw
    mov di, bp
    movsb
    jmp bp
    mov ax, 0xa5ab
    mov dx, 0xd429
    int 0x86
    push ax
    xchg bx, ax
    int 0x86
    pop ax
    mov bx, ax
    push ss
    pop es
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov ax, 0xcccc
    mov dx, 0xdc29
    int 0x87
    movsw
    movsw
    xor si, si
    movsw
    nop
    movsw
    rep movsw
    mov cx, 0x0504
    xchg bx, sp
    xchg dx, bp
    xchg si, ax
    pop si
    pop bp
    shl bp, cl
    mov [bp+si-0x02], bx
    sub sp, 0x0003
    dec ch
    db 0x0F
    test [bx], di
    call word [bp-0x765b]
    out dx, ax
    movsb
    jmp bp
    movsb
    jmp bp
    nop