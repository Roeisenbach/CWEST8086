    jmp label1
    sub word [bx+0x02], 0x0057
    mov dx, [bx+0x02]
    test dx, ax
    mov cl, 0x04
    shl dx, cl
    add dx, [bx]
    add [bx+0x02], ax
    sub di, 0x05a3
    movsw
    movsw
    sub di, 0x0003
    sub sp, 0x516c
    mov cx, 0x0018
    mov si, bx
    add si, 0x0004
    call far [bx]
label1:
    db 0x83, 0xC0, 0x2B ;$1 add ax, 0x002b
    push ax
    push es
    push ds
    pop es
    mov di, 0x2102
    mov ax, 0x0000
    mov dx, ax
    int 0x86
    pop es
    pop ax
    db 0x83, 0xC0, 0x11 ;$1 add ax, 0x0011
    push ax
    push es
    push ds
    pop es
    mov cx, 0x0004
    mov si, ax
    add si, 0x0091
    mov dx, ax
    mov dl, 0x61
    dec dh
    mov di, dx
    rep movsb
    xor cx, cx
    xor dx, dx
    xor si, si
    xor di, di
    pop es
    mov dx, ax
    mov dl, 0x61
    dec dh
    mov ax, dx
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    push es
    pop ds
    mov cl, 0xa1
    mov ch, ah
    inc ch
    sub cx, ax
    push ax
    add ax, cx
    mov bx, ax
    mov ax, cx
    xor dx, dx
    mov cx, 0x0010
    div cx
    sub bx, dx
    mov dx, 0x1000
    sub dx, ax
    mov ax, bx
    mov bx, 0x0050
    mov [bx+0x02], dx
    mov [bx], ax
    pop ax
    pop dx
    add dx, 0x0095
    push cs
    pop ds
    mov si, dx
    mov di, bx
    add di, 0x0004
    mov cx, 0x001b
    rep movsw
    push es
    pop ds
    mov bp, 0x0050
    mov si, bx
    add si, 0x0004
    mov di, ax
    inc di
    mov cx, 0x0018
    push cs
    pop es
    push cs
    pop ss
    mov sp, ax
    mov di, ax
    inc di
    sub sp, 0x4c00
    mov dx, ax
    mov ax, 0x1000
    jmp dx
    add sp, bp
    call far [bx]
    rep movsw
    sub word [bx+0x02], 0x0057
    jb label2
    mov dx, [bx+0x02]
    test dx, ax
    jnz label3
    mov cl, 0x04
    shl dx, cl
    add dx, [bx]
    jb label3
label2:
    add [bx+0x02], ax
label3:
    sub di, 0x05a3
    movsw
    movsw
    sub di, 0x0003
    sub sp, 0x516c
    mov cx, 0x0018
    mov si, bx
    add si, 0x0004
    call far [bx]
    stosb
    add sp, bp
    call far [bx]
    sub word [bx+0x02], 0x0057
    jb label2
    mov dx, [bx+0x02]
    test dx, ax
    jnz label3
    mov cl, 0x04
    shl dx, cl
    add dx, [bx]
    jb label3
    add [bx+0x02], ax
    sub di, 0x05a3
    movsw
    movsw
    sub di, 0x0003
    sub sp, 0x516c
    mov cx, 0x0018
    mov si, bx
    add si, 0x0004
    call far [bx]