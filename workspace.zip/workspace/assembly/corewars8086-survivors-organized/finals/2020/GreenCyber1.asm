    jmp label3
    call prcd1
prcd1:
    pop ax
    db 0x83, 0xE8, 0x05 ;$1 sub ax, 0x0005
    mov bx, ax
    add bx, word 0x001e
label1:
    dec byte [bx]
    jz label2
    jmp label1
label2:
    mov byte [bx], 0x01
    jmp label3
    add [bx+si], al
    add bp, cx
    xchg dh, [bx+di]
    db 0xFF, 0xB8, 0xA5, 0xA5
    mov dx, 0xa5a5
    int 0x87
    push cs
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label1
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    push cs
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label1
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp
label3:
    mov [0x9211], ax
    push ss
    push cs
    pop es
    mov bp, 0x9998
    xchg bp, ax
    mov dx, 0xadd2
    mov di, 0x2102
    int 0x86
    mov cx, 0x0018
    lea si, [bp+0x0126]
    mov bx, bp
    mov dx, 0x0000
    mov ax, 0xce91
    mov di, 0x2102
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    pop es
    mov ax, bp
    rep movsw
    sub bp, 0xdfe7
    mov byte [0xdfe7], 0xe8
    mov [0xdfe8], bp
    mov cl, 0x12
    rep movsw
    mov word [bx+0x0153], 0x0220
    push cs
    pop es
    push ss
    pop ds
    mov word [0x0223], 0x0ffe
    mov bp, 0x0080
    push cs
    pop ss
    mov bx, 0x4e04
    mov sp, ax
    add sp, bx
    xchg bp, ax
    add sp, [bp+word 0x001c]
    add word [bp+word 0x001c], 0x4e00
    xchg bp, ax
    mov ax, 0x01fe
label4:
    mov si, 0x0236
    mov di, sp
    add di, ax
    sub di, 0x0002
    inc ch
    std
    mov dx, 0xa5f3
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz label4
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov bx, 0x0221
    mov ax, sp
    mov al, 0xa3
    mov [bx], ax
    les ax, [bx]
    mov sp, ax
    sub sp, 0x0020
    mov dx, 0x3000
    mov ax, 0x2e00
    mov bp, 0x0000
    cld
    xor si, si
    mov cl, 0x09
    add di, 0x0044
    movsw
    dec bp
    jnz label5
    add di, 0x002c
    mov cl, 0x11
    rep movsw
label5:
    add sp, bx
    add di, 0x5000
    inc ch
    add si, 0x0200
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    push cs
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz 528
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    int 0x86
    xor di, di
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    push cs
    pop es
    push ss
    pop ds
    push ax
    push dx
    push dx
    pop dx
    jmp sp
    rep movsw
    rep movsw
    add [bx], ax
    mov di, [bx]
    add sp, dx
    mov cx, 0x0009
    dec bp
    jz 528
    movsw
    dec di
    xor si, si
    call far [bx+si]
    call far [bx+si]
    mov al, 0xa3
    mov [bx], ax
    xor si, si
    mov cl, 0x09
    rep movsw
    add sp, bx
    push ax
    push dx
    push dx
    pop dx
    jmp sp