    mov bx, 0x2132
    mov di, 0xfacc
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    add [bx], di
    add bl, 0x02
    mov word [bx], 0x3600
    push ax
    mov bx, ax
    lea bx, [bx+0x00d2]
    mov [bx], bx
    mov bx, 0x213c
    mov di, 0x3600
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    mov [bx], di
    sub bl, 0x0e
    mov [bx], cx
    mov bx, 0x2144
    mov word [bx], 0xfacc
    mov bx, [0x00d2]
    mov [0x00d2], ax
    mov bx, 0x26ff
    xchg bx, ax
    mov dx, ax
    push es
    push ds
    pop es
    pop di
    mov di, 0xdfe7
    lea bx, [bx+0x00d1]
    mov [0x26ff], bx
    int 0x86
    cmp ax, bx
    mov di, 0xdfe7
    mov [0x26ff], bx
    int 0x86
    cmp ax, bx
    push ss
    pop es
    push cs
    pop ss
    xor di, di
    pop ax
    mov sp, ax
    mov si, ax
    add si, 0x00a4
    mov cx, 0x0050
    mov bp, 0x0004
loop1:
    movsw
    movsw
    sub si, bp
    loop loop1
    mov si, ax
    add si, 0x00bb
    mov dx, 0x00c8
    mov cx, 0x000b
    mov si, ax
    add si, 0x00bb
    rep movsw
    mov cx, 0x0002
    jmp label1
    movsw
    sub sp, bp
    stosw
label1:
    push ds
    push es
    pop ds
    pop es
    mov bp, 0x000d
    mov di, ax
    add di, 0x00bb
    xor si, si
    mov ax, 0xa59c
    stosw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, dx
    nop
    movsw
    sub di, cx
    call di
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    movsw
label2:
    mov bx, 0x0000
    mov ax, bx
    inc byte [bx+0x0b]
    jz label3+1
    jmp label7
label3:
    dec word [bx+di-0x4b3a]
    add al, 0xb9
    and [bx+si], ax
    push es
    pop ss
    add si, 0x0027
    mov bp, si
    lea bx, [si-0x10]
    xor bh, bh
    mov di, 0x0200
    rep movsw
    mov cx, 0x2021
label4:
    cmp byte [bx], 0xcc
    jz label6
    mov al, [bx]
    and al, 0xf0
    cmp al, 0x10
    jnz label5
    les di, [bx+0x01]
    dec di
    stosw
    stosw
label5:
    mov byte [bx], 0xcc
    inc bx
    dec ah
    jnz label4
label6:
    mov ah, 0x04
    mov bl, 0x60
    add bh, 0x02
    dec ch
    jnz label4
    push ss
    pop ds
    push cs
    pop es
    add bp, 0x4000
    mov di, bp
    mov si, 0x0200
    rep movsw
    push ds
    pop ss
    push es
    pop ds
    mov cx, 0x2021
    sub sp, 0x0003
    jmp bp
    jmp label2
label7:
    xor ax, ax
    xor ch, ch
    xor di, di
    xor bp, bp
    mov cl, [bx+0x0b]
loop2:
    add bp, 0x0041
    loop loop2
label8:
    dec byte [bx+0x0b]
    jz label9
    inc byte [bx+0x0b]
    jmp label8
label9:
    mov cl, [bx+0x0b]
    inc cl
loop3:
    db 0x83, 0xC0, 0x41 ;$1 add ax, 0x0041
    loop loop3
    mov di, ax
    sub bh, 0x77
    push ds
    push es
    pop ds
    pop es
label10:
    stosw
    add di, bp
    jmp label10
    jmp bx
    jmp label7
    push ds
    pop es
    mov di, bx
    mov ax, 0xcccc
label11:
    stosw
    add di, bp
    jmp label11