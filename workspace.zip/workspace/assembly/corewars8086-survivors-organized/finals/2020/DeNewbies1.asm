    jmp label4
    nop
    jmp label1
    nop
label1:
    push cs
    pop es
    mov cx, ss
    mov ax, 0xcccc
    mov dx, 0x13ff
    cmp cx, 0x22c0
    jg label2
    mov ax, 0x1fff
    mov dx, 0xcccc
    cld
label2:
    sub cx, 0x2000
    shr cx, 1
    shr cx, 1
    shr cx, 1
    shr cx, 1
    add cx, 0x0030
    loop $
    mov bx, 0x3141
    mov cx, 0x5926
    db 0x33, 0xFF ;$1 xor di, di
    int 0x87
    cld
    call prcd1
prcd1:
    sub word [0xff0d], 0x3000
    sub byte [0xff0f], 0x04
    mov di, [0xff0d]
    mov dl, [0xff0f]
    pop ax
    mov cx, 0x0012
    add ax, 0x0025
    db 0x8B, 0xF0 ;$1 mov si, ax
    push cs
    pop es
    rep movsw
    sub di, 0x001c
    jmp di
    mov cx, 0x0001
    loop $
    mov cx, 0xafff
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8A, 0xDA ;$1 mov bl, dl
    and bx, 0xf0ff
    mov dx, 0xcccc
label3:
    mov [bx], dx
    add bx, 0x00c0
    jmp label3
label4:
    push es
    push ax
    push cs
    pop es
    mov ax, 0x3141
    mov di, 0x2102
    nop
    int 0x86
    mov ax, 0x0000
    mov dx, 0x0000
    mov di, 0x2102
    mov cx, 0x0004
    loop $
    int 0x86
    mov cx, 0x000b
    loop $
    pop ax
    add ax, 0x0002
    mov byte [0xdfe7], 0xea
    mov [0xdfe8], ax
    mov [0xdfea], cs
    mov cx, 0x000b
    loop $
    mov byte [0xdfe7], 0xea
    mov [0xdfe8], ax
    mov [0xdfea], cs
    pop es
    sub ax, 0x0002
    push cs
    pop ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0113
    mov di, 0x0000
    mov cx, 0x0014
    rep movsw
    mov ax, es
    and ax, 0x0fff
    shl ax, 1
    shl ax, 1
    shl ax, 1
    shl ax, 1
    add ax, 0x0000
    mov [0xff0d], ah
    mov byte [0xff0e], 0x93
    mov byte [0xff0f], 0x95
    mov bp, 0xf800
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov ax, 0x29cc
    mov dx, 0xffdc
    mov cx, 0xcccc
    push es
    push cs
    pop es
    int 0x87
    pop es
    sub bx, 0x1100
    mov bl, 0xa3
    db 0x8B, 0xD3 ;$1 mov dx, bx
    mov bx, 0x0250
    jmp label5
    nop
    rep movsw
    push ds
    pop es
    db 0x2B, 0xD5 ;$1 sub dx, bp
label5:
    push es
    pop ds
    mov [bx], dx
    mov word [bx+0x02], 0x0fff
    les di, [bx]
    mov si, 0x0024
    movsw
    movsw
    sub di, 0x0003
    add dx, 0x0600
    db 0x8B, 0xE2 ;$1 mov sp, dx
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x0014
    call far [bx+si]
    add ax, 0x3141
    sub ax, 0x5926