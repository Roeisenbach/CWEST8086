    jmp label1
    inc di
    stosw
    mov cl, 0x11
    call far [bx]
label1:
    mov si, ax
    xor ax, ax
    xor dx, dx
    mov di, 0x20a0
    push es
    push ds
    pop es
    int 0x86
    int 0x86
    pop es
    mov [si+0x00d4], ss
    xor di, di
    mov ax, si
    add ax, 0x00a9
    sub ah, 0x01
    push ds
    push es
    pop ds
    mov [0x0000], ax
    pop ds
    push es
    push cs
    pop es
    mov cx, 0x0004
    mov ax, 0xcccc
label2:
    stosw
    dec cx
    jcxz loop1
    jmp label2
loop1:
    stosw
    stosw
    stosw
    mov word [0xdfe7], 0x00b8
    mov [0xdfe8], si
    add word [0xdfe8], 0x00d6
    mov word [0xdfea], 0xe0ff
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    mov ax, 0xcccc
    mov dx, 0xdc29
    int 0x87
    xor di, di
    pop es
    push es
    push ss
    pop es
    mov dx, sp
    add si, 0x00b3
    mov cl, 0x0d
    mov cx, 0x0011
    rep movsw
    mov sp, dx
    pop es
    mov dx, ax
    mov dl, 0xa3
    mov ax, 0x1fff
    push ss
    push es
    push ds
    pop es
    mov di, dx
    stosw
    pop es
    pop ds
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], dx
    push cs
    pop es
    push cs
    pop ss
    add dx, 0x0300
    mov sp, dx
    dec di
    xor si, si
    mov cl, 0x11
    call far [bx]
    rep movsw
    sub sp, 0x2e00
    mov cl, 0x11
    mov ax, 0x1fff
    sub di, 0x3125
    mov dx, di
    mov [bx], di
    stosw
    xor si, si
    dec di
    mov di, di
    mov di, di
    mov di, di
    mov di, di
    jmp dx
    add [bx+si], al
    mov si, ax
    db 0x83, 0xC0, 0x64 ;$1 add ax, 0x0064
    push ss
    pop bx
    xchg bx, ax
    sub ax, [si-0x02]
    mov cx, 0x000a
    mul cx
    mov bx, ax
    push es
    push ds
    pop es
    push ax
    mov di, ax
    mov ax, 0xcccc
    mov dx, ax
    int 0x86
    int 0x86
    xor di, di
    pop ax
    pop es
    push es
    push ss
    pop es
    mov dx, sp
    add si, 0x0066
    mov cl, 0x0d
    mov cx, 0x0011
    rep movsw
    mov sp, dx
    pop es
    sub bh, 0x36
    mov bl, 0xa3
    mov ax, 0x1fff
    push ss
    push es
    push ds
    pop es
    mov di, bx
    stosw
    pop es
    pop ds
    mov dx, bx
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], dx
    push cs
    pop es
    push cs
    pop ss
    add dx, 0x0300
    mov sp, dx
    dec di
    xor si, si
    mov cl, 0x11
    mov ax, 0x0240
    call far [bx]
    rep movsw
    sub sp, 0x2e00
    mov cx, ax
    mov ax, 0x1fff
    sub di, 0x3125
    mov dx, di
    mov [bx], di
    stosw
label3:
    mov ax, cx
    xor si, si
    dec ax
    jz label3+1
    mov cx, 0x0011
    dec di
    jmp dx
    inc di
    stosw
    mov cl, 0x11
    call far [bx]