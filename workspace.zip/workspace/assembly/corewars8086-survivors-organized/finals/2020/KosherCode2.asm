    stosw
    mov dx, 0x0810
    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    push dx
    push bx
    push si
    db 0x33, 0xFF ;$1 xor di, di
    push cs
    pop es
    std
    mov ax, 0x52a5
    mov dx, 0xa529
    db 0x33, 0xDB ;$1 xor bx, bx
    db 0x33, 0xC9 ;$1 xor cx, cx
    int 0x87
    mov ax, 0x0028
    mul dx
    db 0x2B, 0xFA ;$1 sub di, dx
    sub di, 0x0100
    push cs
    pop es
    mov dx, 0xcccc
    db 0x8B, 0xC2 ;$1 mov ax, dx
    int 0x86
    push cs
    pop es
    mov bp, 0x0000
    mov di, [bp+0x00]
    add di, 0x3fff
    mov dx, 0xcccc
    db 0x8B, 0xC2 ;$1 mov ax, dx
    int 0x86
    int 0x86
    pop si
    pop bx
    pop dx
    mov cl, 0xcc
label1:
    db 0x2B, 0xDA ;$1 sub bx, dx
    mov [bx], cl
    mov [bx+0x0100], cl
    mov [bx+0x0201], cl
    mov [bx+0x01ff], cl
    jmp label1