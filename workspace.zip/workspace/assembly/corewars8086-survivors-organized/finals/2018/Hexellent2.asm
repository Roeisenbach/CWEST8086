    mov cx, 0x0006
loop1:
    mov word [bx+0x0086], 0x8bcc
    add bx, 0x0005
    loop loop1
    mov cx, 0x0079
    loop $
    push ax
    push es
    push cs
    pop es
    mov ax, 0x7502
    mov dx, 0xfffb
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop es
    pop ax
    mov bx, ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    push ax
    push es
    pop ss
    mov ax, 0xa5ab
    mov dx, 0xd401
    mov di, 0x0150
    int 0x86
    mov di, 0x0194
    mov cx, 0x003e
    shr cx, 1
    add si, 0x007d
    nop
    rep movsw
    mov ss, bx
    pop ax
    mov cx, 0x001e
    shr cx, 1
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x00bb
    mov di, 0x0100
    rep movsw
    movsb
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov dx, 0x3c88
    db 0x8B, 0xE8 ;$1 mov bp, ax
    add bp, 0x1000
    lea sp, [bp-0x171c]
    lea di, [bp+0x01]
    mov si, 0x0150
    mov byte [bp+0x00], 0xab
    mov ax, 0xa552
    jmp bp
    movsw
    movsw
    movsw
    movsw
    mov bx, [bp+0x0996]
    movsw
    movsw
    movsw
    movsw
    mov cx, 0x000b
    rep movsw
    movsw
    movsw
    cmp bx, [bp-0x0452]
    jz label1
    add bp, 0xf000
    lea sp, [bp-0x171c]
    mov si, 0x0100
    mov cx, 0x0002
    rep movsw
    movsb
label1:
    movsw
    movsw
    mov cx, 0x0006
    movsw
    rep movsw
    mov byte [bp+0x00], 0xab
    mov si, 0x0150
    lea di, [bp+0x01]
    jmp bp
    mov byte [bp+0x00], 0xa5
    lea di, [bp+0x01]
    jmp bp
    movsw
    movsw
    movsw
    movsb
    mov cx, 0x0006
    rep movsw
    mov byte [bp+0x00], 0xab
    mov si, 0x0150
    lea di, [bp+0x01]
    jmp bp