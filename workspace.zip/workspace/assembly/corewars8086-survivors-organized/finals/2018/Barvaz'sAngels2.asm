    push ax
    add ax, 0x01eb
    mov [0x5358], ax
    mov [0x3383], ax
    mov [0x6264], ax
    db 0x83, 0xC0, 0x0A ;$1 add ax, 0x000a
    mov [0x2384], ax
    pop ax
    jmp label1
    add ax, 0x00f4
    mov si, ax
    mov cx, 0x001f
    rep movsw
    movsb
    push ds
    push es
    pop ds
    pop es
    push es
    pop ss
    mov dx, 0xaaaa
    xor si, si
    mov di, ax
    mov bx, 0x0060
    mov [bx+0x02], cs
    movsw
    movsw
    mov cx, 0x000a
    rep movsw
    mov bp, di
    add bp, 0x0002
    mov cx, 0x0010
    rep movsw
    movsb
    mov [bp+0x4a], dx
    mov [bp-0x08], dx
    mov [bx], bp
    xor si, si
    call far [bx]
    mov cx, [bp-0x08]
    cmp [bp+0x4a], cx
    db 0x0F
    test [di+0x3900], dh
    push si
    clc
    db 0x0F
    test si, ax
    add [bx+di+0x00c7], al
    add cl, [bx+di-0x5a03]
    jmp bp
    sub di, 0x0100
    mov bp, di
    movsw
    jmp bp
    add ax, 0x00f4
    mov si, ax
    mov cx, 0x001f
    rep movsw
    movsb
    push ds
    push es
    pop ds
    pop es
    push es
    pop ss
    mov dx, 0xaaaa
    xor si, si
    mov di, ax
    mov bx, 0x0060
    mov [bx+0x02], cs
    movsw
    movsw
    mov cx, 0x000a
    rep movsw
    mov bp, di
    add bp, 0x0002
    mov cx, 0x0010
    rep movsw
    movsb
    mov [bp+0x4a], dx
    mov [bp-0x08], dx
    mov [bx], bp
    xor si, si
    call far [bx]
    mov cx, [bp-0x08]
    cmp [bp+0x4a], cx
    jz label2
    cmp [bp-0x08], dx
    jnz label3
    add di, 0x0200
    mov bp, di
    movsw
    jmp bp
    sub di, 0x0100
    mov bp, di
    movsw
    jmp bp
label1:
    add ax, 0x00f4
    mov si, ax
    mov cx, 0x001f
    rep movsw
    movsb
    push ds
    push es
    pop ds
    pop es
    push es
    pop ss
    add sp, 0x5358
    mov dx, 0xaaaa
    xor si, si
    mov di, ax
    mov bx, 0x0060
    mov [bx+0x02], cs
    movsw
    movsw
    movsw
    movsw
    movsw
    mov cx, 0x000a
    rep movsw
    mov bp, di
    add bp, 0x0002
    mov cx, 0x0010
    rep movsw
    movsb
    mov [bp+0x4a], dx
    mov [bp-0x08], dx
    mov [bx], bp
    xor si, si
label2:
    call far [bx]
    mov cx, [bp-0x08]
    cmp [bp+0x4a], cx
    jz label2
    cmp [bp-0x08], dx
    jnz label3
    add di, 0x0200
    mov bp, di
    movsw
    jmp bp
label3:
    sub di, 0x0100
    mov bp, di
    movsw
    jmp bp
    add ax, 0x00f4
    mov si, ax
    mov cx, 0x001f
    rep movsw
    movsb
    push ds
    push es
    pop ds
    pop es
    push es
    pop ss
    mov dx, 0xaaaa
    xor si, si
    mov di, ax
    mov bx, 0x0060
    mov [bx+0x02], cs
    movsw
    movsw
    mov cx, 0x000a
    rep movsw
    mov bp, di
    add bp, 0x0002
    mov cx, 0x0010
    rep movsw
    movsb
    mov [bp+0x4a], dx
    mov [bp-0x08], dx
    mov [bx], bp
    xor si, si
    call far [bx]
    mov cx, [bp-0x08]
    cmp [bp+0x4a], cx
    jz label2
    cmp [bp-0x08], dx
    jnz label3
    add di, 0x0200
    mov bp, di
    movsw
    jmp bp
    sub di, 0x0100
    mov bp, di
    movsw
    jmp bp
    add ax, 0x00f4
    mov si, ax
    mov cx, 0x001f
    rep movsw
    movsb
    push ds
    push es
    pop ds
    pop es
    push es
    pop ss
    mov dx, 0xaaaa
    mov di, ax
    mov bx, 0x0060
    mov [bx+0x02], cs
    movsw
    movsw
    mov cx, 0x000a
    rep movsw
    mov bp, di
    add bp, 0x0002
    mov cx, 0x0010
    rep movsw
    movsb
    mov [bp+0x4a], dx
    mov [bp-0x08], dx
    mov [bx], bp
    xor si, si
    call far [bx]
    mov cx, [bp-0x08]
    cmp [bp+0x4a], cx
    db 0x0F
    test [bx+si-0x01], al
    cmp [bp-0x08], dx
    db 0x0F
    test [bx+di-0x01], dx
    add di, 0x0200
    mov bp, di
    movsw
    jmp bp
    sub di, 0x0100
    mov bp, di
    movsw
    jmp bp
    std
    sub al, 0x06
    pop ds
    int3
    int3
    push cs
    pop es
    int3
    int3
    std
    sub al, 0x06
    pop ds
    int3
    int3
    push cs
    pop es
    int3
    int3