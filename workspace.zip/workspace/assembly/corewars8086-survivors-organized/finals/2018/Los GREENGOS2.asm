    mov ax, 0xe0ff
    les bx, [0x2384]
    mov dx, 0xcccc
    int 0x87
    mov bx, [0x2795]
    mov word [bx], 0x3643
    mov di, [0x5358]
    mov word [bx+0x02], 0x8bcc
    sub di, 0x0051
    int 0x86
    mov word [bx+0x04], 0x8416
    mov word [bx+0x06], 0x8436
    mov word [bx+0x08], 0xff90
    call prcd1
prcd1:
    pop [0x1235]
    cmp dl, 0x00
    jz label1
    mov bp, 0xffff
    mov ax, 0x39a3
    push ax
    jmp label2
label1:
    mov cx, 0x1235
    mov bx, 0x16ff
    mov ax, 0x368b
    mov dx, 0x9793
    int 0x87
    mov bp, 0x0200
    mov ax, 0x3ea3
    push ax
label2:
    call prcd2
prcd2:
    pop si
    mov ax, 0x2e00
    add si, 0x0038
    xor di, di
    mov cx, 0x000b
    push ss
    pop es
    rep movsw
    mov bx, 0x0223
    push ss
    pop ds
    pop [bx]
    mov word [bx+0x02], 0x1002
    les di, [bx]
    push cs
    pop ds
    movsw
    movsw
    sub di, 0x0003
    push ss
    pop ds
    push cs
    pop ss
    mov sp, [bx]
    mov dx, 0x2900
    add sp, 0x0500
    mov cl, 0x09
    xor si, si
    call far [bx]
    rep movsw
    sub [bx], ax
    mov di, [bx]
    sub sp, dx
    mov cl, 0x09
    dec bp
    jz label3
    movsw
    dec di
    xor si, si
    call far [bx]
    db 0x67
    call far [bx]
    call far [bx]
label3:
    xor al, 0x12
    int3
    int3
    int3
    call far [bx]
    int3
    int3
    int3
    call far [bx]
    int3
    int3
    int3
    sub [bx], ax
    mov di, [bx]
    pop [bx]
    mov word [bx+0x02], 0x1002
    les di, [bx]
    push cs
    pop ds
    movsw
    movsw
    sub di, 0x0003
    push ss
    pop ds
    push cs
    pop ss
    mov sp, [bx]
    mov dx, 0x2900
    add sp, 0x0500
    mov cl, 0x09
    xor si, si
    call far [bx]