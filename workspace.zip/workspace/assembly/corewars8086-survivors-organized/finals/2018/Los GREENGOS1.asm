    mov [0x2386], cs
    mov word [0x2384], 0x16ff
    add ax, 0x0053
    mov [bx], ax
    mov bx, [0x3383]
    mov word [bx], 0x3643
    les di, [0x2384]
    int 0x86
    mov cx, 0x1235
    mov word [bx+0x02], 0x8bcc
    mov word [bx+0x04], 0x8416
    mov word [bx+0x06], 0x8436
    mov dx, 0x2384
    mov si, [0x3141]
    sub si, 0x0051
    mov word [bx+0x08], 0xff90
    mov bx, 0x16ff
    mov ax, 0x368b
    mov di, si
    int 0x87
    int 0x86
    mov bp, 0xffff
    mov ax, 0x34a3
    push ax
    jmp label2
    mov bx, [0x6264]
    mov word [bx], 0x3643
    mov di, [0x9793]
    int 0x86
    mov word [bx+0x02], 0x8bcc
    mov cx, 0xd53a
    mov word [bx+0x04], 0x9316
    mov word [bx+0x06], 0x9336
    mov dx, 0x9793
    mov si, [0x5926]
    sub si, 0x0051
    mov word [bx+0x08], 0xff90
    mov bx, 0x16ff
    mov ax, 0x368b
    mov di, si
    int 0x87
    int 0x86
    call prcd1
prcd1:
    pop [0xd53a]
    cmp dl, 0x00
    jz label1
    mov bp, 0x0200
    mov ax, 0x2fa3
    push ax
    jmp label2
label1:
    mov ax, 0xa5a5
    mov dx, 0xa5a5
    int 0x87
    mov bp, 0x0200
    mov ax, 0x2aa3
    push ax
    brk
label2:
    call prcd2
prcd2:
    pop si
    mov ax, 0x2e00
    add si, 0x0038
    xor di, di
    mov cx, 0x000b
    push ss
    pop es
    rep movsw
    mov bx, 0x0223
    push ss
    pop ds
    pop [bx]
    mov word [bx+0x02], 0x1002
    les di, [bx]
    push cs
    pop ds
    movsw
    movsw
    sub di, 0x0003
    push ss
    pop ds
    push cs
    pop ss
    mov sp, [bx]
    mov dx, 0x2900
    add sp, 0x0500
    mov cl, 0x09
    xor si, si
    call far [bx]
    rep movsw
    sub [bx], ax
    mov di, [bx]
    sub sp, dx
    mov cl, 0x09
    dec bp
    jz label3
    movsw
    dec di
    xor si, si
    call far [bx]
    db 0x67
    call far [bx]
    call far [bx]
label3:
    xor al, 0x12
    int3
    mov si, [0xcc41]
    mov si, [0xcc41]
    mov si, [0xcc26]
    mov si, [0xcc26]
    mov si, [0xcc58]
    mov si, [0xcc58]
    mov si, [0xcc64]
    mov si, [0xcc64]
    mov si, [0xcc83]
    mov si, [0xcc83]
    mov si, [0xcc95]
    db 0x8B, 0x36, 0x95  ; mov si, [0x0095]