    mov [0x0000], bx
    mov [0x0002], bx
    mov [0x0004], bx
    mov cx, 0x0003
loop1:
    mov [0x3141], bx
    mov [0x5926], bx
    mov [0x5358], bx
    mov [0x9793], bx
    mov [0x2384], bx
    mov [0x6264], bx
    mov [0x3383], bx
    mov [0x2795], bx
    loop loop1
    mov cx, 0x0031
    loop $
    push ax
    push es
    push cs
    pop es
    mov ax, 0x1fff
    mov dx, 0x1000
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop es
    pop ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov ax, 0xc800
    add ax, [0xdead]
    push ss
    pop es
    add si, 0x0086
    mov cx, 0x0020
    shr cx, 1
    rep movsw
    push es
    push ds
    pop es
    pop ds
    db 0x8B, 0xDF ;$1 mov bx, di
    db 0x8B, 0xD0 ;$1 mov dx, ax
    mov dx, 0xf8a3
    mov [bx], dx
    mov [bx+0x02], cs
    db 0x8B, 0xFA ;$1 mov di, dx
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x000f
    push cs
    pop ss
    db 0x8B, 0xE2 ;$1 mov sp, dx
    add sp, 0x0804
    mov ax, 0x1fff
    stosw
    dec di
    call far [bx]
    rep movsw
    mov cx, 0x000f
    sub di, 0x0823
    sub word [bx], 0x0800
    mov ax, 0xd401
    stosw
    mov ax, 0x1fff
    stosw
    add dx, 0x1700
    dec di
    db 0x33, 0xF6 ;$1 xor si, si
    db 0x2B, 0xE5 ;$1 sub sp, bp
    call far [bx]