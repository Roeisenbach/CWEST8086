    push es
    push ds
    pop es
    pop ds
    mov ax, 0xcccc
    mov cx, 0x0008
    mov dx, [bx]
    mov [bx+0x02], cs
    add cx, dx
    push cs
    pop ss
    jmp dx