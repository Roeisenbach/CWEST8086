    push es
    push ds
    pop es
    pop ds
    add ax, 0x0016
    mov [bx], ax
    mov dx, ax
    mov di, ax
    add di, 0x0100
    mov ax, 0xcccc
    jmp label1
    mov sp, dx
    sub sp, 0x0100
    mov [bx], cx
    call far [bx]
label1:
    mov cx, 0x3d50
    rep stosw
    mov [bx], dx
    mov di, dx
    add di, 0x0100
    jmp label1