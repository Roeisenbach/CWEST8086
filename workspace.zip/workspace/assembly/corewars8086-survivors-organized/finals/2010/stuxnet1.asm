    jmp label7
    jmp label4
    jmp label5
    jmp label9
label1:
    xchg bx, ax
label2:
    mov ah, [0x4743]
    mov al, 0xbd
    mul bx
    mov [0xed8d], ax
    jmp label2
    ror ax, 1
    ror ax, 1
    ror ax, 1
    db 0x8B, 0xC3 ;$1 mov ax, bx
    db 0x03, 0xC1 ;$1 add ax, cx
    db 0x33, 0xC1 ;$1 xor ax, cx
    db 0x8B, 0xDA ;$1 mov bx, dx
    rep movsw
    db 0x3B, 0xF7 ;$1 cmp si, di
    jmp label1
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x6000
    mov ax, 0xe5ff
    mov cx, 0x2000
    mov cx, 0xe0ff
    mov ax, 0xe3f7
    mov dx, 0x0da3
    mov bx, [0x4741]
    int 0x87
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x0400
    mov cx, 0x1f00
    mov cl, 0xbb
    mov cx, 0x1f00
    rep stosw
    int 0x21
    add si, 0x0002
    sub di, 0x0400
    mov ax, 0xe5ff
    int 0x86
    int 0x86
    mov dx, 0xe3ff
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], si
    mov [bx+0x03], dx
    mov cx, 0x7b00
    rep stosw
    mov cl, 0xbb
    mov [bx], cl
label3:
    mov [bx+0x01], si
    mov [bx+0x03], dx
    sub di, 0x0a00
    jmp label3
label4:
    push cs
    pop es
    db 0x8B, 0xD3 ;$1 mov dx, bx
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x6000
    std
    mov ax, 0xe5ff
    mov cx, 0x2000
    rep stosw
    mov byte [0x0000], 0xbb
    mov [0x0001], dx
    mov word [0x0003], 0xe3ff
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x0400
    mov ax, 0xcccc
    mov cx, 0x1f00
    rep stosw
    mov byte [0x0000], 0xbb
    mov [0x0001], dx
    mov word [0x0003], 0xe3ff
    mov cx, 0x1f00
    rep stosw
    mov byte [0x0000], 0xbb
    mov [0x0001], dx
    mov word [0x0003], 0xe3ff
    mov cx, 0x1f00
    rep stosw
    mov byte [0x0000], 0xbb
    mov [0x0001], dx
    mov word [0x0003], 0xe3ff
    mov cx, 0x1f00
    rep stosw
    int 0x21
label5:
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x03fa
    push cs
    pop es
    mov ax, 0xdc01
    mov dx, 0xff55
    mov bx, 0xe5ff
    int 0x87
    mov cx, 0x7c00
    mov ax, 0xe5ff
    int 0x86
    int 0x86
    mov dx, 0x7c00
    mov bx, 0x0800
label6:
    rep stosw
    db 0x8B, 0xCA ;$1 mov cx, dx
    db 0x03, 0xFB ;$1 add di, bx
    jmp label6
label7:
    mov [0x00b9], ax
    mov es, [0x0062]
    mov cx, 0xe0ff
    mov ax, 0xe3f7
    mov dx, 0x0da3
    mov bx, [0x4741]
    int 0x87
    mov si, [0x00b9]
    db 0x8B, 0xFE ;$1 mov di, si
    add si, 0x0003
    sub di, 0x0400
    std
    mov ax, 0xe5ff
    int 0x86
    int 0x86
    mov cx, 0x7a00
    mov dx, 0x7b00
    mov bx, 0x0a00
label8:
    rep stosw
    db 0x8B, 0xCA ;$1 mov cx, dx
    db 0x2B, 0xFB ;$1 sub di, bx
    jmp label8
label9:
    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x9b9b
    db 0x8B, 0xD0 ;$1 mov dx, ax
    mov bx, 0xe5ff
    int 0x87
    db 0x8B, 0xD7 ;$1 mov dx, di
    add di, 0x5400
    mov ax, 0xe5ff
    mov cx, 0x5400
    rep stosw
    mov byte [0x0000], 0xbb
    mov [0x0001], dx
    mov word [0x0003], 0xe3ff
    add di, 0x0800
    mov ax, 0xcccc
    mov cx, 0x7c00
    rep stosw
    int 0x21
    mov bx, 0x0000
    jmp label5
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], dx
    mov cx, 0xe3ff
    mov [bx+0x03], cx
    mov cx, 0x1f00
    rep stosw
    mov bx, 0x0000
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], dx
    mov cx, 0xe3ff
    mov [bx+0x03], cx
    mov cx, 0x1f00
    mov cx, 0xe0ff
    mov ax, 0xe3f7
    mov dx, 0x0da3
    mov bx, [0x4741]
    int 0x87
    std
    mov ax, 0xe5ff
    int 0x86
    int 0x86
    mov dx, 0xe3ff
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], si
    mov [bx+0x03], dx
    mov cx, 0x7b00
    sub di, 0x0a00