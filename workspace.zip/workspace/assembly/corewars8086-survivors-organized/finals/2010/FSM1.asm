    mov [0x4743], bx
    db 0xE9, 0x2B, 0x00 ;$1 jmp 50
    int3
    int3
    int3
    rep movsw
    int3
    int3
    int3
    int 0x86
    int 0x86
    rep movsw
    cld
    mov di, cs
    push es
    pop ds
    mov es, di
    mov ss, di
    jmp sp
    nop
    nop
    nop
    nop
    nop
    mov bx, 0x1000
    mov ss, bx
    mov es, bx
    mov ds, bx
    call prcd1
prcd1:
    pop si
    add ax, 0x00c7
    stosw
    xchg bp, ax
    mov dx, 0x2c2d
    db 0x8B, 0xC2 ;$1 mov ax, dx
    mov di, 0x01fe
    int 0x86
    int 0x86
    std
    lea si, [bp+word 0x0016]
    mov cx, 0x0018
    rep movsw
    cld
    mov di, cs
    push es
    pop ds
    mov es, di
    mov ss, di
    db 0x8B, 0xF5 ;$1 mov si, bp
    lea di, [si-0x0be4]
    lea sp, [si-0x07fc]
    mov si, 0xa5f3
    push sp
    push si
    push sp
    pop sp
    mov bx, 0xf400
    mov dx, 0xf802
    mov bp, 0xfc04
    mov ax, 0x815e
    mov si, 0x0004
    mov cx, 0x01fe
    jmp sp
    nop
    nop
    nop
    nop
    nop
    cld
    mov bp, cs
    mov cl, 0x04
    shl bp, cl
    mov cl, 0x0b
    shl ax, cl
    xchg di, ax
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov cx, 0x001d
    loop $
    mov bx, 0x1000
    mov ss, bx
    mov es, bx
    mov ds, bx
    call prcd2
prcd2:
    pop si
    lea si, [bp+si+0x07]
    push bx
    push si
    retf
    lea sp, [si+0x39]
    mov bx, di
    mov cx, 0x01fe
    pop ax
    and ah, 0x03
    dec ax
    pop sp
    pop bp
    db 0x8B, 0xD5 ;$1 mov dx, bp
    sub bp, 0x03fe
    db 0x8B, 0xF4 ;$1 mov si, sp
    add si, 0xfc1c
    db 0x33, 0xFE ;$1 xor di, si
    jmp sp
    lodsw
    esc 0xde
    rep movsw
    stosw
    add sp, dx
    push word [si-0x18]
    push dx
    xchg sp, ax
    stosw
    xchg sp, ax
    pop dx
    db 0x03, 0xFB ;$1 add di, bx
    add si, bp
    mov cx, 0x01fe
    dec ax
label1:
    jnz label1+1
    in al, 0x1f
    int3
    int3
    int3
    rep movsw
    int3
    int3
    int3
    int 0x86
    int 0x86
    rep movsw
    cld
    mov di, cs
    push es
    pop ds
    mov es, di
    mov ss, di
    jmp sp
    nop
    nop
    nop
    nop
    nop
    mov bx, 0x1000
    mov ss, bx
    mov es, bx
    mov ds, bx
    call prcd3
prcd3:
    pop si
    int3
    int3
    int3
    xchg bx, ax
label2:
    mov ah, [0x4743]
    mov al, 0xbd
    mul bx
    mov [0xed0d], ax
    jmp label2