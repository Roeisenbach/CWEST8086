    push ds
    pop es
    mov di, ax
    mov si, ax
    add si, 0x000c
    add di, 0x001c
    mov cx, 0x0010
    add di, 0x0190
loop1:
    movsb
    loop loop1
    add si, 0x0190
    jmp si