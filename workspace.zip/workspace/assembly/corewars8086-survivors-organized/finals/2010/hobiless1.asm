    nrg
    mov bx, ax
    add bx, 0x0033
    mov al, 0xcc
label1:
    mov ax, bx
    mov [bx+0x01], al
    add bx, 0x0009
    mov bx, ax
    add bx, 0x0033
    mov al, 0xcc
label2:
    mov ax, bx
    mov [bx+0x01], al
    add bx, 0x0007
    jmp label2
    jmp label1
    mov bx, ax
    add bx, 0x0033
    mov al, 0xcc
label3:
    mov ax, bx
    mov [bx+0x01], al
    add bx, 0x0008
    jmp label3