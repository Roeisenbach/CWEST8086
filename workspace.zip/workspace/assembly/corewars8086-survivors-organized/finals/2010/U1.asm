    call prcd5
    call prcd1
prcd1:
    pop ax
    add ax, 0x0041
    stosw
    db 0x33, 0xFF ;$1 xor di, di
    sub ax, 0x0009
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, 0x0013
    rep movsw
    push cs
    push es
    pop ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b9
    mov dx, 0xf37a
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    add di, 0x0426
    db 0x8B, 0xEF ;$1 mov bp, di
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    mov ax, 0x0068
    mov bx, 0x03fc
    mov cx, 0x0002
    jmp bp
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    call prcd2
    db 0x2B, 0xE0 ;$1 sub sp, ax
    call far [bx]
prcd2:
    movsw
    movsw
    movsw
    pop [bx]
    movsw
    add [bx], cx
    movsw
    movsw
    db 0x2B, 0xE8 ;$1 sub bp, ax
    movsw
    movsw
    movsw
    movsw
    db 0x8B, 0xFD ;$1 mov di, bp
    movsw
    jmp bp
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    nop
    nop
    nop
    nop
    call prcd3
prcd3:
    pop ax
    add ax, 0x0041
    stosw
    db 0x33, 0xFF ;$1 xor di, di
    sub ax, 0x0009
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, 0x0013
    rep movsw
    push cs
    push es
    pop ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b9
    mov dx, 0xf37a
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    add di, 0x0426
    db 0x8B, 0xEF ;$1 mov bp, di
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    mov ax, 0x0068
    mov bx, 0x03fc
    mov cx, 0x0002
    jmp bp
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    call prcd4
    db 0x2B, 0xE0 ;$1 sub sp, ax
    call far [bx]
prcd4:
    movsw
    movsw
    movsw
    pop [bx]
    movsw
    add [bx], cx
    movsw
    movsw
    db 0x2B, 0xE8 ;$1 sub bp, ax
    movsw
    movsw
    movsw
    movsw
    db 0x8B, 0xFD ;$1 mov di, bp
    movsw
    jmp bp
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    nop
    nop
    nop
    nop
prcd5:
    call prcd6
prcd6:
    pop ax
    add ax, 0x0041
    stosw
    db 0x33, 0xFF ;$1 xor di, di
    sub ax, 0x0009
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, 0x0013
    rep movsw
    push cs
    push es
    pop ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b9
    mov dx, 0xf37a
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    add di, 0x0426
    db 0x8B, 0xEF ;$1 mov bp, di
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    mov ax, 0x0068
    mov bx, 0x03fc
    mov cx, 0x0002
    jmp bp
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    call prcd7
    db 0x2B, 0xE0 ;$1 sub sp, ax
    call far [bx]
prcd7:
    movsw
    movsw
    movsw
    pop [bx]
    movsw
    add [bx], cx
    movsw
    movsw
    db 0x2B, 0xE8 ;$1 sub bp, ax
    movsw
    movsw
    movsw
    movsw
    db 0x8B, 0xFD ;$1 mov di, bp
    movsw
    jmp bp
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    nop
    nop
    nop
    nop
    call prcd8
prcd8:
    pop ax
    add ax, 0x0041
    stosw
    db 0x33, 0xFF ;$1 xor di, di
    sub ax, 0x0009
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, 0x0013
    rep movsw
    push cs
    push es
    pop ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b9
    mov dx, 0xf37a
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    add di, 0x0426
    db 0x8B, 0xEF ;$1 mov bp, di
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    mov ax, 0x0068
    mov bx, 0x03fc
    mov cx, 0x0002
    jmp bp
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    call prcd9
    db 0x2B, 0xE0 ;$1 sub sp, ax
    call far [bx]
prcd9:
    movsw
    movsw
    movsw
    pop [bx]
    movsw
    add [bx], cx
    movsw
    movsw
    db 0x2B, 0xE8 ;$1 sub bp, ax
    movsw
    movsw
    movsw
    movsw
    db 0x8B, 0xFD ;$1 mov di, bp
    movsw
    jmp bp
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    nop
    nop
    nop
    nop
    call prcd10
prcd10:
    pop ax
    add ax, 0x0041
    stosw
    db 0x33, 0xFF ;$1 xor di, di
    sub ax, 0x0009
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, 0x0013
    rep movsw
    push cs
    push es
    pop ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b9
    mov dx, 0xf37a
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    add di, 0x0426
    db 0x8B, 0xEF ;$1 mov bp, di
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    mov ax, 0x0068
    mov bx, 0x03fc
    mov cx, 0x0002
    jmp bp
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    call prcd11
    db 0x2B, 0xE0 ;$1 sub sp, ax
    call far [bx]
prcd11:
    movsw
    movsw
    movsw
    pop [bx]
    movsw
    add [bx], cx
    movsw
    movsw
    db 0x2B, 0xE8 ;$1 sub bp, ax
    movsw
    movsw
    movsw
    movsw
    db 0x8B, 0xFD ;$1 mov di, bp
    movsw
    jmp bp
    movsw
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    nop
    nop
    nop
    nop