    jmp label6
label1:
    xchg bx, ax
label2:
    mov ah, [0x4743]
    mov al, 0xbd
    mul bx
    mov [0xed8d], ax
    jmp label2
    rol ax, 1
    ror ax, 1
    ror ax, 1
    ror ax, 1
    db 0x8B, 0xC3 ;$1 mov ax, bx
    db 0x03, 0xC1 ;$1 add ax, cx
    db 0x33, 0xC1 ;$1 xor ax, cx
    db 0x8B, 0xDA ;$1 mov bx, dx
    db 0x33, 0xC3 ;$1 xor ax, bx
    rep movsw
    db 0x3B, 0xF7 ;$1 cmp si, di
    jmp label1
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x6000
    mov ax, 0xe5ff
    mov cx, 0x2000
    rep stosw
    mov bx, 0x0000
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], dx
    mov cx, 0xe3ff
    mov [bx+0x03], cx
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x0400
    mov ax, 0xcccc
    mov cx, 0x1f00
    rep stosw
    mov bx, 0x0000
    jmp label4
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], dx
    mov cx, 0xe3ff
    mov [bx+0x03], cx
    mov cx, 0x1f00
    rep stosw
    mov cx, 0xe0ff
    mov ax, 0xe3f7
    mov dx, 0x0da3
    mov bx, [0x4741]
    int 0x87
    mov bx, 0x0000
    mov cx, cs
    mov es, cx
    db 0x8B, 0xF8 ;$1 mov di, ax
    sub di, 0x0400
    std
    mov ax, 0xe5ff
    int 0x86
    int 0x86
    mov dx, 0xe3ff
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], si
    mov [bx+0x03], dx
    mov cx, 0x7b00
    rep stosw
    mov cl, 0xbb
    mov [bx], cl
label3:
    mov [bx+0x01], si
    mov [bx+0x03], dx
    sub di, 0x0a00
    jmp label3
    push cs
    pop es
    db 0x8B, 0xD3 ;$1 mov dx, bx
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x6000
    std
    mov ax, 0xe5ff
    mov cx, 0x2000
    rep stosw
    mov bx, 0x0000
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], dx
    mov cx, 0xe3ff
    mov [bx+0x03], cx
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x0400
    mov ax, 0xcccc
    mov cx, 0x1f00
    int 0x21
label4:
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x03fa
    mov cx, 0x7c00
    mov ax, 0xe5ff
    mov es, [0x0022]
    int 0x86
    int 0x86
label5:
    rep stosw
    mov cx, 0x7c00
    add di, 0x0800
    jmp label5
    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x5400
    mov ax, 0xe5ff
    mov cx, 0x5400
    rep stosw
    mov bx, 0x0000
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], dx
    mov cx, 0xe3ff
    mov [bx+0x03], cx
    add di, 0x0800
    mov ax, 0xcccc
    mov cx, 0x7c00
    rep stosw
    int 0x21
label6:
    mov [0x0062], cs
    mov ax, [0x00b9]
    add ax, 0x0009
    mov byte [0x4741], 0xb0
    mov [0x4742], ax
    mov dx, 0xe3ff
    mov cl, 0xbb
    mov [bx], cl
    sub ax, 0x0006
    mov [bx+0x01], ax
    mov [bx+0x03], dx
    mov bx, ds
    mov [bx], cl
    mov [bx+0x01], ax
    mov [bx+0x03], dx
    add ax, 0x0003
    jmp ax
    xchg bx, ax
    mov ah, [0x4743]
    mov al, 0xbd
    mul bx
    mov [0xed8d], ax
    jmp label2
    rol ax, 1
    ror ax, 1
    ror ax, 1
    ror ax, 1
    db 0x8B, 0xC3 ;$1 mov ax, bx
    db 0x03, 0xC1 ;$1 add ax, cx
    db 0x33, 0xC1 ;$1 xor ax, cx
    db 0x8B, 0xDA ;$1 mov bx, dx
    db 0x33, 0xC3 ;$1 xor ax, bx
    rep movsw
    db 0x3B, 0xF7 ;$1 cmp si, di
    jmp label1
    db 0x8B, 0xFA ;$1 mov di, dx
    sub di, 0x6000
    mov ax, 0xe5ff
    mov cx, 0x2000
    rep stosw
    int 0x21
    rep stosw
    mov cx, 0x7b00
    add di, 0x0800
    jmp label4
    mov bx, es
    mov [bx], ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0002
    mov bx, 0x0000
    mov cx, cs
    mov es, cx
    db 0x8B, 0xF8 ;$1 mov di, ax
    sub di, 0x0400
    std
    mov ax, 0xe5ff
    int 0x86
    int 0x86
    mov dx, 0xe3ff
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], si
    mov [bx+0x03], dx
    mov cx, 0x7b00
    rep stosw
    mov cl, 0xbb
    mov [bx], cl
    mov [bx+0x01], si
    mov [bx+0x03], dx
    sub di, 0x0a00
    jmp label3