    push ax
    push es
    push ds
    pop es
    mov ax, 0xc681
    mov dx, 0x012c
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop ds
    pop dx
    add dx, word 0x0029
    lodsw
    push es
    pop ds
    sub ax, 0x001c
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov si, dx
    mov cx, 0x0012
    rep movsw
    jmp ax
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov cl, 0xdc
    mov ax, 0xcccc
    mov dx, 0xcccc
    std
    int 0x86
    int 0x86
loop1:
    nrg
    loop loop1
    mov cx, 0x7f80
    rep stosw
    sub di, 0x0100
    mov cx, 0x00dc
    jmp loop1