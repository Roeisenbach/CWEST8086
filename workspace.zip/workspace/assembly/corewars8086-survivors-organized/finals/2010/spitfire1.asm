    push ds
    pop es
    push cs
    pop es
    mov di, ax
    mov [0x0101], ax
    add di, 0x0029
    mov si, di
    add di, 0x0026
    mov ax, 0x4187
    mov dx, 0x8820
    mov cx, 0xcccc
    mov bx, cx
    int 0x87
    mov bx, [0x0101]
    add bx, 0x004f
    mov [0x0101], bx
    mov cx, 0x0002
loop1:
    mov [bx], ax
    mov [bx+0x40], ax
    mov [bx+0x0080], ax
    mov [bx+0x00c0], ax
    add bx, 0x0100
    loop loop1
    mov cx, 0x0026
    add di, 0x015e
loop2:
    movsb
    loop loop2
    add si, 0x015e
    jmp si