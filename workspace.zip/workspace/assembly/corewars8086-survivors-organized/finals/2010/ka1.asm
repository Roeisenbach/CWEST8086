    push ds
    pop es
    mov dx, ax
    xchg di, ax
    add di, 0x0019
    mov si, di
    add si, 0x0017
    std
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    inc di
    inc di
    mov bx, dx
    sub bx, 0x0043
    inc bx
    mov dx, 0x00cc
    mov [bx], dx
    jmp di
    add [bx+si], al
    add [bx+si], al
    xor al, 0x00
    db 0x0F
    mov ax, [bp+si+byte 0x00]
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    add [bx+si], al
    db 0x00  ; add [bx+si], al