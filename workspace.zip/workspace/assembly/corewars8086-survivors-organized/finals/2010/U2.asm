    call prcd1
    push ds
    push es
    pop ds
    pop es
    lodsw
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b8
    mov dx, 0x3302
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    mov bx, di
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    sub di, 0x7c00
    std
    int 0x86
    int 0x86
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov bx, 0x03fc
    mov [bx], ax
    mov dx, cs
    mov [bx+0x02], dx
    mov ss, dx
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov ax, 0x2004
    call far [bx]
    nop
    nop
    nop
    nop
    push ds
    push es
    pop ds
    pop es
    lodsw
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b8
    mov dx, 0x3302
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    mov bx, di
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    sub di, 0x7c00
    std
    int 0x86
    int 0x86
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov bx, 0x03fc
    mov [bx], ax
    mov dx, cs
    mov [bx+0x02], dx
    mov ss, dx
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov ax, 0x2004
    call far [bx]
    nop
    nop
    nop
    nop
prcd1:
    push ds
    push es
    pop ds
    pop es
    lodsw
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b8
    mov dx, 0x3302
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    mov bx, di
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    sub di, 0x7c00
    std
    int 0x86
    int 0x86
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov bx, 0x03fc
    mov [bx], ax
    mov dx, cs
    mov [bx+0x02], dx
    mov ss, dx
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov ax, 0x2004
    call far [bx]
    nop
    nop
    nop
    nop
    push ds
    push es
    pop ds
    pop es
    lodsw
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b8
    mov dx, 0x3302
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    mov bx, di
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    sub di, 0x7c00
    std
    int 0x86
    int 0x86
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov bx, 0x03fc
    mov [bx], ax
    mov dx, cs
    mov [bx+0x02], dx
    mov ss, dx
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov ax, 0x2004
    call far [bx]
    nop
    nop
    nop
    nop
    push ds
    push es
    pop ds
    pop es
    lodsw
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0x00b8
    mov dx, 0x3302
    mov bx, 0xcccc
    db 0x8B, 0xCB ;$1 mov cx, bx
    int 0x87
    mov bx, di
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    sub di, 0x7c00
    std
    int 0x86
    int 0x86
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov bx, 0x03fc
    mov [bx], ax
    mov dx, cs
    mov [bx+0x02], dx
    mov ss, dx
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov ax, 0x2004
    call far [bx]
    nop
    nop
    nop
    nop