    mov bx, ax
    add bx, 0x001e
    mov al, 0xcc
    mov cx, 0x0020
label1:
    nrg
label2:
    dec cx
    mov [bx], al
    add bx, 0x0001
    cmp cx, 0x0000
    jz label2
    add bx, 0x0008
    jmp label1