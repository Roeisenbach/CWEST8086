    mov [0xc0de], cl
    mov [0xc1de], cl
    mov [0xc2de], cl
    mov [0xc3de], cl
    mov [0xc4de], cl
    mov [0xc5de], cl
    push cs
    pop es
    push cs
    pop ss
    mov si, ax
    add si, 0x002e
    mov di, si
    inc di
    inc di
    mov sp, si
    sub sp, 0x4000
    mov dx, 0xf6ff
    push dx
    movsw
    call si
    push dx
    movsw
    call si
    push dx
    movsw
    call si
    push dx
    movsw
    call si