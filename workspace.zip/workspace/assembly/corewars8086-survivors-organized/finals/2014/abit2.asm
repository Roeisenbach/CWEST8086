    push es
    push es
    pop ds
    mov bx, [0x0000]
    push cs
    pop es
    mov di, ax
    add di, 0x058c
    int 0x86
    add di, 0x058c
    int 0x86
    mov di, bx
    add di, 0x7fde
    mov cx, 0x0006
    mov si, 0x0100
    push di
loop1:
    movsw
    movsw
    movsw
    loop loop1
    ret
    mov cx, 0x0100
    add di, 0x1500
loop2:
    stosw
    add di, 0x0010
    stosw
    add di, 0x0010
    stosw
    add di, 0x0010
    loop loop2
    push di
    mov si, 0x0100
    mov cx, 0x0006
loop3:
    movsw
    movsw
    movsw
    loop loop3
    ret