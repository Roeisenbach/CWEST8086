    jmp label1
    push es
    push ss
    pop ss
    push ds
    push cs
    db 0x0F
    pop ds
    pop ss
    mov cx, 0x0005
    db 0xF3, 0x43
    sub bx, 0x000a
    mov cx, 0x0001
    mov cx, 0x0000
    push ss
    push cs
    pop ds
    pop ss
    mov bx, 0x0000
label1:
    jmp label2
    int3
    int3
    add si, word 0x003a
    mov cx, 0x0006
    movsb
    rep movsw
    add si, 0x0060
    mov cx, 0x000b
    rep movsw
    mov bp, 0x00ff
    jmp label4
    movsw
    movsw
    movsw
    add dx, 0x17a8
    movsw
    dec bp
    movsw
    movsw
    jz label3
label2:
    mov si, ax
    nop
    add ax, 0x001b
    mov byte [0x0000], 0xbe
    mov [0x0001], si
label3:
    mov word [0x0003], 0xc289
    mov byte [0x0005], 0xe9
    mov [0x0006], ax
    nop
    nop
    nop
    nop
    push es
    push cs
    pop es
    mov bx, 0xdb31
    mov cx, 0xe3ff
    mov ax, 0x8a1e
    mov dx, 0xdec3
    int 0x87
    pop es
    mov dx, si
    add si, 0x00a4
    mov cx, 0x000d
    rep movsw
    mov bp, 0x17a8
label4:
    mov cx, 0x03f3
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov ax, 0xab53
    mov bx, 0xcca5
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    movsw
    add dx, bp
    movsw
    movsw
    mov sp, dx
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, dx
    stosw
    jmp dx
    mov al, 0x00
    add al, 0x14
    int3
    int3
    mov al, al
    add ah, al
    int3
    int3
    inc ah
    mov al, ah
    inc al
    int3
    int3