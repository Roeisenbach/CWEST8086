    mov bx, ax
    mov ax, 0x55a5
    mov dx, 0x55a5
    add di, 0x0200
    int 0x86
    nop
    mov si, bx
    add si, 0x0051
    mov cx, 0x000d
    rep movsw
    push bx
    lea bx, [bx+0x0090]
    lea cx, [bx-0x25]
    lea si, [bx+0x0404]
    mov [bx], cx
    mov cx, bx
    mov bx, 0x16ff
    mov ax, 0xdb84
    mov dx, 0x0679
    push es
    push ds
    pop es
    int 0x87
    pop es
    pop bx
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    add bx, 0x08bb
    mov sp, bx
    mov di, bx
    xor si, si
    mov bp, 0xcccc
    mov ax, di
    movsw
    jmp ax
    movsw
    movsw
    movsw
    add sp, 0xb526
    movsw
    movsw
    movsw
    add ax, 0xb426
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov di, ax
    xor si, si
    movsw
    jmp ax
    mov bx, ax
    mov ax, 0x55a5
    mov dx, 0x55a5
    int 0x86
    nop
    int 0x86
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    add bx, 0x08bb
    mov sp, bx
    mov di, bx
    xor si, si
    mov bp, 0xcccc
    mov ax, di
    movsw
    jmp ax
    add [bx+si], al
    add [bx+si], dl
    push cs
    pop es
    int 0x87
    and ax, 0x7fff
label1:
    push ax
    mov bl, [0xc0de]
    test bl, bl
    jns label2
    div bl
    mov [0xc0dd], ah
label2:
    pop ax
    jmp label1