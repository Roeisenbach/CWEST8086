    add ax, 0x0022
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, 0x0016
    nop
    rep movsw
    movsb
    db 0x8B, 0xF8 ;$1 mov di, ax
    push cs
    push es
    pop ds
    pop es
    mov [0x0152], cs
    mov [0x0150], ax
    db 0x33, 0xF6 ;$1 xor si, si
    push cs
    pop ss
    mov cx, 0x01f4
    db 0x8B, 0xE0 ;$1 mov sp, ax
    loop loop1
    add byte [0x0150], 0x12
loop1:
    nrg
    sub sp, 0x0005
    call far [0x0150]
    sub di, 0x1500
    mov [0x0150], di
    mov cx, 0x0016
    nop
    rep movsw
    movsb
    db 0x33, 0xF6 ;$1 xor si, si
    mov cx, 0x01f4
    sub di, 0x002d
    db 0x8B, 0xE7 ;$1 mov sp, di
    call di