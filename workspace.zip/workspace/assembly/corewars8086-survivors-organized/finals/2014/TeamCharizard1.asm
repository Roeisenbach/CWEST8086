    push cs
    pop es
    mov di, ax
    mov si, ax
    add si, 0x000e
    add di, 0x0020
    mov dx, 0xcccc
    mov cx, 0x0014
    rep movsw
    mov cx, 0x0006
label1:
    add bx, 0x000c
    mov [bx], dx
    jnz label1
    add di, 0x0020
    mov si, di
    jmp di