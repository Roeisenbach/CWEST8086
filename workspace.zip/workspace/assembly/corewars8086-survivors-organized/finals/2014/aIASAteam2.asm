start:
    jmp label1
    mov cx, 0x03fb
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov bx, 0x1284
    mov byte [bx], 0x01
    mov cx, 0x0001
    mov ax, 0xab55
    mov bp, 0xcca5
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x7d4f], ax
    mov [0x7d51], cs
    mov word [0xc0de], 0x7d4f
    push cs
    pop es
    mov ax, 0xc0de
    mov dx, 0xdb84
    mov bx, ax
    mov cx, 0x2fff
    mov word [0xc0de], 0x7d4f
    int 0x87
    jmp $
    push cs
    pop es
    mov di, 0x8abd
    mov ax, 0xdb84
    mov dx, 0x0679
    mov bx, 0x2eff
    mov cx, 0x7d4f
    int 0x87
    jmp $
    push cs
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x7d4f], ax
    mov [0x7d51], cs
    mov word [0xc0de], 0x7d4f
    push cs
    pop es
    mov ax, 0xc0de
    mov dx, 0xdb84
    mov bx, ax
    mov cx, 0x2fff
    mov word [0xc0de], 0x7d4f
    int 0x87
    jmp $
    mov sp, [0x0000]
    sub sp, 0x8000
    and sp, 0xfffc
    inc sp
    mov di, 0x0002
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x7d4f], ax
    push cs
    pop ss
    push cs
    pop es
    mov cx, 0x0065
    loop $
    mov ax, 0x2eff
    mov cx, 0x7d4f
    lea di, [si-0x2000]
    int 0x86
    mov di, 0xa000
    int 0x86
    mov ax, 0xcccc
    mov sp, 0x8abd
    mov byte [0x7a3b], 0x50
    mov word [0x7a3c], 0xfdeb
    mov word [0x7d4f], 0x7a3b
    mov [0x7d51], cs
    jmp word [0x7d4f]
label1:
    mov si, ax
    push ax
    push bx
    push cx
    push dx
    push di
    push es
    add ax, 0x00a1
    mov [0x7d4f], ax
    mov [0x7d51], cs
    push cs
    pop es
    mov di, 0x8abd
    mov ax, 0xa4ef
    mov dx, 0x1dff
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    mov ax, bx
    mov dx, cx
    lea di, [si-0x2000]
    int 0x86
    lea di, [si-0x4000]
    int 0x86
    pop es
    pop di
    pop dx
    pop cx
    pop bx
    pop ax
    mov dx, 0x2238
    add si, 0x0154
    add di, 0x0180
    mov cx, 0x0015
    rep movsw
    mov cx, 0x03fb
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov word [0x01b2], 0x1ffd
    mov [0x01b4], cs
    mov bx, 0x0032
    mov byte [bx], 0x30
    mov cx, 0x0030
    mov ax, 0xab55
    mov bp, 0xcca5
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    pop ds
    mov word [0x1ffd], 0x1fff
    pop ds
    movsw
    movsw
    movsw
    mov bx, 0x01b2
    movsw
    movsw
    movsw
    and sp, 0xfffc
    movsw
    inc sp
    movsw
    movsw
    call far [bx]
    mov word [0xc0de], 0xcccc
    pop es
    int 0x87
    and ax, 0x7fff
    push ax
    mov bl, [0xc5de]
    div bl
    mov [0xc5dd], ah
    pop ax
    jmp 519
    push cs
    pop es
    mov di, 0x8abd
    mov ax, 0xdb84
    mov dx, 0x0679
    mov bx, 0x2eff
    mov cx, 0x7d4f
    int 0x87
    jmp $
    db 0x83, 0xC0, 0x00 ;$1 add ax, 0x0000
    mov [0x7d4f], ax
    mov [0x7d51], cs
    mov word [0xc0de], 0x7d4f
    push cs
    pop es
    mov ax, 0xc0de
    mov dx, 0xdb84
    mov bx, ax
    mov cx, 0x2fff
    mov word [0xc0de], 0x7d4f
    int 0x87
    jmp $
    push cs
    pop ss
    mov sp, 0x1234
    push ax
    jmp $
    push cs
    pop ss
    mov sp, 0x8abd
    push ax
    jmp start
    movsw
    loop 582
    add dx, 0x9356
    inc byte [bx]
    push cs
    pop es
    mov di, 0x8abd
    mov ax, 0xdb84
    mov dx, 0x0679
    mov bx, 0x2eff
    mov cx, 0x7d4f
    int 0x87
    mov word [0xc0de], 0xcccc