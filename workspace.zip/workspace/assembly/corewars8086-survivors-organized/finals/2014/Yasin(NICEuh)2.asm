    jmp label2
    mov bx, 0x0005
    mov cx, bx
    mov [0x2d77], bx
    mov bx, 0x0000
    push ss
    push ds
    db 0x0F
    push es
    push ds
    db 0x0F
    pop es
    pop ss
    mov [bx], bx
    add bx, 0x0002
    mov cx, 0x0006
    db 0xF3, 0x83
    jmp label1+1
label1:
    mov bx, [bx]
    push cs
    pop ds
    push es
    push ss
    mov bx, 0x0000
    pop ss
    pop es
    mov bx, 0x0000
label2:
    push es
    push cs
    pop es
    xor di, di
    mov ax, 0xccbb
    mov dx, ax
    int 0x86
    int 0x86
    mov ax, 0x0000
    pop es
    jmp label3
    int3
    int3
label3:
    mov si, ax
    mov dx, si
    mov bp, 0x17a8
    mov cx, 0x03f3
    mov ax, 0xab53
    mov bx, 0xcca5
    push cs
    push es
    push ds
    pop es
    pop ds
    pop ss
    mov sp, dx
    add sp, 0x00f3
    mov di, dx
    xor si, si
    stosw
    jmp dx
    int3
    int3