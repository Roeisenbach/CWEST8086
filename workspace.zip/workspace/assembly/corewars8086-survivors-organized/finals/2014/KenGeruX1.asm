    brk
    push es
    push ds
    pop es
    mov [0xc8f7], ax
    mov dx, 0xc0dd
    mov cx, 0xc8f7
    mov ax, 0x2688
    mov bx, 0x16ff
    int 0x87
    pop es
    mov si, [0xc8f7]
    add si, 0x00ac
    mov word [si-0x0098], 0xd3ff
    mov [si-0x009a], si
    sub si, 0x00a7
    mov [0xc8f3], si
    add si, 0x0065
    mov di, 0x011e
    mov cx, 0x0021
    rep movsw
    push es
    pop ds
    push cs
    pop ss
    mov sp, 0x2000
    mov cl, 0x08
    mov dx, 0x11e1
    mov es, dx
    mov di, 0x00f8
    mov bx, 0x01f1
label1:
    add [bx+di], di
    sub di, cx
    jnz label1
    mov bp, 0xdea6
    mov ax, 0x0010
    sub bx, 0x000e
    mov cl, 0x10
    mov si, 0x000c
    mov di, 0x01f0
    movsb
    call far [di]
    movsw
    mov al, 0x10
    movsw
    movsw
    mov dx, es
    movsw
    movsw
    movsw
    movsw
    sub dx, 0x01be
    movsw
    movsw
    movsw
    movsw
    or dx, [0x03fe]
    movsw
    movsw
    movsw
    movsw
    mov [0x03fa], dx
    movsw
    movsw
    movsw
    sub dx, 0x001f
    movsw
    push dx
    movsw
    movsw
    movsw
    movsw
    mov dx, [0x03fa]
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov si, 0x0100
label2:
    mov [bx+si], dx
    sub si, cx
    jnz label2
    movsw
    nop
    mov di, 0xc2dd
    mov byte [di+0x01], 0x80
    mov bp, 0x4400
    add byte [bx+0x02], 0x01
    add byte [bx+0x09], 0x24
    mov ch, 0x20
    mov bl, [di]
    mov si, bp
    mov ax, 0x16ff
    mov byte [di+0x01], 0xff
    mov dx, 0xc8f3
    mov bh, 0x00
    sub bh, bl
    add bx, 0x0008
    add bh, [di]
    mov di, bx
    sub bp, 0x0008
    int 0x86
    add di, 0x7e80
    push es
    pop ss
    mov sp, si
    push ax
    push ax
    push ax
    int 0x86
    std
    mov di, bp
    mov ax, 0xcccc
    mov dx, 0x0001
    mov word [si], 0xabf3
    call si