    push ax
    push es
    push ds
    pop es
    mov cx, 0xcece
    mov dx, 0x8958
    mov ax, 0x87cd
    mov bx, 0xcece
    int 0x87
    pop es
    pop ax
    add ax, 0x0039
    db 0x8B, 0xE8 ;$1 mov bp, ax
    db 0x8B, 0xD5 ;$1 mov dx, bp
    db 0x8B, 0xF5 ;$1 mov si, bp
    mov cx, 0x0030
    mov di, 0x0000
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov sp, 0x0000
    mov bx, 0x00cc
    mov si, 0x0000
    db 0x8B, 0xFD ;$1 mov di, bp
    movsw
    jmp bp
    movsw
    movsw
    movsw
    movsw
    movsw
    mov cx, 0x0012
    rep movsw
    mov cx, 0x000a
loop1:
    mov byte [bp+0x58], 0xcc
    mov byte [bp+0x58], 0xcc
    mov byte [bp+0x58], 0xcc
    mov byte [bp+0x58], 0xcc
    mov byte [bp+0x58], 0xcc
    mov byte [bp+0x58], 0xcc
    mov byte [bp+0x58], 0xcc
    mov byte [bp+0x58], 0xcc
    loop loop1
    movsw
    movsw
    movsw
    movsw
    mov cx, 0x0014
    rep movsw
    db 0x8B, 0xEA ;$1 mov bp, dx
    or bp, 0x0001
    db 0x33, 0xF6 ;$1 xor si, si
    mov [bp+0x0088], al
    mov [bp+0x1f], al
label1:
    push bx
    cmp [bp+0x0088], al
    jnz label2
    cmp [bp+0x1f], al
    jz label1
    sub dx, 0x0400
label2:
    add dx, 0x0200
    db 0x8B, 0xFA ;$1 mov di, dx
    movsw
    call dx
    call dx
    and ax, 0x7fff
label3:
    push ax
    mov bl, [0xc0de]
    test bl, bl
    jns label4
    div bl
    mov [0xc0dd], ah
label4:
    pop ax
    jmp label3
    and ax, 0x7fff
label5:
    push ax
    mov bl, [0xc1de]
    test bl, bl
    jns label6
    div bl
    mov [0xc1dd], ah
label6:
    pop ax
    jmp label5
    and ax, 0x7fff
label7:
    push ax
    mov bl, [0xc2de]
    test bl, bl
    jns label8
    div bl
    mov [0xc2dd], ah
label8:
    pop ax
    jmp label7
    and ax, 0x7fff
label9:
    push ax
    mov bl, [0xc3de]
    test bl, bl
    jns label10
    div bl
    mov [0xc3dd], ah
label10:
    pop ax
    jmp label9
    and ax, 0x7fff
label11:
    push ax
    mov bl, [0xc4de]
    test bl, bl
    jns label12
    div bl
    mov [0xc4dd], ah
label12:
    pop ax
    jmp label11
    and ax, 0x7fff
label13:
    push ax
    mov bl, [0xc5de]
    test bl, bl
    jns label14
    div bl
    mov [0xc5dd], ah
label14:
    pop ax
    jmp label13