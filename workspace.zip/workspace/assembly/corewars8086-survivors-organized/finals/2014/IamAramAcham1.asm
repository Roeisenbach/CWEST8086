    jmp label2
    push cs
    pop es
    int 0x87
label1:
    and ax, 0x7fff
    push ax
    mov bl, [0xc1de]
    test bl, bl
    db 0x0F
    mov [bp+si], ax
    add dh, dh
    db 0xF3, 0x88
    es:
    esc 0xdd
    db 0xC1
    pop ax
    jmp label1+1
    push cs
    pop es
    int 0x87
    and ax, 0x7fff
    push ax
    mov bl, [0xc1de]
    test bl, bl
    db 0x0F
    mov di, sp
    db 0xFF, 0xF6  ; push si
    db 0xF3, 0x88
    es:
    esc 0xdd
    db 0xC1
    pop ax
    jmp label1+1
label2:
    mov word [si], 0x1000
    mov cx, cs
    mov es, cx
    mov bl, 0xea
    mov ch, 0x00
    mov [si], ax
    call prcd1
prcd1:
    pop ax
    mov dx, ss
    mov es, dx
    mov si, ax
    add si, 0x005e
    mov cx, 0x0009
    rep movsw
    mov ds, dx
    mov cx, cs
    mov ss, cx
    sub ax, 0x1711
    and al, 0x07
    sub al, 0x08
    mov ch, 0x0f
    mov cl, al
    shl al, 1
    shl al, 1
    shl al, 1
    shl al, 1
    mov sp, ax
    mov al, 0xa3
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cx
    mov di, ax
    sub sp, 0x005d
    mov es, cx
    xor si, si
    mov ax, 0xcccc
    mov dx, 0xcccc
    std
    int 0x86
    int 0x86
    cld
    add di, 0x0200
    mov ax, 0x1fff
    stosw
    dec di
    mov bp, 0x0a00
    add sp, bp
    xor cx, cx
    jmp label3+1
label3:
    jmp 8358
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    dec di
    xor si, si
    call far [bx]
    call far [bx]
    push cs
    pop es
    int 0x87
    and ax, 0x7fff
    push ax
    mov bl, [0xc1de]
    test bl, bl
    db 0x0F
    mov [bp+di-0x01], cx
    div bl
    mov [0xc1dd], ah
    pop ax
    jmp 263
    push cs
    pop es
    int 0x87
    and ax, 0x7fff
    push ax
    mov bl, [0xc1de]
    test bl, bl
    db 0x0F
    mov [bx+si], si
    db 0xFF, 0xF6  ; push si
    db 0xF3, 0x88
    es:
    esc 0xdd
    db 0xC1
    pop ax
    jmp 263