    db 0x83, 0xC0, 0x34 ;$1 add ax, 0x0034
    jmp label1
    mov si, ax
    add si, 0x0010
    mov cx, 0x000e
    mov di, 0x0200
    rep movsw
    push es
    pop ds
    push cs
    pop es
    mov di, ax
    mov ax, 0xcccc
    mov cx, 0x0040
loop1:
    stosw
    sub di, 0x0024
    loop loop1
    mov cx, 0x000e
    mov si, 0x0200
    sub di, 0x0a37
    push di
    rep movsw
    pop ax
    jmp ax
label1:
    mov si, ax
    add si, 0x0010
    mov cx, 0x000e
    rep movsw
    push es
    pop ds
    push cs
    pop es
    mov di, ax
    mov ax, 0xcccc
    mov cx, 0x0040
loop2:
    stosw
    sub di, 0x0024
    loop loop2
    mov cx, 0x000e
    xor si, si
    sub di, 0x0a37
    push di
    rep movsw
    pop ax
    jmp ax