    brk
    push es
    push ds
    pop es
    mov [0xc8f5], ax
    mov dx, 0xc1dd
    mov cx, 0xc8f5
    mov ax, 0x2688
    mov bx, 0x16ff
    int 0x87
    pop es
    mov si, [0xc8f5]
    add si, 0x00b1
    mov word [si-0x009d], 0xd3ff
    mov [si-0x009f], si
    sub si, 0x00ac
    mov [0xc8f1], si
    add si, 0x00a0
    mov cx, 0x0006
    rep movsw
    mov ax, 0xa5a5
    mov dx, 0x1dff
    int 0x86
    sub di, 0x0004
    sub si, 0x0022
    mov cl, 0x0b
    rep movsw
    push es
    pop ds
    mov byte [0x03ff], 0x10
    mov di, 0x01f1
    mov dx, 0x1a00
    xor ax, ax
    int 0x86
    sub dx, 0x001f
    mov es, dx
    push cs
    pop ss
    add dx, 0x001f
    mov sp, dx
    shl sp, cl
    mov cl, 0x08
    mov di, 0x00f8
    mov bx, 0x000e
label1:
    mov word [bx+di], 0xec29
    sub di, cx
    jnb label1
    mov bp, 0xdea6
    mov ax, 0x0010
    mov bx, 0x01eb
    mov cl, 0x10
    mov si, 0x000c
    mov di, 0x01f0
    movsb
    call far [di]
    movsw
    dec ax
    movsw
    push es
    movsw
    movsw
    movsw
    movsw
    jz label2
    xor si, si
label2:
    movsw
    movsw
    movsw
    movsw
    movsw
    sub sp, 0xc9ce
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    pop es
    mov di, 0x01f0
    movsb
    call far [di]
    mov di, 0xc4dd
    mov byte [di+0x01], 0x80
    mov bp, 0xc400
    add byte [bx+0x02], 0x01
    add byte [bx+0x09], 0x24
    mov ch, 0x20
    mov bl, [di]
    mov si, bp
    mov ax, 0x16ff
    mov byte [di+0x01], 0xff
    mov dx, 0xc8f1
    mov bh, 0x00
    sub bh, bl
    add bx, 0x0008
    add bh, [di]
    mov di, bx
    sub bp, 0x0008
    int 0x86
    add di, 0x7e80
    push es
    pop ss
    mov sp, si
    push ax
    push ax
    push ax
    int 0x86
    std
    mov di, bp
    mov ax, 0xcccc
    mov dx, 0x0001
    mov word [si], 0xabf3
    call si