    mov [0xc0de], cl
    mov [0xc1de], cl
    mov [0xc2de], cl
    mov [0xc3de], cl
    mov [0xc4de], cl
    mov [0xc5de], cl
    push cs
    pop es
    push cs
    pop ss
    mov dx, ax
    add dx, 0x0034
    mov cx, 0x1000
    mov bh, 0xea
    mov [0x0000], bh
    mov [0x0001], dx
    mov [0x0003], cx
    jmp label1
    push cs
    pop es
    push cs
    pop ss
    mov si, ax
    mov sp, ax
    add si, 0x0030
    mov di, si
    add di, 0x0002
    mov cl, 0x00
    mov [0xc0de], cl
    mov [0xc1de], cl
    mov [0xc2de], cl
    mov [0xc3de], cl
    mov [0xc4de], cl
    mov [0xc5de], cl
    mov dx, 0xa505
    mov cx, 0xffff
loop1:
    movsw
    push dx
    loop loop1
    hlt
label1:
    mov si, ax
    add si, 0x007b
    mov di, si
    inc di
    inc di
    mov sp, si
    sub sp, 0x8000
    mov dx, 0xf6ff
    push dx
    movsw
    call si
    push dx
    movsw
    call si
    push dx
    movsw
    call si
    push dx
    movsw
    call si