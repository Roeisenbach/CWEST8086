    push es
    push es
    pop ds
    mov word [0x0000], 0x005a
    mov word [0x0004], 0x0249
    push cs
    pop ds
    mov cx, 0x0006
    mov si, ax
    add si, 0x0038
    mov di, 0x0100
loop1:
    movsw
    movsw
    movsw
    loop loop1
    push cs
    pop es
    mov di, ax
    sub di, 0x0750
    int 0x86
    sub di, 0x00fa
    int 0x86
    mov di, 0x005a
    mov ax, 0xcccc
    pop ds
    mov cx, 0x0070
    add di, 0x0930
loop2:
    stosw
    add di, 0x0010
    stosw
    add di, 0x0010
    stosw
    add di, 0x0010
    loop loop2
    push di
    mov si, 0x0100
    mov cx, 0x0006
loop3:
    movsw
    movsw
    movsw
    loop loop3
    ret