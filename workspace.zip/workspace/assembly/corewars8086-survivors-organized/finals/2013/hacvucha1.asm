    mov si, ax
    mov al, 0xcc
    add si, 0x0020
    mov bx, 0x0000
label1:
    mov [si], al
    add si, 0x0001
    add bx, 0x0001
    cmp bx, 0x001e
    jnz label1
    mov bx, 0x0000
    add si, 0x1388
    jmp label1