    jmp label1
    in al, dx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    add di, cx
    xor si, si
    push bx
    jmp sp
label1:
    mov si, ax
    add si, 0x0002
    mov cx, 0x0008
    rep movsw
    xor si, si
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov bx, 0x01a5
    mov sp, 0x7fff
    mov di, sp
    mov bp, 0x2eb2
    mov cx, 0x2ea2
    push bx
    jmp sp