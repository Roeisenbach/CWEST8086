    mov si, ax
    add si, 0x0011
    mov cx, 0x0008
    rep movsw
    push cs
    push es
    pop ds
    pop es
    mov di, 0x0256
    add di, 0x0500
    mov bp, di
    xor si, si
    mov cx, 0x0008
    rep movsw
    cld
    jmp bp