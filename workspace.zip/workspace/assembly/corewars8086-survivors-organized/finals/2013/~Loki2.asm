    jmp label1
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
label1:
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    jmp label1
    db 0x12, 0xEA ;$1 adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x013e
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x19aa
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    db 0x12, 0xEA ;$1 adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x013e
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x19aa
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    db 0x12, 0xEA ;$1 adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x013e
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x19aa
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    db 0x12, 0xEA ;$1 adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x013e
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x19aa
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    db 0x12, 0xEA ;$1 adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x013e
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x19aa
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    add [bx+si], al
    mov si, 0xe33f
    inc word [bx+si]
    add [bp+word 0x003f], bh
    jmp bx
    add [bp-0x1cc1], bh
    inc word [bx+si]
    add [bx], bh
    mov si, 0xff35
    inc bp
    add [bp+word 0x003f], bh
    jmp bx
    add [bp-0x1cc1], ch
    inc word [bx+si]
    movsw