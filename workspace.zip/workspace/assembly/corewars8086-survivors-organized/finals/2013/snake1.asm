    jmp label3
    jmp label4
    movsb
    int3
    int3
    int3
    int3
    stosw
    movsw
    int3
    movsw
    movsw
    movsw
    add sp, bx
    movsw
    movsw
    hlt
    jmp word [di-0x5a5b]
    movsw
    movsw
    mov si, ax
    add si, 0x0002
    mov cx, 0x0006
    rep movsw
    mov cx, ax
    push cs
    pop ss
    mov sp, ax
    call far [bx]
    add sp, 0x0801
    mov di, ax
    xor si, si
    mov bp, 0x1000
    mov bx, 0x1803
    mov ax, 0xab52
    mov dx, 0xcca5
    push es
    push ds
    pop es
    pop ds
    stosw
    call cx
    jmp label4
    movsw
    movsw
    int3
    int3
    movsw
    add sp, bx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov si, ax
    add si, 0x0002
    mov cx, 0x0006
    rep movsw
    mov cx, ax
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0801
    mov di, ax
    xor si, si
    mov bp, 0x1000
    mov bx, 0x1803
label1:
    mov ax, 0xab52
    mov dx, 0xcca5
    push es
    push ds
    int3
    int3
    pop es
    pop ds
    stosw
    call cx
    esc 0xdf
    int3
    esc 0xdd
    aas
label2:
    pop bx
    inc dx
    mov [0x7845], ax
    aas
    db 0xFF, 0x3F
    js label5
    mov [0x78cc], al
    jno label1+1
    int3
    esc 0xdd
    aas
    pop bx
    inc dx
    mov [0x7845], ax
    aas
    db 0xFF, 0x3F
    js label6+2
    mov [0x78cc], al
    jno label2
    int3
    esc 0xdd
    aas
    pop bx
    inc dx
    mov [0x7845], ax
    aas
    db 0xFF, 0x3F
    db 0xFF, 0x3F
label3:
    jmp label4
    movsw
    movsw
    movsw
    add sp, bx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
label4:
    add ax, 0x00b8
    mov si, ax
    add si, 0x0002
    mov cx, 0x0006
    rep movsw
label5:
    mov cx, ax
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov di, ax
    add di, 0x0800
    xchg bp, cx
label6:
    mov cx, 0xcccc
    mov bx, 0xcccc
    mov ax, 0x7fff
    mov dx, 0xcccc
    int 0x87
    mov ax, di
    sub ax, 0x0800
    int 0x86
    xchg bp, cx
    mov di, ax
    sub di, 0x0800
    int 0x86
    mov sp, ax
    add sp, 0x0601
    mov di, ax
    xor si, si
    mov bp, 0x2000
    mov bx, 0x2603
    mov ax, 0xab52
    mov dx, 0xcca5
    stosw
    call cx
    jmp label4
    movsw
    movsw
    movsw
    add sp, bx
    movsw
    movsw
    stosw
    push dx
    movsw
    movsw
    movsw
    movsw
    movsw
    mov si, ax
    add si, 0x0002
    mov cx, 0x0006
    rep movsw
    mov cx, ax
    mov sp, ax
    jg label7+1
    add sp, 0x0801
    mov di, ax
    xor si, si
    mov bp, 0x1000
    mov bx, 0x1803
    mov ax, 0xab52
    mov dx, 0xcca5
    push es
    push ds
    js label8
    pop es
    pop ds
    push cs
    pop ss
    stosw
    call cx
    jmp label4
    movsw
    movsw
    movsw
    add sp, bx
    movsw
    movsw
    movsw
    movsw
    js label9
    movsw
    movsw
    movsw
    mov si, ax
    add si, 0x0002
    mov cx, 0x0006
    rep movsw
    mov cx, ax
    push cs
    pop ss
label7:
    mov sp, ax
    add sp, 0x0801
    mov di, ax
    xor si, si
    mov bp, 0x1000
    int3
    int3
    mov bx, 0x1803
    mov ax, 0xab52
    mov dx, 0xcca5
    push es
label8:
    push ds
    pop es
    pop ds
    stosw
    call cx
    jmp label4
    movsw
    movsw
    movsw
    add sp, bx
    movsw
    movsw
    movsw
    movsw
    js label10
    movsw
label9:
    movsw
    movsw
    mov si, ax
    add si, 0x0002
    mov cx, 0x0006
    rep movsw
    mov cx, ax
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0801
    mov di, ax
    xor si, si
    mov bp, 0x1000
    int3
    int3
    mov bx, 0x1803
    mov ax, 0xab52
    mov dx, 0xcca5
    push es
    push ds
    pop es
    pop ds
    stosw
    call cx
    jmp label4
    movsw
    movsw
    movsw
    add sp, bx
    movsw
    movsw
    movsw
    movsw
    js 547
    movsw
label10:
    movsw
    movsw
    mov si, ax
    add si, 0x0002
    mov cx, 0x0006
    rep movsw
    mov cx, ax
    push cs
    pop ss
    call cx