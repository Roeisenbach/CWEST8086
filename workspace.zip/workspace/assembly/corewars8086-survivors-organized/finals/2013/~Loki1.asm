    jmp label1
    db 0x12, 0xEA ;$1 adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x00bb
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x19aa
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    db 0x12, 0xEA ;$1 adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x00bb
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x19aa
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    db 0x12, 0xEA ;$1 adc ch, dl
label1:
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x00bb
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x17a8
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x00bb
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x17a8
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    adc ch, dl
    mov di, 0x023f
    stosw
    mov di, 0x0200
    mov si, ax
    add si, 0x00bb
    mov cx, 0x000a
    rep movsw
    push ds
    push es
    pop ds
    pop es
    push cs
    pop ss
    mov bx, ax
    mov bp, 0x17a8
    mov dx, 0xcccc
    mov cx, 0x17a8
    lea sp, [bx-0x01f3]
    mov di, bx
    xor si, si
    movsw
    call bx
    movsw
    add bx, bp
    movsw
    movsw
    add sp, cx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    xor si, si
    mov di, bx
    movsw
    call bx
    jmp label2
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
label2:
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    db 0x12, 0xEA ;$1 adc ch, dl
    xchg bx, ax
    mov ax, 0xa552
    mov dx, ax
    int 0x86
    int 0x86
    push ds
    push es
    pop ds
    mov si, 0x023f
    lodsw
    xchg bx, ax
    add bx, 0x00a2
    jmp bx
    add [bx+si], al
    add [bx+si], al
    mov si, 0xe33f
    db 0xFF, 0xBE, 0x3F, 0x00
    db 0xFF, 0x3F
    mov si, 0x00e3
    mov si, 0xe33f
    inc word [bx+si]
    add [di], dh
    inc word [di+byte 0x00]
    scasb
    aas
    mov si, 0x003f
    jmp bx
    add bl, ah
    inc word [bx+si]