    brk
    xor si, si
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov bx, 0x01a5
    mov sp, 0x7fff
    mov di, sp
    mov bp, 0x2bf2
    mov cx, 0x2be2
    push bx
    jmp sp