    add ax, 0x00b1
    call ax
    call prcd1
prcd1:
    mov bp, ax
    pop ax
    push es
    mov dx, ds
    mov es, dx
    mov bp, ax
    mov bx, 0xcccc
    mov ax, 0xcccc
    mov dx, 0x1fff
    int 0x87
    pop es
    mov di, 0x0000
    int3
    mov ax, bp
    mov bp, 0x0000
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add dx, 0x0089
    mov cx, 0x0010
    mov si, dx
    mov dx, ss
    mov es, dx
    rep movsw
    sub ax, 0x8100
    db 0x8B, 0xF8 ;$1 mov di, ax
    sub di, 0x0400
    mov cx, 0xf000
    and di, cx
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov cx, 0x0004
    shr di, cl
    mov bp, 0x0fff
    and di, bp
    add di, 0x0ff6
    db 0x8B, 0xDC ;$1 mov bx, sp
    mov bp, cs
    mov ss, bp
    push word [0x18ff]
    pop [bx]
    mov ds, dx
    mov cx, 0x00a3
    mov bp, 0x000a
    mov bx, 0x0146
    sub bx, bp
    mov [bx], cx
    mov [bx+0x02], di
    les di, [bx]
    add sp, 0x0403
    mov cl, 0x0c
    mov dx, 0x1000
    mov ax, 0x18ff
    stosw
    dec di
    mov ax, [bx+0x02]
    db 0x33, 0xF6 ;$1 xor si, si
    mov word [bx+word 0x001e], 0x0100
    call far [bx+si]
    movsw
    rep movsw
    mov cl, 0x0c
    sub ax, bx
    or ax, dx
    db 0x2B, 0xC5 ;$1 sub ax, bp
    mov [bx+0x02], ax
    les di, [bx]
    movsw
    dec word [bx+si]
    jz label1
    sub sp, [si]
    db 0x33, 0xF6 ;$1 xor si, si
    dec di
    call far [bx+si]
    call far [bx+si]
label1:
    add [si], cl
    mov bp, ax
    pop ax
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0400
    push es
    mov dx, ds
    mov es, dx
    mov byte [bx+0x1000], 0xb8
    mov [bx+0x1001], ax
    mov word [bx+0x1003], 0xd0ff
    mov ax, 0xf789
    mov bx, 0xc30e
    mov dx, 0xd146
    int 0x87
    pop es
    push cs
    pop ss
    mov sp, bp
    mov ax, 0xf000
    db 0x23, 0xE0 ;$1 and sp, ax
    sub sp, 0x0600
    mov ax, 0xd4ff
    mov bx, 0x5350
    push ax
    push bx
    call sp
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label2:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label2
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label2
    int3
    int3
    int3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label3:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label3
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label3
    int3
    int3
    int3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label4:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label4
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label4
    int3
    int3
    int3
    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    lea bx, [si+0x3c]
    mul si
    db 0x8B, 0xEA ;$1 mov bp, dx
label5:
    mov di, si
    inc si
    shr si, 1
    jb label5
    db 0x03, 0xF7 ;$1 add si, di
    mul si
    xchg bp, ax
    mul si
    add ax, 0xbdb7
    scasw
    xchg bp, ax
    jnz label5
    int3
    int3
    int3
    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    lea bx, [si+0x3c]
    mul si
    db 0x8B, 0xEA ;$1 mov bp, dx
label6:
    mov di, si
    inc si
    shr si, 1
    jb label6
    db 0x03, 0xF7 ;$1 add si, di
    mul si
    xchg bp, ax
    mul si
    add ax, 0xbdb7
    scasw
    xchg bp, ax
    jnz label6
    int3
    int3
    int3
    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    lea bx, [si+0x3c]
    mul si
    db 0x8B, 0xEA ;$1 mov bp, dx
label7:
    mov di, si
    inc si
    shr si, 1
    jb label7
    db 0x03, 0xF7 ;$1 add si, di
    mul si
    xchg bp, ax
    mul si
    add ax, 0xbdb7
    scasw
    xchg bp, ax
    jnz label7