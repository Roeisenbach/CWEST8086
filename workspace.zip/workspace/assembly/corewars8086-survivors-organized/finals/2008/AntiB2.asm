    nrg
    nrg
    nrg
    push ds
    push es
    pop ds
    pop es
    lodsw
    push es
    push ds
    pop es
    pop ds
    mov sp, ax
    add sp, 0x0019
    mov bx, ds
    mov ss, bx
loop1:
    call ax
    push di
    db 0x65
    and [bx+si+0x61], ch
    jz 140
    and [bp+si+0x61], al
    jz 141
    jz 143
    and cl, ch
    and cl, ch
    cli
    out dx, al
    in al, dx
    and bl, ch
    loopz loop1
    jcxz 92
    db 0x21  ; and [bx+si], ax