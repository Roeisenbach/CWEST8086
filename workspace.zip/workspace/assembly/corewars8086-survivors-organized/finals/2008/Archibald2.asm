    db 0x8B, 0xF0 ;$1 mov si, ax
    mov al, 0xcc
    mov ah, 0xcc
    push ds
    pop es
    add si, 0x0010
    cld
    mov di, si
label1:
    db 0x03, 0xFE ;$1 add di, si
    stosw
    jmp label1