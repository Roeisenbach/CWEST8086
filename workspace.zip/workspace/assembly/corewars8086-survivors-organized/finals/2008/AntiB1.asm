    add ax, 0x004e
    stosw
    sub ax, 0x004e
    push ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    sub di, 0x0400
    push ax
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    cld
    int 0x86
    int 0x86
    pop ax
    mov sp, ax
    add sp, 0xfa36
    add ax, 0x002d
    mov bx, ds
    mov ss, bx
    sub sp, 0x0029
    call ax
    sub sp, 0x0029
loop1:
    call ax
    push di
    db 0x65
    and [bx+si+0x61], ch
    jz 158
    and [bp+si+0x61], al
    jz 159
    jz 161
    and cl, ch
    and cl, ch
    cli
    out dx, al
    in al, dx
    and bl, ch
    loopz loop1
    jcxz 110
    and [bp+di+0x2dc4], ax
    call ax