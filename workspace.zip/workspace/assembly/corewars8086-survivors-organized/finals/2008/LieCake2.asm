    add ax, 0x002f
    stosw
    mov si, ax
    mov di, si
    sub ax, 0x0002
    mov dx, ax
    sub dx, word 0x0064
    push ds
    push es
    pop ds
    mov cx, 0x12ef
    mov bp, 0x12ef
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], ax
    pop es
    push cs
    pop ss
    mov sp, dx
    mov dx, 0x0009
    mov ax, 0x0ccc
    call far [bx]
    push es
    push ds
    pop es
    pop ds
    mov bx, 0x0050
    add ax, 0x0038
    mov si, ax
    mov di, ax
    add di, word 0x0032
    mov ax, 0x1fff
    mov cx, 0x0898
loop1:
    add di, dx
    stosw
    sub di, bp
    mov [bx], di
    loop loop1
    mov [bx], si
    db 0xE9, 0x00, 0x00 ;$1 jmp 85
    mov di, si
    mov dx, 0x0003
    mov cx, 0x00f6
    mov bp, cx
    mov bx, 0x2a7c
    add di, bx
    db 0xE9, 0x08, 0x00 ;$1 jmp 111
    mov bx, 0x08f0
    add di, bx
    db 0xE9, 0x0C, 0x00 ;$1 jmp 123
loop2:
    add di, dx
    stosw
    stosw
    loop loop2
    mov cx, bp
    add di, bx
    jmp loop2
loop3:
    add di, dx
    stosw
    stosw
    loop loop3
    mov cx, bp
    add di, bx
    jmp loop3