    push ds
    push es
    pop ds
    lodsw
    pop ds
    add ax, 0x0096
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov dx, 0x46eb
    jmp bx
    stosw
    add ax, 0x00d4
    db 0x8B, 0xD8 ;$1 mov bx, ax
    sub ax, 0x00d6
    mov [bx], ax
    add ax, 0x001e
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add ax, 0x00e9
    mov [bx], ax
    mov dx, 0xb6eb
    db 0xE9, 0x6B, 0x00 ;$1 jmp 149
    mov bx, 0x0000
    db 0xE9, 0x04, 0x00 ;$1 jmp 52
    nop
    nop
    nop
    nop
    mov ax, 0xcccc
    db 0xE9, 0x02, 0x00 ;$1 jmp 60
    nop
    nop
label1:
    mov [bx], ax
    db 0xE9, 0x03, 0x00 ;$1 jmp 68
    nop
    nop
    nop
    add bx, 0x0004
    jmp label1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    add bx, 0x00ff
    mov ax, 0x0048
label2:
    mov [bx], dx
    add bx, ax
    jmp label2
    nop
    nop
    nop
    sub bx, 0x00c3
    mov ax, 0x0048
label3:
    mov [bx], dx
    sub bx, ax
    jmp label3
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    mov ax, 0x0000
    add ax, 0x0100
    jmp label4
    nop
    nop
label4:
    db 0x8B, 0xD8 ;$1 mov bx, ax
    sub al, 0x11
    jmp label5
    nop
    nop
label5:
    mov [bx], ax
    push cs
    pop ss
    jmp label6
    nop
    nop
label6:
    sub bx, 0x0105
    jmp label7
    nop
    nop
label7:
    db 0x8B, 0xEB ;$1 mov bp, bx
    mov sp, bp
    jmp label8
    nop
    nop
label8:
    call 0x1001:0x0000