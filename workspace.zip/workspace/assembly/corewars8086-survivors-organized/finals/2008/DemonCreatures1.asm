    db 0x8B, 0xD8 ;$1 mov bx, ax
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov al, 0xcc
label1:
    sub bx, word 0x0014
    add si, word 0x0014
    mov [bx], al
    mov [si], al
    jmp label1