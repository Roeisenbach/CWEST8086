    add ax, 0x0005
    call ax
    mov bp, ax
    pop ax
    push es
    mov dx, ds
    mov es, dx
    db 0x8A, 0xF8 ;$1 mov bh, al
    mov cl, ah
    mov bl, 0x68
    mov ch, 0xc3
    mov ax, 0xcccc
    mov dx, 0x1fff
    int 0x87
    pop es
    mov ax, bp
    mov bp, 0x0000
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add dx, word 0x007f
    mov cx, 0x000e
    mov si, dx
    mov dx, ss
    mov es, dx
    rep movsw
    db 0x8B, 0xF8 ;$1 mov di, ax
    sub di, 0x0400
    mov cx, 0xf000
    and di, cx
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov cx, 0x0004
    shr di, cl
    mov bp, 0x0fff
    and di, bp
    add di, 0x0ff6
    db 0x8B, 0xDC ;$1 mov bx, sp
    mov bp, cs
    mov ss, bp
    push word [0x18ff]
    pop [bx]
    mov ds, dx
    mov cx, 0x00a3
    mov bp, 0x000a
    mov bx, 0x0146
    sub bx, bp
    mov [bx], cx
    mov [bx+0x02], di
    les di, [bx]
    add sp, 0x0403
    mov cl, 0x0a
    mov dx, 0x1000
    mov ax, 0x18ff
    stosw
    dec di
    mov ax, [bx+0x02]
    db 0x33, 0xF6 ;$1 xor si, si
    call far [bx+si]
    movsw
    rep movsw
    mov cl, 0x0a
    sub ax, bx
    or ax, dx
    db 0x2B, 0xC5 ;$1 sub ax, bp
    mov [bx+0x02], ax
    les di, [bx]
    movsw
    sub sp, [si]
    db 0x33, 0xF6 ;$1 xor si, si
    dec di
    call far [bx+si]
    call far [bx+si]
    add [si], cl
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label1:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label1
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label1
    int3
    int3
    int3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label2:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label2
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label2
    int3
    int3
    int3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label3:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label3
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label3
    int3
    int3
    int3
    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    lea bx, [si+0x3c]
    mul si
    db 0x8B, 0xEA ;$1 mov bp, dx
label4:
    mov di, si
    inc si
    shr si, 1
    jb label4
    db 0x03, 0xF7 ;$1 add si, di
    mul si
    xchg bp, ax
    mul si
    add ax, 0xbdb7
    scasw
    xchg bp, ax
    jnz label4
    int3
    int3
    int3
    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    lea bx, [si+0x3c]
    mul si
    db 0x8B, 0xEA ;$1 mov bp, dx
label5:
    mov di, si
    inc si
    shr si, 1
    jb label5
    db 0x03, 0xF7 ;$1 add si, di
    mul si
    xchg bp, ax
    mul si
    add ax, 0xbdb7
    scasw
    xchg bp, ax
    jnz label5
    int3
    int3
    int3
    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    lea bx, [si+0x3c]
    mul si
    db 0x8B, 0xEA ;$1 mov bp, dx
label6:
    mov di, si
    inc si
    shr si, 1
    jb label6
    db 0x03, 0xF7 ;$1 add si, di
    mul si
    xchg bp, ax
    mul si
    add ax, 0xbdb7
    scasw
    xchg bp, ax
    jnz label6