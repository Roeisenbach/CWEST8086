    push es
    push ss
    pop es
    pop ss
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x001c
    mov cx, 0x001e
    rep movsw
    push es
    push ds
    pop es
    pop ds
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, word 0x0059
    mov ax, 0xcccc
    push es
    push ds
    pop es
    pop ds
    mov cx, 0xffff
    sub cx, di
    mov ch, cl
    mov ch, 0x00
    shr cl, 1
    cmp cl, 0x00
    jz label1
loop1:
    mov [di], ax
    add di, 0x0008
    loop loop1
label1:
    mov di, bx
    push es
    push ds
    pop es
    pop ds
    mov cx, 0x001e
    mov si, 0x0000
    add di, 0x4109
    cmp di, word 0xffc2
    ja label3
label2:
    mov bx, di
    rep movsw
    jmp bx
label3:
    add di, word 0x003d
    jmp label2