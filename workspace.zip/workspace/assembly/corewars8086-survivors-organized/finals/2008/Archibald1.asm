    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0014
    cld
    mov di, 0x0000
    mov cx, 0x0004
    rep movsw
    push es
    push ds
    pop es
    pop ds
    mov di, si
    mov si, 0x0000
    mov cx, 0x0004
    rep movsw