    jmp label1
    add ax, 0x0001
    add ax, 0x0002
    add ax, 0x0003
    add ax, 0x0004
    call far [bx]
    add ax, 0x0005
    add ax, 0x0006
    add ax, 0x0007
    add ax, 0x0008
    int3
    int3
    int3
    int3
    add ax, 0x0001
    add ax, 0x0002
    add ax, 0x0003
    add ax, 0x0004
    call far [bx]
    add ax, 0x0005
    add ax, 0x0006
    add ax, 0x0007
    add ax, 0x0008
    int3
    int3
    int3
    int3
    add ax, 0x0001
    add ax, 0x0002
    add ax, 0x0003
    add ax, 0x0004
    call far [bx]
    add ax, 0x0005
    add ax, 0x0006
    add ax, 0x0007
    add ax, 0x0008
label1:
    mov di, ax
    mov dx, ax
    add dx, 0x0086
    mov ax, 0x0d0d
    mov bx, 0x0a86
label2:
    mov cx, 0x0013
    xor si, si
loop1:
    lea bp, [bx+si]
    cmp bp, di
    jb label3
    cmp bp, dx
    ja label3
    jmp label4
label3:
    mov word [bx+si], 0xcccc
    add si, ax
    loop loop1
label4:
    add ax, 0x000d
    add bx, 0x0080
    jmp label2
    add ax, 0x0001
    add ax, 0x0002
    add ax, 0x0003
    add ax, 0x0004
    call far [bx]
    add ax, 0x0005
    add ax, 0x0006
    add ax, 0x0007
    add ax, 0x0008
    int3
    int3
    int3
    int3
    add ax, 0x0001
    add ax, 0x0002
    add ax, 0x0003
    add ax, 0x0004
    call far [bx]
    add ax, 0x0005
    add ax, 0x0006
    add ax, 0x0007
    add ax, 0x0008
    int3
    int3
    int3
    int3
    add ax, 0x0001
    add ax, 0x0002
    add ax, 0x0003
    add ax, 0x0004
    call far [bx]
    add ax, 0x0005
    add ax, 0x0006
    add ax, 0x0007
    add ax, 0x0008