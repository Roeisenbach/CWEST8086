    mov bx, 0x1ffb
    mov ax, 0x00cc
    mov cx, 0x0015
loop1:
    mov [bx], ax
    inc bx
    loop loop1
    mov bx, 0xf008
    mov ax, 0x00cc
    mov cx, 0x0014
loop2:
    mov bx, 0xf00c
    mov [bx], ax
    add bx, word 0x0002
    loop loop2
    push ds
    push es
    pop ds
    lodsw
    pop ds
    mov bp, 0x0002
    mov dx, 0x0007
    jmp ax
    push es
    push ds
    pop es
    pop ds
    mov bx, 0x0050
    mov di, ax
    mov ax, 0x1fff
label1:
    add di, word 0x0002
    stosw
    sub di, word 0x0002
    mov [bx], di
    jmp label1