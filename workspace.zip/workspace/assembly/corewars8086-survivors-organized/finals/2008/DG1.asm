    mov si, 0xe12b
    mov bx, 0x17ff
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov cx, 0xcccc
    mov di, bx
    sub di, 0x0004
    mov [di], si
    add di, 0x0002
    mov [di], bx
    push cs
    pop ss
    push es
    pop ds
    push cs
    pop es
    mov sp, 0xdbff
    mov bx, 0x0100
    mov [bx], di
    mov [bx+0x02], cs
    add di, 0x0002
    int 0x86
    int 0x86
    int 0x87
    call word [bx]
    push dx
    mov ax, [0x000f]