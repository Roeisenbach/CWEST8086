    push cs
    pop ss
    mov bx, 0x17ff
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov cx, 0xcccc
    mov di, bx
    sub di, 0x0004
    mov sp, 0x4bff
    push es
    pop ds
    push cs
    pop es
    mov bx, 0x0104
    mov [bx], di
    mov [bx+0x02], cs
    mov di, 0x0400
    int 0x86
    int 0x86
    int 0x87
    mov cx, 0x0800
    call word [bx]
    mov [0x15f3], al
    db 0xFF  ; inc word [bx+si]