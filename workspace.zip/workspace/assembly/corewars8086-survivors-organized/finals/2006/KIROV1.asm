    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov cx, 0x70c7
    mov ax, 0xcccc
loop1:
    div cx
    db 0x8B, 0xC3 ;$1 mov ax, bx
    mov [bx+0x0f], dx
    cwd
    inc si
    add bh, bh
    loopnz loop1
    stosw
    inc word [bx+si+0x4f6f]
    sbb al, 0xab
    mov sp, ax
    add sp, word 0x0045
    db 0x8B, 0xDC ;$1 mov bx, sp
    add sp, 0x0415
    add bx, 0x0007
    mov cx, cs
    mov ss, cx
    mov cx, 0x0064
loop2:
    nrg
    nrg
    nrg
    nrg
    nrg
    loop loop2
    mov ax, 0x001b
    mov word [bx], 0xe003
    jcxz loop4+2
    add bl, [bp+si-0x7700]
    pop di
    add cx, [si+0x054f]
    jmp bx
    stosw
    push cs
    pop es
    push cs
    pop ss
    mov sp, ax
    sub sp, 0xafc8
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, word 0x003a
    mov word [bx], 0x009a
    mov dx, bx
    sub dx, word 0x0007
    mov [bx+0x01], dx
    mov [bx+0x03], cs
    mov ax, 0xcccc
    mov di, bx
    add di, 0x03e8
    mov cx, 0x01f4
loop3:
    nrg
    loop loop3
    mov bx, [di+0x02]
    mov [bx-0x02], ax
    stosb
loop4:
    sub byte [bx+0x4f], 0x1c
    stosw
    mov sp, ax
    add sp, word 0x0045
    db 0x8B, 0xDC ;$1 mov bx, sp
    add sp, 0x0415
    add bx, 0x0007
    mov cx, cs
    mov ss, cx
    mov cx, 0x0064
loop5:
    nrg
    nrg
    nrg
    nrg
    nrg
    loop loop5
    mov ax, 0x0003
    mov word [bx], 0xe02b
    mov word [bx+0x02], 0x009a
    mov [bx+0x03], bx
    mov [bx+0x05], cs
    jmp bx
    stosw
    push cs
    pop es
    push cs
    pop ss
    mov sp, ax
    sub sp, 0xafc8
    mov cx, 0x0023
loop6:
    nrg
    nrg
    nrg
    nrg
    nrg
    nrg
    loop loop6
    mov cx, 0xcccc
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x00ff
    mov di, bx
    add di, 0x0007
    mov dx, 0x0003
    mov ax, 0x1fff
label1:
    stosw
    add [bx], dx
    inc di
    mov si, [di+0x1e]
    mov [si-0x02], cx
    jmp label1
    mov bx, 0x26fb
    mov si, 0x1000
    push cs
    pop ss
    db 0x8B, 0xE3 ;$1 mov sp, bx
    mov dx, bx
    sub dx, 0x0002
    sub sp, 0x1770
    mov word [bx], 0x009a
    mov [bx+0x01], bx
    mov [bx+0x03], cs
    mov word [si], 0x1002
    add si, 0x0002
    mov word [si], 0x170e
    add si, 0x0002
    mov word [si], 0x009a
    mov [si+0x01], si
    mov [si+0x03], cs
    jmp bx