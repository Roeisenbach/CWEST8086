    add ax, 0x0014
    db 0x8B, 0xD8 ;$1 mov bx, ax
    sub bx, 0x0002
    mov cx, 0x0011
    xor word [bx], 0x3f3f
    add bx, 0x0002
    esc 0xdd
    db 0xC8
    xchg sp, ax
    mov bl, 0xf5
    mov cl, 0xed
    mov ah, 0xe7
    mov sp, 0x3dd4
    mov dh, 0x28
    mov sp, 0x3dd4
    cmp ah, [bp+di]
    aas
    mov dh, 0x38
    mov dh, 0xfb
    mov sp, 0x3bd3
    test [bp+di], si
    cmp ax, 0xeb3e
    db 0xC0
    and [bx+si+0x61], ch
    jbe label1
    and [bp+0x75], ah
    db 0x6E
    and [bx+0x68], dh
    db 0x69
    db 0x6C
    db 0x65
    and [si+0x65], ah
    db 0x63
    db 0x68
    db 0x69
    jo label3
    jb label4
    db 0x6E
    db 0x67
    and [di+0x79], ch
    and [bx+si+0x72], dh
    db 0x6F
    db 0x67
    db 0x67
    db 0x69
    db 0x65
    and [si+0x6f], ch
    db 0x6C
    and [bp+0x30], ah
    xor ch, [si+0x2c]
    jnb label2
    db 0x60
    and [bx+si], di
    jp label6
    db 0x66
    db 0x6D
    jbe label6
    db 0x65
    db 0x69
    jno loop7
    db 0x66
    sub al, 0x6e
    db 0x6F
    jo label7
    db 0x64
    db 0x6B
    db 0x67
    db 0x6C
    db 0x6A
    sub al, 0x6d
    db 0x6D
    jz loop8+1
    ja loop8+4
    and [bx+di+0x61], ch
loop1:
    jz label5
    and al, 0x31
    or [bx+si], sp
    sub bp, [bx+di]
    or [bx+si+0x53], al
    cmp ax, 0x7a29
loop2:
    xor dl, [bx+di+0x49]
    xor [di], bh
    das
    daa
    cli
label1:
    in al, 0xf3
    hlt
    pop bp
    pop bx
label2:
    sub al, 0x2e
    cmc
loop3:
    jcxz loop1+1
    hlt
loop4:
    jmp 0xf8f7:0x272f
    loopnz loop2+2
label3:
    in ax, 0xef
    in ax, dx
    hlt
    pop bp
    pop bx
label4:
    pop sp
    or ax, 0xe341
label5:
    loop loop3+1
    db 0xF2, 0xE9
    out 0xec, ax
    jmp 0xf1e6:0x2cf3
    loopz loop4+2
    lock
    out dx, al
    idiv dl
    cmc
    cs:
loop5:
    and [bx+di], dh
    xor dh, [bp+di]
    xor al, 0x35
    ss:
    aaa
loop6:
    cmp [bx+di], bh
label6:
    xor [di], ch
    cmp ax, 0xe4ea
    in ax, dx
    clc
    mul ah
    jmp -3884
loop7:
    stc
    jcxz loop5
    in al, dx
    stc
    loop loop6
    out 0xe3, ax
label7:
    stc
    loop loop7
    daa
    das
loop8:
    jmp 0xfa27:0x2ff7
    db 0xF1
    cmc
    lock
    out 0xec, ax
loop9:
    jmp 0x5df9:0xf3e3
    jmp loop8+3
    pop bp
    daa
loop10:
    in al, dx
    loopnz loop8
    db 0xF3, 0xF1
loop11:
    in al, dx
    in al, 0xf1
    out dx, ax
    xor al, 0x33
    daa
    cli
    loopnz loop11
    loop loop10
label8:
    jmp -3844
    loopz loop9+3
    jmp -2038
    out dx, al
loop12:
    daa
    div si
    jmp label8
    hlt
    das
    pop bx
    stc
    sub al, 0x2e
    db 0xF1
    in al, dx
    out 0xf2, ax
    cli
    out dx, al
    jcxz loop12
    idiv dx
loop13:
    jmp 0xf2f4:0xeaeb
    cli
    jcxz loop13+1
    db 0xF3, 0xEB
    db 0xF2, 0xE3
    db 0xF3, 0xEC
    cli
    div bh
    clc
    daa
    hlt
    out dx, ax
    in ax, dx
    clc
    out dx, ax
    cmp [bx+si], di
    xor al, 0x33
    xor dh, [di]
loop14:
    out 0x39, ax
loop15:
    in al, 0xf1
    idiv dl
    out dx, al
    xor al, 0x32
    xor ax, 0x3039
    stc
    jcxz loop15
    das
    daa
    pop bp
    hlt
    db 0xF2, 0xEB
    hlt
    out dx, ax
    loopnz loop19
    cmc
    imul dh
label9:
    jcxz loop14
    in ax, dx
    out dx, ax
    jmp label10+2
loop16:
    sub ax, 0xe2e3
loop17:
    jmp 0x32f3:0xecf3
    xor si, [bx+di]
loop18:
    jmp 0xe3e2:0xf3f4
    jmp label9+1
    jcxz loop17+3
    loop loop16
    cmp [bx+si], si
    jcxz loop21+1
    clc
    sub ax, 0xf433
    das
    imul dx
    das
    db 0xF3, 0xE7
    db 0xF3, 0xE6
    loopz loop18+1
    out dx, ax
    hlt
    in ax, dx
    clc
loop19:
    daa
    mul ax
label10:
    jmp 0xf1e1:0xf6fa
    jmp 0xedf9:0xeff3
    db 0xF2, 0xF4
    loopnz 523
    hlt
    lock
    in al, dx
    db 0xF3, 0xF9
    out 0xf6, ax
    in al, 0x5d
    and [bx+si], ah
    das
    and [di+0x39], dl
loop20:
    push bp
    sub [bx+di+0x41], dl
    out dx, ax
loop21:
    loop loop20
label11:
    db 0xF3, 0xEA
    db 0xF2, 0xE7
loop22:
    jmp 0xf9e2:0xf3ec
    out 0xee, ax
    jmp 0xe7f9:0xe2e3
    loopnz loop22+1
    xor si, [di]
    das
    ss:
    cli
    in al, 0xe3
    stc
    jmp label11+1
    cmp dx, si
    xor cl, bh
    sub ax, 0xe63d
    cmp [bx+si], si
    in al, 0x2d
    out 0x32, al
    cmc
    cli
    daa
    idiv dx
    cmc
    clc
    mul word [bx]
    jmp 0xf2f1:0xecf8
    xor [bx], ah
    db 0xEA, 0xF7, 0xF3  ; jmp 0x0000:0xf3f7