    mov cx, 0x0070
loop1:
    nop
    loop loop1
    mov dx, ds
    mov bp, es
    mov ds, bp
    lodsw
    mov ds, dx
    jmp ax