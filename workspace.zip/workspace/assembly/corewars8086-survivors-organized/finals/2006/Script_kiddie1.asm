    stosw
    push ss
    pop ds
    mov dx, cs
    mov ss, dx
    db 0x8B, 0xDC ;$1 mov bx, sp
    dec bx
    dec bx
    mov [bx], dx
    dec bx
    dec bx
    db 0x8B, 0xD0 ;$1 mov dx, ax
    add ax, 0x001e
    mov [bx], ax
    mov sp, ax
    sub sp, 0x0004
    mov dx, 0xa13d
    sub sp, dx
    call far [bx]