    push es
    mov dx, ds
    mov es, dx
    db 0x8A, 0xFC ;$1 mov bh, ah
    mov bl, 0xa5
    add bh, 0x04
    mov di, bx
    sub di, word 0x000b
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x0038
    mov cx, 0x00c5
    rep movsb
    pop es
    db 0x2B, 0xFF ;$1 sub di, di
    mov [bx-0x06], bx
    mov byte [bx], 0x9a
    mov [bx+0x01], bx
    mov [bx+0x03], cs
    add bx, word 0x0005
    db 0x8B, 0xC3 ;$1 mov ax, bx
    add ax, 0x0021
    stosw
    jmp bx
label1:
    mov dx, ds
    mov ss, dx
    mov sp, 0x0000
    sub sp, 0x0903
    db 0x8B, 0xE3 ;$1 mov sp, bx
    sub sp, 0x0003
    std
    push ds
    pop es
    mov dx, bx
    inc dx
    sub bx, 0x0010
    sub bx, 0x0002
    mov di, bx
    mov cx, 0x1000
    mov ax, 0x9b9b
    rep stosw
    mov di, dx
    mov al, 0xaa
    mov dx, ds
    mov es, dx
    cld
    jmp label1
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov bp, ax
    mov ax, 0x9b9b
    push ds
    pop es
    add di, 0x0900
    mov cx, 0x0008
    rep stosw
    sub di, 0x1210
    mov cx, 0x0008
    rep stosw
    add di, 0x1200
label2:
    sub di, 0x0010
    mov cx, 0x0008
    db 0x33, 0xD2 ;$1 xor dx, dx
    db 0x33, 0xDB ;$1 xor bx, bx
loop1:
    add dx, [di]
    add bx, [di-0x1200]
    add di, 0x0002
    loop loop1
    cmp dx, 0xdcd8
    jnz label3
    cmp bx, 0xdcd8
    jnz label3
    jmp label2
label3:
    sub di, 0x0010
    mov cx, 0x0008
    rep stosw
    sub di, 0x1210
    mov cx, 0x0008
    rep stosw
    db 0x8B, 0xF5 ;$1 mov si, bp
    sub si, 0x0031
    mov cx, 0x00c5
    mov di, si
    add di, 0x1100
    rep movsb
    sub si, 0x00a1
    add si, 0x0002
    mov di, si
    add di, 0x1100
    mov byte [si], 0x9a
    mov [si+0x01], di
    mov [si+0x03], cs
    mov word [si-0x02], 0x9090
    sub di, 0x001b
    mov [di-0x06], di
    mov [di+0x01], di
    sub si, 0x001b
    mov [si+0x01], di
    add di, 0x0026
    db 0x8B, 0xC7 ;$1 mov ax, di
    jmp ax