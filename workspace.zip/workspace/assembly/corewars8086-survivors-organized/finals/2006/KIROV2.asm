    mov cx, 0x0005
loop1:
    nrg
    loop loop1
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, es
    push cs
    pop es
    mov ss, cx
    mov bp, 0x0000
    mov ax, [bp+0x00]
    add ax, 0x0004
    db 0x8B, 0xD8 ;$1 mov bx, ax
    sub bx, 0x0058
    mov cx, cs
    mov ss, cx
    mov sp, ax
    sub sp, 0x0a00
    mov word [bx], 0x009a
    mov [bx+0x01], bx
    mov [bx+0x03], cs
    mov cx, 0x001e
loop2:
    nrg
    nrg
    nrg
    loop loop2
    jmp bx
    mov cx, 0x002d
loop3:
    nrg
    nrg
    nrg
    nrg
    nrg
    nrg
    loop loop3
    mov cx, es
    push cs
    pop es
    mov ss, cx
    mov bp, 0x0000
    mov ax, [bp+0x00]
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x00ff
    mov cx, cs
    mov ss, cx
    mov sp, ax
    sub sp, 0x0a00
    mov ax, 0x0003
    mov dx, bx
    add dx, 0x0004
    mov [bx], dx
    mov [bx+0x02], cs
    mov word [bx+0x04], 0x1fff
    jmp dx