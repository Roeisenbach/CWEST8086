    push cs
    pop ss
    mov bx, ss
    mov ds, bx
    mov cx, 0x4b8c
    mov sp, 0xfff0
    mov bx, 0x4b84
    mov word [bx], 0xe12b
    mov byte [bx+0x02], 0x9a
    mov [bx+0x03], bx
    mov [bx+0x05], cs
    jmp bx
    int 0x21
    int 0x21
    int 0x21
    int 0x21