    push es
    push ds
    pop es
    pop ds
    lodsw
    add ax, 0x801e
    push ss
    pop ds
    mov dx, cs
    mov ss, dx
    db 0x8B, 0xDC ;$1 mov bx, sp
    dec bx
    dec bx
    mov [bx], dx
    dec bx
    dec bx
    mov [bx], ax
    mov sp, ax
    sub sp, 0x0004
    mov dx, 0xa13d
    mov bp, ax
    mov word [bp+0x00], 0xd429
    mov word [bp+0x02], 0x1fff
    jmp ax
    sub sp, dx
    call far [bx]