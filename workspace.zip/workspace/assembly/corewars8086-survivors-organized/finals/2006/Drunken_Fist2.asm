    push es
    pop ss
    mov bp, 0x0000
    mov ax, [bp+0x00]
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov bx, cs
    mov es, bx
    add di, 0x0400
    mov al, 0xaa
    stosb
    mov bx, di
    dec bx
    jmp bx
    inc di
    lodsw
    mov ax, bp
    db 0x8B, 0xF5 ;$1 mov si, bp
    add si, 0x0050
    movsw
    movsw
    push bp
    push ax
    pop dx
    call word [bx]
    xchg dx, ax
    ret
    int3
    sub si, 0x0050
    mov word [di], 0xcccc
    jmp dx