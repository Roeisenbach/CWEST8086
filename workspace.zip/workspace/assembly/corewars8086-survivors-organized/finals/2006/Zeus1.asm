    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x0059
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    jmp label1+2
label1:
    mov word [0x1f06], 0x170e
    mov bx, 0x006f
    mov dx, [bx+0x02]
    mov es, dx
    jmp label2+2
label2:
    mov word [0x278b], 0x10b0
    mul dl
    db 0x03, 0xE0 ;$1 add sp, ax
    mov di, [bx]
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    movsw
    sub di, 0x0003
    jmp label3+2
label3:
    mov word [0xffb8], 0xbd1f
    add [di], dl
    mov dx, 0x27b0
    mov cx, 0x0002
    jmp label4+2
label4:
    mov word [0x1fff], 0xd88b
    jmp 0x1000:0x04d2
    mov word [0xe22b], 0x1fff
    movsw
    movsw
    add [bx], cx
    movsw
    movsw
    db 0x2B, 0xE1 ;$1 sub sp, cx
    movsw
    movsw
    movsw
    sub [bx], bp
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    mov si, 0x000c
    mov di, [bx]
    stosw
    dec di
    call far [bx]