    push ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    sub di, 0x0424
    mov cx, 0x0bb8
loop1:
    nrg
    sub di, 0x0015
    mov [di], di
    loop loop1
    sub di, 0x0a08
    mov cx, 0x0bb8
    jmp loop1
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x3c
    int 0x3c
    int 0x3c
    int 0x3c
    int 0x3c
    int 0x3c
    int 0x3c
    int 0x3c
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    nrg
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x03d1
    nrg
    add di, 0x0015
    mov [di], di
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    int 0x08
    int 0x08
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    jmp loop1
    call -240
    jmp loop1
    call -240
    int 0x23
    in al, 0x12
    nrg
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x03d1
    nrg
    add di, 0x0015
    mov [di], di
    jmp loop1