    add ax, 0x000f
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov cx, 0x0010
    xor word [bx], 0x3f3f
    add bx, 0x0002
    esc 0xdd
    db 0xC8
    and [bx+di], di
    and [bx+si], bh
    call 0xb6c1:0x42b4
    db 0xC1
    mov si, 0x3ff8
    cmp ax, 0xc4b6
    mov ah, 0xf8
    mov sp, 0x3efc
    cmp [bx+si], sp
    xchg ch, [bx]
    aas
    int3
    call 0x7469:0xfc6c
    and [bx+0x61], dh
    jnb label1
    jbe label8
    jb label9+1
    and [bp+0x75], ah
    db 0x6E
    and [si+0x6f], dh
    and [bp+di+0x6f], ah
    db 0x64
    db 0x65
    and [si+0x68], dh
    db 0x69
    jnb label2
    jo label11
    db 0x6F
    db 0x67
    jb label9+1
    db 0x6D
    and [bx+di+0x20], ch
label1:
    db 0x68
    db 0x6F
    jo label10+1
    and [bx+di+0x6f], bh
    jnz label3
    ja label12
    db 0x6C
    db 0x6C
    and [di+0x6e], ah
    db 0x6A
    db 0x6F
    jns label4
    jz label13
label2:
    and [si+0x65], ah
    db 0x63
    db 0x69
    jo label13
    db 0x65
    jb label5
    db 0x69
    jz label6+2
    db 0x61
    jnb label7
    ja label14
    db 0x6C
label3:
    db 0x6C
    and [si+0x6f], ch
    db 0x6C
    and [bx+di+0x64], ah
    db 0x66
    db 0x6B
    db 0x6E
label4:
    js label15+2
    jbe label18
    jo label17
    ja label16
    jb label19
    db 0x6C
    db 0x61
label5:
    inc si
label6:
    cmp dx, [bp+di+0x41]
    inc sp
    dec cx
label7:
    push ax
label8:
    dec di
    push bx
    inc sp
    push bx
    dec bp
    inc di
    inc sp
    sub al, 0x46
    cs:
    inc di
    inc sp
    dec sp
    cmp ax, [si+0x53]
    push si
    pop bx
    xor [bx+si+0x56], bl
label9:
    xor [di], ch
    xor [bx+di], bh
    cmp ax, 0x3433
    xor ax, 0x4b27
    inc si
    inc cx
label10:
    xor [di], bh
label11:
    daa
    cmp dx, [bp+si+0x50]
    pop bx
    dec di
    push di
    pop bx
    dec cx
    inc dx
label12:
    dec bp
    das
    cs:
    sub al, 0x56
    dec bp
    pop ax
    inc bx
    dec sp
    inc di
    dec cx
    dec sp
    push bx
    cmp ax, [bp+0x4b]
    inc sp
label13:
    inc si
    dec di
    dec cx
    push di
    push ax
    dec di
    push dx
    push sp
label14:
    dec di
    inc bp
    push dx
    dec dx
    push di
    sub al, 0x4a
    inc si
    inc sp
    push bx
label15:
    cmp cx, [si+0x4b]
    push si
    pop ax
    sub al, 0x2e
    dec bp
    push si
    pop ax
label16:
    inc bx
    cs:
label17:
    sub al, 0x4e
    push di
    inc bp
label18:
    inc si
    dec bx
    push bx
    inc sp
    inc si
    dec bx
    push bx
    inc sp
    pop bx
    push ax
    push cx
label19:
    push dx
    pop bx
    dec di
    push ax
    push ax
    inc bp
    push sp
    pop cx
    dec di
    push bp
    push ax
    pop bx
    inc di
    inc sp
    inc si
    inc di
    push ax
    dec cx
    inc sp
    dec di
    pop bp
    pop bx
    push ax
    dec di
    dec cx
    push bp
    pop cx
    push sp
    push dx
    inc bp
    push di
    push cx
    daa
    cmp cx, [si+0x4b]
    das
    cs:
    sub al, 0x4d
    dec si
    inc dx
    push si
    inc bx
    pop ax
    pop dx
    dec dx
    dec ax
    inc di
    inc si
    inc sp
    push bx
    inc cx
    cmp [bx+di+0x4a], cx
    dec si
    inc dx
    dec ax
    push bp
    cmp [bx], dh
    pop cx
    inc di
    push si
    inc si
    inc bx
    inc si
    push sp
    ss:
    xor ax, 0x4452
    pop ax
    pop dx
    push bx
    inc bp
    xor al, 0x33
    push di
    inc cx
    push cx
    xor [bp+si], si
    push di
    inc sp
    push ax
    inc si
    dec di
    inc di
    dec cx
    dec ax
    push bp
    dec dx
    pop cx
    dec bx
    push sp
    dec sp
    push dx
    cmp ax, [di+0x3b]
    daa
    push di
    pop ax
    inc bx
    dec bx
    push si
    pop ax
    inc bx
    dec cx
    dec di
    dec bx
    dec ax
    inc si
    push bx
    inc sp
    dec bx
    dec sp
    inc si
    inc cx
    push bx
    pop bx
    dec di
    inc bx
    push ax
    inc cx
    dec sp
    push ax
    cmp si, [bp+di]
    push cx
    xor al, 0x30
    xor bh, [bx+si]
    sub ax, 0x4b30
    inc bx
    pop dx
    pop ax
    inc si
    dec di
    push ax
    inc di
    dec ax
    dec cx
    inc si
    push bp
    inc sp
    push bx
    pop cx
    inc di
    xor [si], dh
    xor dh, [bp+di]
    dec cx
    ss:
    push cx
    dec di
    push ax
    dec dx
    xor [bp+si+0x53], bl
    cmp [bx+di+0x5a], cx
    pop ss
    sub [bx+0x75], bl
    jz 562
    cmp [bp+si+0x64], di
    ja label20+1
    and [di+0x6a], dh
    jz 572
    cmp ax, 0x295b
    pop di
    jno 578
    and [si+0x2d], dl
    xor [bx+si], ah
    push bx
    inc sp
    dec dx
    inc si
    dec di
    dec bx
    push bp
    sub ax, 0x3330
    xor dl, [bx+di+0x4c]
    dec bx
    inc cx
    push bx
    push ax
    dec di
    dec cx
    pop bx
    push di
    inc bp
    dec di
    push dx
    inc si
    dec bx
    dec sp
    push ax
    push di
    push bx
    dec dx
label20:
    cmp [bx+si], si
    aaa
    aaa
    pop cx
    push bp
    xor [bx+di], bh
    xor dl, [bx+di-0x11]
    scasw
    mov al, [0xda0a]
    esc 0xda
    db 0xF3, 0x43
    xor sp, [bx+si]