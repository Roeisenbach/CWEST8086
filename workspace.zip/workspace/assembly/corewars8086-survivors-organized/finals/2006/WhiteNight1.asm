    db 0x8B, 0xD8 ;$1 mov bx, ax
    sub bx, 0x0400
    push bx
    mov cx, 0x0010
loop1:
    mov word [bx], 0x9090
    sub bx, 0x0002
    loop loop1
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, word 0x0060
    add bx, 0x0400
    push bx
    mov cx, 0x0010
loop2:
    mov word [bx], 0x9090
    add bx, 0x0002
    loop loop2
    pop dx
    pop ax
    push bx
label1:
    mov bx, dx
    mov cx, 0x0010
loop3:
    cmp word [bx], 0x9090
    jnz label2
    add bx, 0x0002
    loop loop3
    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov cx, 0x0010
loop4:
    cmp word [bx], 0x9090
    jnz label2
    sub bx, 0x0002
    loop loop4
    jmp label1
label2:
    pop di
    push ds
    pop es
    mov cx, 0xffff
    mov ax, 0xcccc
    mov word [bx], 0xabf3
    jmp bx
    jmp $