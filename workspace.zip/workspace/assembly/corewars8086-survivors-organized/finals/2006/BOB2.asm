    push es
    pop ds
    nop
    mov di, [si]
    sub di, word 0x0037
    mov dx, di
    mov cx, 0x0037
    push es
    pop bp
    push cs
    push cs
    pop ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x003b
    rep movsb
    push bp
    pop ds
    push cs
    pop ss
    push cs
    pop bp
    db 0x8B, 0xE2 ;$1 mov sp, dx
    sub sp, 0x0200
    mov bx, 0x0002
    mov [bx], dx
    add word [bx], word 0x0003
    add bx, 0x0002
    mov [bx], bp
    sub bx, 0x0002
    jmp dx
label1:
    mov ax, 0x0006
    db 0x2B, 0xE0 ;$1 sub sp, ax
    call far [bx]
    mov si, dx
    add si, 0x0003
    mov di, si
    add di, 0x1f40
    sub sp, 0x0005
    mov dx, di
    mov cx, 0x0004
    mov ax, cs
    mov es, ax
    mov bp, ds
    mov ax, cs
    mov ds, ax
    rep movsb
    mov ds, bp
    mov [bx], dx
    mov ax, 0x0006
    jmp dx
    sub [bx], bx
    sub sp, 0x0400
    jmp label1