    mov di, 0x0000
    stosw
    push cs
    pop es
    std
    db 0x8B, 0xD0 ;$1 mov dx, ax
    sub dx, 0x0400
    mov ax, 0xaaaa
label1:
    mov di, dx
    mov cx, 0x7acf
    rep stosw
    jmp label1