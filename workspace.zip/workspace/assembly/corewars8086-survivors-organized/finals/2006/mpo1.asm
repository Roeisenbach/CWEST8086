    push cs
    pop ss
    mov bx, ss
    mov ds, bx
    mov bx, 0x4b8c
    db 0x8B, 0xCB ;$1 mov cx, bx
    sub bx, 0x4b94
    db 0x8B, 0xE3 ;$1 mov sp, bx
    mov word [bx], 0xe12b
    mov byte [bx+0x02], 0x9a
    mov [bx+0x03], bx
    mov [bx+0x05], cs
    jmp bx
    int 0x21
    int 0x21
    int 0x21
    int 0x21