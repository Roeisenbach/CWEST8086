    jmp label1+2
label1:
    mov word [0x1f06], 0xdebb
    add [bx+di-0x7ef9], cl
    das
    add [0x07c6], al
    mov ax, [0x37ff]
    pop [0x006f]
    sub word [0x006f], 0x8000
    mov dx, cs
    mov ss, dx
    jmp label2+2
label2:
    mov word [0x0324], 0xc0fe
    db 0x02, 0xD0 ;$1 add dl, al
    mov [bx+0x02], dx
    mov [0x0071], dx
    mov es, dx
    jmp label3+2
label3:
    mov word [0x278b], 0x10b0
    mul dl
    db 0x03, 0xE0 ;$1 add sp, ax
    mov di, [bx]
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    movsw
    sub di, 0x0003
    jmp label4+2
label4:
    mov word [0xffb8], 0xbd1f
    add [di], dl
    mov dx, 0x27b0
    mov cx, 0x0002
    jmp label5+2
    mov word [0x1d20], 0x6060
    mov word [0x0929], 0x6060
    mov word [0x224b], 0x6060
    mov word [0x0929], 0x6060
    mov word [0x224b], 0x6060
    mov word [0x224b], 0x6060
    mov word [0x0929], 0x6060
    mov word [0x224b], 0x6060
label5:
    db 0xC7, 0x06, 0xFF, 0x1F  ; mov word [0x1fff], 0x0000