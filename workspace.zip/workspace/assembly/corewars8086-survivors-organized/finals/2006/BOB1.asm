    push es
    pop ds
    mov [bx], ax
    mov bp, ax
    push cs
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0400
    mov ax, 0xcccc
    mov bx, 0x0002
    mov cx, 0x0320
loop1:
    add di, 0x000b
    stosw
    loop loop1
    add word [bx], 0x0004
    mov al, 0xaa
    stosb
    mov dx, di
    dec dx
    jmp dx