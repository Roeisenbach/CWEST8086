    db 0x8B, 0xD8 ;$1 mov bx, ax
    mov di, 0x0000
    mov si, bx
    add si, word 0x0022
    mov cx, 0x0010
    rep movsw
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    mov cx, 0x0012
    rep movsw
    add bx, word 0x0042
    jmp bx
    mov sp, ax
    sub sp, 0x0004
    add ax, 0x0016
    push es
    push ds
    pop es
    pop ds
    mov di, 0x03fe
    stosw
    push es
    push ds
    pop es
    pop ds
    call ax
    mov si, 0x03fe
    lodsw
    sub sp, 0x0029
    call ax
    int3
    push es
    push ds
    pop es
    pop ds
    mov di, bx
    sub di, 0x3000
    db 0x8B, 0xC7 ;$1 mov ax, di
    mov si, 0x0000
    mov cx, 0x00a2
    rep movsw
    mov bx, di
    sub bx, 0x0024
    push es
    push ds
    pop es
    pop ds
    mov di, 0x03fe
    stosw
    jmp bx
    int3