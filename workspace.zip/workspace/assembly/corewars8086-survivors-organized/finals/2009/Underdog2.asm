    push ds
    mov di, [si]
    push es
    pop ds
    pop es
    mov ax, 0x1fff
    mov dx, 0xcccc
    mov bx, dx
    db 0x8B, 0xCA ;$1 mov cx, dx
    int 0x87
    db 0x8B, 0xC7 ;$1 mov ax, di
    mov bx, 0x03fc
    mov [bx], ax
    mov dx, cs
    mov [bx+0x02], dx
    mov ss, dx
    mov sp, ax
    sub sp, 0x8446
    call far [bx]
    nop
    nop
    nop
    nop