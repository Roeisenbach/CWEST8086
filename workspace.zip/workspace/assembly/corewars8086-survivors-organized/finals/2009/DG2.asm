    push cs
    pop ss
    mov dx, ss
    mov ds, dx
    push ds
    pop es
    mov si, 0xa881
    mov bx, 0x1fff
    mov word [si], 0x1589
    mov word [si+0x02], 0xf903
    mov word [si+0x04], 0xe52b
    mov word [si+0x06], 0xd6ff
    mov [si+0x08], bx
    mov di, bx
    sub di, 0x0002
    mov [di], bx
    mov bx, 0xc887
    mov [bx], di
    mov [bx+0x02], dx
    mov cx, 0x0010
    db 0x8B, 0xE6 ;$1 mov sp, si
    sub sp, 0x0004
    mov bp, 0x000e
    mov dx, 0xcccc
    db 0x8B, 0xC2 ;$1 mov ax, dx
    mov di, 0x0000
    sub di, 0x0010
    int 0x86
    mov di, 0x30e0
    int 0x86
    mov di, si
    add di, word 0x000a
    add di, 0x0004
    call si
    mov [di], dx
    add di, cx
    db 0x2B, 0xE5 ;$1 sub sp, bp
    call si
    call far [bx]