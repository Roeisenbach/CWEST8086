    call prcd2
    call prcd1
prcd1:
    pop ax
    cld
    mov bx, 0x1000
    mov cx, es
    cmp cx, bx
    jnz label3
    mov cx, ds
    cmp cx, bx
    jnz label1
    mov cx, ss
    cmp cx, bx
    jnz label2
label1:
    push ds
    pop es
    jmp label3
label2:
    push ss
    pop es
label3:
    xor di, di
    int 0x86
    push cs
    push es
    pop ds
    pop es
    mov di, 0x40e0
    int 0x86
    mov dx, 0x078e
    db 0x83, 0xC0, 0x35 ;$1 add ax, 0x0035
    push cs
    pop ss
    mov sp, 0xb00a
    sub sp, dx
    call ax
    push es
    push ds
    pop es
    mov byte [0x4743], 0x00
    db 0x83, 0xC0, 0x03 ;$1 add ax, 0x0003
    stosw
    mov ax, 0x1000
    stosw
    mov bx, 0x2eff
    mov ax, 0x1fff
    mov dx, 0xa5a5
    int 0x87
    mov dx, 0xfa95
    mov ax, [0xed0d]
    mul dx
    mov bx, ax
    mov word [bx+0x01], 0x2eff
    mov word [bx+0x03], 0x0000
    xor di, di
    pop es
    pop ax
    mov si, ax
    add si, 0x0164
    mov cl, 0x36
    rep movsw
    xor di, di
    push ss
    pop es
    mov si, ax
    add si, 0x0142
    mov cl, 0x11
    rep movsw
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov dx, 0xffe1
    mov ax, 0x10a5
    mov bx, 0x0028
    mov sp, 0xb530
    mov bp, 0x4a86
    mov word [bx], 0x0284
    mov word [bx+0x02], 0x1480
    mov word [bx+0x0287], 0x6aa8
    mov word [bx+0x0299], 0x0090
    les di, [bx]
    mov si, 0x001e
    movsw
    movsw
    dec di
    xor si, si
    mov cl, 0x07
    jmp far [bx]
prcd2:
    push es
    push ds
    pop es
    mov byte [0x4743], 0x00
    db 0x83, 0xC0, 0x03 ;$1 add ax, 0x0003
    stosw
    mov ax, 0x1000
    stosw
    mov bx, 0x2eff
    mov ax, 0x1fff
    mov dx, 0xa5a5
    int 0x87
    mov dx, 0xfa95
    mov ax, [0xed0d]
    mul dx
    mov bx, ax
    mov word [bx+0x01], 0x2eff
    mov word [bx+0x03], 0x0000
    xor di, di
    pop es
    pop ax
    mov si, ax
    add si, 0x0164
    mov cl, 0x36
    rep movsw
    xor di, di
    push ss
    pop es
    mov si, ax
    add si, 0x0142
    mov cl, 0x11
    rep movsw
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov dx, 0xffe1
    mov ax, 0x10a5
    mov bx, 0x0028
    mov sp, 0xb530
    mov bp, 0x4a86
    mov word [bx], 0x0284
    mov word [bx+0x02], 0x1480
    mov word [bx+0x0287], 0x6aa8
    mov word [bx+0x0299], 0x0090
    les di, [bx]
    mov si, 0x001e
    movsw
    movsw
    dec di
    xor si, si
    mov cl, 0x07
    jmp far [bx]
    movsw
label4:
    rep movsw
    sub bp, [bx+di]
    sub [bx+0x02], dx
    or [bx+0x03], ah
    sub [bx+0x02], bx
    mov cl, 0x06
    rep movsw
    les di, [bx]
    movsw
    movsw
    dec di
    xor si, si
    mov cx, 0x0007
    jmp far [bx]
    sub sp, [bx+di]
    call far [bx]
    inc di
    xchg cl, [bp+di-0x205a]
    dec cx
    mov sp, 0x9e40
    dec ax
    esc 0xdf
    lahf
    pop bp
    db 0x1B, 0xC1 ;$1 sbb ax, cx
    inc ax
    in al, dx
    or al, 0xa5
    db 0xC1
    test [si+0x3f], dh
    jmp -7436
    db 0x68
    db 0x6E
    loopnz 486
    mov bp, 0xa1d0
    scasb
loop1:
    mov di, 0x5c1c
    pop cx
    push bx
    aad 0x14
    db 0xC0
    adc bx, [si]
    mov di, 0x9035
    and ax, 0x5711
    adc word [bx+di], 0x3d14
    db 0xC1
    lds cx, [bp-0x2dd9]
    dec cx
    db 0x8E, 0xB5, 0x30, 0x32 ;$1 mov ss, [di+0x3230]
    push cs
    adc dh, ah
    push di
    db 0x22, 0xF2 ;$1 and dh, dl
    xchg si, ax
    adc ax, 0x4247
    db 0x66
    push bp
    mov bx, 0x861d
    retf 0xbbbc
    push bx
    int3
    lock
    loopz loop1+2
    ja label4
    cbw
    inc ax
    push ax
    cmc
    db 0x9B, 0x74  ; wait
    esc 0xd9
    inc cx
    pop bx
    popf
    add ax, 0x758f
    cld
    dec bp
    movsb
    db 0x1B, 0x82, 0xE8  ; sbb ax, [bp+si+0x00e8]