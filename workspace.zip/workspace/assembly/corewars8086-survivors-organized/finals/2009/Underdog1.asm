    add ax, 0x0030
    mov [si], ax
    sub ax, 0x0007
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov cx, 0x000f
    rep movsw
    push cs
    push es
    pop ds
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x041e
    db 0x8B, 0xEF ;$1 mov bp, di
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    mov ax, 0xcccc
    mov dx, 0x0054
    mov bx, 0x03fc
    jmp bp
    movsw
    movsw
    movsw
    movsw
    call prcd1
    call far [bx]
prcd1:
    movsw
    movsw
    pop [bx]
    movsw
    movsw
    sub bp, dx
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    db 0x8B, 0xFD ;$1 mov di, bp
    db 0x33, 0xF6 ;$1 xor si, si
    movsw
    jmp bp