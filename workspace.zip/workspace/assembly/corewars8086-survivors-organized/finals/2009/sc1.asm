    mov bx, ax
    add bx, word 0x0010
    mov al, 0xcc
label1:
    mov [bx], al
    add bx, word 0x0009
    jmp label1