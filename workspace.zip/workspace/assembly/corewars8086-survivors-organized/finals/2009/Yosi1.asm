    db 0xE9, 0x07, 0x00 ;$1 jmp 10
    int3
    int3
    stosb
    stosw
    movsb
    movsw
    db 0xF3, 0x1E
    pop es
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x04c8
    add di, word 0x0024
    mov ax, 0xcccc
    std
label1:
    stosw
    jmp label1
    rep movsw
    movsb
    stosw
    stosb
    int3
    int3