    push es
    push ds
    pop es
    pop ds
    db 0x8B, 0xF8 ;$1 mov di, ax
    add di, 0x0437
    push ax
    mov ax, 0xcccc
    db 0x8B, 0xD0 ;$1 mov dx, ax
    std
    int 0x86
    int 0x86
    pop ax
    push es
    push ds
    pop es
    pop ds
    push ds
    pop ss
    mov sp, ax
    sub sp, 0x0004
    add ax, 0x002e
    mov di, 0x03fe
    stosw
    push es
    push ds
    pop es
    pop ds
    call ax
    mov si, 0x03fe
    lodsw
    sub sp, 0x0029
    call ax