    call prcd2
    call prcd1
prcd1:
    pop ax
    cld
    mov bx, 0x1000
    mov cx, es
    cmp cx, bx
    jnz label2
    mov cx, ss
    cmp cx, bx
    jnz label1
label1:
    push ss
    pop es
label2:
    xor di, di
    int 0x86
    push cs
    push es
    pop ds
    pop es
    mov di, 0x40e0
    int 0x86
    mov dx, 0x078e
    db 0x83, 0xC0, 0x2B ;$1 add ax, 0x002b
    push cs
    pop ss
    mov sp, 0xb00a
    sub sp, dx
    call ax
    push es
    mov bx, ds
    db 0x8E, 0xE3 ;$1 mov es, bx
    db 0x83, 0xC0, 0x03 ;$1 add ax, 0x0003
    stosw
    mov ax, 0x1000
    stosw
    mov bx, 0x2eff
    mov ax, 0x1fff
    mov dx, 0xa5a5
    int 0x87
    xor di, di
    pop es
    pop ax
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0190
    mov di, sp
    mov cl, 0x36
    mov bp, 0x10ce
    mov dx, 0x0288
    mov bx, 0x00a5
    mov word [bx+0x20], 0xa862
    mov word [bx], 0x0284
    mov word [bx+0x02], 0x1a60
    mov word [bx+0x0287], 0x02ae
    mov word [bx+0x36], 0x2000
    mov word [bx+0x0284], 0x0200
loop1:
    pop ax
    xor [si], ax
    add si, 0x0002
    loop loop1
    xor si, si
    mov cl, 0x08
loop2:
    mov [bp+0x36], dx
    add bp, 0x2000
    loop loop2
    mov ax, 0x10a5
    mov sp, 0xab34
    mov cl, 0x08
    movsw
    sub sp, dx
    call ax
    push es
    mov bx, ds
    db 0x8E, 0xE3 ;$1 mov es, bx
    db 0x83, 0xC0, 0x03 ;$1 add ax, 0x0003
    stosw
    mov ax, 0x1000
    stosw
    mov bx, 0x2eff
    mov ax, 0x1fff
    mov dx, 0xa5a5
    int 0x87
    xor di, di
    pop es
    pop ax
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0190
    mov di, sp
    mov cl, 0x36
    mov bp, 0x10ce
    mov dx, 0x0288
    mov bx, 0x00a5
    mov word [bx+0x20], 0xa862
    mov word [bx], 0x0284
    mov word [bx+0x02], 0x1a60
    mov word [bx+0x0287], 0x02ae
    mov word [bx+0x36], 0x2000
    mov word [bx+0x0284], 0x0200
loop3:
    pop ax
    xor [si], ax
    add si, 0x0002
    loop loop3
    xor si, si
    mov cl, 0x08
loop4:
    mov [bp+0x36], dx
    add bp, 0x2000
    loop loop4
    mov ax, 0x10a5
    mov sp, 0xab34
    mov cl, 0x08
    movsw
    sub sp, dx
    call ax
prcd2:
    push es
    mov bx, ds
    db 0x8E, 0xE3 ;$1 mov es, bx
    db 0x83, 0xC0, 0x03 ;$1 add ax, 0x0003
    stosw
    mov ax, 0x1000
    stosw
    mov bx, 0x2eff
    mov ax, 0x1fff
    mov dx, 0xa5a5
    int 0x87
    xor di, di
    pop es
    pop ax
    push es
    push ds
    pop es
    pop ds
    push cs
    pop ss
    mov sp, ax
    add sp, 0x0190
    mov di, sp
    mov cl, 0x36
    mov bp, 0x10ce
    mov dx, 0x0288
    mov bx, 0x00a5
    mov word [bx+0x20], 0xa862
    mov word [bx], 0x0284
loop5:
    mov word [bx+0x02], 0x1a60
label3:
    mov word [bx+0x0287], 0x02ae
    mov word [bx+0x36], 0x2000
    mov word [bx+0x0284], 0x0200
loop6:
    pop ax
    xor [si], ax
    add si, 0x0002
    loop loop6
    xor si, si
    mov cl, 0x08
loop7:
    mov [bp+0x36], dx
    add bp, 0x2000
    loop loop7
    mov ax, 0x10a5
    mov sp, 0xab34
    mov cl, 0x08
    movsw
    mov ah, 0x23
    cmp ah, [bx+di+0x265e]
    mov si, 0x61b8
    inc ax
    mov ax, 0xde9c
    jz label3+1
    db 0x68
    pop ds
    test ax, 0xe922
    inc ax
    dec bx
    adc al, 0xc0
    db 0xD6
    inc sp
    daa
    xlatb
    out 0x61, ax
    inc dx
    dec word [bp+si+0x408f]
    db 0x0B, 0xF9 ;$1 or di, cx
    stosb
    not byte [bp+si+0x7b]
    loopnz loop5+1
    adc al, 0xbc
    sbb ax, 0x37a9
    lock
    lodsw
    xor [di], dl
    out 0x98, ax
    mov ah, 0xc0
loop8:
    xor [bx], ah
    sar al, cl
    xchg dl, [bx+si]
    xchg bp, ax
    xchg di, ax
    mov di, 0x1503
    db 0xF2, 0x9B
    not byte [bp+0x629c]
    iret
    add [bp+0x32], ah
    xor al, 0x36
    iret
    loop loop8
    sub byte [bx+di], 0x79
    mov bl, 0x30
    hlt
    db 0x6A
    db 0x9B, 0xBE  ; wait
    cbw
    sub byte [bx+di+0x45], 0x2f
    retf 0xcf72
    db 0x8E, 0xAA, 0xC4, 0xF4 ;$1 mov cs, [bp+si-0x0b3c]
    std
    add [bp-0x1bb1], di