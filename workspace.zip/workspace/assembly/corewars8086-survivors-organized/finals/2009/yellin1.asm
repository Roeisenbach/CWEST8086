    std
    mov ax, 0xcd04
    mov dx, 0xcd04
    push ds
    push es
    pop ds
    mov bx, [0x0000]
    pop ds
    jmp bx
    cmpsb
    db 0xE9, 0x18, 0x00 ;$1 jmp 45
    cwd
    daa
    hlt
    dec ax
    das
    jb loop1
    push es
    push ds
    pop es
    pop ds
    loopz loop1
    rcr al, 1
    sbb ax, 0x0088
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label1:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label1
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label1
loop1:
    jmp -263
    in al, dx
    iret
    ja loop1