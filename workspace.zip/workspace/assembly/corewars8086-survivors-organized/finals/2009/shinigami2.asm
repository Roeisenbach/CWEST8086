    db 0x8B, 0xF8 ;$1 mov di, ax
    sub di, 0x0400
    mov ax, 0xcccc
    mov dx, 0xcccc
    push cs
    pop ss
    push ds
    pop es
    std
    int 0x86
    int 0x86
    db 0x8B, 0xE7 ;$1 mov sp, di
    mov ax, 0xd4ff
    mov bx, 0x5350
    push ax
    push bx
    call sp