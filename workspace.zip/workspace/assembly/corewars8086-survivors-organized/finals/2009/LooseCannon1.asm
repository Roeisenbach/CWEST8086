    push ds
    pop es
    db 0x8B, 0xF0 ;$1 mov si, ax
    mov dx, 0x5453
    db 0x23, 0xD1 ;$1 and dx, cx
    push dx
    pop cx
    add cx, 0x0057
    db 0x3B, 0xCA ;$1 cmp cx, dx
    xchg sp, bp
    db 0x8B, 0xE5 ;$1 mov sp, bp
    db 0x8B, 0xEC ;$1 mov bp, sp
    db 0x03, 0xCD ;$1 add cx, bp
    sub cx, 0x8564
    inc dx
    xor dx, 0x0100
    db 0x03, 0xCA ;$1 add cx, dx
    db 0x2B, 0xCD ;$1 sub cx, bp
    db 0x8B, 0xD0 ;$1 mov dx, ax
    db 0x8B, 0xFE ;$1 mov di, si
    add di, 0x2000
    cmp byte [di], 0xcc
    sub bx, 0x00ff
    mov ax, 0xcccc
    add si, 0x0048
    db 0x8B, 0xFE ;$1 mov di, si
    add di, 0x0800
    db 0x8B, 0xD0 ;$1 mov dx, ax
    int 0x86
    int 0x86
    db 0x8B, 0xD7 ;$1 mov dx, di
    db 0x8B, 0xDF ;$1 mov bx, di
    mov cx, 0x000f
loop1:
    movsw
    loop loop1
    inc di
    mov cx, 0x0080
loop2:
    mov [si], ax
    add si, 0x7861
    loop loop2
    db 0x8B, 0xF2 ;$1 mov si, dx
    add di, 0x8791
    db 0x8B, 0xD7 ;$1 mov dx, di
    jmp bx
    ret