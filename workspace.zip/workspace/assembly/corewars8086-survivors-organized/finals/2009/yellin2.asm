    mov cx, ax
    add cx, word 0x0057
    push ds
    push es
    pop ds
    mov [0x0000], cx
    pop es
    add ax, 0x0467
    db 0x8B, 0xF8 ;$1 mov di, ax
    mov ax, 0xcd04
    mov dx, 0xcd04
    int 0x86
    int 0x86
    mov cx, 0xffff
    rep stosw
    cmpsb
    db 0xE9, 0x18, 0x00 ;$1 jmp 62
    cwd
    daa
    hlt
    dec ax
    das
    jb loop1
    push es
    push ds
    pop es
    pop ds
    loopz loop1
    rcr al, 1
    sbb ax, 0x0088
    db 0x8B, 0xD8 ;$1 mov bx, ax
    add bx, 0x0400
label1:
    add bx, 0x0011
    cmp word [bx], 0x1000
    jnz label1
    mov bx, [bx-0x02]
    mov byte [bx-0x02], 0xcc
    jmp label1
loop1:
    jmp -279
    in al, dx
    iret
    ja loop1
    mov di, bx
    sub di, 0x0057
    push ds
    pop es
    int 0x86
    int 0x86
    mov cx, 0xffff
    rep stosw