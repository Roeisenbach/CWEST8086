    mov dx, ss
    mov es, dx
    db 0x8B, 0xF0 ;$1 mov si, ax
    add si, 0x005a
    mov cx, 0x0009
    rep movsw
    mov ds, dx
    mov cx, cs
    mov ss, cx
    sub ax, 0x1700
    and al, 0x07
    sub al, 0x08
    mov ch, 0x0f
    db 0x8A, 0xC8 ;$1 mov cl, al
    shl al, 1
    shl al, 1
    shl al, 1
    shl al, 1
    db 0x8B, 0xE0 ;$1 mov sp, ax
    mov al, 0xa3
    mov bx, 0x0100
    mov [bx], ax
    mov [bx+0x02], cx
    db 0x8B, 0xF8 ;$1 mov di, ax
    sub sp, 0x005d
    mov es, cx
    db 0x33, 0xF6 ;$1 xor si, si
    mov ax, 0xcccc
    mov dx, 0xcccc
    std
    int 0x86
    int 0x86
    cld
    add di, 0x0200
    mov ax, 0x1fff
    stosw
    dec di
    mov bp, 0x0800
    db 0x03, 0xE5 ;$1 add sp, bp
    db 0x33, 0xC9 ;$1 xor cx, cx
    call far [bx]
    movsw
    movsw
    mov cl, 0x05
    rep movsw
    sub [bx], bp
    mov di, [bx]
    movsw
    dec di
    db 0x33, 0xF6 ;$1 xor si, si
    call far [bx]
    call far [bx]