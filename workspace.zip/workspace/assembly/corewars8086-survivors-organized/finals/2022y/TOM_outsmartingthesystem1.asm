    jmp label1
    push cs
    pop es
    mov cx, 0x0005
    add ax, 0x0154
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x42 ;$1 add ax, 0x0042
    mov [0x0000], ax
    jmp label4
    jmp label2
    push cs
    pop es
    mov bx, [0x0000]
    add bx, 0x0236
    mov di, bx
    int 0x86
    mov bx, [0x0000]
    add bx, 0x07c8
    add bx, 0x0150
    mov byte [bx], 0x00
    jmp label3
    mov bx, [0x2604]
    xchg bx, ax
    mov bx, 0x2605
    mov [bx], al
    mov ax, [0x2605]
    xchg bx, ax
    mov word [bx], 0x25ff
    mov bx, [0x0000]
    add bx, 0x0636
    mov di, bx
    int 0x86
    mov di, 0x0000
    jmp label6
    push cs
    pop es
    mov bx, [0x0000]
    add bx, 0x0436
    mov di, bx
    int 0x86
    mov bx, [0x0000]
    add bx, 0x0786
    add bx, 0x0300
    mov byte [bx], 0x11
    jmp label5
    mov cx, 0xffff
    mov bx, [0x0000]
    add bx, 0x5036
    mov di, bx
    rep stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    mov cx, 0x0005
    jmp label2
    add ax, 0x0154
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x42 ;$1 add ax, 0x0042
    mov [0x0000], ax
    jmp label4
    push cs
    pop es
    mov bx, [0x0000]
    add bx, 0x0236
    mov di, bx
    int 0x86
    mov bx, [0x0000]
    add bx, 0x07c8
    add bx, 0x0150
    mov byte [bx], 0x00
    jmp label3
    mov bx, [0x2604]
    xchg bx, ax
    mov bx, 0x2605
    mov [bx], al
    mov ax, [0x2605]
    xchg bx, ax
    mov word [bx], 0x25ff
    mov bx, [0x0000]
    add bx, 0x0636
    mov di, bx
    int 0x86
    mov di, 0x0000
    jmp label6
    push cs
    pop es
    mov bx, [0x0000]
    add bx, 0x0436
    mov di, bx
    int 0x86
    mov bx, [0x0000]
    add bx, 0x0786
    add bx, 0x0300
    mov byte [bx], 0x11
    jmp label5
    mov cx, 0xffff
    mov bx, [0x0000]
    add bx, 0x5036
    mov di, bx
    rep stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    push cs
    pop es
    mov cx, 0x0004
label2:
    loop $
    add ax, 0x0154
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x42 ;$1 add ax, 0x0042
    mov [0x0000], ax
    jmp label4
    push cs
    pop es
    mov bx, [0x0000]
    add bx, 0x0236
    mov di, bx
    int 0x86
    mov bx, [0x0000]
    add bx, 0x07c8
label3:
    add bx, 0x0150
    mov byte [bx], 0x00
    jmp label3
label4:
    mov bx, [0x2604]
    xchg bx, ax
    mov bx, 0x2605
    mov [bx], al
    mov ax, [0x2605]
    xchg bx, ax
    mov word [bx], 0x25ff
    mov bx, [0x0000]
    add bx, 0x0636
    mov di, bx
    int 0x86
    mov di, 0x0000
    jmp label6
    push cs
    pop es
    mov bx, [0x0000]
    add bx, 0x0436
    mov di, bx
    int 0x86
    mov bx, [0x0000]
    add bx, 0x0786
label5:
    add bx, 0x0300
    mov byte [bx], 0x11
    jmp label5
label6:
    mov cx, 0xffff
    mov bx, [0x0000]
    add bx, 0x5036
    mov di, bx
    rep stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    mov cx, 0x0005
    add ax, 0x0154
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x42 ;$1 add ax, 0x0042
    mov [0x0000], ax
    jmp label4
    push cs
    pop es
    mov bx, [0x0000]
    add bx, 0x0236
    mov di, bx
    int 0x86
    mov bx, [0x0000]
    add bx, 0x07c8
    jmp label2