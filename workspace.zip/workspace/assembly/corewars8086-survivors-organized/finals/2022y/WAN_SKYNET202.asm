    jmp label5
    mov word [0x1ffd], 0x1fff
    mov word [0x5782], 0x1ffd
    mov bp, ax
    mov cx, 0x0007
    loop $
    add ax, 0x0039
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
label1:
    push cs
    push ss
    pop ds
    pop ss
    mov ax, 0x1ffd
    mov bx, 0x0200
    mov sp, ax
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp label1
label2:
    mov ax, [0x5782]
    add ax, 0x01ae
    push cs
    pop es
    mov cx, 0xffff
    mov di, ax
    add di, 0x01ae
    rep stosw
    jmp label2
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov word [0x1ffd], 0x1fff
    mov word [0x5782], 0x1ffd
    mov bp, ax
    mov cx, 0x0007
    loop $
    add ax, 0x0039
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
label3:
    push cs
    push ss
    pop ds
    pop ss
    mov ax, 0x1ffd
    mov bx, 0x0200
    mov sp, ax
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp label3
label4:
    mov ax, [0x5782]
    add ax, 0x01ae
    push cs
    pop es
    mov cx, 0xffff
    mov di, ax
    add di, 0x01ae
    rep stosw
    jmp label4
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label5:
    mov word [0x1ffd], 0x1fff
    mov word [0x5782], 0x1ffd
    mov bp, ax
    mov cx, 0x0007
    loop $
    add ax, 0x0039
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
label6:
    push cs
    push ss
    pop ds
    pop ss
    mov ax, 0x1ffd
    mov bx, 0x0200
    mov sp, ax
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp label6
label7:
    mov ax, [0x5782]
    add ax, 0x01ae
    push cs
    pop es
    mov cx, 0xffff
    mov di, ax
    add di, 0x01ae
    rep stosw
    jmp label7
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov word [0x1ffd], 0x1fff
    mov word [0x5782], 0x1ffd
    mov bp, ax
    mov cx, 0x0007
    loop $
    add ax, 0x0039
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    push cs
    push ss
    pop ds
    pop ss
    mov ax, 0x1ffd
    mov bx, 0x0200
    mov sp, ax
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp label3
label8:
    mov ax, [0x5782]
    add ax, 0x01ae
    push cs
    pop es
    mov cx, 0xffff
    mov di, ax
    add di, 0x01ae
    rep stosw
    jmp label8
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov word [0x1ffd], 0x1fff
    mov word [0x5782], 0x1ffd
    mov bp, ax
    mov cx, 0x0007
    loop $
    add ax, 0x0039
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    push cs
    push ss
    pop ds
    pop ss
    mov ax, 0x1ffd
    mov bx, 0x0200
    mov sp, ax
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp label3
label9:
    mov ax, [0x5782]
    add ax, 0x01ae
    push cs
    pop es
    mov cx, 0xffff
    mov di, ax
    add di, 0x01ae
    rep stosw
    jmp label9
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al