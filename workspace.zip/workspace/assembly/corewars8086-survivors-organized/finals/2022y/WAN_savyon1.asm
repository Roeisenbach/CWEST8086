    mov ax, 0xfeeb
    mov dx, 0x9090
    push cs
    pop es
    int 0x87
label1:
    mov byte [bx], 0x01
    add bx, 0x0001
    cmp bx, ax
    jz label3
label2:
    jmp label1
label3:
    add bx, word 0x001c
    jmp label2