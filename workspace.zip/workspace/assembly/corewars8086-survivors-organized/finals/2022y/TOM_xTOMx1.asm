    db 0x83, 0xC0, 0x14 ;$1 add ax, 0x0014
    push es
    pop ds
    mov bx, 0x0050
    mov [bx+0x04], cs
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    call far [bx]