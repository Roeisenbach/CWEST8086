    push ds
    pop ss
    mov bx, ax
    mov sp, ax
    add ax, 0x001f
    add bx, word 0x0035
    mov [bx], ax
    mov [bx+0x02], cs
    mov [bx+0x04], ax
    mov [bx+0x06], cs
    add word [bx+0x04], 0x0005
    add sp, 0x0001
    sub sp, 0x0006
    call far [bx]
    sub sp, 0x0006
    call far [bx]
    sub sp, 0x0006
    call far [bx]
    sub sp, 0x0006
    call far [bx]
    brk
    mov bx, ax
    mov byte [bx+0x5d], 0xeb
    mov byte [bx+0x5e], 0xfe
    jmp end
    jmp end
    jmp end
    jmp end
    jmp end
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
end: