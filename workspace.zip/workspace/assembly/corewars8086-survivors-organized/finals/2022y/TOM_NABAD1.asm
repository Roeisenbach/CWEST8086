    jmp label1
    mov cx, 0x000a
    loop loop1
    add ax, 0x00dd
    mov bx, [0x2204]
    mov [0x0000], ax
    mov word [bx+0x03], 0x25ff
    push cs
    pop es
    mov di, 0x0000
    mov cx, 0x0002
    int 0x86
    loop loop2
    mov cx, 0xffff
    mov di, ax
    add di, 0x0124
    rep stosw
    jmp $
    push cs
    pop es
    mov di, 0x0200
    mov cx, 0x0002
    int 0x86
    loop loop3
    int3
    mov cx, 0x000a
    loop loop4
    add ax, 0x00dd
    mov bx, [0x2204]
    mov [0x0000], ax
    mov word [bx+0x03], 0x25ff
    push cs
    pop es
    mov di, 0x0000
    mov cx, 0x0002
    int 0x86
    loop loop5
    mov cx, 0xffff
    mov di, ax
    add di, 0x0124
    rep stosw
    jmp $
    push cs
    pop es
    mov di, 0x0200
    mov cx, 0x0002
    int 0x86
    loop loop6
    int3
label1:
    mov cx, 0x000a
loop1:
    loop $
    add ax, 0x00a3
    mov bx, [0x2204]
    mov [0x0000], ax
    mov word [bx+0x03], 0x25ff
    push cs
    pop es
    mov di, 0x0000
    mov cx, 0x0002
loop2:
    int 0x86
    loop loop2
    mov cx, 0xffff
    mov di, ax
    add di, 0x0124
    rep stosw
    jmp $
    push cs
    pop es
    mov di, 0x0200
    mov cx, 0x0002
loop3:
    int 0x86
    loop loop3
    int3
    mov cx, 0x000a
loop4:
    loop $
    add ax, 0x00dd
    mov bx, [0x2204]
    mov [0x0000], ax
    mov word [bx+0x03], 0x25ff
    push cs
    pop es
    mov di, 0x0000
    mov cx, 0x0002
loop5:
    int 0x86
    loop loop5
    mov cx, 0xffff
    mov di, ax
    add di, 0x0124
    rep stosw
    jmp $
    push cs
    pop es
    mov di, 0x0200
    mov cx, 0x0002
loop6:
    int 0x86
    loop loop6
    int3
    mov cx, 0x000a
    loop loop4
    add ax, 0x00dd
    mov bx, [0x2204]
    mov [0x0000], ax
    mov word [bx+0x03], 0x25ff
    push cs
    pop es
    mov di, 0x0000
    mov cx, 0x0002
    int 0x86
    loop loop5
    mov cx, 0xffff
    mov di, ax
    add di, 0x0124
    rep stosw
    jmp $
    push cs
    pop es
    mov di, 0x0200
    mov cx, 0x0002
    int 0x86
    loop loop6
    int3