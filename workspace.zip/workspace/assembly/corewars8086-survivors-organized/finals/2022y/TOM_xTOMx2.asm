    db 0x83, 0xC0, 0x22 ;$1 add ax, 0x0022
    mov dx, 0x0055
    push dx
    push dx
    push dx
    push dx
    push dx
    push dx
    push dx
    push es
    pop ds
    mov bx, 0x0050
    mov [bx+0x04], cs
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    add sp, word 0xffdc
    call far [bx]