    mov si, ax
    add cx, 0x0007
    loop loop1
    add ax, 0x008a
    mov [0x0000], ax
    mov word [bx], 0x25ff
    add ax, 0x006c
    jmp label1
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x008a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x008a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    add cx, 0x0007
loop1:
    loop $
    add ax, 0x008a
    mov [0x0000], ax
    mov word [bx], 0x25ff
    mov bx, 0x008a
    add bx, si
label2:
    dec si
    mov byte [si], 0xcc
    inc bx
    mov byte [bx], 0xcc
    jmp label2
label3:
    mov [di], dx
    add di, 0x0006
    jmp label3
    jmp label3
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x008a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x008a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al