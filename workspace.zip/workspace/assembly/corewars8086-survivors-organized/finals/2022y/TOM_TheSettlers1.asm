    jmp label1
    push es
    pop ds
    nop
    lodsw
    push cs
    pop ds
    jmp ax
    push es
    pop ds
    nop
    lodsw
    push cs
    pop ds
    jmp ax
label1:
    push es
    pop ds
    nop
    lodsw
    push cs
    pop ds
    jmp ax
    push es
    pop ds
    nop
    lodsw
    push cs
    pop ds
    jmp ax
    push es
    pop ds
    nop
    lodsw
    push cs
    pop ds
    jmp ax