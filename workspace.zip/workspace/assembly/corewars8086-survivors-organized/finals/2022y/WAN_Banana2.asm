    push cs
    pop ss
    mov bx, ax
    mov sp, ax
    db 0x83, 0xC0, 0x12 ;$1 add ax, 0x0012
    add bx, word 0x0014
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]