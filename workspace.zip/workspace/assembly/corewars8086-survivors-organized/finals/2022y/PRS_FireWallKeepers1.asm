    add cx, 0x0007
    loop loop1
    add ax, 0x009a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x6E ;$1 add ax, 0x006e
    jmp label1
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x009a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x009a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    add cx, 0x0007
loop1:
    loop $
    add ax, 0x009a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
label2:
    push cs
    pop es
    mov di, ax
    add di, 0x0006
    mov dx, 0xcccc
    mov ax, dx
    int 0x86
    int 0x86
label3:
    mov [di], dx
    add di, 0x0003
    jmp label3
    jmp label2
label4:
    mov [di], dx
    add di, 0x0006
    push es
    pop di
    lodsw
    push cs
    pop ds
    db 0x83, 0xF8, 0x01 ;$1 cmp ax, 0x0001
    jz label6
    db 0x83, 0xF8, 0x02 ;$1 cmp ax, 0x0002
    jz label7
    db 0x83, 0xF8, 0x03 ;$1 cmp ax, 0x0003
    jz label5
label5:
    jmp $
label6:
    jmp $
label7:
    jmp $
    jmp label4
    jmp label4
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x009a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    add cx, 0x0007
    loop loop1
    add ax, 0x009a
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx], 0x25ff
    int 0x86
    jmp $
    int 0x86
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al