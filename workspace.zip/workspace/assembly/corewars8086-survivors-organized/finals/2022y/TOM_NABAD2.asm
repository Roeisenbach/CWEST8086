    push cs
    pop es
    mov ax, 0xc381
    mov dx, 0x00c0
    mov bx, 0xcccc
    mov cx, 0xcccc
    int 0x87
    push cs
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x02c0
    add di, 0x00c0
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c0
    add bx, 0x0200
    add di, 0x00c0
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c0
    add bx, 0x0200
    add di, 0x00c0
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c0
    add bx, 0x0200
    add di, 0x00c0
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c0
    add bx, 0x0200
    add di, 0x00c0
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx