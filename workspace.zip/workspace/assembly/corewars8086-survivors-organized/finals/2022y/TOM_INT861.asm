    mov bx, ax
    add bx, 0x008c
    mov [bx], ax
    mov dx, ax
    push es
    pop ds
    lodsw
    push cs
    pop ds
    mov cx, 0x0001
    brk
    add dx, 0x0000
    mov bx, [0x2402]
    mov [0x0000], dx
    mov word [bx], 0x25ff
    add bx, 0x8000
    mov word [bx], 0x25ff
    brk
    loop $
    add dx, word 0x0049
    mov bx, [0x2004]
    mov [0x0000], dx
    mov word [bx], 0x25ff
    db 0x83, 0xF8, 0x01 ;$1 cmp ax, 0x0001
    jz label2
    db 0x83, 0xF8, 0x02 ;$1 cmp ax, 0x0002
    jz label4
    mov si, [0x0000]
    push cs
    pop es
    mov cx, 0x008c
label1:
    cmp di, si
    jz end
    add si, 0x0001
    cmp di, si
    jz end
    sub si, 0x0001
    stosw
    add di, 0x0010
    jmp label1
label2:
    push cs
    pop es
    mov di, dx
    add di, word 0x0077
    mov ax, 0xabab
label3:
    stosw
    add di, 0x0004
    jmp label3
label4:
    push cs
    pop ss
    mov bx, dx
    mov sp, dx
    add dx, 0x008a
    add bx, 0x008c
    mov [bx], dx
    mov [bx+0x02], cs
    call far [bx]
end: