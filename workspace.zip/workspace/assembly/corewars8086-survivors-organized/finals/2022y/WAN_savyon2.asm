    push cs
    pop es
label1:
    mov di, ax
    add di, word 0x000f
    mov cx, 0x7ff8
    rep stosw
    jmp label1