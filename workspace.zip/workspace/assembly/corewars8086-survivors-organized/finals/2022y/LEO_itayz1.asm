    mov cx, 0x0005
    loop $
    add ax, 0x004c
    mov [0xcccc], ax
    mov [0x83cc], ax
    mov bx, [0x2004]
    mov word [bx], 0x26ff
    mov bx, [0x2204]
    mov word [bx+0x03], 0x26ff
    mov bx, [0x2402]
    mov word [bx], 0x26ff
    mov word [bx-0x8000], 0x26ff
    mov bl, [0x2604]
    mov bh, [0x2606]
    mov word [bx], 0x26ff
    push cs
    pop es
    add ax, 0x0085
    mov di, ax
    mov ax, 0xcccc
label1:
    mov word [di], 0xcccc
    add di, 0x000a
    jmp label1
    mov di, ax
    and di, 0xff00
    mov cx, 0x0100
loop1:
    push cx
    mov cx, 0x000c
loop2:
    mov word [di], 0xcccc
    add di, 0x000a
    loop loop2
    add di, 0x0100
    and di, 0xff00
    pop cx
    loop loop1
    int3
    mov ax, 0x0ac3
    mov dx, 0xf7eb
    mov bp, 0x1000
    mov es, bp
    mov di, 0x0000
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    int3