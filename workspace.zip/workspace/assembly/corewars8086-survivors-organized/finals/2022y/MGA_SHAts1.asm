    add ax, 0x018a
    jmp label1
    mov bx, ax
    xor bx, 0x9669
    mov [bx], ax
    xchg bx, dx
    push es
    push cs
    pop es
    nop
    mov bx, [0x2004]
    mov [bx+0x02], dx
    mov word [bx], 0x26ff
    mov bx, [0x2204]
    mov bx, [bx+0x05]
    mov di, [bx]
    int 0x86
    pop es
    mov dx, ax
    db 0x83, 0xC0, 0x0C ;$1 add ax, 0x000c
    nop
    nop
    jmp label2
    mov dx, ax
    mov bx, ax
    mov bx, [bx+0x02]
    mov ax, [bx]
    db 0x83, 0xC0, 0x0C ;$1 add ax, 0x000c
    mov bp, ax
    mov di, 0x0000
    lea si, [bp+0x3c]
    mov cx, 0x0016
    rep movsw
    mov bp, dx
    lea bp, [bp+0x067e]
    mov di, bp
    mov cx, 0x0004
    lea si, [0x0000]
    push es
    pop ds
    push cs
    pop es
    push cs
    pop ss
    lea di, [bp+0x04]
    mov [0x0200], di
    mov [0x0202], cs
    lea di, [bp+0x00]
    lea sp, [bp-0x033f]
    rep movsw
    mov cx, 0x0100
    jmp bp
loop1:
    mov bp, 0x1eff
    add [bp+si], al
    loop loop1+1
    movsw
    movsw
    movsw
    mov cx, 0x0010
    rep movsw
    lea bp, [bp+0x067e]
    lea di, [bp+0x04]
    mov [0x0200], di
    mov di, bp
    mov cx, 0x0004
    mov si, 0x0000
    lea sp, [bp-0x04e6]
    rep movsw
    mov cx, 0x0100
    jmp bp
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov bx, ax
    xor bx, 0x9669
    mov [bx], ax
    xchg bx, dx
    push es
    push cs
    pop es
    nop
    mov bx, [0x2004]
    mov [bx+0x02], dx
    mov word [bx], 0x26ff
    mov bx, [0x2204]
    mov bx, [bx+0x05]
    mov di, [bx]
    int 0x86
    pop es
    mov dx, ax
    db 0x83, 0xC0, 0x0C ;$1 add ax, 0x000c
    nop
    nop
    jmp label2
    mov dx, ax
    mov bx, ax
    mov bx, [bx+0x02]
    mov ax, [bx]
    db 0x83, 0xC0, 0x0C ;$1 add ax, 0x000c
    mov bp, ax
    mov di, 0x0000
    lea si, [bp+0x3c]
    mov cx, 0x0016
    rep movsw
    mov bp, dx
    lea bp, [bp+0x067e]
    mov di, bp
    mov cx, 0x0004
    lea si, [0x0000]
    push es
    pop ds
    push cs
    pop es
    push cs
    pop ss
    lea di, [bp+0x04]
    mov [0x0200], di
    mov [0x0202], cs
    lea di, [bp+0x00]
    lea sp, [bp-0x033f]
    rep movsw
    mov cx, 0x0100
    jmp bp
loop2:
    mov bp, 0x1eff
    add [bp+si], al
    loop loop2+1
    movsw
    movsw
    movsw
    mov cx, 0x0010
    rep movsw
    lea bp, [bp+0x067e]
    lea di, [bp+0x04]
    mov [0x0200], di
    mov di, bp
    mov cx, 0x0004
    mov si, 0x0000
    lea sp, [bp-0x04e6]
    rep movsw
    mov cx, 0x0100
    jmp bp
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    mov bx, ax
    xor bx, 0x9669
    mov [bx], ax
    xchg bx, dx
    push es
    push cs
    pop es
    nop
    mov bx, [0x2004]
    mov [bx+0x02], dx
    mov word [bx], 0x26ff
    mov bx, [0x2204]
    mov bx, [bx+0x05]
    mov di, [bx]
    int 0x86
    pop es
    mov dx, ax
    db 0x83, 0xC0, 0x0C ;$1 add ax, 0x000c
    nop
    nop
    jmp label2
    mov dx, ax
    mov bx, ax
    mov bx, [bx+0x02]
    mov ax, [bx]
    db 0x83, 0xC0, 0x0C ;$1 add ax, 0x000c
label2:
    mov bp, ax
    mov di, 0x0000
    lea si, [bp+0x3c]
    mov cx, 0x0016
    rep movsw
    mov bp, dx
    lea bp, [bp+0x067e]
    mov di, bp
    mov cx, 0x0004
    lea si, [0x0000]
    push es
    pop ds
    push cs
    pop es
    push cs
    pop ss
    lea di, [bp+0x04]
    mov [0x0200], di
    mov [0x0202], cs
    lea di, [bp+0x00]
    lea sp, [bp-0x033f]
    rep movsw
    mov cx, 0x0100
    jmp bp
loop3:
    mov bp, 0x1eff
    add [bp+si], al
    loop loop3+1
    movsw
    movsw
    movsw
    mov cx, 0x0010
    rep movsw
    lea bp, [bp+0x067e]
    lea di, [bp+0x04]
    mov [0x0200], di
    mov di, bp
    mov cx, 0x0004
    mov si, 0x0000
    lea sp, [bp-0x04e6]
    rep movsw
    mov cx, 0x0100
    jmp bp
    int3
    int3