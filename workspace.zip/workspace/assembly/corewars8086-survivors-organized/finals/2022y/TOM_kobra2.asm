    jmp label1
    jmp $
    jmp label2
    jmp word [di+0x04]
    push ds
    pop es
    db 0x83, 0xC0, 0x4D ;$1 add ax, 0x004d
    mov di, ax
    add di, 0x4000
    mov [di], ax
    mov bl, [0x2604]
    mov bh, [0x2606]
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x0300
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    mov bx, [0x2402]
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x2000
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    jmp label3
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    push cs
    pop es
    int 0x87
    mov ax, 0xcccc
    mov cx, 0x1000
    add di, 0x3000
    int 0x86
    add di, 0xd000
    rep stosw
    jmp word [di]
    mov di, [0x0000]
    int 0x86
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    mov bx, 0x2000
    stosw
    pop es
    mov di, 0x0000
    mov ax, [di]
    pop dx
    push cs
    pop ss
    mov sp, ax
    add sp, 0xc000
    mov ax, dx
    mov bx, ax
    add ax, 0x0166
    add bx, 0x0168
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
label1:
    push ax
    push es
    add ax, 0x00b4
    mov [di+0x02], ax
    jmp label2
    jmp word [di+0x04]
label2:
    push ds
    pop es
    db 0x83, 0xC0, 0x4D ;$1 add ax, 0x004d
    mov di, ax
    mov bx, [0x2402]
    mov word [0x2402], 0x4000
    mov word [0x2604], 0x5000
    add di, 0x4000
    mov [di], ax
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x2000
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    mov [bx-0x7ffa], di
    mov word [bx+0x0804], 0x26ff
    add dx, 0x2000
    mov [bx-0x7ffe], dx
    mov word [bx-0x8000], 0xbf90
    jmp label3
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    push cs
    pop es
    int 0x87
    mov ax, 0xcccc
    mov cx, 0x1000
    push di
    mov di, [0x2002]
    mov di, [di]
    int 0x86
    add di, 0xd000
    rep stosw
    jmp word [di]
label3:
    mov di, [0x5002]
    mov di, [di]
    int 0x86
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    mov bx, 0x2000
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    pop es
    mov di, 0x0000
    mov ax, [di]
    pop dx
    push cs
    pop ss
    mov sp, ax
    add sp, 0xc000
    mov ax, dx
    mov bx, ax
    add ax, 0x0166
    add bx, 0x0168
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    push ds
    pop es
    db 0x83, 0xC0, 0x4D ;$1 add ax, 0x004d
    mov di, ax
    add di, 0x4000
    mov [di], ax
    mov bl, [0x2604]
    mov bh, [0x2606]
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x0300
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    mov bx, [0x2402]
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x2000
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    jmp label3
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    push cs
    pop es
    int 0x87
    mov ax, 0xcccc
    mov cx, 0x1000
    push di
    mov di, [0x2002]
    mov di, [di]
    int 0x86
    pop di
    rep stosw
    jmp word [di]
    mov di, [0x0000]
    int 0x86
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    mov bx, 0x2000
    stosw
    stosw
    stosw
    stosw
    stosw
    stosw
    pop es
    mov di, 0x0000
    mov ax, [di]
    pop dx
    push cs
    pop ss
    mov sp, ax
    add sp, 0xc000
    mov ax, dx
    mov bx, ax