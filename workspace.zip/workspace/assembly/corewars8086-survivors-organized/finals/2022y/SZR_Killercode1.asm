    jmp label1
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c2
    add bx, 0x0200
    add di, 0x00c2
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c2
    add bx, 0x0200
    add di, 0x00c2
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c2
    add bx, 0x0200
    add di, 0x00c2
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c2
    add bx, 0x0200
    add di, 0x00c2
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    add di, ax
    mov bx, ax
    add bx, 0x00c2
    add bx, 0x0200
    add di, 0x00c2
    mov ax, 0xab50
    int 0x86
    int 0x86
    stosw
    jmp bx