    jmp label1
    jmp $
    push es
    push ax
    add ax, 0x00ba
    mov [di+0x04], ax
    jmp word [di+0x02]
    push ds
    pop es
    db 0x83, 0xC0, 0x33 ;$1 add ax, 0x0033
    mov di, ax
    add di, 0x4000
    mov [di], ax
    mov bx, [0x2204]
    add bx, 0x0003
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x0400
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    mov bx, [0x2004]
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x2000
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    jmp label2
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    push cs
    pop es
    int 0x87
    mov ax, 0xcccc
    mov cx, 0x1000
    add di, 0x3000
    int 0x86
    add di, 0xd000
    rep stosw
    jmp word [di]
    add ax, 0x00ed
    mov di, ax
    add di, 0xfd00
    int 0x86
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop ax
    mov bx, ax
    pop es
    mov di, 0x0000
    mov [di], ax
    push cs
    pop ss
    mov sp, ax
    add sp, 0xfc00
    add ax, 0x0147
    add bx, 0x0149
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
label1:
    mov dx, ax
    push es
    push ax
    add ax, 0x00ba
    mov [di+0x04], ax
    jmp word [di+0x02]
    mov word [0x2004], 0x2000
    mov bx, [0x2204]
    mov word [0x2204], 0x3000
    db 0x83, 0xC0, 0x33 ;$1 add ax, 0x0033
    mov si, ax
    add si, 0x4000
    mov [si], ax
    mov [bx+0x0b], si
    mov word [bx+0x09], 0x26ff
    add dx, 0x0400
    mov [bx+0x07], dx
    mov word [bx+0x05], 0xbf90
    push ds
    pop es
    jmp label2
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    push cs
    pop es
    int 0x87
    mov ax, 0xcccc
    mov cx, 0x1000
    push di
    mov di, [0x3006]
    mov di, [di]
    int 0x86
    pop di
    rep stosw
    jmp word [di]
label2:
    add ax, 0x00ed
    mov di, [0x4006]
    mov di, [di]
    int 0x86
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop ax
    mov bx, ax
    pop es
    mov di, 0x0000
    mov [di], ax
    push cs
    pop ss
    mov sp, ax
    add sp, 0xfc00
    add ax, 0x0147
    add bx, 0x0149
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    mov dx, ax
    push es
    push ax
    add ax, 0x00ba
    mov [di+0x04], ax
    jmp word [di+0x02]
    push ds
    pop es
    db 0x83, 0xC0, 0x33 ;$1 add ax, 0x0033
    mov di, ax
    add di, 0x4000
    mov [di], ax
    mov bx, [0x2204]
    add bx, 0x0005
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x0400
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    mov bx, [0x2004]
    mov [bx+0x06], di
    mov word [bx+0x04], 0x26ff
    add dx, 0x2000
    mov [bx+0x02], dx
    mov word [bx], 0xbf90
    jmp label2
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    push cs
    pop es
    int 0x87
    mov ax, 0xcccc
    mov cx, 0x1000
    add di, 0x3000
    int 0x86
    add di, 0xd000
    rep stosw
    jmp word [di]
    add ax, 0x00ed
    mov di, ax
    add di, 0xfd00
    int 0x86
    mov ax, 0x07c7
    mov dx, 0x25ff
    mov cx, 0xcccc
    mov bx, 0xcccc
    int 0x87
    pop ax
    mov bx, ax
    pop es
    mov di, 0x0000
    mov [di], ax
    push cs
    pop ss
    mov sp, ax
    add sp, 0xfc00
    add ax, 0x0147
    add bx, 0x0149
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]