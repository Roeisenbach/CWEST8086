    jmp label1
    db 0x83, 0xC0, 0x12 ;$1 add ax, 0x0012
    push es
    pop ds
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    stosw
    call far [bx]
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    db 0x83, 0xC0, 0x12 ;$1 add ax, 0x0012
    push es
    pop ds
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    stosw
    call far [bx]
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    add ax, 0x003a
    db 0x83, 0xC0, 0x19 ;$1 add ax, 0x0019
    push es
    pop ds
    nrg
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    stosw
    call far [bx]
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    db 0x83, 0xC0, 0x12 ;$1 add ax, 0x0012
    push es
    pop ds
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    stosw
    call far [bx]
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    db 0x83, 0xC0, 0x12 ;$1 add ax, 0x0012
    push es
    pop ds
    mov bx, 0x0050
    mov [bx+0x02], cs
    mov [bx], ax
    push cs
    pop ss
    mov sp, ax
    stosw
    call far [bx]