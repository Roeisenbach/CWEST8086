    add ax, 0x0040
    mov [0x0566], ax
    push cs
    pop es
    mov cx, 0x0004
    loop $
    mov ax, [0x2100]
    mov cx, 0x1000
    mul cx
    mov bx, [0x2102]
    xchg bx, ax
    mov cx, 0x0005
    div cx
    add ax, bx
    db 0x83, 0xC0, 0x02 ;$1 add ax, 0x0002
    xchg bx, ax
    mov word [bx], 0x0566
    add bx, 0xfffe
    mov word [bx], 0x16ff
    mov di, [0x0566]
    add di, word 0x0040
    int 0x86
    add di, 0x0260
    int 0x86
    mov bx, [0x0566]
    add bx, word 0x0058
label1:
    add bx, 0x0050
    mov byte [bx], 0x66
    jmp label1
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al