    jmp label1
    push ax
    add ax, 0x00f0
    stosw
    sub di, 0x0002
    pop ax
    sub sp, 0x0002
    mov bx, 0x5d8f
    mov [bx], ax
    add word [bx], 0x010f
    mov bh, [0x2606]
    mov bl, [0x2604]
    mov word [bx+0x02], 0x5d8f
    mov word [bx], 0x26ff
    mov bx, 0x0000
    mov cl, 0x00
    push es
    pop ds
    mov al, 0xa1
    stosw
    mov [di], cs
    mov ss, [di]
    mov ax, 0x1fff
    sub word [bx], 0x01ba
    les di, [bx]
    sub di, 0x0080
    int 0x86
    mov cl, 0xdf
    mov sp, [bx]
    stosw
    dec di
    sub bl, 0x0e
    mov di, [bx]
    stosw
    call far [bx]
    push cs
    pop es
    mov bx, [0x2004]
    mov word [bx+0x02], 0x5d8f
    mov word [bx], 0x26ff
    mov di, [0x2204]
    int 0x86
    mov di, [0x2402]
    int 0x86
    jmp $
    nop
    nop
    nop
    nop
    push cs
    pop es
    mov di, [0x5d8f]
    add di, 0x013c
    add di, 0x0200
    mov cx, 0x000a
    cmp ax, [0x2004]
    db 0x0F
    test [bx+di-0x7d00], ch
    mov word [bp+di], 0xe2ab
    cli
    int 0x03
    add di, 0x0005
    jmp label3
label1:
    push ax
    add ax, 0x00f0
    stosw
    sub di, 0x0002
    pop ax
    sub sp, 0x0002
    mov bx, 0x5d8f
    mov [bx], ax
    add word [bx], 0x010f
    mov bx, [0x2004]
    mov word [bx+0x02], 0x5d8f
    mov bh, [0x2606]
    mov bl, [0x2604]
    mov word [bx+0x02], 0x5d8f
    mov word [bx], 0x26ff
    mov bx, 0x0000
    mov cl, 0x00
    push es
    pop ds
    mov al, 0xa7
    stosw
    mov [di], cs
    mov ss, [di]
    mov ax, 0x1fff
    sub word [bx], 0x01ba
    les di, [bx]
    sub di, 0x0080
    int 0x86
    mov cl, 0x0a
    mov sp, [bx]
    stosw
    dec di
    call far [bx]
    push cs
    pop es
    mov bx, [0x2004]
    mov word [bx], 0x26ff
    mov di, [0x2204]
    int 0x86
    mov di, [0x2402]
    int 0x86
    mov ax, [0x5d8f]
    jmp label2
    nop
    nop
    nop
    nop
label2:
    push cs
    pop es
    mov di, [0x5d8f]
    add di, 0x013c
    add di, 0x0200
    mov cx, 0x7530
    cmp ax, [0x5d8f]
    jz label5
    cmp ax, [0x2004]
    jz label4
label3:
    mov ax, 0xcccc
loop1:
    add di, 0x0005
    stosw
    loop loop1
    int 0x03
label4:
    add di, 0x0003
    jmp label3
label5:
    add di, 0x0005
    jmp label3
    push ax
    add ax, 0x00f0
    stosw
    sub di, 0x0002
    pop ax
    sub sp, 0x0002
    mov bx, 0x5d8f
    mov [bx], ax
    add word [bx], 0x010f
    mov bh, [0x2606]
    mov bl, [0x2604]
    mov word [bx+0x02], 0x5d8f
    mov word [bx], 0x26ff
    mov bx, 0x0000
    mov cl, 0x00
    push es
    pop ds
    mov al, 0xa7
    stosw
    mov [di], cs
    mov ss, [di]
    mov ax, 0x1fff
    sub word [bx], 0x01ba
    les di, [bx]
    sub di, 0x0080
    int 0x86
    mov cl, 0x0a
    mov sp, [bx]
    stosw
    dec di
    call far [bx]
    push cs
    pop es
    mov bx, [0x2004]
    mov word [bx+0x02], 0x5d8f
    mov word [bx], 0x26ff
    mov di, [0x2204]
    int 0x86
    mov di, [0x2402]
    int 0x86
    jmp $
    nop
    nop
    nop
    nop
    push cs
    pop es
    mov di, [0x5d8f]
    add di, 0x013c
    add di, 0x0200
    mov cx, 0x000a
    cmp ax, [0x2004]
    db 0x0F
    test [bx+di-0x01], dh
loop2:
    add di, 0x0003
    stosw
    loop loop2
    int 0x03
    add di, 0x0005
    jmp label3