    jmp label2
    push ds
    pop es
    xchg di, ax
    add di, 0x000c
    mov si, di
    add si, 0x000a
    std
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    inc di
    inc di
    jmp di
    push cs
    pop es
    mov di, ax
    add di, word 0x002e
    mov ax, 0xcccc
    mov ax, 0xccbb
    mov dx, 0xb9cc
label1:
    stosw
    jmp label1
label2:
    push cs
    pop es
    mov di, ax
    add di, word 0x002e
    mov ax, 0xcccc
    mov ax, 0xccbb
    mov dx, 0xb9cc
    stosw
    mov bx, 0x9090
    int 0x87
    jmp label1
    push cs
    pop es
    mov di, ax
    add di, word 0x002e
    mov ax, 0xcccc
    mov ax, 0xccbb
    mov dx, 0xb9cc
    stosw
    mov bx, 0x9090
    int 0x87
    jmp label1
    push ds
    pop es
    xchg di, ax
    add di, 0x000c
    mov si, di
    add si, 0x000a
    std
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    inc di
    inc di
    jmp di
    push ds
    pop es
    xchg di, ax
    add di, 0x000c
    mov si, di
    add si, 0x000a
    std
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    inc di
    inc di
    jmp di
    push cs
    pop es
    mov di, ax
    add di, word 0x002e
    mov ax, 0xcccc
    mov ax, 0xccbb
    mov dx, 0xb9cc
    stosw
    jmp label1
    jmp label2
    push ds
    pop es
    xchg di, ax
    add di, 0x000c
    mov si, di
    add si, 0x000a
    std
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    inc di
    inc di
    jmp di
    push cs
    pop es
    mov di, ax
    add di, word 0x002e
    mov ax, 0xcccc
    mov ax, 0xccbb
    mov dx, 0xb9cc
    stosw
    jmp label1
    jmp label2
    push ds
    pop es
    xchg di, ax
    add di, 0x000c
    mov si, di
    add si, 0x000a
    std
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    inc di
    inc di
    jmp di
    push cs
    pop es
    mov di, ax
    add di, word 0x002e
    mov ax, 0xcccc
    mov ax, 0xccbb
    mov dx, 0xb9cc
    stosw
    jmp label1
    jmp label2
    push ds
    pop es
    xchg di, ax
    add di, 0x000c
    mov si, di
    add si, 0x000a
    std
    dec di
    dec di
    movsw
    movsw
    movsw
    movsw
    movsw
    movsw
    inc di
    inc di
    jmp di
    push cs
    pop es
    mov di, ax
    add di, word 0x002e
    mov ax, 0xcccc
    mov ax, 0xccbb
    mov dx, 0xb9cc
    stosw
    jmp label1