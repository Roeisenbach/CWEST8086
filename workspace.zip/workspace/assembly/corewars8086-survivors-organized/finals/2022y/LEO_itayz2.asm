    push ax
    mov cx, 0x0004
    loop $
    mov ax, [0x2100]
    mov bx, 0x1000
    mul bx
    mov cx, 0x0002
    loop $
    xchg bx, ax
    mov ax, [0x2102]
    mov cx, 0x0005
    div cx
    add bx, ax
    pop ax
    add ax, 0x0085
    mov si, 0xdddd
    mov [si], ax
    mov [bx+0x02], si
    mov word [bx], 0x26ff
    sub ax, 0x0085
    mov bx, ax
    add bx, word 0x0046
    mov cx, 0x001f
    mov si, bx
    rep movsw
    push es
    push ds
    pop es
    pop bp
    mov bl, 0xc3
    jmp label2
    mov word [bx-0x0600], 0xd45f
    mov word [bx-0x05c3], 0xd45f
    push cs
    pop es
    mov di, bx
label1:
    add di, 0x0040
    mov cx, 0x000c
loop1:
    mov word [di], 0xcccc
    add di, 0x000a
    loop loop1
    mov ax, [bx-0x05c3]
    cmp [bx-0x0600], ax
    jz label1
label2:
    mov cx, 0x001f
    mov si, 0x0000
    add bx, 0xfa00
    mov di, bx
    mov ds, bp
    rep movsw
    push es
    pop ds
    jmp bx
    jmp $
    push cs
    pop es
    mov di, ax
    mov cx, 0x0014
loop2:
    push cx
    mov cx, 0x0028
    rep stosw
    add di, 0x000d
    pop cx
    loop loop2
    int3