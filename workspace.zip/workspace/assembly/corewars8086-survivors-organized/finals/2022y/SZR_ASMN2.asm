    mov cx, 0x0001
    loop $
    db 0x83, 0xC0, 0x39 ;$1 add ax, 0x0039
    xchg di, ax
    xchg dx, ax
    mov bx, 0x2100
    mov dx, [bx]
    mov ax, 0x1000
    mul dx
    xchg sp, ax
    mov ax, [bx+0x02]
    mov cx, 0x0005
    div cx
    add ax, sp
    mov bx, ax
    mov [0x000b], di
    mov ax, 0x26ff
    mov cx, 0x000b
    mov [bx+0x02], cx
    mov [bx], ax
    brk
label1:
    mov [bx], bx
    add bx, 0x0009
    jmp label1
label2:
    mov [bx], bx
    add bx, 0x000a
    jmp label2