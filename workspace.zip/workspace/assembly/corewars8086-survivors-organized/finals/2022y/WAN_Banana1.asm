    jmp label6
    nop
    nop
    nop
    mov bx, ax
    mov ax, [0x0000]
    db 0x83, 0xC0, 0x38 ;$1 add ax, 0x0038
    push es
    pop ds
    push cs
    pop es
    mov di, ax
    add di, 0x1000
    int 0x86
    push cs
    pop ss
    mov sp, bx
    mov bx, 0x0050
    add bx, 0x0002
    mov [bx], cs
    sub bx, 0x0002
    mov [bx], ax
    add ax, 0x0100
    mov cx, ax
    add cx, 0x0001
    mov dx, cx
    add dx, 0x0001
    mov si, dx
    add si, 0x0001
label1:
    cmp sp, ax
    jz label2
    cmp sp, cx
    jz label2
    cmp sp, dx
    jz label2
    cmp sp, si
    jz label2
    call far [bx]
label2:
    sub sp, 0x0200
    jmp label1
label3:
    push cx
    pop ds
    push cx
    pop es
    push cs
    mov word [0x0000], 0xcccc
    pop ss
    mov sp, ax
    add ax, 0x007c
    mov bx, 0x0050
    mov di, 0x0050
    stosw
    mov cx, 0x1000
    xchg cx, ax
    stosw
    xchg cx, ax
    db 0x83, 0xC0, 0x0B ;$1 add ax, 0x000b
    mov si, ax
    add si, 0x0001
label4:
    cmp sp, si
    jz label5
    call far [bx]
label5:
    sub sp, 0x0037
    jmp label4
label6:
    stosw
    push es
    pop cx
    push cs
    pop es
    mov di, ax
    add di, 0x0500
    int 0x86
    nop
    nop
    nop
    nop
    nop
    db 0x83, 0xC0, 0x05 ;$1 add ax, 0x0005
    mov [0x0000], ax
    mov bl, [0x2604]
    mov bh, [0x2606]
    add bx, 0x0002
    mov word [bx], 0x26ff
    add bx, 0x0002
    mov word [bx], 0x0000
    sub bx, 0x0004
    mov word [bx], 0x9090
    db 0x83, 0xE8, 0x06 ;$1 sub ax, 0x0006
    jmp label3