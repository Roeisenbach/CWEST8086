    jmp label3
    mov cx, 0x0007
    add ax, 0x008d
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx+0x02], 0x25ff
    jmp label5
    int 0x86
label1:
    mov byte [bx], 0x01
    add bx, 0x0002
    jmp label1
    jmp label4
    int 0x86
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    mov di, ax
    add di, 0x001d
    mov ax, 0xab50
    stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov cx, 0x0007
    loop loop1
    add ax, 0x008d
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx+0x02], 0x25ff
    jmp label5
    int 0x86
label2:
    mov byte [bx], 0x01
    add bx, 0x0002
    jmp label2
    jmp label4
    int 0x86
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    mov di, ax
    add di, 0x001d
    mov ax, 0xab50
    stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label3:
    mov cx, 0x0007
loop1:
    loop $
    add ax, 0x008d
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx+0x02], 0x25ff
    jmp label5
    int 0x86
label4:
    mov byte [bx], 0x01
    add bx, 0x0002
    jmp label4
    jmp label4
label5:
    int 0x86
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    mov di, ax
    add di, 0x001d
    mov ax, 0xab50
    stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov cx, 0x0007
    loop loop1
    add ax, 0x008d
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx+0x02], 0x25ff
    jmp label5
    int 0x86
label6:
    mov byte [bx], 0x01
    add bx, 0x0002
    jmp label6
    jmp label4
    int 0x86
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    mov di, ax
    add di, 0x001d
    mov ax, 0xab50
    stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    mov cx, 0x0007
    loop loop1
    add ax, 0x008d
    mov bx, [0x2004]
    mov [0x0000], ax
    mov word [bx+0x02], 0x25ff
    jmp label5
    int 0x86
label7:
    mov byte [bx], 0x01
    add bx, 0x0002
    jmp label7
    jmp label4
    int 0x86
    push cs
    push cs
    pop es
    pop ss
    mov sp, ax
    mov di, ax
    add di, 0x001d
    mov ax, 0xab50
    stosw
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al