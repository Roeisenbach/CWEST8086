    jmp label6
    push ds
    pop es
    add cx, 0x0004
    loop $
    add ax, 0x003a
    mov [0x0000], ax
    mov cx, 0x000a
    mov bx, [0x2004]
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x0E ;$1 add ax, 0x000e
    int 0x86
    lodsw
    db 0x83, 0xF8, 0x00 ;$1 cmp ax, 0x0000
    jz label1
    db 0x83, 0xF8, 0x01 ;$1 cmp ax, 0x0001
    jz label2
    db 0x83, 0xF8, 0x02 ;$1 cmp ax, 0x0002
label1:
    add di, 0x0021
    stosw
    cmp di, word 0x002e
    jz label1
    jmp label1
label2:
    push ds
    pop es
    add di, 0x0100
    int 0x86
label3:
    stosw
    add di, 0x001f
    jmp label3
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push ds
    pop es
    add cx, 0x0004
    loop $
    add ax, 0x003a
    mov [0x0000], ax
    mov cx, 0x000a
    mov bx, [0x2004]
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x0E ;$1 add ax, 0x000e
    int 0x86
label4:
    add di, 0x0021
    stosw
    cmp di, word 0x006d
    jz label4
    jmp label4
    push ds
    pop es
    add di, 0x0100
    int 0x86
label5:
    stosw
    add di, 0x001f
    jmp label5
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label6:
    push ds
    pop es
    add cx, 0x0004
    loop $
    add ax, 0x003a
    mov [0x0000], ax
    mov cx, 0x000a
    mov bx, [0x2004]
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x0E ;$1 add ax, 0x000e
    int 0x86
label7:
    add di, 0x0021
    cmp di, 0x00ac
    jz label7
    stosw
    jmp label7
    push ds
    pop es
    add di, 0x0100
    int 0x86
label8:
    stosw
    add di, 0x001f
    jmp label8
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push ds
    pop es
    add cx, 0x0004
    loop $
    add ax, 0x003a
    mov [0x0000], ax
    mov cx, 0x000a
    mov bx, [0x2004]
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x0E ;$1 add ax, 0x000e
    int 0x86
label9:
    add di, 0x0021
    stosw
    cmp di, 0x00eb
    jz label9
    jmp label9
    push ds
    pop es
    add di, 0x0100
    int 0x86
label10:
    stosw
    add di, 0x001f
    jmp label10
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push ds
    pop es
    add cx, 0x0004
    loop $
    add ax, 0x003a
    mov [0x0000], ax
    mov cx, 0x000a
    mov bx, [0x2004]
    mov word [bx], 0x25ff
    db 0x83, 0xC0, 0x0E ;$1 add ax, 0x000e
    int 0x86
label11:
    add di, 0x0021
    stosw
    cmp di, 0x012a
    jz label11
    jmp label11
    push ds
    pop es
    add di, 0x0100
    int 0x86
label12:
    stosw
    add di, 0x001f
    jmp label12