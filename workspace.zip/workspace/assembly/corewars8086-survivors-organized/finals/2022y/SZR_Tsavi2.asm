    push ax
    add ax, 0x0038
    mov si, ax
    mov di, 0x0000
    push cs
    pop es
    mov di, ax
    mov dx, 0xcccc
    mov ax, 0xab50
    std
    sub di, 0xab53
    mov [0xab51], di
    mov byte [0xab50], 0xe9
    mov cx, 0x002d
    mov si, 0xcccc
loop1:
    mov [bx], si
    add bx, 0x0002
    loop loop1
    mov cx, 0xe0ff
    mov bx, 0x9090
    int 0x87
    jmp label2
label1:
    call prcd1
    jmp label1
prcd1:
    pop di
    push cs
    pop es
    mov dx, 0xcccc
    mov ax, 0xab50
    mov cx, 0xe0ff
    mov bx, 0x9090
    std
    sub di, 0xab53
    mov [0xab51], di
    mov byte [0xab50], 0xe9
    int 0x87
    int3
label2:
    pop ax
    push ds
    push ss
    pop ds
    pop ss
    xor bx, bx
    mov sp, ax
    add ax, 0x0071
    mov [bx], ax
    mov [bx+0x02], cs
    add sp, 0xfffa
    sub sp, 0x000c
    call far [bx]