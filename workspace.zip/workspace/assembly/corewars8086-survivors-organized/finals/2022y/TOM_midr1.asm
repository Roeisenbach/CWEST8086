    jmp label1
    push cs
    pop es
    mov di, ax
    add di, word 0x0054
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x86
    stosw
    mov ax, 0xcccc
    jmp label2
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    mov di, ax
    add di, word 0x0054
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x86
    stosw
    mov ax, 0xcccc
    jmp label2
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    push cs
    pop es
    mov di, ax
    add di, word 0x0054
label2:
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x86
    stosw
    mov ax, 0xcccc
    jmp label2
    stosw
    mov ax, 0xcccc
    stosw
    mov ax, 0xcccc
    stosw
    mov ax, 0xcccc
    stosw
    mov ax, 0xcccc
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    mov di, ax
    add di, word 0x0054
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x86
    stosw
    mov ax, 0xcccc
    jmp label2
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop es
    mov di, ax
    add di, word 0x0054
    mov ax, 0xcccc
    mov dx, 0xcccc
    int 0x86
    stosw
    mov ax, 0xcccc
    jmp label2
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al