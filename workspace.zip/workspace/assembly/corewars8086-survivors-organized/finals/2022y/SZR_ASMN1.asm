    cmp [bp+di], dh
    inc bx
    xor [bx+di], dh
    xor al, 0x0a
    inc bp
    inc dx
    xor [bx+di+0x0a], ax
    xor [di+0x0a], al
    xor [bx], si
    or bh, [bx+si]
    cmp [bp+di+0x33], ax
    or bh, [bx+si]
    cmp [bp+di+0x34], ax
    or bh, [bx+si]
    cmp [bx+si], si
    aaa
    or bh, [bx+si]
    inc bx
    xor al, 0x46
    xor [bp+si], dh
    or al, [bp+0x46]
    xor [bp+0x0a], ax
    xor [di+0x0a], al
    xor [bx], si
    or bh, [bx+si]
    cmp [bp+di+0x33], ax
    or bh, [bx+si]
    cmp [bp+di+0x34], ax
    or bh, [bx+si]
    cmp [bx+si], si
    aaa
    or bh, [bx+si]
    inc bx
    xor al, 0x46
    xor [bp+si], dh
    or al, [bp+0x46]
    xor [bp+0x0a], ax
    xor [di+0x0a], al
    xor [bx], si
    or bh, [bx+si]
    cmp [bp+di+0x33], ax
    or bh, [bx+si]
    cmp [bp+di+0x34], ax
    or dh, [bx+si]
    xor ax, 0x3133
    xor [bx+si], dh
    or bh, [bx+si]
    xor [bp+di+0x33], ax
    xor si, [bp+di]
    xor [bx+si], dh
    or bh, [bx+si]
    cmp [bx+si], si
    aaa
    or bh, [bx+si]
    inc bx
    xor al, 0x46
    xor [bp+si], dh
    or al, [bp+0x46]
    xor [bp+0x0a], ax
    xor [di+0x0a], al
    xor [bx], si
    or bh, [bx+si]
    cmp [bp+di+0x33], ax
    or bh, [bx+si]
    cmp [bp+di+0x34], ax
    or bh, [bx+si]
    cmp [bx+si], si
    aaa
    or bh, [bx+si]
    inc bx
    xor al, 0x46
    xor [bp+si], dh
    or al, [bp+0x46]
    xor [bp+0x0a], ax
    xor [di+0x0a], al
    xor [bx], si
    or bh, [bx+si]
    cmp [bp+di+0x33], ax
    or bh, [bx+si]
    cmp [bp+di+0x34], ax
    or bh, [bx+si]
    cmp [bx+si], si
    aaa
    or bh, [bx+si]
    inc bx
    xor al, 0x46
    xor [bp+si], dh
    or al, [bp+0x46]
    db 0x31, 0x46  ; xor [bp+0x00], ax