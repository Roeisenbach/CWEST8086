    push es
    push cs
    pop es
    int 0x86
    pop es
    xor di, di
    mov si, ax
    add si, 0x0022
    mov cx, 0x000a
    rep movsw
    xor si, si
    mov di, ax
    add di, 0xfeaf
    push ds
    push es
    push ds
    pop es
    pop ds
    pop ss
    jmp label1
    sub di, 0x0fff
    xor si, si
    mov sp, di
    add sp, 0x0190
    push bx
    mov cx, 0x00d2
    jmp sp
label1:
    mov bx, 0xabf3
    mov ax, 0xa5f3
    mov cx, 0x00d2
    rep stosw