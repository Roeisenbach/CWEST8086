    add ax, 0x003b
    jmp label1
    db 0x83, 0xC0, 0x15 ;$1 add ax, 0x0015
    mov cx, 0x0008
    mov sp, ax
    div cx
    xchg dx, ax
    mov cx, 0x0100
    mul cx
    xchg bx, ax
    mov [bx+0x4100], sp
    jmp $
    int3
    int3
    int3
    int3
    db 0x83, 0xC0, 0x15 ;$1 add ax, 0x0015
    mov cx, 0x0008
    mov sp, ax
    div cx
    xchg dx, ax
    mov cx, 0x0100
    mul cx
    xchg bx, ax
    mov [bx+0x4100], sp
    jmp $
    int3
    int3
    int3
    int3
label1:
    db 0x83, 0xC0, 0x15 ;$1 add ax, 0x0015
    mov cx, 0x0008
    mov sp, ax
    div cx
    xchg dx, ax
    mov cx, 0x0100
    mul cx
    xchg bx, ax
    mov [bx+0x4100], sp
    jmp $
    int3
    int3
    int3
    int3
    db 0x83, 0xC0, 0x15 ;$1 add ax, 0x0015
    mov cx, 0x0008
    mov sp, ax
    div cx
    xchg dx, ax
    mov cx, 0x0100
    mul cx
    xchg bx, ax
    mov [bx+0x4100], sp
    jmp $
    int3
    int3
    int3
    int3
    db 0x83, 0xC0, 0x15 ;$1 add ax, 0x0015
    mov cx, 0x0008
    mov sp, ax
    div cx
    xchg dx, ax
    mov cx, 0x0100
    mul cx
    xchg bx, ax
    mov [bx+0x4100], sp
    jmp $