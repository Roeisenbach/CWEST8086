    jmp label1
    push cs
    pop ss
    mov bx, ax
    mov sp, ax
    add ax, 0x0014
    add bx, word 0x0052
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop ss
    mov bx, ax
    mov sp, ax
    add ax, 0x0032
    add bx, word 0x0052
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
label1:
    push cs
    pop ss
    mov bx, ax
    mov sp, ax
    add ax, 0x0050
    add bx, word 0x0052
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop ss
    mov bx, ax
    mov sp, ax
    add ax, 0x006e
    add bx, word 0x0052
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al
    push cs
    pop ss
    mov bx, ax
    mov sp, ax
    add ax, 0x008c
    add bx, word 0x0052
    mov [bx], ax
    mov [bx+0x02], cs
    call far [bx]
    jmp $
    int3
    int3
    int3
    int3
    add [bx+si], al
    add [bx+si], al